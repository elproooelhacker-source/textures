# v2.2.3.126 — server-authoritative inventory actions

## Step 3 completed in source
- Q and Ctrl+Q send a slot-drop intent to the integrated server; the server removes the stack and creates the EntityItem.
- HUD Q targets the selected hotbar slot. Inventory Q targets the hovered main-inventory or armor slot only when the carried cursor stack is empty.
- Closing the inventory sends the carried cursor stack to the server for a world drop; the client no longer reinserts it locally.
- `/give` is parsed as a request and inserted by the server-owned PlayerInventory. Item names/metadata are normalized against the 1.8.9 client item-model registry before dispatch; the server independently validates numeric legacy item mapping, count and metadata. Any uninserted remainder is emitted as server-owned world drops.
- `/clear` is executed by the server and clears main inventory, armor and cursor state. This build intentionally supports the no-argument `/clear` form.
- Removed the remaining client-side EntityItem tick, merge, pickup and despawn loop from the gameplay thread. The renderer now builds its world-item list exclusively from server snapshots.
- Added tests for player-thrown EntityItem pickup delay/NBT, server cursor extraction, command parsing without local mutation, and integrated-server drop/give/clear processing.

## Validation
- Source ZIP integrity checked; source paths and authority-boundary references statically inspected.
- Cargo tests and release compilation were not executable in the authoring environment because `cargo` and `rustc` are unavailable. Run both on Windows before treating this build as runtime-validated.
