# v1.6 — biome-aware grass tint

- Reads the vanilla `assets/minecraft/textures/colormap/grass.png` directly from the supplied client JAR.
- Uses the selected chunk's 256 legacy biome IDs and the vanilla biome temperature/rainfall lookup to calculate grass tint per X/Z column.
- Carries per-quad linear-RGB tint through the GPU vertex buffer and multiplies it with the sampled atlas texture in the fragment shader.
- Applies biome tint only to tint-indexed faces of legacy grass blocks (ID 2); untinted faces and all other blocks retain a white multiplier.
- Reports how many grass blocks received biome tint and how many lacked usable biome data.
- Adds tests for common/mutated biome climate mappings and sRGB-to-linear conversion.

Leaves, water, other biome-colored blocks, biome interpolation at block boundaries, and biome-specific special cases remain future work. Unknown biome IDs are left untinted instead of guessed.

Validation note: this authoring environment has no Cargo/Rust toolchain, so `cargo fmt` and `cargo test` have not been run here. Windows validation is required before treating this milestone as compiled and tested.
