# v2.2.3.52 — Main menu layout pass

- Reworked the main title-screen controls to match the Minecraft 1.8.9 `GuiMainMenu` layout: Singleplayer, Multiplayer, Minecraft Realms, Options, Quit Game, and the compact language control.
- Restored the vanilla main-screen vertical positions (168, 192, 216, and 252 on the 854x480 virtual GUI) and the 98x20 split Options/Quit buttons.
- Loads a splash phrase from `assets/minecraft/texts/splashes.txt` in `client.jar`, draws it in yellow with the vanilla -20 degree tilt beside the logo.
- Displays `Minecraft 1.8.9` at the lower-left and the Mojang copyright notice at the lower-right.
- Keeps the existing Singleplayer world list and same-window world launch behavior.
- Multiplayer and Realms are visible but do not launch yet; language control is visual only. Their functional screens are not implemented in this increment.
- The panorama still uses the previous shader approximation. Exact seven-pass `rotateAndBlurSkybox` rendering is the next background-rendering task; this release does not claim pixel-identical panorama blur.
