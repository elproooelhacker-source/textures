# v2.2.3.143 — World generation: MathHelper parity and shared RNG boundary

## Changes

- Ported the `MathHelper.sin` / `MathHelper.cos` lookup-index semantics used by MCP 1.8.9, including the `10430.378F` multiplier, 16-bit table index, cosine quarter-turn offset, and f32 table result.
- Updated `WorldGenMinable` vein endpoints and ellipsoid radii to use the Minecraft lookup behavior instead of Rust's direct `f32::sin` / `f32::cos` calls.
- Added `populate_overworld_ores_with_rng`, which accepts a mutable, already-seeded `JavaRandom` stream and does not reseed it. This is the correct integration seam for continuing the shared `ChunkProviderGenerate.populate` stream after structure/lake/dungeon generation.
- Kept `populate_overworld_ores` as a deterministic isolated convenience wrapper, but clarified that it does not yet replay the pre-decoration random-consuming structure/lake/dungeon passes.
- Added tests for cardinal lookup values, periodic table indexing, and deterministic use of a continuing shared RNG stream.

## Remaining limitations

- The full structure/lake/dungeon prelude is not yet ported, so seed-for-seed parity of the complete vanilla population pass is not claimed.
- The primer-backed ore writer still clips placements to the current 16x16 chunk; vanilla's world writer can touch neighboring chunk coordinates during a vein walk. Cross-chunk write staging is still required for exact boundary parity.
- Specialized biome surfaces, all non-ore decorations, structures, lighting, spawn selection, and complete world serialization remain outstanding.
- Create World remains disabled until generation and persistence are integrated and validated end to end.

## Validation

- Source compared against MCP 1.8.9 `MathHelper.java`, `WorldGenMinable.java`, `BiomeDecorator.java`, and `ChunkProviderGenerate.java`.
- ZIP integrity checked after packaging.
- Rust tests were added but not executed because `cargo` and `rustc` are unavailable in this environment.
