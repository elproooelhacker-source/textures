# v2.2.3.30 — AO predicate compile fix

## Fix
- Fixed the `E0425` compilation failure reported by Windows Rust: `block_ao_value` referenced an undefined `ao_occludes` function.
- Reused the already-defined `occludes_model_face` predicate so AO classification and the renderer's existing full-cube face-occlusion classification cannot drift apart.

## Scope
- This is a compile fix only. It does not claim to complete the vanilla 1.8.9 lightmap or the full `BlockModelRenderer` AO implementation.
- The full workspace test suite must be rerun on Windows; this environment does not have Cargo installed.
