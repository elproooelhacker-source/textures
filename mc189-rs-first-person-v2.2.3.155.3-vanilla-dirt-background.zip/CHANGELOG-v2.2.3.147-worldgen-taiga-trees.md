# v2.2.3.147 — Worldgen ordinary taiga trees

## Included
- Added spruce log/leaves legacy block states: log ID 17 metadata 1, leaves ID 18 metadata 5.
- Added `WorldGenTaiga1` and `WorldGenTaiga2` ports based on the deobfuscated 1.8.9 MCP sources.
- Added tree attempts for Taiga, Taiga Hills, Cold Taiga and Cold Taiga Hills (biome IDs 5, 19, 30, 31), with the vanilla 10-attempt base and 1-in-10 extra attempt.
- Ported the Taiga type-0 selector: `nextInt(3)==0` selects Taiga1, otherwise Taiga2.
- Kept shared `JavaRandom`, terrain-height lookup, and cross-chunk region writes.
- Added deterministic regression coverage and legacy-state assertions.

## Fidelity boundaries
- Mega Taiga (biome IDs 32/33) remains deferred because it selects MegaPineTree variants and includes additional biome-specific decoration.
- Forest BigTree selection and the complete post-tree decoration pipeline remain incomplete.
- The terrain representation still omits saplings, vines, farmland and several other block/material distinctions. Those can affect edge-case clearance and support behavior.
- No claim of bit-identical full chunk population is made.

## Validation
- ZIP integrity is checked at packaging time.
- Cargo tests/build were not run in this environment because `cargo` and `rustc` are unavailable.
