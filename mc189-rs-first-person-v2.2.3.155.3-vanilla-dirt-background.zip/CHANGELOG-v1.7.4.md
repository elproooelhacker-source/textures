# v1.7.4

## Vanilla 1.8.9 vegetation resource-name corrections

- Dandelion (legacy block ID 37) now resolves `blockstates/dandelion.json`, variant `normal`.
- The nine legacy red-flower metadata values (ID 38) now resolve their individual vanilla blockstates: `poppy`, `blue_orchid`, `allium`, `houstonia`, `red_tulip`, `orange_tulip`, `white_tulip`, `pink_tulip`, and `oxeye_daisy`, each with variant `normal`.
- Double-plant direct model paths now use the exact vanilla 1.8.9 archive names: `double_sunflower_*`, `double_syringa_*`, `double_grass_*`, `double_fern_*`, `double_rose_*`, and `double_paeonia_*`.
- Added regression coverage for all nine flower selectors and all twelve double-plant half models.

No world data, region parsing, or saved chunks are modified.
