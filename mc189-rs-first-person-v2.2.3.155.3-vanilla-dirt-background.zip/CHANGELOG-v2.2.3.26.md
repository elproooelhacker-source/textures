# v2.2.3.26 — smooth-lighting regression fixture correction

The v2.2.3.25 regression test constructed a raw model-local quad, but called the lighting routine as though its positions had already passed through `transform_instance`. In production, `transform_instance` adds the block's Y coordinate before lighting is calculated. The test therefore sampled Y=1 instead of the top-face outward neighbor at Y=66, causing the height-map fallback to return full brightness.

The fixture now uses the same transformed world-Y positions as production and places SkyLight 6 in the outward sample voxel (section-local Y=2). It continues to exercise the negative chunk coordinate conversion for X/Z. The test warning from redundant parentheses is also removed.

No runtime lighting algorithm is changed by this patch. It corrects the regression test so it validates the intended coordinate-space fix rather than an impossible intermediate state.
