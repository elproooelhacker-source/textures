# v2.2.3.128 — player pose persistence foundation (Step 5)

## Changes

- The single-player loader now reads the vanilla `Data.Player.Pos` and `Rotation` fields from `level.dat` when they are well-formed and finite. Invalid/missing fields fall back to the world's saved spawn and default rotation.
- The loader restores `Motion` when present, finite, and within the movement system's bounded velocity range.
- The gameplay loop includes the latest authoritative player pose in the existing deferred `PlayerDataSnapshot`, alongside the inventory patch. Coordinates are converted from the integrated server's origin-relative space back to world coordinates.
- The persistence worker continues merging only owned fields into `Data.Player`, preserving unrelated player NBT and world metadata through the existing `level.dat_new` / `level.dat_old` transaction.
- Position, rotation, and motion are checkpointed through the existing five-minute autosave and graceful-close barrier; movement does not synchronously write `level.dat` on the simulation tick.

## Scope boundary

This is a first Step 5 increment, not completion of world persistence. Dropped `EntityItem` entities are still server-owned in memory but are not yet serialized into chunk `Level.Entities`; world time/weather and other dynamic world state are also not fully persisted. Those remain explicit follow-up work. Inventory persistence currently uses the server-synchronized GUI replica when creating the NBT patch; the server snapshot remains the source for supported inventory actions.

## Validation

- Static source review and ZIP integrity checks only.
- `cargo test --workspace` and release compilation were not run in the authoring environment because the Rust toolchain is unavailable.
