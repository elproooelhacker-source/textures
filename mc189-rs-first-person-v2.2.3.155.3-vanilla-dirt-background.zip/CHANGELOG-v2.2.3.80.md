# v2.2.3.80 — Mining mechanics foundation

## Added
- A dedicated `mining` module, isolated from item/block first-person camera transforms.
- Amanatides–Woo voxel ray traversal with a caller-supplied block predicate and hit-face output.
- A 20 Hz mining controller with target-change/release resets, per-tick damage accumulation, break completion, and post-break delay.
- Vanilla `Block.getPlayerRelativeBlockHardness`-shaped damage calculation: hardness, harvest eligibility, `/30` vs `/100`, tool speed, Efficiency, Haste, Java Mining Fatigue values, underwater/Aqua Affinity and airborne penalties.
- Initial legacy block-property/drop registry for common terrain, stone, ores, wood, glass and utility blocks.
- Dropped-item simulation data with vanilla-style randomized spawn point, initial toss, gravity/drag, age, pickup delay and proximity predicate.
- Unit tests for vanilla mining damage, incorrect-tool penalty, reset behavior, ray-hit face and item spawn delay.

## Source references
- MCP 1.8.9 `PlayerControllerMP` mining lifecycle.
- MCP 1.8.9 `Block.getPlayerRelativeBlockHardness` and `Block.dropBlockAsItemWithChance`.
- MCP 1.8.9 `C07PacketPlayerDigging` action states.

## Important scope limitation
This is an engine foundation, not yet the complete in-world feature. The current gameplay loop still labels world access read-only and does not yet connect the mining controller to mouse-held state, mutate loaded chunk block arrays, rebuild the affected GPU chunk mesh, render dropped-item entities, or insert pickups into the inventory. Those integration steps are intentionally not represented as complete in this version. Unknown block IDs are not assigned guessed hardness or drops. Cargo was unavailable in the build environment, so tests and compilation could not be executed here.
