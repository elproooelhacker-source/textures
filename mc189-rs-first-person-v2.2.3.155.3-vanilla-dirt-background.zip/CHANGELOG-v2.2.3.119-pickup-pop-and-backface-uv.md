# v2.2.3.119 — pickup pop audibility and vanilla item back-face UVs

## Item rear face

- Rechecked MCP 1.8.9 `ItemModelGenerator.makeItemModel`, `FaceBakery`, `BlockFaceUV`, and `EnumFaceDirection`.
- The NORTH face source rectangle reverses U, but NORTH also has a different baked vertex order. When expressed in our shared TL/TR/BR/BL quad order, the resulting UVs are the normal full UV order.
- Removed the second horizontal reflection. The rear face now shows the same pickaxe/tool orientation as the front instead of making an X.
- Updated the regression test to use an asymmetric silhouette and compare the final back-face UV order.

## Pickup sound

- Rechecked MCP `EntityItem.onCollideWithPlayer`: `random.pop` is emitted after a positive inventory transfer, at the player's position, with volume `0.2F` and the two-`nextFloat` vanilla pitch formula. It does not depend on the drop's age.
- The local pickup branch now makes that rule explicit: audio depends only on inserted count > 0; age and pickup delay are diagnostic only after `can_pickup` has passed.
- The sound request is anchored to the player, matching the local EntityItem collision route.
- Effective output gain is raised to 0.45 in this standalone client because it does not yet implement vanilla sound-category mixing; the original randomized pitch formula and original OGG selection are retained.
- Added logs showing item age, pickup delay, and whether `random.pop` was queued.

## Validation

- Source changes and versioned ZIP integrity checked.
- Cargo/rustc are not installed in this authoring environment; Windows compilation and audible pickup test remain required.
