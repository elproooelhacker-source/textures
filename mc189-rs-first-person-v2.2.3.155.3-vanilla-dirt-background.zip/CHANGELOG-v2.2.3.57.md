# v2.2.3.57 — Campo de densidad y bloque base del chunk

- Añade `BiomeTerrain` para transportar `minHeight`/`maxHeight` del vecindario de biomas usado por `ChunkProviderGenerate`.
- Añade `TerrainSettings` con los parámetros de terreno de `ChunkProviderSettings` y sus valores vanilla por defecto.
- Implementa el campo de densidad 5×33×5: ruido de profundidad, ruido principal, límites inferior/superior, ponderación parabólica 5×5, ajuste Amplified y desvanecimiento superior.
- Implementa la interpolación de densidad 4×8×4 hasta 16×256×16, produciendo piedra, agua bajo el nivel del mar y aire.
- Añade pruebas de determinismo, dependencia de coordenadas, validación de vecindario e interpolación básica.

## Alcance pendiente

Esta versión todavía no genera un `Chunk` integrado al mundo: el llamador debe proporcionar los 100 parámetros de bioma correctos. Aún faltan la sustitución de superficie por bioma, cuevas/ravinas, estructuras, población, serialización Anvil/`level.dat` e integración con la carga del mundo. No se afirma equivalencia total de chunks todavía.

## Referencia técnica

Port basado en el flujo de `ChunkProviderGenerate.func_147423_a` y `setBlocksInChunk` de MCP 1.8.9, manteniendo las dimensiones, el orden de mezcla y las constantes de interpolación vanilla.

## Validación

ZIP comprobado estructuralmente. No se ejecutó Cargo en este entorno.
