# Minecraft 1.8.9 Rust recreation — v2.2.3.130

# v2.2.3.130 — protocol 47 offline network foundation

A new `mc189-protocol` crate now contains the protocol-47 packet registry extracted from the supplied deobfuscated 1.8.9 `EnumConnectionState`, VarInt/String codecs, TCP packet framing, Zlib compression negotiation, and the offline Handshake/Login Start/Login Success flow. `probe-offline-server` diagnoses connection to a local vanilla 1.8.9 server configured with `online-mode=false`. This is a network foundation, not yet a playable remote-world client: PLAY packet payload decoders, chunk ingestion, rendering integration, and continuous movement/input synchronization remain next steps. See `CHANGELOG-v2.2.3.130.md`, `RED-CLIENTE-VANILLA-1.8.9-MODO-OFFLINE.md`, and `docs/PROTOCOLO-RED-MC189-REGISTRO-PAQUETES.md`.

## v2.2.3.129 — dropped EntityItem persistence

The integrated 20 TPS server owns block-drop and player-drop EntityItem lifecycles, pickup transfer, and the supported inventory mutations. Q/Ctrl+Q, inventory cursor-stack drops on close, `/give`, and `/clear` are dispatched as server commands. The gameplay client no longer simulates world-item physics/merging/pickups or performs those inventory mutations locally; it renders server entity and inventory snapshots. `/give` overflow is emitted as world items.

This completes source implementation of steps 1–3 in the staged gameplay-authority migration. It does not complete the full migration: durability/player state, chunk/world ownership, authoritative persistence, full regression testing, block placement, and Minecraft protocol 47 remain future steps. Cargo tests and release compilation still require validation on the Windows machine.

See `CHANGELOG-v2.2.3.129.md`, `ENTITY-ITEM-PERSISTENCE-v2.2.3.129.md`, `CHANGELOG-v2.2.3.128.md`, `WORLD-PERSISTENCE-STEP5-v2.2.3.128.md`, `CHANGELOG-v2.2.3.126.md`, `SERVER-CLIENT-ARCHITECTURE-v2.2.3.126.md`, `ENTITY-ITEM-AUTHORITY-v2.2.3.125.md`, and the preceding changelogs for milestone history.

## v2.2.3.122 — server-authoritative mining and block drops

Opening a single-player world automatically starts the integrated 20 TPS server. The server owns the deferred Anvil chunk and `level.dat` player-data writer; the client submits revisioned snapshots and waits for a confirmed final flush before closing. The persistence worker is separate from the simulation tick thread, so disk compression/region rewrites do not stall the 20 TPS loop. The dedicated-server BAT remains an optional headless networking experiment.

This is still a staged migration: the integrated server now decides mining progress, target selection, block-break acceptance and block-drop tables, while the client still creates/render-interpolates item entities and performs chunk-lighting/mesh derivation. Complete authoritative inventory, item-entity physics/pickup/persistence, world time/weather metadata, remote chunk streaming, dedicated-server mining protocol and graphical join-server support remain future work. No claim is made that every vanilla subsystem is migrated.

See `SERVER-CLIENT-ARCHITECTURE-v2.2.3.122.md` and `CHANGELOG-v2.2.3.122.md`.

## v2.2.3.118 — source-verified pickup sound and aligned flat-item back face

Pickup sound now follows MCP 1.8.9 `NetHandlerPlayClient.handleCollectItem`: the local client plays `random.pop` at the collected entity position, using volume 0.2 and the original two-random-float pitch. Active Rodio sinks stay owned until playback completes, and the log distinguishes a successful queue from a failed one. Manual item drops retain their 40-tick protection and only play pop when they are actually inserted into inventory.

The generated dropped-item back face now shares the front face's centered model-space bounds. Its U coordinates remain mirrored exactly as in `ItemModelGenerator`, but it no longer appears shifted above/right of tools. The first-person held model and 3D block drops are unchanged.

See `CHANGELOG-v2.2.3.118-pickup-audio-backface-align.md`.

## v2.2.3.117 — local sound pack extraction and vanilla-style flat item drops

This patch builds on v2.2.3.116. On first world launch, it materializes every OGG sound object referenced by the selected Minecraft 1.8 asset index into `runtime/audio/assets/minecraft/sounds`, plus `sounds.json` when present. Subsequent launches reuse the project-local files, so the running client no longer needs the launcher object store after extraction. The supplied 1.8.9 `client.jar` contains no OGG files or `sounds.json`; the original sound payloads therefore come from UltimMC's hashed asset cache, not from extracting nonexistent entries from the JAR. The launcher sets `MC189_PROJECT_ROOT` to the package folder and explains the resulting local path.

Flat/generated dropped items now use MCP `GROUND` display transforms and the true net scale of the `RenderEntityItem` path (flat models retain the inner 0.5x render transform; the separate 2x GUI/hand pre-transform is not used here). Their stack copies are centered using `RenderEntityItem.func_177077_a` spacing, and world-drop sprites receive the mirrored back face generated by `ItemModelGenerator` plus directional side shading. The current first-person held-item mesh is intentionally unchanged. GUI-3D block drops retain their existing transform and pile appearance.

See `CHANGELOG-v2.2.3.117-local-sounds-and-flat-drop-render.md`.

## v2.2.3.116 — pickup sound coverage and drop hand animation

This patch keeps the v2.2.3.115 baseline and improves item pickup feedback:
- Every successful EntityItem-to-inventory transfer now emits a pickup diagnostic and requests the original `random.pop` event, regardless of whether the item came from a mined block or a manual Q/Ctrl+Q drop.
- The pickup pitch follows the 1.8.9 `EntityItem` / `NetHandlerPlayClient` two-random-float distribution. A subtle per-pickup gain variation is added, and the launcher's weighted sound variants remain randomly selected.
- Successful Q and Ctrl+Q drops start the first-person hand swing. Empty Q presses do not animate.
- Manual player drops retain vanilla's 40-tick pickup delay; the sound is played when inventory insertion actually succeeds, not when the item merely enters pickup range.

See `CHANGELOG-v2.2.3.116-pickup-sound-and-drop-arm-animation.md`.

## Windows play-test package

Start with [`EMPEZAR-AQUI-WINDOWS.md`](EMPEZAR-AQUI-WINDOWS.md). Run `INICIAR-PRUEBA-MINECRAFT-RUST.bat` to locate the existing 1.8.9 instance, create a backup of your saves, build the native client in release mode, and open the native title screen. `EJECUTAR-PRUEBAS-RUST.bat` runs the workspace unit tests separately.

## Current gameplay implementation

The current source includes a native title screen and first-person world session, streamed chunk rendering/collision, left-click block mining, the original ten block-damage textures, block mutation, basic drop rules, server-owned block-generated item entity physics, merging, despawn and inventory pickup, item/block drop rendering, and chunk light sampling. Inventory and pickup are only partially migrated: supported GUI slot commands and block-drop collection are server-owned, while Q/Ctrl+Q and command paths remain pending.

## v2.2.3.115 — hovered-stack accessor compile fix

The 2.2.3.114 Windows build reached `mc189-app` and failed because `gpu_block_preview.rs` read `InventoryUi.hovered_slot` directly even though that field is intentionally private. This patch keeps the hover index encapsulated and adds `InventoryUi::hovered_stack()` as a read-only accessor for the hovered main-inventory or armor stack. The Q/Ctrl+Q path now validates the hovered item through that accessor before removing it. Added unit coverage for normal inventory slots, armor slots, and no hovered slot. No audio, rendering, inventory mutation, or world-drop behavior was changed. See `CHANGELOG-v2.2.3.116-hovered-stack-accessor-fix.md`.

## v2.2.3.114 — audio asset resolution, slot clipping, and Q drops

The audio loader now merges all available launcher asset-index snapshots (with the 1.8 index taking priority), reports the exact playable events and uses a regular rodio output sink with local-action volume instead of backend-dependent spatial output. It still reads any definitions or OGG files embedded in `client.jar` first, then resolves the actual Mojang OGG objects from UltimMC's shared `assets/objects` store. The launcher checks any JSON asset index rather than requiring one exact filename, and Rust skips empty/incomplete per-instance caches so they cannot shadow UltimMC's shared audio store. The client JAR normally does not contain the OGG payloads; the official launcher stores them by SHA-1 in the shared object store. See `CHANGELOG-v2.2.3.114-audio-slot-pop-drop-q.md`.

Slot pop icons are rasterized into independent 16x16 slot surfaces, guaranteeing that the animation cannot spill into the adjacent hotbar slot or outside the inventory frame. Manual cursor moves/swaps are detected from before/after inventory snapshots and do not trigger receive-item pop; pickup/consumption stack changes still do. `Q` drops one item from the selected hotbar slot and `Ctrl+Q` drops the entire stack; while the inventory is open, the same keys act on the hovered slot when the cursor is empty.

## v2.2.3.112 — live hotbar inventory updates, slot-pop animation, and block mining audio

Ground pickups are inserted into `InventoryPlayer` immediately. The HUD/hotbar texture is refreshed in the same simulation tick, so the first cobblestone appears without opening the inventory and later pickups update the stack count in place. The existing isometric cube icon path is retained for block items. Any changed stack identity, metadata, NBT payload, or count arms a five-tick slot pop; the renderer interpolates it with `partialTicks` using the vanilla `GuiIngame.renderHotbarItem` scale formula. The count overlay stays anchored while the icon bounces. Both increases and decreases (for example 2 to 1) are detected.

Block mining loads sound events from the active launcher's hashed 1.8 assets, with an explicit OGG-variant report and a regular output sink for reliable Windows playback. It plays MCP-style periodic step sounds while mining and the block-specific break sound when the block is destroyed, with vanilla event volume/pitch factors. Pickup uses `random.pop`. Missing assets or an unavailable audio device remain non-fatal. See `CHANGELOG-v2.2.3.114-audio-slot-pop-drop-q.md`.

## v2.2.3.110 — vanilla pickup animation and player inventory persistence

Collected items now use a transient visual copy that follows MCP 1.8.9 `EntityPickupFX`: it moves from the item entity's world position toward the interpolated player position plus 0.5 blocks on Y with the original three-tick quadratic curve. The actual accepted quantity enters InventoryPlayer immediately; if only part of a stack fits, the remainder remains in the world.

On world load, the client reads `Data.Player.Inventory` and `Data.Player.SelectedItemSlot`. On save, it writes main/hotbar slots 0–35 and armor slots 100–103, including each stack's opaque `ItemStack.tag` payload. Only those owned player fields are patched; other Player tags and level metadata are retained. Inventory changes join the background five-minute checkpoint and the final world-close flush. The carried GUI cursor stack remains transient as in vanilla. See `CHANGELOG-v2.2.3.110.md`.

## v2.2.3.107 — incremental lighting and section-local mesh updates — test compile fix

Gameplay block edits now use a two-phase, radius-17 decrease/reseed light update modeled on MCP 1.8.9 `World.checkLightFor`, with `Chunk.relightBlock`-style HeightMap column changes. It removes stale light dependencies, restores valid light from surviving sources/direct skylight, and only rebuilds mesh sections touched by the block edit or actual light changes. GPU chunk buffers are split by 16-block section, so an edit uploads the affected section/layer buffers rather than replacing the whole chunk. The conservative neighborhood relight remains only as a fallback when the required radius-17 chunk area is not available or a missing light baseline must be reconstructed. See `CHANGELOG-v2.2.3.106.md` for the incremental-light and section-mesh scope, and `CHANGELOG-v2.2.3.107.md` for the test compile correction.

## v2.2.3.105 — light-invariant edit fast path

Block edits that preserve both vanilla light opacity and emission skip neighborhood light invalidation/rebuild. This remains the zero-light-work fast path for replacements such as one opaque full cube with another.

## v2.2.3.104 — drop-before-chunk/light refresh ordering

The completed mining-break event now follows a strict sequence: (1) the block is removed from the live collision snapshot immediately, and its owned vertices are culled from the displayed chunk mesh; (2) once the mining crack animation has completed and `MiningEvent::Broken` is emitted, the provisional item entity is created and a redraw is requested; (3) only after the drop entity has been inserted is the neighbor-aware block-edit worker request sent, starting chunk mesh and lighting recalculation. This keeps chunk/light work from delaying the drop transition while preserving the asynchronous rebuild and rollback behavior. If the worker rejects the edit, only that revision's provisional drops are removed and the previous collision/mesh state is restored.

The ordering is source-reviewed and ZIP-integrity checked. This authoring environment has no Cargo/rustc or Windows GPU runtime, so a fresh Windows build and in-game timing test are still required.

## v2.2.3.103 — immediate block disappearance and smoother item entities

The visible chunk mesh now keeps CPU-only source-block ownership for every emitted vertex in opaque, cutout, translucent, and fluid layers. On the exact fixed tick that the mining controller emits `Broken`, the selected block's geometry is filtered from the current chunk mesh and uploaded before the next redraw; its provisional drop entity is created in the same tick. The asynchronous neighbor-aware chunk rebuild still follows to restore newly exposed neighbor faces and recompute dependent fluid/light geometry. If the in-memory edit transaction fails, the saved pre-edit CPU mesh is restored and provisional drops are removed.

Dropped item entities now use the block collision registry's complete local collision boxes and MCP-style Y/X/Z swept-AABB clipping, including partial shapes and collision boxes extending 1.5 blocks above fences/gates. The renderer interpolates previous/current fixed-tick positions and entity age using `partialTicks` and regenerates the small item batch immediately before each actual `RedrawRequested`, rather than uploading the batch only during 20 TPS `AboutToWait` simulation cadence.

New regression tests cover per-layer immediate owner culling, owner-coordinate translation into session space, lateral wall collision, elevated fence collision, floor contact, and display-frame interpolation. This authoring environment cannot run Cargo/rustc or a Windows GPU runtime; the ZIP is integrity-tested, but the new code still needs Windows compilation and gameplay verification.

## v2.2.3.102 — title-screen RefCell borrow fix

The Windows run log from v2.2.3.101 confirmed that `cargo build --release --package mc189-app` completed and the native title screen initialized; the process then panicked in `main_menu.rs` while handling a redraw surface error. v2.2.3.102 releases the mutable `RefCell` borrow immediately after `MenuGpu::render()` returns, before matching `SurfaceError`. This permits the `Lost`/`Outdated` recovery branch to borrow the GPU state again for `window_size` and `resize`.

## v2.2.3.101 — deferred world persistence

Mining and other block edits now update the live decoded chunk state in memory. The block-edit worker owns a session cache, applies block deltas, recalculates the local light neighborhood, and builds replacement CPU meshes without calling the Anvil writer. The render/event thread only receives completed snapshots and updates its live collision state, dirty-chunk map, and mesh queue.

A separate serial world-save worker performs disk persistence. It receives immutable snapshots of dirty chunks, loads their original NBT trees to preserve unrelated vanilla tags, applies block IDs/metadata plus HeightMap and light arrays (including light-only air sections), and batches all modified chunks in each region into one Anvil region rewrite. A shared world-I/O mutex serializes region reads and writes with the chunk streamer and edit worker so a region file is not read while its temporary replacement is being committed.

A safety checkpoint is queued every five minutes while there are unsaved dirty chunks. On window-close or the second Escape press, input/mining stops, pending in-memory block edits are drained, and the client waits for a final flush to finish and report success before closing. If the final save fails, the world remains open and the dirty snapshots are retained so the user can retry. The saved snapshot revision is compared with the current dirty revision, so an edit made during an earlier autosave is not accidentally marked clean.

## Important limits

This remains an experimental compatibility implementation, not a complete or verified Minecraft 1.8.9 client. v2.2.3.101 defers and persists **modified chunk block states, metadata, block/sky light arrays, and HeightMap**. Player position, health, experience, dropped-item entities, world time/weather changes, and all other dynamic world entities are not yet fully simulated or serialized by this save worker. Inventory persistence currently covers main/hotbar slots, armor slots, selected hotbar slot, and the opaque item-stack NBT payload; the GUI cursor stack is transient. These remaining systems require separate player/entity/world-metadata work before claiming a full vanilla-equivalent world save.

Mining cracks still use cube-face geometry rather than each block's baked model. Dropped items now have basic block-shape AABB collision and display-frame interpolation, but exact vanilla push-out behavior, per-block slipperiness, and full item-entity persistence remain incomplete. Gameplay block edits now use localized MCP-style light decrease/reseed updates, but chunk-generation baseline reconstruction, dimension-specific no-sky lighting, global relight edge cases, special item renderers, persisted World.rand, and many other MCP parity cases remain incomplete. The block-edit worker's decoded chunk cache is session-scoped and currently retains chunks it has touched; long mining sessions over a large explored area may increase memory use.

The play-test launcher is prefilled with the UltimMC `.minecraft` directory and `client.jar` paths supplied in the play-test conversation; those values can still be overridden at the prompts. The user-provided Windows log confirms that v2.2.3.101 compiled successfully in release mode and initialized the native title screen, but then hit a `RefCell already mutably borrowed` panic during redraw recovery. v2.2.3.102 addresses that specific runtime panic. This authoring environment does not contain Cargo/rustc or a Windows GPU runtime, so this fix still needs a fresh Windows build and runtime test. The launcher stops if Cargo compilation fails.

See `CHANGELOG-v2.2.3.114-audio-slot-pop-drop-q.md`, `CHANGELOG-v2.2.3.110.md`, `CHANGELOG-v2.2.3.109.md`, `CHANGELOG-v2.2.3.108.md`, `CHANGELOG-v2.2.3.107.md`, `CHANGELOG-v2.2.3.106.md`, `CHANGELOG-v2.2.3.105.md`, `CHANGELOG-v2.2.3.104.md`, `BLOCK-BREAK-ITEM-PHYSICS-v2.2.3.103.md`, `CHANGELOG-v2.2.3.103.md`, `MENU-REFCELL-PANIC-FIX-v2.2.3.102.md`, `CHANGELOG-v2.2.3.102.md`, `DEFERRED-WORLD-SAVE-v2.2.3.101.md`, `CHANGELOG-v2.2.3.101.md`, and earlier changelogs for milestone details.


## v2.2.3.126
Server-authoritative Q/Ctrl+Q drops, cursor-stack drop on inventory close, `/give`, `/clear`, and server-only EntityItem simulation/pickup. See `CHANGELOG-v2.2.3.126.md` and `SERVER-CLIENT-ARCHITECTURE-v2.2.3.126.md`.


## v2.2.3.126 — Step 3
Q/Ctrl+Q, cursor-stack drops on inventory close, `/give`, and `/clear` are now server commands. The client no longer simulates world item entities or mutates the inventory for those operations. See `CHANGELOG-v2.2.3.126.md` and `SERVER-CLIENT-ARCHITECTURE-v2.2.3.126.md`.


## v2.2.3.127 — Step 4 durability foundation
Mining now reduces durability on the authoritative selected tool; the UI renders the vanilla 1.8.9 damage bar in hotbar/inventory/armor/cursor positions and plays `random.break` when the server confirms a tool break. This is the mining durability foundation, not yet full combat durability: sword hits and armor damage await entity combat. See `CHANGELOG-v2.2.3.127.md`.


## v2.2.3.128 — Step 5 foundation

The existing deferred chunk/inventory save pipeline now also persists and restores the player pose (`Pos`, `Rotation`, `Motion`) through vanilla `level.dat` player NBT. This is an incremental persistence milestone: dropped EntityItem serialization, full entity persistence, and dynamic world metadata remain pending. See `CHANGELOG-v2.2.3.128.md` and `WORLD-PERSISTENCE-STEP5-v2.2.3.128.md`.


## v2.2.3.130 — protocol 47 offline network foundation

A new `mc189-protocol` crate now contains the protocol-47 packet registry extracted from the supplied deobfuscated 1.8.9 `EnumConnectionState`, VarInt/String codecs, TCP packet framing, Zlib compression negotiation, and the offline Handshake/Login Start/Login Success flow. `probe-offline-server` diagnoses connection to a local vanilla 1.8.9 server configured with `online-mode=false`. This is a network foundation, not yet a playable remote-world client: PLAY packet payload decoders, chunk ingestion, rendering integration, and continuous movement/input synchronization remain next steps. See `CHANGELOG-v2.2.3.130.md`, `RED-CLIENTE-VANILLA-1.8.9-MODO-OFFLINE.md`, and `docs/PROTOCOLO-RED-MC189-REGISTRO-PAQUETES.md`.

## v2.2.3.129 — dropped EntityItem persistence

The integrated server now restores `Item` entities from each loaded chunk's `Level.Entities` list and saves the authoritative item snapshots back into chunk NBT during autosave and graceful world close. Position is converted between the renderer's origin-relative coordinates and absolute world coordinates. Item ID, count, metadata, custom stack NBT, motion, age, pickup delay, and stable Rust entity ID are preserved. Previous chunks are included in later saves so a moved or collected item does not remain as a stale duplicate in its former chunk. See `CHANGELOG-v2.2.3.129.md` and `ENTITY-ITEM-PERSISTENCE-v2.2.3.129.md`.
