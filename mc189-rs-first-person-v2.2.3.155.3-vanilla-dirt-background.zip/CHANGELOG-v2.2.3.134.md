# v2.2.3.134 — Optional multiplayer server port

- The Multiplayer screen now accepts an empty port field and defaults to Minecraft Java's standard TCP port `25565`.
- Custom ports remain supported; zero, non-numeric, and out-of-range values are rejected.
- Saved entries store the resolved port, and selecting a server with the default port leaves the field blank while showing the default in the UI.
- Added focused unit tests for blank, whitespace, custom, zero, and invalid port values.
- Updated the multiplayer testing guide.

Build/test status: source changes and archive integrity are checked in this environment; Cargo is unavailable here, so Rust compilation and unit-test execution remain pending on the user's PC.
