# v2.2.3.99 — mesh builder JAR scope compile fix

## Windows compiler report addressed

The Windows play-test report showed three `E0425` errors in `textured_chunk.rs` because `jar` was passed to `cached_variant_model(...)` from `build_chunk_from_neighborhood(...)` but was not in that function scope.

Changes:
- Threaded `&Path` for the Minecraft client JAR through `process_gameplay_block_edit(...)`.
- The edit worker now passes its owned `jar: PathBuf` into the edit processor.
- Added `jar: &Path` to `build_chunk_from_neighborhood(...)`.
- Updated both call paths: gameplay edit mesh rebuild and normal selected-chunk mesh building.
- The formerly unused `jar` parameter in `build_chunk_from_selected(...)` is now consumed by the downstream model-variant resolver.

No gameplay behavior was intentionally changed.

## Verification

- Static call-site/signature review confirms all three `build_chunk_from_neighborhood` call sites pass the JAR argument.
- ZIP integrity checked after packaging.
- Cargo/rustc are not available in the authoring environment; a fresh Windows build is required to confirm compilation and expose any subsequent errors.
