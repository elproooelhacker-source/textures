# v2.2.3.6 — stable interpolated first-person camera pose

## Fixed / improved
- Kept the render-only interpolated camera position separate from the authoritative 20 Hz player simulation state.
- Mouse-look events now update yaw and pitch immediately without submitting the raw simulation position to the renderer. This prevents an asynchronous input event from briefly snapping camera translation away from its interpolated position.
- Window resize and swapchain-recovery paths now reuse the last rendered camera pose instead of replacing it with the raw player state.
- Centralized render-pose interpolation in a small pure helper and added tests for position interpolation, orientation preservation, and alpha clamping.

## Preserved
- No changes to movement speed, acceleration, friction, gravity, jump timing, collision detection, or the 20 Hz simulation step.
- No changes to world files, chunk data, textures, or the Minecraft client JAR.

## Validation
- Added two unit tests for the render-pose interpolation helper.
- The source was statically reviewed in this environment. The Rust toolchain is not installed here, so `cargo fmt` and `cargo test` must be run on the Windows machine before gameplay validation.
