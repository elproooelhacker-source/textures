# v2.2.3.37 — Dynamic world lightmap, stage 2

Continues from v2.2.3.36, which passed 160 app tests and 13 storage tests on the user's Windows machine and successfully loaded the existing `New World` save.

## Included

- Reads `DayTime`, `raining` and `thundering` from the world's read-only `level.dat` before starting gameplay.
- Adds the 1.8.x celestial-angle sun-brightness curve and applies the vanilla rain/thunder attenuation factors.
- Advances the in-session day clock at the classic 20 ticks/second simulation rate without writing changes to the save.
- Regenerates and uploads the 16×16 GPU lightmap while playing, so the sky-light contribution transitions between day and night instead of remaining fixed at clear daytime.
- Ports the Java 48-bit `java.util.Random` / `Math.random()` sequence semantics and the `EntityRenderer.updateTorchFlicker()` accumulator, updated at render-update cadence. The session seed differs per launch, as expected for a client-side random stream.
- Adds regression tests for noon, midnight, rain and thunder sun-brightness behavior.

## Known limitations

- Weather is initialized from the saved `raining`/`thundering` flags and is not yet simulated with vanilla transition timers or interpolation.
- Lightning flash events are not yet simulated; the lightmap function retains the flash branch for a future event source.
- The PRNG and accumulator arithmetic match the Java implementation, but the initial process-wide `Math.random()` seed is session-local and is not expected to match a separate vanilla process bit-for-bit.
- Block/material property classification and fluid corner-lighting still need further JAR-driven auditing. This is not yet complete renderer equivalence.
- This build environment does not have Rust/Cargo installed. Windows `cargo fmt` and `cargo test` verification is required before treating it as stable.
