# v2.2.3.105 — light-invariant block-edit fast path

## Changes

- Added a conservative light-property comparison using the project's vanilla 1.8.9 light-opacity and emission tables.
- Block edits whose old and new block IDs have identical light opacity and emission no longer invalidate or rebuild the 3x3 lighting neighborhood.
- The fast path updates only the edited chunk snapshot; neighboring chunk geometry is still rebuilt at chunk borders when required by face visibility.
- Edits that can affect skylight or block light retain the existing full neighbor-aware relight path. This intentionally avoids an unsafe fixed-radius shortcut or stale-light artifacts.
- Added unit coverage for opaque replacements, block removal, emissive blocks, water and leaves.

## Scope / limitation

This is a safe first optimization, not the complete incremental-lighting and section-mesh patch. Breaking a typical opaque block into air still changes light opacity and therefore uses the conservative full relight path. Section-local GPU buffers and decrease/reseed light propagation remain follow-up work; they are not claimed as implemented here.

## Validation

Source-level changes and test cases were added. Rust compilation/tests could not be run in this environment because `cargo`/`rustc` are not installed. Please run the included project test/build script on Windows before treating this build as runtime-verified.
