# v1.8.0 — Legacy stone variants

## Implemented

- Maps block ID 1 metadata 0 to the vanilla `stone` blockstate `normal` variant.
- Maps metadata 1–6 to the exact 1.8.9 texture resources while retaining the vanilla `block/stone` full-cube model:
  - 1: `stone_granite`
  - 2: `stone_granite_smooth`
  - 3: `stone_diorite`
  - 4: `stone_diorite_smooth`
  - 5: `stone_andesite`
  - 6: `stone_andesite_smooth`
- Overrides the resolved model-face texture paths before atlas UV remapping; geometry, face UVs, culling and normals remain those of the vanilla stone model.
- Reports the number of rendered non-normal stone variants separately.
- Extends the read-only client-JAR state audit to verify that every referenced variant texture actually exists.
- Adds regression coverage for all seven metadata values and explicitly rejects reserved metadata 7–15 rather than guessing.

## Scope and validation

This change does not add a new model or alter world data. The six variant texture files must be present in the extracted static atlas; if an atlas is stale or incomplete, the existing strict atlas lookup reports the missing resource instead of substituting another texture.

The assistant environment does not have the Rust toolchain. Run `cargo fmt --all`, `cargo test --workspace`, then the existing `preview-textured-chunk` command on Windows. Inspect the new `Rendered non-normal stone variants` counter and visually compare all six textures in a chunk containing these states.
