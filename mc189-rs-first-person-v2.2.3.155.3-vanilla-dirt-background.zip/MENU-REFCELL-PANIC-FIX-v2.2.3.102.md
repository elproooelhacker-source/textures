# Native title-screen redraw panic fix — v2.2.3.102

In v2.2.3.101, `WindowEvent::RedrawRequested` matched directly on the result of `gpu_events.borrow_mut().as_mut().expect(...).render()`. A `RefMut` temporary in a match scrutinee can live through the match expression. The `Lost`/`Outdated` branch then tried to borrow the same `RefCell` again to retrieve the window size and reconfigure the surface.

The fixed implementation stores `render()`'s result in a local created within an explicit block. The mutable borrow is dropped when that block ends. Surface recovery then takes fresh, non-overlapping borrows.

The reported `RefCell` panic is thereby addressed at its source rather than caught or suppressed. A new Windows run is still required to check the complete UI event sequence and world selection.
