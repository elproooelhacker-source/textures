Minecraft 1.8.9 project-local sound assets

The first successful world launch extracts all .ogg payloads from the official
UltimMC/Minecraft assets/objects cache into:
  minecraft/sounds/

The extraction follows the selected 1.8 asset index and copies sounds.json
beside the sound tree when that object is present. Later launches use these
project-local files first. The provided client.jar has no OGG entries or
assets/minecraft/sounds.json, so the original audio files cannot be extracted
from the JAR itself.
