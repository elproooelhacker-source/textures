Minecraft 1.8.9 audio cache

On first world launch, the native client extracts every .ogg object referenced by the selected 1.8 asset index into:
  assets/minecraft/sounds/

and copies sounds.json alongside it when present. The source OGG files are the official UltimMC/Minecraft launcher content-addressed assets, because vanilla client.jar does not include OGG payloads. The files in this directory are generated at runtime and are reused on later launches.
