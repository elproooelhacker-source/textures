# v2.2.3.142 — World generation: ore population foundation

## Implemented

- Added the legacy block-state mapping for the new generated terrain states.
- Added the vanilla `WorldGenMinable.generate` ellipsoid/vein walk, including its float/double operations, randomized endpoints, radius, stone-only replacement predicate, and chunk-bound clipping.
- Added the default 1.8.9 ore/deposit sequence from `BiomeDecorator.generateOres`: dirt, gravel, diorite, granite, andesite, coal, iron, gold, redstone, diamond, and lapis.
- Added the vanilla chunk population seed derivation (`nextLong()/2*2+1`) and the `genStandardOre1` / `genStandardOre2` height sampling rules.
- Added `generate_overworld_chunk_with_ores` as an explicit two-stage entry point: terrain/carvers, then ore population.
- Added determinism, coordinate-sensitivity, and legacy block-ID/metadata tests.

## Important integration boundary

The ore vein geometry and default counts/heights/sizes are ported from MCP 1.8.9. However, the convenience population entry point currently initializes the decorator random stream without replaying earlier structure-generation calls from `ChunkProviderGenerate.populate`. In a normal feature-enabled world, those calls can consume random values before biome decoration. Therefore this is not yet a claim of seed-for-seed parity with a full vanilla populated chunk. The next integration step is to replay/port the structure and population prelude, then pass its continuing RNG into the biome decorator.

The ore stage is not yet wired to the actual new-world creation flow or Anvil chunk writer. New biome-specific surface strata, biome decoration (trees/plants/lakes), structures, lighting/heightmaps, spawn preparation, and complete world metadata remain outstanding.

## Validation

- ZIP integrity is checked after packaging.
- Rust tests were added but not executed: this environment does not have `cargo` or `rustc` available.
