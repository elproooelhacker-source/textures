# v2.2.3.51

## Singleplayer world-list foundation

- Reworked the Singleplayer world list into wider selectable world rows.
- Displays each Java save's `icon.png` thumbnail at native-list scale, using a neutral fallback tile when the icon is absent or invalid.
- Displays the saved level name, region-file count, and spawn coordinates for each listed world.
- Added a visible, deliberately disabled `CREATE NEW WORLD` control. Clicking it performs no navigation or file operation.
- Kept world selection wired to the existing same-window gameplay handoff.
- Added a focused test for the disabled create action and world-screen controls.

## Not included yet

- Rename/edit and delete/confirmation workflows are not implemented in this incremental build.
- The list currently shows the first seven worlds; paging/scrolling will be added with the management actions.

## Validation

- Source and ZIP structure inspected.
- Rust formatting, compilation, tests, and Windows runtime were not run in this environment because the Rust toolchain is unavailable.
