# v2.2.0 — First-person gameplay foundation

## Added
- `select-world` now opens a native first-person session at the selected world's saved spawn instead of the orbiting diagnostic camera.
- Mouse-look with captured cursor; Escape releases the cursor and a left click captures it again. Escape while released exits the session.
- WASD and arrow-key movement, Space jump (edge-triggered; holding Space does not auto-bunny-hop), and Left/Right Shift sprint.
- Fixed 20 Hz player simulation with bounded frame-time accumulation, classic player dimensions, gravity, jump impulse, and axis-separated swept block collision.
- Collision reads decoded legacy block IDs from the loaded 3x3 Anvil chunk window, handles negative chunk coordinates, and treats absent horizontal chunks as solid boundaries to prevent walking/falling into unloaded space.
- First-person perspective camera (70-degree vertical FOV) uses the player's eye position and look direction.
- Existing diagnostic preview commands remain available.

## Explicit scope / limitations
- This milestone is a playable first-person prototype only within the initial 3x3 chunk window. It does not yet stream chunks as the player moves; the window boundary is intentionally solid.
- Collision currently uses a conservative allowlist of full-block legacy IDs. Fences, doors, slabs, stairs, snow layers, ladders, water/lava swimming, and other non-full-block shapes need a dedicated collision-shape registry.
- Player orientation is initialized facing +Z; saved player yaw/pitch and player NBT position are not read yet.
- No block breaking/placing, inventory, entity AI, sound, lighting updates, or world writes.
- The existing chunk mesh renderer still uses its current static frame-zero fluid sprites and current transparency limitations.

## Safety
- World data is read-only. This milestone does not write region files, level.dat, player data, or other save contents.
