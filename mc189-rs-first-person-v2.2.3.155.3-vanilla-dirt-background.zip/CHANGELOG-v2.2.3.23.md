# v2.2.3.23 — vanilla liquid wall-exit step and scaled crosshair

## Player movement
- Reproduced the Minecraft 1.8.9 `EntityLivingBase#moveEntityWithHeading` liquid-exit branch for both water and lava.
- After a horizontal collision, the player AABB is tested at the vanilla upward offset (`motionY + 0.6 - verticalDisplacement`). The step is allowed only when the translated body has no solid collision and intersects no liquid block, matching `Entity#isOffsetPositionInLiquid` semantics.
- When the test succeeds, vanilla's `motionY = 0.3` blocks/tick is converted to this engine's blocks/second velocity as `+6.0`.
- Added regression tests for water and lava wall-exit impulses, no impulse without horizontal collision, and rejection while the offset body remains in deep water.

## Crosshair
- Kept the exact 17-pixel alpha mask from `client.jar` `textures/gui/icons.png` and corrected its presentation scale.
- The overlay now reproduces `ScaledResolution` GUI scale Auto (GUI scale 0, Unicode font disabled): a 16x16 logical-pixel sprite is rasterized at the calculated physical-pixel scale instead of always occupying 16 physical pixels.
- Scale is recalculated on window resize. Added tests for vanilla scale-factor thresholds and scaled crosshair dimensions.

## Validation
- Run `cargo fmt --all` and `cargo test --workspace` on Windows.
- Expected: 142 `mc189-app` tests and 13 `mc189-storage` tests.
- World remains read-only; no fluid simulation or save-file writes were added.
