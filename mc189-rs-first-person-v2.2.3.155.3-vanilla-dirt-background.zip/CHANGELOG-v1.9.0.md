# v1.9.0 — Multi-chunk region preview and camera pan

## Added
- `preview-textured-region <world> <client.jar> <atlas-dir> <center-chunk-x> <center-chunk-z> <radius>` command.
- Radius 1 produces a 3×3 region (up to 9 chunks); supported radius range is 0–4 (1×1 through 9×9). Missing chunks are skipped, and loaded/requested counts are printed.
- Chunk-local model geometry is translated into a common region coordinate system before the combined mesh is uploaded.
- Region statistics aggregate block, vegetation, tint, fluid, legacy-visual, UV-lock and missing-model counters across loaded chunks.
- Shared model catalog, biome colormaps and weighted selector cache across all chunks in one region build.
- Right mouse drag pans the camera in screen-relative horizontal and vertical directions. Left mouse drag remains orbit; wheel remains zoom. `R` resets pan, orbit and zoom to the initial camera.
- Added a geometry translation regression test.

## Scope and limitations
- This is an eager static region build, not a streaming terrain system. It does not yet perform asynchronous chunk loading, chunk eviction, incremental remeshing, player movement, or LOD.
- Each loaded chunk is still decoded and meshed with its four horizontal neighbors for contextual block states and boundary culling.
- Existing renderer limitations remain: fluids, animated textures, UV-lock compensation, full lighting/AO, tile entities and complete transparency sorting are not added by this milestone.
- World and client JAR inputs remain read-only.

## Validation status
- ZIP integrity and source/resource structure are checked in the build environment.
- Rust compilation and `cargo test --workspace` must be confirmed on the user's Windows environment; Cargo is unavailable in the authoring environment.
