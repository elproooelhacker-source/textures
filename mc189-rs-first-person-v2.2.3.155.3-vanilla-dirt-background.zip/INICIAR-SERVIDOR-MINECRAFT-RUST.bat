@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Minecraft 1.8.9 Rust - Servidor dedicado 20 TPS

echo ============================================================
echo   MINECRAFT 1.8.9 RUST - SERVIDOR DEDICADO v2.2.3.122
echo ============================================================
echo.
echo Este proceso carga el mundo y ejecuta la simulacion autoritativa a 20 TPS.
echo El cliente grafico aun se integrara con este protocolo en la siguiente fase.
echo Cierra Minecraft Java/UltimMC antes de abrir el mundo aqui.
echo.

set "MC189_WORLD=C:\Users\Admin\Downloads\UltimMC-Launcher-All-Versions (1)\UltimMC-Launcher-Win32\UltimMC\instances\1.8.9\.minecraft\saves\New World"
set "MC189_INPUT="
echo Ruta de la carpeta del mundo (la que contiene region y level.dat).
echo Pulsa ENTER para usar: "%MC189_WORLD%"
set /p "MC189_INPUT=Carpeta del mundo: "
if defined MC189_INPUT (
  set "MC189_INPUT=%MC189_INPUT:"=%"
  for %%I in ("%MC189_INPUT%") do set "MC189_WORLD=%%~fI"
)
if not exist "%MC189_WORLD%\level.dat" (
  echo.
  echo [ERROR] No encuentro level.dat en "%MC189_WORLD%"
  goto :fail
)

echo.
echo [1/2] Compilando servidor en modo release...
cargo build --release --package mc189-server
if errorlevel 1 goto :fail

echo.
echo [2/2] Iniciando servidor dedicado en 0.0.0.0:25566...
echo Para probar el protocolo abre otra consola y ejecuta:
echo   target\release\mc189-server.exe --probe 127.0.0.1:25566

target\release\mc189-server.exe --world "%MC189_WORLD%" --bind 0.0.0.0:25566 --radius 5
if errorlevel 1 goto :fail
goto :eof

:fail
echo.
echo [ERROR] El servidor no pudo iniciarse. Revisa el mensaje anterior.
pause
exit /b 1
