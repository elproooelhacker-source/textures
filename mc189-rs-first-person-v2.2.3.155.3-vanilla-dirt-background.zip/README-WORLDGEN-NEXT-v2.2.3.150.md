# Worldgen next — v2.2.3.150

Continues from v2.2.3.149. Adds jungle tree attempts for Jungle/Jungle Hills and Jungle Edge, ordinary jungle trees, shrub trees, jungle wood/leaves, and directional vines. The standard tree path includes the vines RNG branches and cocoa attempt draws.

`WorldGenBigTree` and `WorldGenMegaJungle` remain deferred because their internal random walks are variable. Unsupported selections are not silently replaced by another tree. Cocoa placement, melon generation, the biome's 50 vine attempts, and the remaining plant/feature stages remain pending.

No Rust compiler or Cargo is available in the build environment, so compile/tests could not be run. ZIP integrity is checked separately.
