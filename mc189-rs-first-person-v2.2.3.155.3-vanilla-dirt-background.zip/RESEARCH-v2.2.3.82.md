# Research notes — v2.2.3.82

## Primary 1.8.9 reference

- MCP 1.8.9 source browser: https://mc-packet-reference.netlify.app/1.8.9/source/
- `net.minecraft.block.Block`: https://mc-packet-reference.netlify.app/1.8.9/source/net/minecraft/block/block/
- `net.minecraft.init.Blocks`: https://mc-packet-reference.netlify.app/1.8.9/source/net/minecraft/init/blocks/

`Block.dropBlockAsItemWithChance` first calls `quantityDroppedWithBonus(fortune, world.rand)`, then for each unit rolls `world.rand.nextFloat() <= chance`, obtains the dropped item, and creates a one-item stack using `damageDropped(state)`. `Block.harvestBlock` routes Silk Touch through `canSilkHarvest()` and `createStackedBlock(state)`; otherwise it calls the ordinary drop method. `Block.spawnAsEntity` separately checks `doTileDrops` and consumes three `nextFloat()` values for the entity position. These details mean an isolated per-block RNG seed cannot reproduce the real shared world stream.

## Ore-specific source cross-check

- `BlockOre` 1.8-style source mirror: https://www.javatips.net/api/Youtube-Hacked-Client-1.8-master/minecraft/net/minecraft/block/BlockOre.java
- `BlockRedstoneOre` 1.8.9-style source mirror: https://www.javatips.net/api/Youtube-Hacked-Client-1.8-master/minecraft/net/minecraft/block/BlockRedstoneOre.java

`BlockOre` returns coal, diamond, lapis dye, emerald, and quartz for their respective ore blocks; iron and gold retain the block item. Fortune's multiplier is `max(0, nextInt(fortune + 2) - 1) + 1` only when the dropped item differs from the block item. Lapis then rolls `4 + nextInt(5)` for its base quantity. `BlockRedstoneOre` instead calculates `quantityDropped(random) + random.nextInt(fortune + 1)`, with `quantityDropped` equal to `4 + random.nextInt(2)`.

## Supplied artifact

The supplied `/mnt/data/mc189fix/client.jar` was inspected as a binary artifact. The manifest declares `net.minecraft.client.Main`; the archive contains 5,597 entries, with class files such as `auz.class` obfuscated while a small number of launcher/Realms classes retain package names. The manifest has no explicit Minecraft version field. SHA-256: `14f0d96d1a56fb4f5c3b2233d00699525893fe5ce3dcf181e7de59120595d298`.

Because the supplied jar is obfuscated and no matching MCP mapping bundle is included in the project archive, I did not pretend to extract named `BlockOre` methods directly from its obfuscated bytecode. The jar was inspected and fingerprinted locally; named method behavior was cross-referenced against the 1.8.9 MCP source browser and 1.8.x class source mirrors above. For a bytecode-level proof tied to this exact jar, the next step is to obtain the exact 1.8.9 MCP/SRG mapping set and decompile the mapped class names from this SHA-256 artifact.
