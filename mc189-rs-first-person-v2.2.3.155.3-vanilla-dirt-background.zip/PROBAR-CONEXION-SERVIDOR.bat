@echo off
setlocal
cd /d "%~dp0"
title Minecraft 1.8.9 Rust - Prueba de protocolo
if not exist "target\release\mc189-server.exe" (
  echo [ERROR] Primero compila el proyecto con INICIAR-SERVIDOR-MINECRAFT-RUST.bat
  pause
  exit /b 1
)
set "MC189_ADDRESS=127.0.0.1:25566"
set /p "MC189_ADDRESS=Direccion del servidor [%MC189_ADDRESS%]: "
if not defined MC189_ADDRESS set "MC189_ADDRESS=127.0.0.1:25566"
target\release\mc189-server.exe --probe "%MC189_ADDRESS%"
echo.
pause
