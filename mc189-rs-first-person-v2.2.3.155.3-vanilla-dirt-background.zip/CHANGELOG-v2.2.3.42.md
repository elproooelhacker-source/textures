# v2.2.3.42 — Minecraft 1.8.9 title screen foundation

- Added a native winit/wgpu title screen entry point: `main-menu <saves> <client.jar> <atlas-dir>`.
- Loads all six original 1.8.9 title panorama faces, the original title logo, button widget texture, and ASCII font from `client.jar`.
- Renders an animated cubemap panorama with subtle camera movement, multi-tap softening, and vignette.
- Adds the requested three main actions: Singleplayer, Options, and Quit Game. Multiplayer is intentionally omitted.
- Singleplayer opens a read-only world list; selecting a world starts the existing world renderer.
- Options opens a simple placeholder page with a Back button; detailed option controls are not implemented yet.
- Mouse hover/click and Escape navigation are supported.
- Adds unit tests for the requested main-menu action set and button hit bounds.
