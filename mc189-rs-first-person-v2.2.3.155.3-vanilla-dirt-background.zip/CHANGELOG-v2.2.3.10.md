# v2.2.3.10

- Corrected the first-person Steve arm pose: the view-space cuboid is now rotated diagonally inward instead of appearing as a vertical pillar.
- Added mild pitch and yaw to the arm pose for visible depth/foreshortening while retaining the existing 3D geometry and classic 64x32/64x64 skin UV handling.
- Added a regression assertion that the upper/hand end leans toward screen center.
- Did not change player movement, collision, world rendering, chunk streaming, or camera interpolation.
