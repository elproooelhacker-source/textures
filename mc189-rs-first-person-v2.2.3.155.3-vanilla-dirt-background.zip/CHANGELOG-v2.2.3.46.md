# v2.2.3.46

- Centered title-screen buttons from the same UI center coordinate used by the Minecraft logo; added a regression test proving both centers coincide.
- Replaced the single sharp cubemap lookup with a 3x3 Gaussian panorama filter to reduce visible pixelation and approximate the soft title-screen sampling used by vanilla 1.8.9.
- Preserved the original six 256x256 panorama faces from client.jar. A high-resolution reconstruction source was identified (Minecraft@Home seed 2151901553968352745), but the source images could not be fetched into this build environment, so no upscaled or fabricated replacement textures are bundled.
- The separate-process gameplay launch is unchanged; same-window menu-to-gameplay transition still requires a renderer/event-loop refactor.
