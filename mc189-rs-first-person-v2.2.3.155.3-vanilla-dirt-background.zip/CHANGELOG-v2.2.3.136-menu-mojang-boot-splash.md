# v2.2.3.136 — menú: pantalla de arranque Mojang

## Objetivo

Iniciar la transición hacia una reproducción fiel del ciclo visual de Minecraft Java 1.8.9, comenzando por el splash de Mojang que `Minecraft.java#drawSplashScreen` dibuja antes de abrir `GuiMainMenu`.

## Cambios

- Se carga `assets/minecraft/textures/gui/title/mojang.png` directamente desde el `client.jar` indicado al lanzador.
- Se valida que la textura original sea de 256x256 píxeles.
- Antes del menú principal se presenta el fondo negro y la textura Mojang original, centrada en el lienzo lógico 854x480, igual que el método vanilla `drawSplashScreen`.
- La pantalla inicial es una fase del bucle de eventos; no bloquea el hilo de ventana y no acepta clics/teclas hasta que termina.
- Después de 1,4 segundos se sustituye por el menú principal existente, manteniendo el panorama, logo, widgets y splash text obtenidos del JAR.
- Se añadió una prueba unitaria de dimensiones, fondo negro y centrado de la textura.
- El BAT de inicio identifica ahora la versión 2.2.3.136.

## Referencia MCP 1.8.9

- `net.minecraft.client.Minecraft#drawSplashScreen(TextureManager)`
- `net.minecraft.client.Minecraft#locationMojangPng`
- Recurso: `assets/minecraft/textures/gui/title/mojang.png`

## Alcance honesto

Esta entrega implementa la fase visual de arranque Mojang, no afirma que todo el menú ya sea una réplica completa. El selector de mundos, las opciones, la lista multijugador, las pantallas de conexión y el progreso real de carga siguen necesitando portar sus clases vanilla y conectar sus estados al cliente Rust. El multijugador PLAY persistente de v2.2.3.135 se conserva sin cambios intencionales.

## Verificación

- Se comprobó que el recurso `mojang.png` ya incluido en los assets del proyecto mide 256x256 y corresponde al recurso que el código vanilla solicita.
- Se añadió test de centrado del splash.
- No se pudo ejecutar Cargo en el entorno de empaquetado (no hay `cargo`/`rustc` disponibles); ejecutar `cargo test --workspace --offline --locked` en Windows antes de considerar esta versión compilada.
