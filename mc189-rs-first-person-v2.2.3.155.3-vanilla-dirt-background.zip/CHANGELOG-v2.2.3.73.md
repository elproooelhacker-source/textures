# v2.2.3.73 — first-person generated item alignment and chat layer order

- Centered generated item-layer geometry around the model origin, matching Minecraft 1.8.9 ItemLayerModel coordinates before applying each item model's `display.firstperson` transform. The diamond sword transform was checked directly in the library `client.jar`: rotation `[0, -135, 25]`, translation `[0, 4, 2]`, scale `[1.7, 1.7, 1.7]`.
- Split chat rendering into a transparent overlay drawn after the hotbar selected-slot frame, matching the vanilla `GuiIngame` ordering so chat glyphs are not hidden behind the selector.
- Kept hotbar selection as its separate GPU sprite; selecting slots still does not require re-rasterizing the entire HUD texture.
