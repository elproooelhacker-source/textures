# v2.2.3.92 — Gameplay drop entities, ground response and inventory pickup

- Connected successful block breaks to `drop_registry::resolve_drops_with_rng` and `DroppedItem::spawn_from_drop`.
- Drop generation is gated by `can_harvest`, so an ineffective tool can break a block slowly without receiving harvest-only drops.
- Added a persistent session `JavaRandom` stream shared between drop rolls and item spawn offsets/velocities. This is not yet the world's persisted `World.rand` state.
- Added 20 Hz item-entity updates in the gameplay loop: gravity/drag/age/pickup delay, a basic loaded-block ground response, and expiry removal.
- Added nearby item+metadata stack merging with a 64-item cap.
- Added merge-first inventory insertion and item-ID-to-registry-name mapping for supported legacy item IDs. Picked-up amounts are removed from the world entity; remainders stay in the world.

## Explicit limitations

- Dropped items are simulated but are not yet rendered as visible 3D entities.
- Collision is a simplified ground check, not full `EntityItem` AABB collision; water/lava, entity pushing, and exact vanilla merge timing are not implemented.
- The session RNG is not serialized into the world's `Random` state, and inventory persistence to player NBT is not implemented.
- The item registry-name mapping intentionally covers common drop IDs; unknown IDs remain as world entities and cannot be inserted into inventory yet.
- Cargo/rustc are unavailable in this environment, so compilation and Rust tests remain unverified. ZIP integrity is checked separately.
