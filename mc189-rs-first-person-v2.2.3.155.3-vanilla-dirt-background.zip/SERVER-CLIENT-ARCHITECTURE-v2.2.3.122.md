# v2.2.3.122 — server-authoritative mining foundation

## Current single-player flow

The integrated server thread now owns the mining controller and block-break decision at 20 TPS. The graphical client sends attack-held intent and a provisional held-tool descriptor. The server does not accept a client-provided block target: it raycasts from its authoritative player eye/look vector against its own loaded collision world, resolves the legacy block state and hardness, and advances the mining controller.

On completion, the server captures the original `(block_id, metadata)`, resolves the drop table using its own JavaRandom instance initialized from the world's `RandomSeed`, and commits the target block to air before publishing an `AuthoritativeMiningEvent`. The event carries the target, original block state, and server-computed drops. The client consumes it to trigger sound/crack cleanup, hide the mesh immediately, and submit the neighbor-aware lighting/mesh transaction. The returned chunk snapshots are then mirrored back to the server collision cache.

## MCP 1.8.9 source mapping

- `minecraft/net/minecraft/client/multiplayer/PlayerControllerMP.java`: `clickBlock`, `onPlayerDamageBlock`, `resetBlockRemoving`, and `onPlayerDestroyBlock` establish client attack cadence, progress display, and break feedback.
- `minecraft/net/minecraft/server/management/ItemInWorldManager.java`: `onBlockClicked`, `updateBlockRemoving`, `blockRemoving`, and `tryHarvestBlock` establish server-side validation, mining progress, and harvest.
- `minecraft/net/minecraft/network/NetHandlerPlayServer.java`: `processPlayerDigging` shows the C07 action split (`START_DESTROY_BLOCK`, `ABORT_DESTROY_BLOCK`, `STOP_DESTROY_BLOCK`) and server-side distance/build-height checks.
- `minecraft/net/minecraft/block/Block.java`: `getPlayerRelativeBlockHardness` is the source for the hardness/tool-speed formula.
- `minecraft/net/minecraft/entity/item/EntityItem.java` and `minecraft/net/minecraft/entity/player/InventoryPlayer.java` remain the next sources for server-owned item physics, pickup and insertion.

## Ownership boundary after this increment

**Server-owned now:** authoritative player movement/collision, server raycast target selection for held attack, mining progress/controller, block-break acceptance, original block state capture, drop-table resolution, and immediate air mutation in the integrated server world. Mining and drop rules are compiled into `mc189-server`; the app uses compatibility re-exports.

**Still client-owned / transitional:** the held-tool descriptor is supplied by the client because inventory authority has not yet moved; visual dropped-item entity creation and physics, merge, pickup, inventory mutations and GUI interaction remain in `mc189-app`. The client still runs the asynchronous chunk-lighting/mesh derivation worker and sends resulting chunk snapshots to the integrated server. The dedicated TCP server protocol does not yet expose mining actions.

The server drop RNG is seeded from `level.dat` `RandomSeed`, but it is not yet the continuous historical `World.rand` state from vanilla; exact parity requires moving all world-random consumers and entity spawn random calls to one server-owned stream.

## Next migration steps

1. Move `InventoryPlayer` state and slot mutations into `mc189-server`; client GUI becomes a replica issuing slot-click/held-slot commands.
2. Move `EntityItem` creation, movement, collision, merge, despawn and pickup to the 20 TPS server. The server should apply `InventoryPlayer.addItemStackToInventory` semantics and send item/inventory snapshots.
3. Move manual Q/Ctrl+Q drops and tool durability consumption to server commands.
4. Convert mining to explicit C07-like start/abort/stop actions and validate held item against server inventory rather than client-supplied tool data.
5. Route the same commands through the dedicated TCP protocol and implement graphical join-server.

## Validation status

Static inspection and archive checks only. `cargo`, `rustc` and `rustfmt` are not installed in the authoring environment, so no compilation or runtime test result is claimed. Run `cargo test --workspace` on the Windows machine before replacing the prior test build.
