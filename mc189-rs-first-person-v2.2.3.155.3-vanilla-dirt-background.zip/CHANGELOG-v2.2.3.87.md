# v2.2.3.87 — decoded live chunk mutation

## Added
- `ChunkData::set_block(x, y, z, id, metadata)` mutates the decoded Anvil representation in memory.
- Supports legacy 12-bit block IDs and 4-bit metadata.
- Materializes absent sections only when writing a non-air block; absent sections remain implicit air otherwise.
- Keeps section order sorted by Y and validates coordinates, IDs, metadata, and decoded array lengths before mutation.
- `LoadedWorldCollision::set_block_local` maps first-person session-local coordinates through the origin chunk into the correct loaded `ChunkData`, so collision queries see the edited state immediately.
- Adds regression tests for section creation, ID/metadata writes, block removal, and invalid inputs.

## Not yet integrated
- No mouse-hold mining or progress/crack overlay yet.
- No CPU/GPU chunk remesh after edits.
- No save-on-break or derived HeightMap/light recalculation. Use the explicit `set-world-block` command for persisted edits.
- No dropped-item entity lifecycle/pickup.

The Anvil persistence layer remains from v2.2.3.86. Rust tests are included but were not executed in this environment.
