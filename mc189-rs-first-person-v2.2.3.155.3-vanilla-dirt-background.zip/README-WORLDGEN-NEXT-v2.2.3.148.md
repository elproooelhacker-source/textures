# World generation continuation — v2.2.3.148

Base: v2.2.3.147.

This version adds the roofed-forest dark-oak generator from MCP 1.8.9 and the biome's 4x4 tree-attempt layout. The previous oak, birch and ordinary taiga tree implementations remain in place.

Next source-level targets:
1. `WorldGenBigMushroom` so the roofed-forest branch consumes the correct random stream.
2. `WorldGenMegaPineTree` plus `WorldGenHugeTrees` for mega taiga.
3. Canopy/forest post-generation details and all other biome decoration generators.

Do not treat the currently ported feature prefix as complete or bit-identical.
