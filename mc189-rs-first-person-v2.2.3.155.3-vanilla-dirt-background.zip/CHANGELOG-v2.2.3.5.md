# v2.2.3.5 — flower and leaf cutout rendering

## Fixed / improved
- Expanded the dedicated alpha-cutout vegetation path from crossed grass and ferns to every vanilla 1.8.9 flower texture, including double-height plants and sunflower front/back faces.
- Added all six vanilla leaf textures (oak, spruce, birch, jungle, acacia, and dark oak) to the cutout path so transparent texels no longer participate in alpha blending or write blended depth.
- Added all six sapling textures because they use the same crossed-plane model construction as flowers and tall grass.
- Kept the existing replacement blend, alpha discard, back-face culling, depth writes, and strict `Less` depth comparison. The texture's alpha is still sampled from the original client JAR atlas.

## Preserved
- First-person movement, jump handling, camera, collision, loaded chunks, and read-only world access are unchanged.
- No world save or client JAR is modified.

## Validation
- Expanded the renderer unit test to cover flowers, double plants, leaves, saplings, and negative cases for ordinary opaque blocks.
- The original Minecraft 1.8.9 JAR was checked for all routed texture files; their alpha channels are binary for most foliage, with the peony top texture retaining a few antialiased alpha levels handled by the existing `0.1` alpha discard threshold.
