# v2.2.3.129 — dropped EntityItem persistence

## Implemented

- Integrated-server startup reads `Level.Entities` from the chunks already loaded for the play area and reconstructs vanilla `Item` entities. Streamed chunks are checked when the integrated server receives them, so saved drops in newly loaded chunks are restored too.
- Entity NBT uses the vanilla 1.8.9 `Item` entity layout: `Pos`, `Motion`, `Rotation`, `Age`, `PickupDelay`, `Health`, and the nested `Item` stack (`id`, `Count`, `Damage`, optional `tag`). A `RustEntityId` plus UUID fields preserve identity across this native runtime's saves.
- The deferred persistence worker groups server-owned item snapshots by absolute world chunk, updates each chunk's `Level.Entities` list, and preserves unrelated chunk NBT. Empty lists clear old entities from chunks where items previously existed.
- Item positions are converted between origin-relative gameplay coordinates and absolute Anvil world coordinates, including negative chunk coordinates.
- Item snapshots participate in the five-minute autosave and the graceful-close save barrier. The final snapshot is frozen while the final disk flush completes so the continuously ticking item age does not prevent shutdown.
- Added an EntityItem NBT round-trip unit test for identity, stack data, NBT payload, position, motion, age, and pickup delay.

## Scope

This is only persistence for dropped `EntityItem` objects. It does not add mob persistence, tile-entity ticking, world time/weather persistence, or a general entity framework. It does not change mining, inventory actions, item physics, or rendering behavior.

## Validation

- Source changes were reviewed and packaged.
- `cargo test --workspace` and Windows release compilation could not be executed in this authoring environment because `cargo`/`rustc` are unavailable. The new unit test is included but has not been run here.
- ZIP archive integrity is checked after packaging. The first Windows launch should compile the project; if compilation fails, the launcher should stop and retain the error output.
