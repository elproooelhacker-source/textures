# Client/server ownership after v2.2.3.125

## Integrated server owns

- Player movement/collision and mining at fixed 20 TPS.
- `PlayerInventory`, selected hotbar slot, cursor stack, armor slots and supported inventory commands.
- Block-break acceptance, drop-table resolution, `World.rand` continuation for block-drop positions, and block-generated `EntityItem` creation.
- Block-generated item entity IDs, age, pickup delay, gravity, movement, collision, push-out, friction, liquid acceleration, nearby stack merging, despawn and player pickup. Provisional drops remain unmergeable and uncollectable until the corresponding in-memory block-edit transaction is accepted.
- Pickup eligibility, inventory insertion (including partial insertion and NBT preservation), entity count reduction/removal, and the pickup event sent to the renderer.
- Deferred Anvil persistence writes.

## Client owns

- wgpu rendering, camera, HUD, GUI textures, pointer coordinates, item icons, animation presentation and render interpolation.
- Movement and mining intent submission, supported inventory command submission, and snapshot consumption.
- Render-only copies of server-owned block-drop entities. The client does not simulate, collect, award, reduce or remove those entities.
- Pickup animation and `random.pop` audio are presentation effects driven by confirmed server transfer events.
- Transitional local Q/Ctrl+Q dropped items; these are not yet part of the authoritative entity registry and will migrate with the related inventory commands.
- Client-side chunk lighting/mesh derivation and chunk snapshot submission remain transitional; chunk ownership is not yet complete.

## Server snapshots

`IntegratedSnapshot` contains the authoritative player, optional revisioned inventory, a full list of `EntityItemSnapshot` values, and confirmed pickup events. Pickup events are retained by the server until a snapshot carrying them is accepted by the snapshot queue, so a temporarily full queue cannot lose the inventory-transfer presentation event. Entity snapshots include stable entity IDs, stack identity/metadata/NBT, previous/current position, velocity, age, pickup delay and hover phase. The client can therefore interpolate presentation without advancing gameplay state.

## Remaining migration order

1. **EntityItem lifecycle:** server-owned spawn, fixed-tick simulation, collision, merge and despawn.
2. **Pickup (this increment):** server checks player/entity AABB overlap and pickup delay, inserts into server-owned inventory, preserves partial remainders, removes fully collected entities, and publishes revisioned inventory/entity snapshots plus confirmed pickup events.
3. Q/Ctrl+Q drops and `/give`/`/clear` as server commands; remove local inventory mutations.
4. Tool durability and remaining player/item gameplay state.
5. Audit and migrate world/chunk authority and persistence boundaries.
6. Close the client/server migration with regression tests and remove transitional local gameplay paths.
7. Add server-authoritative block placement with MCP 1.8.9 checks and reconciled client visuals.
8. Implement the external Minecraft 1.8.9 protocol (protocol 47) only after the gameplay ownership boundary is stable.

The internal dedicated-server JSON-line transport is not Minecraft protocol 47.
