@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "MC189_PROJECT_ROOT=%~dp0"
title Minecraft 1.8.9 Rust - Lanzador de pruebas

echo ============================================================
echo   MINECRAFT 1.8.9 RUST - LANZADOR DE PRUEBAS v2.2.3.138
echo ============================================================
echo.
echo Este lanzador compila el proyecto y abre el menu nativo.
echo Se necesita Rust estable, conexion a Internet para descargar
echo dependencias la primera vez y el client.jar de Minecraft 1.8.9.
echo.

rem Puedes definir estas dos variables antes de ejecutar el BAT, o
rem introducir las rutas cuando el lanzador las solicite.
if not defined MC189_GAME_DIR set "MC189_GAME_DIR=C:\Users\Admin\Downloads\UltimMC-Launcher-All-Versions (1)\UltimMC-Launcher-Win32\UltimMC\instances\1.8.9\.minecraft"
if not defined MC189_CLIENT_JAR if exist "C:\Users\Admin\Documents\client.jar" set "MC189_CLIENT_JAR=C:\Users\Admin\Documents\client.jar"
set "MC189_INSTANCE_ROOT=%MC189_GAME_DIR%"

echo Ruta de la carpeta .minecraft (la que contiene saves).
echo Para UltimMC tambien puedes pegar la carpeta de la instancia;
echo si contiene una subcarpeta .minecraft, el lanzador la detecta.
echo Pulsa ENTER para usar: "%MC189_GAME_DIR%"
set "MC189_INPUT="
set /p "MC189_INPUT=Carpeta de juego: "
if defined MC189_INPUT for %%I in ("%MC189_INPUT%") do set "MC189_GAME_DIR=%%~fI"
set "MC189_INSTANCE_ROOT=%MC189_GAME_DIR%"

if not exist "%MC189_GAME_DIR%\saves" if exist "%MC189_GAME_DIR%\.minecraft\saves" set "MC189_GAME_DIR=%MC189_GAME_DIR%\.minecraft"
if not exist "%MC189_GAME_DIR%\saves" (
    echo.
    echo [ERROR] No encuentro la carpeta saves en:
    echo         "%MC189_GAME_DIR%"
    echo Abre la carpeta de tu instancia de UltimMC y pega esa ruta,
    echo o pega directamente la ruta de su subcarpeta .minecraft.
    goto :fail
)
set "MC189_SAVES_DIR=%MC189_GAME_DIR%\saves"

rem Buscar las ubicaciones frecuentes de client.jar en lanzadores vanilla y UltimMC.
if not defined MC189_CLIENT_JAR if exist "%MC189_GAME_DIR%\versions\1.8.9\1.8.9.jar" set "MC189_CLIENT_JAR=%MC189_GAME_DIR%\versions\1.8.9\1.8.9.jar"
if not defined MC189_CLIENT_JAR if exist "%MC189_GAME_DIR%\versions\1.8.9\1.8.9-client.jar" set "MC189_CLIENT_JAR=%MC189_GAME_DIR%\versions\1.8.9\1.8.9-client.jar"
if not defined MC189_CLIENT_JAR if exist "%MC189_GAME_DIR%\libraries\net\minecraft\client\1.8.9\client-1.8.9.jar" set "MC189_CLIENT_JAR=%MC189_GAME_DIR%\libraries\net\minecraft\client\1.8.9\client-1.8.9.jar"
if not defined MC189_CLIENT_JAR if exist "%MC189_INSTANCE_ROOT%\libraries\net\minecraft\client\1.8.9\client-1.8.9.jar" set "MC189_CLIENT_JAR=%MC189_INSTANCE_ROOT%\libraries\net\minecraft\client\1.8.9\client-1.8.9.jar"
if not defined MC189_CLIENT_JAR if exist "%MC189_GAME_DIR%\..\libraries\net\minecraft\client\1.8.9\client-1.8.9.jar" set "MC189_CLIENT_JAR=%MC189_GAME_DIR%\..\libraries\net\minecraft\client\1.8.9\client-1.8.9.jar"
if not defined MC189_CLIENT_JAR if exist "%~dp0client.jar" set "MC189_CLIENT_JAR=%~dp0client.jar"

rem No capturar la entrada dentro de un bloque entre parentesis:
rem CMD expande %variables% antes de ejecutar SET /P y terminaria usando "".
if defined MC189_CLIENT_JAR goto :jar_check

 echo.
echo No pude localizar automaticamente el JAR de Minecraft 1.8.9.
echo En UltimMC suele estar en la carpeta libraries o versions de la instancia.
echo Tambien puedes usar el client.jar de tu instalacion 1.8.9.
echo Pega la ruta con o sin comillas; ambas formas son aceptadas.
set "MC189_JAR_INPUT="
set /p "MC189_JAR_INPUT=Ruta completa del client.jar: "
if not defined MC189_JAR_INPUT goto :fail
rem Normalizar comillas opcionales y resolver rutas relativas/absolutas con espacios.
set "MC189_JAR_INPUT=%MC189_JAR_INPUT%"
set "MC189_JAR_INPUT=%MC189_JAR_INPUT:"=%"
for %%I in ("%MC189_JAR_INPUT%") do set "MC189_CLIENT_JAR=%%~fI"

:jar_check
echo JAR seleccionado: "%MC189_CLIENT_JAR%"
if not exist "%MC189_CLIENT_JAR%" (
    echo.
    echo [ERROR] No existe el JAR indicado: "%MC189_CLIENT_JAR%"
    goto :fail
)

echo.
echo Carpeta de mundos: "%MC189_SAVES_DIR%"
echo Client JAR:       "%MC189_CLIENT_JAR%"
echo.
echo [AUDIO] El client.jar no suele incluir los OGG originales; UltimMC los guarda en su carpeta compartida assets.
set "MC189_ASSETS_ROOT="
rem UltimMC can name the asset index differently; accept any JSON index with objects.
if exist "%MC189_GAME_DIR%\assets\indexes\*.json" if exist "%MC189_GAME_DIR%\assets\objects" set "MC189_ASSETS_ROOT=%MC189_GAME_DIR%\assets"
if not defined MC189_ASSETS_ROOT if exist "%MC189_INSTANCE_ROOT%\assets\indexes\*.json" if exist "%MC189_INSTANCE_ROOT%\assets\objects" set "MC189_ASSETS_ROOT=%MC189_INSTANCE_ROOT%\assets"
if not defined MC189_ASSETS_ROOT if exist "%MC189_GAME_DIR%\..\assets\indexes\*.json" if exist "%MC189_GAME_DIR%\..\assets\objects" for %%I in ("%MC189_GAME_DIR%\..\assets") do set "MC189_ASSETS_ROOT=%%~fI"
if not defined MC189_ASSETS_ROOT if exist "%MC189_GAME_DIR%\..\..\assets\indexes\*.json" if exist "%MC189_GAME_DIR%\..\..\assets\objects" for %%I in ("%MC189_GAME_DIR%\..\..\assets") do set "MC189_ASSETS_ROOT=%%~fI"
if not defined MC189_ASSETS_ROOT if exist "%MC189_GAME_DIR%\..\..\..\assets\indexes\*.json" if exist "%MC189_GAME_DIR%\..\..\..\assets\objects" for %%I in ("%MC189_GAME_DIR%\..\..\..\assets") do set "MC189_ASSETS_ROOT=%%~fI"
if not defined MC189_ASSETS_ROOT if exist "%MC189_INSTANCE_ROOT%\..\assets\indexes\*.json" if exist "%MC189_INSTANCE_ROOT%\..\assets\objects" for %%I in ("%MC189_INSTANCE_ROOT%\..\assets") do set "MC189_ASSETS_ROOT=%%~fI"
if not defined MC189_ASSETS_ROOT if exist "%MC189_INSTANCE_ROOT%\..\..\assets\indexes\*.json" if exist "%MC189_INSTANCE_ROOT%\..\..\assets\objects" for %%I in ("%MC189_INSTANCE_ROOT%\..\..\assets") do set "MC189_ASSETS_ROOT=%%~fI"
if not defined MC189_ASSETS_ROOT if exist "%MC189_GAME_DIR%\assets\virtual\legacy\sounds" set "MC189_ASSETS_ROOT=%MC189_GAME_DIR%\assets"
if not defined MC189_ASSETS_ROOT if exist "%MC189_INSTANCE_ROOT%\assets\virtual\legacy\sounds" set "MC189_ASSETS_ROOT=%MC189_INSTANCE_ROOT%\assets"
if not defined MC189_ASSETS_ROOT if exist "%APPDATA%\.minecraft\assets\indexes\*.json" if exist "%APPDATA%\.minecraft\assets\objects" set "MC189_ASSETS_ROOT=%APPDATA%\.minecraft\assets"
if defined MC189_ASSETS_ROOT (
    echo [AUDIO] Candidato de assets: "%MC189_ASSETS_ROOT%"
    if exist "%MC189_ASSETS_ROOT%\objects" (echo [AUDIO] Almacen de objetos OGG encontrado.) else (echo [AUDIO] AVISO: falta assets\objects.)
    echo [AUDIO] Rust extraera el paquete OGG 1.8.9 completo a runtime\audio\assets dentro del proyecto.
) else (
    echo [AUDIO] AVISO: no encontre un indice JSON mas objetos OGG; el cliente buscara el almacen virtual legacy y mostrara el diagnostico de audio.
)
echo.

set "MC189_HAS_WORLD="
set "MC189_WORLD_COUNT=0"
for /d %%D in ("%MC189_SAVES_DIR%\*") do if exist "%%~fD\level.dat" (set "MC189_HAS_WORLD=1" & set /a MC189_WORLD_COUNT+=1)
if not defined MC189_HAS_WORLD (
    echo [ERROR] No encontre mundos con level.dat dentro de saves.
    echo Comprueba que elegiste la instancia correcta y que el mundo esta ahi.
    goto :fail
)

where cargo >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Rust/Cargo no esta instalado o no esta en PATH.
    echo Instala Rust estable desde https://rustup.rs y vuelve a abrir este BAT.
    echo En Windows selecciona la toolchain MSVC predeterminada.
    goto :fail
)
where rustc >nul 2>nul
if errorlevel 1 (
    echo [ERROR] No encuentro rustc. Reinstala/activa la toolchain estable de Rust.
    goto :fail
)

echo.
echo IMPORTANTE: cierra Minecraft/UltimMC antes de continuar.
echo Este cliente modifica el mismo mundo .mca y no debe abrirse a la vez
echo que Minecraft Java. Se recomienda crear una copia de seguridad.
echo.
set "MC189_BACKUP_CHOICE=Y"
set /p "MC189_BACKUP_CHOICE=Copiar todos tus mundos antes de probar? [S/n]: "
if /I not "%MC189_BACKUP_CHOICE%"=="N" if /I not "%MC189_BACKUP_CHOICE%"=="NO" goto :backup

echo.
echo [AVISO] Has omitido la copia de seguridad. Los bloques minados se guardaran
echo directamente en el mundo seleccionado.
goto :build

:backup
set "MC189_BACKUP_STAMP="
for /f %%I in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd-HHmmss" 2^>nul') do set "MC189_BACKUP_STAMP=%%I"
if not defined MC189_BACKUP_STAMP set "MC189_BACKUP_STAMP=%RANDOM%-%RANDOM%"
set "MC189_BACKUP_DIR=%MC189_GAME_DIR%\saves-backup-mc189-%MC189_BACKUP_STAMP%"
echo.
echo Creando copia en:
echo "%MC189_BACKUP_DIR%"
robocopy "%MC189_SAVES_DIR%" "%MC189_BACKUP_DIR%" /E /COPY:DAT /DCOPY:DAT /R:1 /W:1
if errorlevel 8 (
    echo.
    echo [ERROR] Robocopy no pudo completar la copia. No iniciare el juego.
    goto :fail
)
echo Copia de seguridad completada.

:build
echo.
echo [1/2] Compilando mc189-app en modo release...
cargo build --release --package mc189-app --offline
if errorlevel 1 (
    echo.
    echo [ERROR] La compilacion fallo. No se ha iniciado el juego.
    echo Copia el error completo de arriba para poder corregirlo.
    goto :fail
)

if not exist "%~dp0runtime\block-atlas" mkdir "%~dp0runtime\block-atlas"
echo.
echo [2/2] Iniciando Minecraft 1.8.9 Rust...
if %MC189_WORLD_COUNT% GTR 7 (
    echo Se detectaron %MC189_WORLD_COUNT% mundos. Abriendo selector completo en consola.
    "%~dp0target\release\mc189-app.exe" select-world "%MC189_SAVES_DIR%" "%MC189_CLIENT_JAR%" "%~dp0runtime\block-atlas"
) else (
    echo Abriendo el menu nativo. Multiplayer permite guardar servidores y probar el handshake offline.
    "%~dp0target\release\mc189-app.exe" main-menu "%MC189_SAVES_DIR%" "%MC189_CLIENT_JAR%" "%~dp0runtime\block-atlas"
)
set "MC189_EXIT_CODE=%ERRORLEVEL%"
if not "%MC189_EXIT_CODE%"=="0" (
    echo.
    echo [ERROR] El juego termino con codigo %MC189_EXIT_CODE%.
    echo Si aparecio un error de GPU, actualiza el controlador grafico.
    echo Si falta un recurso, comprueba que el client.jar sea realmente 1.8.9.
) else (
    echo.
    echo Sesion cerrada correctamente.
)
echo.
pause
exit /b %MC189_EXIT_CODE%

:fail
echo.
pause
exit /b 1
