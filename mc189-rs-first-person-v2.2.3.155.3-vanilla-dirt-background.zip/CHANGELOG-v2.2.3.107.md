# v2.2.3.107 — workspace test compile fix

## Fixes

- Corrected the Fortune test-loop types in `drop_registry.rs`: the public drop API accepts Fortune as `u8`, and the JavaRandom bounds are explicitly converted to `u32`.
- Corrected the Nether Wart expected-count assertion to compare `u8` values directly instead of casting the item count to `u32`.
- No gameplay or lighting algorithm changes from v2.2.3.106.

## Verification

- Source-level checks confirm both compiler-reported mismatches are corrected.
- This environment does not contain `cargo` or `rustc`, so a fresh workspace build and test run could not be executed here. Run `EJECUTAR-PRUEBAS-RUST.bat` on Windows to verify the full workspace.
