# v2.2.3.27 — smooth-lighting regression fixture geometry

Corrects the test quad's Y coordinates to match the production output of `transform_instance`: a block at Y=65 has its top face at Y=66. The outward lighting sample therefore reads the intended voxel at Y=66, where the fixture stores SkyLight 6/15 in section-local Y=2.

This is a test-fixture correction only; no runtime lighting code is changed. The test continues to verify negative chunk X/Z world-coordinate sampling. Full vanilla 1.8.9 ambient occlusion and lightmap parity remain unfinished.
