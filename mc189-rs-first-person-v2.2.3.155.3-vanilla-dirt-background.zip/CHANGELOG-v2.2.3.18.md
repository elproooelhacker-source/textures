# v2.2.3.18 — compile fix for biome tint calls

## Fix
- Borrow the loaded chunk map when calling `biome_tint_at_world` for foliage and grass tint. This fixes the two Rust E0308 type mismatches reported while compiling v2.2.3.17.

## Scope
- No gameplay, liquid physics, rendering, crosshair, texture, or world-data behavior changed.
- All v2.2.3.17 features are retained unchanged.
