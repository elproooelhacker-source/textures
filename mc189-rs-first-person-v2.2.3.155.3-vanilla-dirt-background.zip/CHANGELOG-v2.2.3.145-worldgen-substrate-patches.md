# v2.2.3.145 — Biome substrate patches

## Implemented
- Added the legacy block representation for clay (block ID 82).
- Ported the shared circular patch walk used by MCP `WorldGenClay` and `WorldGenSand`.
- Added the three sand attempts, one clay attempt, and one gravel-as-sand attempt from the default `BiomeDecorator.genDecorations` prefix, preserving the order of coordinate RNG draws.
- Added a combined entry point that runs ores, then substrate patches, using one shared `JavaRandom` stream and a writable 3x3 chunk region.
- Implemented the top-solid-or-liquid position convention based on `World.getTopSolidOrLiquidBlock` for represented terrain blocks.

## Important limits
- This is not a complete `BiomeDecorator`: trees, flowers, grass, mushrooms, reeds, pumpkins, cactus, water lilies, dead bushes, and biome-specific decoration are not implemented here.
- World height/biome behavior is only as accurate as the current terrain representation. Leaves and several block materials are not represented.
- `ChunkProviderGenerate.populate()` still needs the actual structure, lake, dungeon, spawning, freeze/snow, and feature-generator implementations in exact source order.
- No claim of bit-identical world generation is made.

## Validation
- ZIP archive integrity checked after packaging.
- Rust compilation/tests were not run because `cargo`/`rustc` are unavailable in the build environment.
