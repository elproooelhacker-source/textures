# v2.2.3.83 — block drop rule fidelity pass

## Scope
A narrow continuation of the standalone 1.8.9 drop registry. No rendering, inventory, world mutation, or mining-input code was changed.

## Corrections and additions
- Gravel (block 13): implements the vanilla flint roll `nextInt(10 - 3 * fortune) == 0`; otherwise drops gravel.
- Old leaves (18): models the sapling chance, jungle's lower sapling rate, oak-only apple roll, and Fortune denominator adjustments in vanilla call order.
- New leaves (161): models sapling drops and variant metadata (acacia/dark oak item metadata 4/5); shears harvest preserves the leaf item variant metadata.
- Tall grass (31): models the Fortune-dependent number of independent seed trials and the 1-in-8 wheat-seed chance for each trial.
- Dead bush (32): no normal item drop; shears harvest yields the dead-bush block.
- Wheat (59): age-sensitive seed/wheat drop and mature bonus seed trials.
- Carrots (141) and potatoes (142): age-sensitive crop item; mature potatoes have the additional 1-in-50 poisonous-potato roll.
- Glowstone (89): quantity uses the base 2–4 roll plus Fortune bonus roll, clamped to 1–4.
- Silk Touch metadata is normalized for old/new leaves to the item metadata represented by the block's `createStackedBlock` implementation.
- DropStatus now distinguishes a known probabilistic empty result from an unsupported block rule.

## Source basis
MCP 1.8.9 `Block.java`, `BlockLeaves.java`, `BlockOldLeaf.java`, `BlockCrops.java`, `BlockPotato.java`, and `BlockTallGrass.java`. See `RESEARCH-v2.2.3.83.md` for source links and the inspected `client.jar` notes.

## Accuracy boundary
This remains a rule-by-rule expansion, not full vanilla drop parity. The resolver is not yet wired into the actual break-block event, world RNG lifecycle, entity spawn physics, inventory pickup, or Anvil persistence. The `client.jar` is obfuscated and does not contain named `net/minecraft/block` classes; exact direct bytecode-to-MCP class mapping still requires the matching mappings/SRG set. Do not interpret this phase as a completed 3.0.0 mining implementation.

## Validation
- Source-level test cases added for gravel, leaves, tall grass, crops, potato poison chance, glowstone, and dead bush.
- Archive integrity is checked after packaging.
- Cargo/Rust compiler is unavailable in this environment; Rust compilation and unit tests were not executed.
