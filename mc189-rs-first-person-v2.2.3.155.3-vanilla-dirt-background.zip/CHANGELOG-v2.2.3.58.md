# v2.2.3.58 — biome surface replacement

- Added the block-level 16×16 biome surface pass for terrain primers.
- Added grass, dirt, sand, gravel, mycelium and bedrock terrain block variants.
- Added the 16×16 surface-noise field using the four-octave Perlin generator and vanilla 0.0625 sampling scale.
- Added deterministic chunk random seeding with the 1.8.9 `ChunkProviderGenerate` constants and bedrock floor generation.
- Added base top/filler mappings for desert/beach, stone/highland, mushroom and ordinary overworld biomes.
- Added deterministic and invalid-input tests.

Limitations: mesa banding, snowy biome top/filler states, specialized beach/stone-beach behavior, cave/ravine carving, and feature population are not implemented yet. This pass is a foundation for biome-specific `BiomeGenBase.genTerrainBlocks` ports, not a complete biome surface clone.
