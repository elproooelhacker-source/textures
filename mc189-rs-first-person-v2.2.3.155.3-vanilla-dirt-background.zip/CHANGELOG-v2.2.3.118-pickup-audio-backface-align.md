# v2.2.3.118 — vanilla collect sound routing and aligned item back face

## Source-verified pickup sound

- Compared against MCP 1.8.9 `EntityItem.onCollideWithPlayer` and `NetHandlerPlayClient.handleCollectItem`.
- The client packet handler plays `random.pop` at the collected `EntityItem` coordinates for non-XP pickups, at volume `0.2F`, with `((nextFloat() - nextFloat()) * 0.7F + 1.0F) * 2.0F` pitch, then spawns `EntityPickupFX` and removes the entity.
- The Rust local-client pickup path now calls the same event at the collected item's world position after a positive inventory insertion, uses the fixed vanilla 0.2 gain and the exact two-float pitch formula, and logs whether the sink was actually queued.
- Active Rodio sinks are now retained by `BlockAudio` until their buffers finish; finished sinks are reaped on the next playback. This preserves overlapping sounds without relying on detached-sink lifetime.
- Manual Q/Ctrl+Q drops still honor the vanilla 40-tick pickup protection. `random.pop` is not emitted at drop time; it is emitted when the stack really enters the inventory.

## Generated-item rear face alignment

- MCP `ItemModelGenerator` creates SOUTH and NORTH faces from the same 0..16 model bounds, with the NORTH U coordinates reversed.
- The generated drop sprite's back plane previously used 0..1 XY coordinates while the front/sides had already been centered to -0.5..0.5. This shifted the mirrored rear silhouette +0.5 on X and Y.
- The back plane now uses the same centered XY bounds as the front plane while retaining mirrored U coordinates and its negative-Z normal. First-person held-item geometry is unchanged.
- Added regression assertions for centered back-face bounds, center, Z offset, normal and mirrored UV order.

## Validation

- ZIP integrity checked after packaging. Cargo/rustc are unavailable in this authoring environment; the Windows release build and audible pickup test remain required.
