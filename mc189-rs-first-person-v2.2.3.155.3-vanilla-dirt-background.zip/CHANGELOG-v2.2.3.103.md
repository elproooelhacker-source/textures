# v2.2.3.103 — immediate block break visibility and item entity physics

## Immediate block removal at the break tick

- Added CPU-only `source_block` ownership to `CpuMeshQuad`.
- Tagged block model and fluid geometry with the block cell which emitted it; ownership is translated into the same session-local coordinates used by player targeting.
- Kept an owner tag alongside each vertex in the CPU copy of all four chunk render layers.
- When the mining controller emits `Broken`, the current CPU chunk mesh removes every vertex owned by that block and the filtered mesh is uploaded before the next redraw. The drop entity is created in that same fixed tick, so the block vanishes and the item appears in the same rendered frame.
- A later neighbor-aware asynchronous rebuild restores newly exposed faces, updates nearby fluid geometry, and recalculates dependent lighting. The async result is also filtered against any still-pending immediate removals to prevent stale mesh uploads from resurrecting a mined block.
- The previous visual mesh is retained for transaction rollback. If the in-memory edit worker rejects the block edit, provisional drops are removed, collision state is restored, and the previous mesh is re-uploaded.

## Dropped-item collision and smooth rendering

- Added a 0.25 x 0.25 entity AABB and swept block collision using `BlockCollision::collision_boxes`.
- Movement clips against collision shapes in vanilla `Entity.moveEntity` Y, X, Z order, including top/bottom slabs, trapdoors, stairs, doors, fences, gates, and ordinary cubes.
- Broadphase includes the block row below the item's swept bounds so 1.5-block fences/gates are not missed when their collision extends above their owning cell.
- Retained previous/current physics positions. RenderEntityItem transforms now interpolate position, age, bobbing and spin with render `partialTicks`.
- Dynamic item geometry is updated immediately before `RedrawRequested`, not during 20 TPS simulation updates, so it follows the display frame rate while world physics remains fixed at 20 TPS.

## Tests added

- Immediate block culling removes only the selected owner's vertices across opaque and fluid layers.
- Source-block owner coordinates translate correctly to session-local coordinates.
- Dropped items collide against lateral walls, raised fence collision boxes, and floors.
- Previous/current item position is interpolated between simulation ticks.

## Verification status

Static source review and ZIP integrity verification completed. Cargo/rustc and a Windows GPU runtime are unavailable in the authoring environment, so compilation, frame-time behavior, and the break/drop transition still require user-side Windows play-testing. This release does not claim full MCP parity for every collision shape or dropped-item behavior.
