# v2.2.3.13 — Resolved legacy rendering and collision regressions

- Added classic pumpkin (86) and jack-o-lantern (91) to the player full-block collision registry.
- Routed brown and red mushroom crossed-plane textures through the same alpha-cutout, replacement-blend, back-face-culling pipeline used by grass and flowers, preventing coincident-face z-fighting.
- Water now emits only its horizontal top surface in this preview path; vertical water side quads are suppressed. Lava retains its existing top and side geometry.
- Added regression tests for pumpkin collision, mushroom cutout classification, water top-only geometry, and unchanged lava side geometry.

The first-person arm transform and sleeve UVs are unchanged from v2.2.3.12.
