# v1.7.5

## Correcciones de hojas y diagnóstico de tintado

- Las hojas legacy (IDs 18 y 161) ahora resuelven el modelo hijo vanilla correspondiente a su especie: `block/oak_leaves`, `block/spruce_leaves`, `block/birch_leaves`, `block/jungle_leaves`, `block/acacia_leaves` y `block/dark_oak_leaves`.
- Se conserva la herencia vanilla hacia `block/leaves`, que define las seis caras con `tintindex: 0`; cada hijo proporciona la textura `all` correcta.
- Se elimina el uso incorrecto directo del modelo padre sin la asignación de textura de la especie.
- Se añaden contadores de caras de césped/plantas y hojas que realmente reciben tintado (`tintindex >= 0`), diferenciándolos del número de bloques con datos de bioma.
- Se actualiza el mensaje de alcance del visor para reflejar que el tintado por bioma sí se aplica a las caras marcadas por los modelos.

## Césped vanilla confirmado

- `block/grass` marca con `tintindex: 0` la cara superior y la capa `grass_side_overlay` de los cuatro laterales.
- `grass_side` permanece sin tinte; la cara inferior tampoco se tiñe.
- Esta versión conserva esa distinción a través del `tintindex` de cada cara; no aplica tinte indiscriminado al cubo.

## Verificación

- La estructura y los cambios se revisaron estáticamente en este entorno.
- No se ejecutaron `cargo fmt` ni `cargo test` aquí porque no hay toolchain Rust disponible. Deben ejecutarse en Windows antes de considerar validada esta versión.
