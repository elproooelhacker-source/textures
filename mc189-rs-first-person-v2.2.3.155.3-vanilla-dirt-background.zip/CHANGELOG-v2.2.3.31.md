# v2.2.3.31 — Vanilla dim-light response

- Added the 1.8.x `WorldProvider.generateLightBrightnessTable` level-to-brightness response.
- Applied the neutral `EntityRenderer.updateLightmap` output floor (`0.96 * brightness + 0.03`) so zero saved light no longer becomes absolute black.
- Kept AO and directional face shading separate; no arbitrary post-AO clamp was introduced.
- Added regression coverage for the zero-light floor and monotonic light response.
- Documented remaining scalar-lightmap limitations.

This version does not yet implement the full 16x16 RGB lightmap, day/night interpolation, dimension tint, torch flicker, gamma setting, or complete vanilla AO neighbor tables.
