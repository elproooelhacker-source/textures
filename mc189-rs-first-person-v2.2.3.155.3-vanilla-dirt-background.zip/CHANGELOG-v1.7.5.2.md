# v1.7.5.2

## Corrección de coordenadas de los mapas de color vanilla

- Corrige el orden de consulta de `grass.png` y `foliage.png`: temperatura en el eje X y humedad ajustada por temperatura en el eje Y, conforme al índice vanilla `(humidityIndex << 8) | temperatureIndex`.
- Actualiza la prueba de regresión para usar un mapa sintético asimétrico y detectar una futura inversión de los ejes.
- No cambia geometría, modelos, atlas, selección de variantes ni lectura del mundo.

## Verificación

- Revisión estática de los dos puntos de consulta y de la prueba de regresión.
- Este entorno no dispone de Rust; `cargo fmt --all` y `cargo test --workspace` deben ejecutarse en Windows.
