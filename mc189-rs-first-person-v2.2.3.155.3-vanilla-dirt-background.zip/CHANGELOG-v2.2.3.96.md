# v2.2.3.96 — Windows play-test launcher fix

- Fixed manual `client.jar` path capture in `INICIAR-PRUEBA-MINECRAFT-RUST.bat`.
- Moved `SET /P` and path normalization outside the parenthesized `IF` block, avoiding CMD percent-variable early expansion that previously replaced the entered path with an empty value.
- Accepts paths with or without surrounding double quotes.
- Prints the resolved JAR path before checking that it exists.
- Updated Windows start instructions with the concrete `C:\Users\Admin\Documents\client.jar` example.

This is a launcher-only correction. It does not claim that the Rust application was compiled or executed in this environment.
