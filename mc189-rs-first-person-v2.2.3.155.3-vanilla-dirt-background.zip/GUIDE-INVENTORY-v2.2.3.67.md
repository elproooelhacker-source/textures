# Inventory prototype — quick test

Run the standard main-menu command with the same `saves`, `client.jar`, and atlas paths used for v2.2.3.66. Once a world opens:

1. Press `T`, type `/give @p minecraft:diamond 64`, and press Enter.
2. Repeat `/give @p minecraft:wool 64 14` for red wool, `/give @p minecraft:diamond_sword 1`, `/give @p minecraft:sea_lantern 64`, and `/give @p minecraft:water_bucket 1`.
3. Press `E`. Left-click a stack to pick it up; left-click another compatible stack to merge or an incompatible stack to swap. Right-click takes half or places one. Hold Shift while clicking a slot to transfer between the hotbar and main inventory.
4. Armor can be placed in the four slots at the left when the item matches that equipment slot. Shift-clicking suitable armor attempts to equip it.
5. Press `1`–`9` or use the mouse wheel to change the selected hotbar slot after closing the inventory.
6. Use `/clear` from chat to clear the local test inventory.

The first pass is designed to exercise the real 1.8.9 icon assets and stack behaviour before adding crafting, dropped-item entities, inventory NBT saving and using/placing held items in the world. The remaining item count is reported if inventory capacity is exhausted.
