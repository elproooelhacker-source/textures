# v2.2.3.34 — Correct unloaded-neighbor lighting samples

- Fixed the smooth-lighting regression at negative chunk boundaries: samples that fall into an unloaded neighbor no longer receive maximum brightness.
- Unknown neighbor data now uses the same dim lightmap floor as zero saved light. This prevents artificial bright halos and over-bright AO corners while the neighbor is not yet available.
- Kept the four-sample corner interpolation, AO weighting, vanilla-style lightmap curve, biome tint averaging, and the safe single-level atlas mipmap from v2.2.3.33.
- Added a regression test proving that an unloaded neighbor is not interpreted as open sky.

Validation: source-level checks and ZIP integrity only in this environment; Rust tooling is unavailable here. Run `cargo fmt --all` and `cargo test --workspace` on Windows.
