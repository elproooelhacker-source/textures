use serde::{Deserialize, Serialize};
use crate::player::PlayerInput;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "packet", rename_all = "snake_case")]
pub enum ClientPacket {
    Hello { protocol: u32, username: String },
    Input { sequence: u64, input: PlayerInputWire, yaw: f32, pitch: f32 },
    Ping { nonce: u64 },
}

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Default)]
pub struct PlayerInputWire {
    pub forward: bool, pub backward: bool, pub left: bool, pub right: bool,
    pub jump: bool, pub jump_held: bool, pub sprint: bool,
}
impl From<PlayerInputWire> for PlayerInput {
    fn from(v: PlayerInputWire) -> Self { Self { forward:v.forward, backward:v.backward, left:v.left, right:v.right, jump:v.jump, jump_held:v.jump_held, sprint:v.sprint } }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "packet", rename_all = "snake_case")]
pub enum ServerPacket {
    Welcome { protocol: u32, entity_id: u32, tick_rate: u32, server_tick: u64, origin_chunk_x: i32, origin_chunk_z: i32 },
    PlayerSnapshot { tick:u64, acknowledged_input:u64, position:[f32;3], velocity:[f32;3], yaw:f32, pitch:f32, on_ground:bool, in_water:bool, in_lava:bool },
    Pong { nonce:u64, server_tick:u64 },
    Disconnect { reason:String },
}

#[cfg(test)] mod tests {
    use super::*;
    #[test] fn input_packet_round_trips_including_jump_edge() {
        let p=ClientPacket::Input { sequence:42, input:PlayerInputWire { forward:true,jump:true,..Default::default() }, yaw:1.25,pitch:-0.2 };
        let encoded=serde_json::to_string(&p).unwrap();
        assert_eq!(serde_json::from_str::<ClientPacket>(&encoded).unwrap(),p);
    }
    #[test] fn protocol_tick_rate_is_classic_twenty() { assert_eq!(crate::TICKS_PER_SECOND,20); assert_eq!(crate::TICK_MILLIS,50); }
}
