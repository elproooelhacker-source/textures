//! Server-owned Minecraft 1.8.9 `EntityItem` simulation.
//!
//! Rendering clients receive immutable snapshots; only the server advances item
//! age, pickup delay, movement, block collision, stack merging and despawning.
use glam::Vec3;
use mc189_storage::NbtTag;
use crate::mining::BlockPos;
use crate::player::{BlockCollision, FluidKind, PlayerState, PLAYER_HEIGHT, PLAYER_WIDTH};
use crate::drop_registry::{ItemDrop, JavaRandom};

const GRAVITY: f32 = 0.039_999_999_105_930_33;
const AIR_DRAG: f32 = 0.98;
const ITEM_HALF_WIDTH: f32 = 0.125;
const ITEM_HEIGHT: f32 = 0.25;
const DESPAWN_TICKS: u16 = 6000;

#[derive(Debug, Clone, PartialEq)]
pub struct EntityItem {
    pub entity_id: u64,
    pub item_id: u16,
    pub metadata: u16,
    pub count: u8,
    pub nbt_tag: Option<NbtTag>,
    pub previous_position: Vec3,
    pub position: Vec3,
    pub velocity: Vec3,
    pub age: u16,
    pub pickup_delay: u16,
    pub hover_start: f32,
    /// Block-edit transaction has not yet been accepted by the in-memory world worker.
    pub provisional: bool,
}

#[derive(Debug, Clone, PartialEq)]
pub struct EntityItemSnapshot {
    pub entity_id: u64,
    pub item_id: u16,
    pub metadata: u16,
    pub count: u8,
    pub nbt_tag: Option<NbtTag>,
    pub previous_position: Vec3,
    pub position: Vec3,
    pub velocity: Vec3,
    pub age: u16,
    pub pickup_delay: u16,
    pub hover_start: f32,
}

impl From<&EntityItem> for EntityItemSnapshot {
    fn from(item: &EntityItem) -> Self {
        Self { entity_id:item.entity_id, item_id:item.item_id, metadata:item.metadata,
            count:item.count, nbt_tag:item.nbt_tag.clone(), previous_position:item.previous_position,
            position:item.position, velocity:item.velocity, age:item.age,
            pickup_delay:item.pickup_delay, hover_start:item.hover_start }
    }
}

impl EntityItem {
    /// Serializes the vanilla 1.8.9 EntityItem fields plus a stable Rust-side ID.
    /// Unknown vanilla-compatible item NBT is retained verbatim.
    pub fn to_chunk_nbt(&self) -> NbtTag {
        let mut item = vec![
            ("id".into(), NbtTag::Short(self.item_id as i16)),
            ("Count".into(), NbtTag::Byte(self.count as i8)),
            ("Damage".into(), NbtTag::Short(self.metadata as i16)),
        ];
        if let Some(tag) = self.nbt_tag.clone() { item.push(("tag".into(), tag)); }
        NbtTag::Compound(vec![
            ("id".into(), NbtTag::String("Item".into())),
            ("RustEntityId".into(), NbtTag::Long(self.entity_id as i64)),
            ("Pos".into(), NbtTag::List(6, vec![NbtTag::Double(self.position.x as f64), NbtTag::Double(self.position.y as f64), NbtTag::Double(self.position.z as f64)])),
            ("Motion".into(), NbtTag::List(6, vec![NbtTag::Double(self.velocity.x as f64), NbtTag::Double(self.velocity.y as f64), NbtTag::Double(self.velocity.z as f64)])),
            ("Rotation".into(), NbtTag::List(5, vec![NbtTag::Float(0.0), NbtTag::Float(0.0)])),
            ("FallDistance".into(), NbtTag::Float(0.0)),
            ("Fire".into(), NbtTag::Short(0)),
            ("Air".into(), NbtTag::Short(300)),
            ("OnGround".into(), NbtTag::Byte(0)),
            ("Dimension".into(), NbtTag::Int(0)),
            ("Invulnerable".into(), NbtTag::Byte(0)),
            ("PortalCooldown".into(), NbtTag::Int(0)),
            ("UUIDMost".into(), NbtTag::Long(self.entity_id as i64)),
            ("UUIDLeast".into(), NbtTag::Long(self.entity_id.rotate_left(23) as i64)),
            ("Age".into(), NbtTag::Short(self.age.min(32767) as i16)),
            ("PickupDelay".into(), NbtTag::Short(self.pickup_delay.min(32767) as i16)),
            ("Health".into(), NbtTag::Short(5)),
            ("Item".into(), NbtTag::Compound(item)),
        ])
    }

    /// Reads vanilla EntityItem NBT. The fallback ID is deterministic for legacy
    /// chunks that do not contain our optional RustEntityId field.
    pub fn from_chunk_nbt(tag: &NbtTag, fallback_id: u64) -> Option<Self> {
        if tag.get("id").and_then(NbtTag::as_string) != Some("Item") { return None; }
        let item = tag.get("Item")?;
        let item_id = item.get("id").and_then(NbtTag::as_short)? as u16;
        let count = item.get("Count").and_then(NbtTag::as_byte)? as u8;
        let metadata = item.get("Damage").and_then(NbtTag::as_short).unwrap_or(0) as u16;
        if item_id == 0 || count == 0 { return None; }
        let read_vec = |name: &str| -> Option<Vec3> {
            let (kind, values) = tag.get(name)?.as_list()?;
            if kind != 6 || values.len() != 3 { return None; }
            let value = |v: &NbtTag| if let NbtTag::Double(x) = v { Some(*x as f32) } else { None };
            Some(Vec3::new(value(&values[0])?, value(&values[1])?, value(&values[2])?))
        };
        let position = read_vec("Pos")?;
        let velocity = read_vec("Motion").unwrap_or(Vec3::ZERO);
        if !position.is_finite() || !velocity.is_finite() || position.y < -64.0 || position.y > 512.0 { return None; }
        let entity_id = tag.get("RustEntityId").and_then(NbtTag::as_long).map(|v| v as u64).filter(|v| *v != 0).unwrap_or(fallback_id.max(1));
        let age = tag.get("Age").and_then(NbtTag::as_short).unwrap_or(0).max(0) as u16;
        let pickup_delay = tag.get("PickupDelay").and_then(NbtTag::as_short).unwrap_or(0).max(0) as u16;
        let nbt_tag = item.get("tag").cloned();
        let hover_start = hover_phase(position, item_id, metadata, count);
        Some(Self { entity_id, item_id, metadata, count, nbt_tag, previous_position: position,
            position, velocity, age, pickup_delay, hover_start, provisional: false })
    }
    /// Mirrors Block.spawnAsEntity + EntityItem construction in MCP 1.8.9.
    /// Uses the same java.util.Random stream as the preceding block-drop roll.
    pub fn spawn_from_drop(entity_id:u64, pos:BlockPos, drop:ItemDrop, rng:&mut JavaRandom)->Option<Self> {
        if entity_id == 0 || drop.item_id == 0 || drop.count == 0 { return None; }
        let offset=|r:&mut JavaRandom| 0.25+r.next_float()*0.5;
        let position=Vec3::new(pos.x as f32+offset(rng),pos.y as f32+offset(rng),pos.z as f32+offset(rng));
        // EntityItem's constructor uses Math.random(), not World.rand, for its
        // initial horizontal motion and hover phase. Derive a stable local phase
        // without consuming the shared Java world RNG stream.
        let metadata=u16::from(drop.metadata);
        let seed=entity_id ^ (u64::from(drop.item_id)<<32) ^ (u64::from(metadata)<<16) ^ u64::from(drop.count);
        let velocity=Vec3::new((deterministic_unit(seed,0xA511_E9B3)*0.2)-0.1,0.2,
            (deterministic_unit(seed,0x63D8_3595)*0.2)-0.1);
        let phase=hover_phase(position,drop.item_id,metadata,drop.count);
        let hover_start=phase;
        Some(Self { entity_id,item_id:drop.item_id,metadata,count:drop.count,nbt_tag:None,
            previous_position:position,position,velocity,age:0,pickup_delay:10,hover_start,provisional:true })
    }

    /// Server-side equivalent of EntityPlayer.dropPlayerItemWithRandomChoice.
    /// Player-thrown items are authoritative immediately and use the vanilla 40-tick pickup delay.
    pub fn spawn_from_player_drop(
        entity_id: u64, item_id: u16, metadata: u16, count: u8,
        nbt_tag: Option<NbtTag>, player: PlayerState,
    ) -> Option<Self> {
        if entity_id == 0 || item_id == 0 || count == 0 { return None; }
        let look = player.look_direction();
        let seed = entity_id ^ (u64::from(item_id) << 32) ^ (u64::from(metadata) << 16) ^ u64::from(count);
        let jitter_x = deterministic_unit(seed, 0xA511_E9B3) * 0.02 - 0.01;
        let jitter_z = deterministic_unit(seed, 0x63D8_3595) * 0.02 - 0.01;
        let position = Vec3::new(player.position.x, player.position.y + 1.32, player.position.z);
        let velocity = Vec3::new(look.x * 0.3 + jitter_x, look.y * 0.3 + 0.1, look.z * 0.3 + jitter_z);
        let hover_start = hover_phase(position, item_id, metadata, count);
        Some(Self { entity_id, item_id, metadata, count, nbt_tag,
            previous_position: position, position, velocity, age: 0,
            pickup_delay: 40, hover_start, provisional: false })
    }

    pub fn snapshot(&self)->EntityItemSnapshot { EntityItemSnapshot::from(self) }
    pub fn is_expired(&self)->bool { self.age >= DESPAWN_TICKS }
    pub fn is_in_pickup_range(&self, player_feet:Vec3)->bool {
        if self.pickup_delay != 0 || self.provisional { return false; }
        let item_bounds=ItemAabb::from_position(self.position);
        let half=PLAYER_WIDTH*0.5;
        let player_bounds=ItemAabb {
            min:Vec3::new(player_feet.x-half,player_feet.y,player_feet.z-half),
            max:Vec3::new(player_feet.x+half,player_feet.y+PLAYER_HEIGHT,player_feet.z+half),
        };
        item_bounds.intersects(player_bounds)
    }
    pub fn can_merge_with(&self, other:&Self)->bool {
        self.entity_id != other.entity_id && self.item_id == other.item_id
            && self.metadata == other.metadata && self.nbt_tag == other.nbt_tag
            && (self.position.x-other.position.x).abs() < 0.75
            && (self.position.y-other.position.y).abs() < ITEM_HEIGHT
            && (self.position.z-other.position.z).abs() < 0.75
            && self.pickup_delay != 32767 && other.pickup_delay != 32767
            && !self.provisional && !other.provisional
    }

    /// One `EntityItem.onUpdate` simulation step at the server's fixed 20 TPS.
    /// Movement is clipped Y, X, Z against the block collision shapes, matching
    /// Entity.moveEntity's axis order. Pickup and merge are handled separately.
    pub fn tick<C:BlockCollision>(&mut self, world:&C) -> bool {
        self.previous_position=self.position;
        if self.pickup_delay>0 && self.pickup_delay!=32767 { self.pickup_delay-=1; }
        self.velocity.y-=GRAVITY;
        let mut bounds=ItemAabb::from_position(self.position);
        // EntityItem.onUpdate sets noClip when Entity.pushOutOfBlocks succeeds.
        // In that case Entity.moveEntity applies the motion without collision clipping.
        let no_clip=push_out_of_blocks(self,world,bounds);
        let requested=self.velocity;
        let on_ground=if no_clip {
            bounds.offset(requested);
            false
        } else {
            let obstacles=collect_collision_boxes(world,bounds,requested);
            let mut dy=requested.y;
            for obstacle in &obstacles { dy=obstacle.clip_y(bounds,dy); }
            bounds.offset(Vec3::new(0.0,dy,0.0));
            let collided_y=(dy-requested.y).abs()>1.0e-7;
            let on_ground=collided_y && requested.y<0.0;
            let mut dx=requested.x;
            for obstacle in &obstacles { dx=obstacle.clip_x(bounds,dx); }
            bounds.offset(Vec3::new(dx,0.0,0.0));
            let collided_x=(dx-requested.x).abs()>1.0e-7;
            let mut dz=requested.z;
            for obstacle in &obstacles { dz=obstacle.clip_z(bounds,dz); }
            bounds.offset(Vec3::new(0.0,0.0,dz));
            let collided_z=(dz-requested.z).abs()>1.0e-7;
            if collided_x { self.velocity.x=0.0; }
            if collided_y { self.velocity.y=0.0; }
            if collided_z { self.velocity.z=0.0; }
            on_ground
        };
        self.position=Vec3::new((bounds.min.x+bounds.max.x)*0.5,bounds.min.y,(bounds.min.z+bounds.max.z)*0.5);
        let crossed_block = self.previous_position.floor() != self.position.floor();
        if crossed_block || (self.age.saturating_add(1) % 25 == 0) {
            let bx=self.position.x.floor() as i32; let by=self.position.y.floor() as i32; let bz=self.position.z.floor() as i32;
            if world.fluid_at(bx,by,bz).is_some_and(|cell|cell.kind==FluidKind::Lava) {
                let phase=hover_phase(self.position,self.item_id,self.metadata,self.count);
                self.velocity.x=phase.cos()*0.2; self.velocity.y=0.2; self.velocity.z=phase.sin()*0.2;
            }
        }
        let below_x=self.position.x.floor() as i32;
        let below_y=(bounds.min.y.floor() as i32).saturating_sub(1);
        let below_z=self.position.z.floor() as i32;
        let horizontal_drag=if on_ground { world.slipperiness_at(below_x,below_y,below_z)*AIR_DRAG } else { AIR_DRAG };
        self.velocity.x*=horizontal_drag;
        self.velocity.y*=0.980_000_019_073_486_3;
        self.velocity.z*=horizontal_drag;
        if on_ground { self.velocity.y*=-0.5; }
        self.age=self.age.saturating_add(1);
        self.apply_water_movement(world,bounds);
        crossed_block || self.age % 25 == 0
    }

    /// Entity.handleWaterMovement: query the item AABB expanded 0.4 blocks
    /// downward, collect BlockLiquid flow vectors, normalize and add 0.014.
    fn apply_water_movement<C:BlockCollision>(&mut self, world:&C, bounds:ItemAabb) {
        let min= bounds.min + Vec3::new(0.0,-0.400_000_006,0.0) + Vec3::splat(0.001);
        let max= bounds.max + Vec3::new(0.0,-0.400_000_006,0.0) - Vec3::splat(0.001);
        let min_x=min.x.floor() as i32; let max_x=(max.x+1.0).floor() as i32;
        let min_y=min.y.floor() as i32; let max_y=(max.y+1.0).floor() as i32;
        let min_z=min.z.floor() as i32; let max_z=(max.z+1.0).floor() as i32;
        let mut in_water=false; let mut flow=Vec3::ZERO;
        for x in min_x..max_x { for y in min_y..max_y { for z in min_z..max_z {
            if let Some(cell)=world.fluid_at(x,y,z).filter(|cell|cell.kind==FluidKind::Water) {
                let surface=y as f32+cell.surface_height();
                if max.y>=surface { in_water=true; flow+=world.fluid_flow_at(x,y,z,cell); }
            }
        }}}
        if in_water && flow.length_squared()>0.0 { self.velocity+=flow.normalize()*0.014; }
    }
}

/// Merge nearby stacks deterministically in entity-id order. The source entity
/// is removed when fully consumed; callers provide the vanilla item stack cap.
pub fn merge_nearby(items:&mut Vec<EntityItem>, max_stack_size:impl Fn(u16)->u8) {
    let searchers:Vec<u64>=items.iter().map(|item|item.entity_id).collect();
    merge_nearby_for_searchers(items,&searchers,max_stack_size);
}

/// Run the nearby search only for entities whose `onUpdate` requested it (block
/// coordinate changed or `ticksExisted % 25 == 0`), matching the MCP call site.
pub fn merge_nearby_for_searchers(items:&mut Vec<EntityItem>, searchers:&[u64], max_stack_size:impl Fn(u16)->u8) {
    items.sort_by_key(|item|item.entity_id);
    loop {
        let mut merged=false;
        'pairs: for i in 0..items.len() {
            for j in i+1..items.len() {
                if !searchers.contains(&items[i].entity_id) && !searchers.contains(&items[j].entity_id) { continue; }
                if !items[i].can_merge_with(&items[j]) { continue; }
                let (destination,source)=if items[i].count>items[j].count {(i,j)}else{(j,i)};
                let cap=max_stack_size(items[destination].item_id).max(1);
                let total=items[destination].count.saturating_add(items[source].count);
                // EntityItem.combineItems refuses partial merges: the entire source
                // stack must fit in the destination stack or neither entity changes.
                if total>cap { continue; }
                let source_item=items.remove(source);
                let destination_index=if source<destination {destination-1}else{destination};
                items[destination_index].count=items[destination_index].count.saturating_add(source_item.count);
                items[destination_index].pickup_delay=items[destination_index].pickup_delay.max(source_item.pickup_delay);
                items[destination_index].age=items[destination_index].age.min(source_item.age);
                merged=true;
                break 'pairs;
            }
        }
        if !merged { break; }
    }
    items.retain(|item|item.count>0 && !item.is_expired());
}

fn deterministic_unit(seed:u64,salt:u32)->f32 {
    let mut value=(seed as u32) ^ ((seed>>32) as u32) ^ salt;
    value^=value>>16; value=value.wrapping_mul(0x7FEB_352D); value^=value>>15;
    value=value.wrapping_mul(0x846C_A68B); value^=value>>16;
    value as f32 / u32::MAX as f32
}

fn hover_phase(position:Vec3,item_id:u16,metadata:u16,count:u8)->f32 {
    let mut phase=(position.x.floor() as u32).wrapping_mul(0x9E37_79B9)
        ^ (position.y.floor() as u32).wrapping_mul(0x85EB_CA6B)
        ^ (position.z.floor() as u32).wrapping_mul(0xC2B2_AE35)
        ^ u32::from(item_id).wrapping_mul(0x27D4_EB2D)
        ^ u32::from(metadata).wrapping_mul(0x1656_67B1) ^ u32::from(count);
    phase^=phase>>16; phase=phase.wrapping_mul(0x7FEB_352D); phase^=phase>>15;
    ((phase&0x00FF_FFFF) as f32/16_777_216.0)*std::f32::consts::TAU
}

/// Entity.pushOutOfBlocks from MCP 1.8.9. It selects the nearest open
/// horizontal/upward neighboring cell and gives the item a short impulse.
fn push_out_of_blocks<C:BlockCollision>(item:&mut EntityItem,world:&C,bounds:ItemAabb)->bool {
    let center=Vec3::new(item.position.x,item.position.y+ITEM_HEIGHT*0.5,item.position.z);
    let bx=center.x.floor() as i32; let by=center.y.floor() as i32; let bz=center.z.floor() as i32;
    let colliding=!collect_collision_boxes(world,bounds,Vec3::ZERO).is_empty();
    if !colliding && !world.is_full_cube_at(bx,by,bz) { return false; }
    let dx=center.x-bx as f32; let dy=center.y-by as f32; let dz=center.z-bz as f32;
    let mut direction=3_u8; let mut nearest=f32::MAX;
    if !world.is_full_cube_at(bx-1,by,bz) && dx<nearest { nearest=dx; direction=0; }
    if !world.is_full_cube_at(bx+1,by,bz) && 1.0-dx<nearest { nearest=1.0-dx; direction=1; }
    if !world.is_full_cube_at(bx,by+1,bz) && 1.0-dy<nearest { nearest=1.0-dy; direction=3; }
    if !world.is_full_cube_at(bx,by,bz-1) && dz<nearest { nearest=dz; direction=4; }
    if !world.is_full_cube_at(bx,by,bz+1) && 1.0-dz<nearest { direction=5; }
    let seed=u64::from(item.entity_id as u32) ^ (u64::from(item.item_id)<<32) ^ (u64::from(item.metadata)<<16);
    let impulse=0.1+(deterministic_unit(seed,0xC2B2_AE35)*0.2);
    match direction { 0=>item.velocity.x=-impulse,1=>item.velocity.x=impulse,3=>item.velocity.y=impulse,4=>item.velocity.z=-impulse,5=>item.velocity.z=impulse,_=>{} }
    true
}

#[derive(Debug,Clone,Copy)] struct ItemAabb { min:Vec3,max:Vec3 }
impl ItemAabb {
    fn from_position(p:Vec3)->Self { Self { min:Vec3::new(p.x-ITEM_HALF_WIDTH,p.y,p.z-ITEM_HALF_WIDTH),max:Vec3::new(p.x+ITEM_HALF_WIDTH,p.y+ITEM_HEIGHT,p.z+ITEM_HALF_WIDTH) } }
    fn offset(&mut self,d:Vec3) { self.min+=d; self.max+=d; }
    fn intersects(&self,o:Self)->bool { self.max.x>o.min.x&&self.min.x<o.max.x&&self.max.y>o.min.y&&self.min.y<o.max.y&&self.max.z>o.min.z&&self.min.z<o.max.z }
    fn clip_y(self,m:Self,mut d:f32)->f32 { if m.max.x>self.min.x&&m.min.x<self.max.x&&m.max.z>self.min.z&&m.min.z<self.max.z { if d>0.0&&m.max.y<=self.min.y { d=d.min(self.min.y-m.max.y); } else if d<0.0&&m.min.y>=self.max.y { d=d.max(self.max.y-m.min.y); } } d }
    fn clip_x(self,m:Self,mut d:f32)->f32 { if m.max.y>self.min.y&&m.min.y<self.max.y&&m.max.z>self.min.z&&m.min.z<self.max.z { if d>0.0&&m.max.x<=self.min.x { d=d.min(self.min.x-m.max.x); } else if d<0.0&&m.min.x>=self.max.x { d=d.max(self.max.x-m.min.x); } } d }
    fn clip_z(self,m:Self,mut d:f32)->f32 { if m.max.x>self.min.x&&m.min.x<self.max.x&&m.max.y>self.min.y&&m.min.y<self.max.y { if d>0.0&&m.max.z<=self.min.z { d=d.min(self.min.z-m.max.z); } else if d<0.0&&m.min.z>=self.max.z { d=d.max(self.max.z-m.min.z); } } d }
}
fn collect_collision_boxes<C:BlockCollision>(world:&C,bounds:ItemAabb,motion:Vec3)->Vec<ItemAabb> {
    let swept_min=bounds.min.min(bounds.min+motion); let swept_max=bounds.max.max(bounds.max+motion);
    let min_x=swept_min.x.floor() as i32; let min_y=(swept_min.y.floor() as i32).saturating_sub(1); let min_z=swept_min.z.floor() as i32;
    let max_x=(swept_max.x-1.0e-6).floor() as i32; let max_y=(swept_max.y-1.0e-6).floor() as i32; let max_z=(swept_max.z-1.0e-6).floor() as i32;
    let mut result=Vec::new();
    for y in min_y..=max_y { for z in min_z..=max_z { for x in min_x..=max_x { for shape in world.collision_boxes(x,y,z) {
        let obstacle=ItemAabb { min:Vec3::new(x as f32+shape.min[0],y as f32+shape.min[1],z as f32+shape.min[2]),max:Vec3::new(x as f32+shape.max[0],y as f32+shape.max[1],z as f32+shape.max[2]) };
        if bounds.intersects(obstacle) || swept_min.x<obstacle.max.x&&swept_max.x>obstacle.min.x&&swept_min.y<obstacle.max.y&&swept_max.y>obstacle.min.y&&swept_min.z<obstacle.max.z&&swept_max.z>obstacle.min.z { result.push(obstacle); }
    }}}}
    result
}

#[cfg(test)] mod tests {
    use super::*;
    use crate::player::{BlockCollisionBox, BlockCollision, FluidCell, FluidKind};
    struct Floor;
    impl BlockCollision for Floor {
        fn is_solid(&self,_x:i32,y:i32,_z:i32)->bool { y == 0 }
        fn collision_boxes(&self,_x:i32,y:i32,_z:i32)->Vec<BlockCollisionBox> {
            if y == 0 { vec![BlockCollisionBox::FULL_CUBE] } else { Vec::new() }
        }
    }
    struct Embedded;
    impl BlockCollision for Embedded {
        fn is_solid(&self,x:i32,y:i32,z:i32)->bool { x==0&&y==0&&z==0 }
        fn collision_boxes(&self,x:i32,y:i32,z:i32)->Vec<BlockCollisionBox> {
            if self.is_solid(x,y,z) { vec![BlockCollisionBox::FULL_CUBE] } else { Vec::new() }
        }
    }
    struct WaterFlow;
    impl BlockCollision for WaterFlow {
        fn is_solid(&self,_x:i32,_y:i32,_z:i32)->bool { false }
        fn fluid_at(&self,x:i32,y:i32,z:i32)->Option<FluidCell> {
            (x==0&&y==0&&z==0).then_some(FluidCell{kind:FluidKind::Water,level:0})
        }
        fn fluid_flow_at(&self,_x:i32,_y:i32,_z:i32,_cell:FluidCell)->Vec3 { Vec3::X }
    }
    struct Lava;
    impl BlockCollision for Lava {
        fn is_solid(&self,_x:i32,_y:i32,_z:i32)->bool { false }
        fn fluid_at(&self,x:i32,y:i32,z:i32)->Option<FluidCell> {
            (x==0&&y==0&&z==0).then_some(FluidCell{kind:FluidKind::Lava,level:0})
        }
    }
    fn entity(id:u64,x:f32,count:u8)->EntityItem { EntityItem { entity_id:id,item_id:4,metadata:0,count,nbt_tag:None,previous_position:Vec3::new(x,2.0,0.0),position:Vec3::new(x,2.0,0.0),velocity:Vec3::ZERO,age:0,pickup_delay:0,hover_start:0.0,provisional:false } }
    #[test] fn player_inventory_drop_is_authoritative_and_uses_vanilla_pickup_delay() {
        let player = PlayerState::at(Vec3::new(3.0, 64.0, -2.0));
        let tag = mc189_storage::NbtTag::Compound(vec![("display".into(), mc189_storage::NbtTag::Compound(vec![]))]);
        let item = EntityItem::spawn_from_player_drop(9, 278, 42, 1, Some(tag.clone()), player).unwrap();
        assert_eq!(item.entity_id, 9);
        assert_eq!(item.item_id, 278);
        assert_eq!(item.metadata, 42);
        assert_eq!(item.count, 1);
        assert_eq!(item.nbt_tag, Some(tag));
        assert_eq!(item.pickup_delay, 40);
        assert!(!item.provisional);
        assert_eq!(item.age, 0);
    }

    #[test] fn entity_item_nbt_round_trip_preserves_stack_motion_and_timers() {
        let mut original = entity(9876, -17.25, 12);
        original.item_id = 278;
        original.metadata = 42;
        original.position = Vec3::new(-17.25, 68.5, 33.75);
        original.previous_position = original.position;
        original.velocity = Vec3::new(0.125, -0.03125, 0.0625);
        original.age = 321;
        original.pickup_delay = 17;
        original.nbt_tag = Some(NbtTag::Compound(vec![("display".into(), NbtTag::Compound(vec![]))]));
        let restored = EntityItem::from_chunk_nbt(&original.to_chunk_nbt(), 1).unwrap();
        assert_eq!(restored.entity_id, original.entity_id);
        assert_eq!(restored.item_id, original.item_id);
        assert_eq!(restored.metadata, original.metadata);
        assert_eq!(restored.count, original.count);
        assert_eq!(restored.nbt_tag, original.nbt_tag);
        assert_eq!(restored.position, original.position);
        assert_eq!(restored.velocity, original.velocity);
        assert_eq!(restored.age, original.age);
        assert_eq!(restored.pickup_delay, original.pickup_delay);
        assert!(!restored.provisional);
    }

    #[test] fn entity_tick_applies_gravity_and_pickup_delay() {
        let world=Floor;
        let mut item=entity(1,0.5,1); item.position.y=2.0; item.pickup_delay=2; let y=item.position.y;
        let _ = item.tick(&world); assert!(item.position.y<y); assert_eq!(item.pickup_delay,1); assert_eq!(item.age,1);
    }
    #[test] fn block_spawn_consumes_only_three_world_random_floats_for_position() {
        let mut actual=JavaRandom::new(1234);
        let mut expected=JavaRandom::new(1234);
        for _ in 0..3 { let _=expected.next_float(); }
        let _=EntityItem::spawn_from_drop(1,BlockPos{x:2,y:3,z:4},ItemDrop{item_id:4,metadata:0,count:1},&mut actual).unwrap();
        assert_eq!(actual.next_float().to_bits(),expected.next_float().to_bits());
    }
    #[test] fn embedded_entity_uses_vanilla_push_out_no_clip_step() {
        let mut item=entity(1,0.5,1); item.position=Vec3::new(0.5,0.5,0.5);
        let _=item.tick(&Embedded); assert!(item.position.y>0.5);
    }
    #[test] fn water_flow_adds_vanilla_acceleration() {
        let mut item=entity(1,0.5,1); item.position=Vec3::new(0.5,1.1,0.5);
        let _=item.tick(&WaterFlow); assert!(item.velocity.x>0.0);
    }
    #[test] fn lava_contact_bounces_item_on_block_change_or_25th_tick() {
        let mut item=entity(1,0.5,1); item.position=Vec3::new(0.5,0.5,0.5); item.age=24;
        let _=item.tick(&Lava); assert!(item.velocity.y>0.0);
    }
    #[test] fn entity_lands_on_full_cube_and_bounces() {
        let world=Floor;
        let mut item=entity(1,0.5,1); item.position.y=1.0; item.velocity.y=-0.2;
        let _ = item.tick(&world); assert!(item.position.y>=1.0); assert!(item.velocity.y>=0.0);
    }
    #[test] fn nearby_equal_stacks_only_merge_when_whole_source_fits() {
        let mut items=vec![entity(2,0.6,40),entity(1,0.5,40)];
        merge_nearby(&mut items,|_|64); assert_eq!(items.len(),2); assert_eq!(items[0].entity_id,1); assert_eq!(items[0].count,40); assert_eq!(items[1].entity_id,2); assert_eq!(items[1].count,40);
        let mut fits=vec![entity(4,0.5,20),entity(3,0.6,30)];
        merge_nearby(&mut fits,|_|64); assert_eq!(fits.len(),1); assert_eq!(fits[0].count,50); assert_eq!(fits[0].entity_id,3);
        let mut equal=vec![entity(5,0.5,20),entity(6,0.6,20)];
        merge_nearby(&mut equal,|_|64); assert_eq!(equal.len(),1); assert_eq!(equal[0].entity_id,6); assert_eq!(equal[0].count,40);
    }
    #[test] fn nearby_search_runs_only_for_entities_that_requested_it() {
        let mut items=vec![entity(1,0.5,10),entity(2,0.6,10),entity(3,4.0,10)];
        merge_nearby_for_searchers(&mut items,&[3],|_|64);
        assert_eq!(items.len(),3);
    }
    #[test] fn incompatible_or_distant_stacks_do_not_merge() {
        let mut a=entity(1,0.0,10); let mut b=entity(2,2.0,10); b.item_id=5;
        let mut items=vec![a.clone(),b]; merge_nearby(&mut items,|_|64); assert_eq!(items.len(),2);
        a.age=DESPAWN_TICKS; let mut expired=vec![a]; merge_nearby(&mut expired,|_|64); assert!(expired.is_empty());
    }
    #[test] fn pickup_delay_sentinel_is_not_decremented_and_blocks_merging() {
        let mut item=entity(1,0.0,1); item.pickup_delay=32767;
        let _=item.tick(&Floor); assert_eq!(item.pickup_delay,32767);
        let mut other=entity(2,0.1,1); other.pickup_delay=0;
        assert!(!item.can_merge_with(&other));
        item.pickup_delay=0; item.provisional=true; assert!(!item.can_merge_with(&other));
    }
    #[test] fn entity_despawns_at_the_vanilla_6000_tick_age() {
        let mut item=entity(1,0.0,1); item.age=5999;
        let _=item.tick(&Floor); assert_eq!(item.age,6000); assert!(item.is_expired());
    }
    #[test] fn pickup_range_requires_zero_delay_and_player_aabb_intersection() {
        let mut item=entity(1,0.0,1); item.position=Vec3::ZERO; assert!(item.is_in_pickup_range(Vec3::ZERO));
        item.pickup_delay=1; assert!(!item.is_in_pickup_range(Vec3::ZERO));
        item.pickup_delay=0; assert!(!item.is_in_pickup_range(Vec3::new(1.1,0.0,0.0)));
        item.provisional=true; assert!(!item.is_in_pickup_range(Vec3::ZERO));
    }
}
