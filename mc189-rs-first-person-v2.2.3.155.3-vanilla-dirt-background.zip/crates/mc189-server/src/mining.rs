//! Server-owned 1.8.9 mining rules. The formulas mirror MCP Block.getPlayerRelativeBlockHardness and PlayerControllerMP.
use glam::Vec3;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct BlockPos { pub x: i32, pub y: i32, pub z: i32 }
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ToolKind { Hand, Pickaxe, Axe, Shovel, Shears }
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ToolTier { None, Wood, Stone, Iron, Diamond, Gold }
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct HeldTool { pub kind: ToolKind, pub tier: ToolTier, pub efficiency: u8 }
impl Default for HeldTool { fn default() -> Self { Self { kind: ToolKind::Hand, tier: ToolTier::None, efficiency: 0 } } }
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct MiningContext { pub creative: bool, pub on_ground: bool, pub submerged: bool, pub aqua_affinity: bool, pub haste: u8, pub fatigue: u8 }
impl Default for MiningContext { fn default() -> Self { Self { creative:false, on_ground:true, submerged:false, aqua_affinity:false, haste:0, fatigue:0 } } }
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct BlockInfo { pub hardness: f32, pub required_tool: ToolKind, pub harvest_tier: ToolTier, pub drop_id: u16, pub drop_meta: u8, pub drop_count: u8 }

/// Common vanilla 1.8 legacy block properties. Unknown IDs intentionally have
/// no guessed drop/hardness and are not mined by this first registry.
pub fn block_info(id:u16, meta:u8)->Option<BlockInfo> {
    let (hardness, tool, tier, drop_id, drop_meta, count) = match id {
        1 => (1.5,ToolKind::Pickaxe,ToolTier::Wood,1,0,1),
        2 => (0.6,ToolKind::Shovel,ToolTier::None,3,0,1),
        3 => (0.5,ToolKind::Shovel,ToolTier::None,3, if meta==1 {1}else{0},1),
        4 => (2.0,ToolKind::Pickaxe,ToolTier::Wood,4,0,1),
        5 => (2.0,ToolKind::Axe,ToolTier::None,5,meta&3,1),
        12 => (0.5,ToolKind::Shovel,ToolTier::None,12,0,1),
        13 => (0.6,ToolKind::Shovel,ToolTier::None,13,0,1),
        14 => (3.0,ToolKind::Pickaxe,ToolTier::Iron, gold_ore_drop(meta),0,1),
        15 => (3.0,ToolKind::Pickaxe,ToolTier::Stone,15,0,1),
        16 => (3.0,ToolKind::Pickaxe,ToolTier::Wood,263,0,1),
        17 => (2.0,ToolKind::Axe,ToolTier::None,17,meta&3,1),
        18 => (0.2,ToolKind::Shears,ToolTier::None, sapling_drop(meta),meta&3,1),
        20 => (0.3,ToolKind::Pickaxe,ToolTier::None,0,0,0),
        21 => (3.0,ToolKind::Pickaxe,ToolTier::Iron, lapis_drop(meta),4,4),
        22 => (3.0,ToolKind::Pickaxe,ToolTier::Stone,22,0,1),
        24 => (0.8,ToolKind::Shovel,ToolTier::None, if meta==2 {13}else{24},0,1),
        35 => (0.8,ToolKind::Shears,ToolTier::None,35,meta&15,1),
        41|42|57|133 => (3.0,ToolKind::Pickaxe,ToolTier::Wood,id,0,1),
        45|48 => (1.5,ToolKind::Pickaxe,ToolTier::Wood,id,0,1),
        49 => (50.0,ToolKind::Pickaxe,ToolTier::Diamond,0,0,0),
        56 => (3.0,ToolKind::Pickaxe,ToolTier::Iron,264,0,1),
        73|74 => (3.0,ToolKind::Pickaxe,ToolTier::Iron, redstone_drop(meta),0,4),
        79 => (0.5,ToolKind::Pickaxe,ToolTier::Wood,79,0,1),
        80 => (0.2,ToolKind::Shovel,ToolTier::None,80,0,1),
        82 => (0.6,ToolKind::Shovel,ToolTier::None,337,0,4),
        87 => (0.4,ToolKind::Pickaxe,ToolTier::Wood,87,0,1),
        89 => (0.3,ToolKind::Pickaxe,ToolTier::Wood,89,0,1),
        95 => (0.3,ToolKind::Pickaxe,ToolTier::None,0,0,0),
        97 => (0.75,ToolKind::Pickaxe,ToolTier::Wood,0,0,0),
        98 => (1.5,ToolKind::Pickaxe,ToolTier::Wood,98,meta,1),
        129 => (3.0,ToolKind::Pickaxe,ToolTier::Iron, emerald_drop(meta),0,1),
        152 => (5.0,ToolKind::Pickaxe,ToolTier::Wood,152,0,1),
        153 => (3.0,ToolKind::Pickaxe,ToolTier::Wood,406,0,1),
        159 => (1.4,ToolKind::Pickaxe,ToolTier::None,159,meta&15,1),
        162 => (2.0,ToolKind::Axe,ToolTier::None,162,meta&1,1),
        172 => (0.8,ToolKind::Shovel,ToolTier::None,172,0,1),
        173 => (5.0,ToolKind::Pickaxe,ToolTier::Wood,263,1,1),
        174 => (0.5,ToolKind::Pickaxe,ToolTier::Wood,174,0,1),
        _ => return None,
    };
    Some(BlockInfo { hardness, required_tool:tool, harvest_tier:tier, drop_id, drop_meta, drop_count:count })
}
fn gold_ore_drop(_m:u8)->u16 { 266 }
fn lapis_drop(_m:u8)->u16 { 351 }
fn redstone_drop(_m:u8)->u16 {  redstone_dust_id() }
fn redstone_dust_id()->u16 { 331 }
fn emerald_drop(_m:u8)->u16 { 388 }
fn sapling_drop(_m:u8)->u16 { 6 }

/// Resolve the selected inventory registry name into the vanilla tool class/tier.
/// Inventory identifiers may be stored either as `diamond_pickaxe` or
/// `minecraft:diamond_pickaxe`; unknown items deliberately behave as a hand.
pub fn held_tool_from_item_id(item_id: Option<&str>) -> HeldTool {
    let Some(raw) = item_id else { return HeldTool::default(); };
    let name = raw.rsplit(':').next().unwrap_or(raw);
    let (kind, tier) = match name {
        "wooden_pickaxe" => (ToolKind::Pickaxe, ToolTier::Wood),
        "stone_pickaxe" => (ToolKind::Pickaxe, ToolTier::Stone),
        "iron_pickaxe" => (ToolKind::Pickaxe, ToolTier::Iron),
        "diamond_pickaxe" => (ToolKind::Pickaxe, ToolTier::Diamond),
        "golden_pickaxe" => (ToolKind::Pickaxe, ToolTier::Gold),
        "wooden_axe" => (ToolKind::Axe, ToolTier::Wood),
        "stone_axe" => (ToolKind::Axe, ToolTier::Stone),
        "iron_axe" => (ToolKind::Axe, ToolTier::Iron),
        "diamond_axe" => (ToolKind::Axe, ToolTier::Diamond),
        "golden_axe" => (ToolKind::Axe, ToolTier::Gold),
        "wooden_shovel" => (ToolKind::Shovel, ToolTier::Wood),
        "stone_shovel" => (ToolKind::Shovel, ToolTier::Stone),
        "iron_shovel" => (ToolKind::Shovel, ToolTier::Iron),
        "diamond_shovel" => (ToolKind::Shovel, ToolTier::Diamond),
        "golden_shovel" => (ToolKind::Shovel, ToolTier::Gold),
        "shears" => (ToolKind::Shears, ToolTier::None),
        _ => return HeldTool::default(),
    };
    HeldTool { kind, tier, efficiency: 0 }
}

fn tier_level(t:ToolTier)->i8 { match t { ToolTier::None=>-1,ToolTier::Wood=>0,ToolTier::Gold=>0,ToolTier::Stone=>1,ToolTier::Iron=>2,ToolTier::Diamond=>3 } }
fn tool_speed(tool:HeldTool, block:BlockInfo)->f32 {
    let effective = tool.kind==block.required_tool && tool.kind!=ToolKind::Hand;
    if !effective { return 1.0; }
    let base = match (tool.kind,tool.tier) {
        (ToolKind::Pickaxe,ToolTier::Wood)=>2.0,(ToolKind::Pickaxe,ToolTier::Stone)=>4.0,(ToolKind::Pickaxe,ToolTier::Iron)=>6.0,(ToolKind::Pickaxe,ToolTier::Diamond)=>8.0,(ToolKind::Pickaxe,ToolTier::Gold)=>12.0,
        (ToolKind::Axe,ToolTier::Wood)=>2.0,(ToolKind::Axe,ToolTier::Stone)=>4.0,(ToolKind::Axe,ToolTier::Iron)=>6.0,(ToolKind::Axe,ToolTier::Diamond)=>8.0,(ToolKind::Axe,ToolTier::Gold)=>12.0,
        (ToolKind::Shovel,ToolTier::Wood)=>2.0,(ToolKind::Shovel,ToolTier::Stone)=>4.0,(ToolKind::Shovel,ToolTier::Iron)=>6.0,(ToolKind::Shovel,ToolTier::Diamond)=>8.0,(ToolKind::Shovel,ToolTier::Gold)=>12.0,
        (ToolKind::Shears,_)=>15.0,_=>1.0,
    };
    base + if tool.efficiency>0 { f32::from(tool.efficiency.min(5) as u16 * tool.efficiency.min(5) as u16 + 1) } else {0.0}
}
pub fn can_harvest(tool:HeldTool, block:BlockInfo)->bool {
    if block.harvest_tier==ToolTier::None { return true; }
    tool.kind==block.required_tool && tier_level(tool.tier)>=tier_level(block.harvest_tier)
}
/// Exact Block.getPlayerRelativeBlockHardness structure: dig efficiency / hardness / 30 or 100.
pub fn damage_per_tick(block:BlockInfo, tool:HeldTool, ctx:MiningContext)->f32 {
    if ctx.creative { return 1.0; }
    if block.hardness<0.0 { return 0.0; }
    if block.hardness==0.0 { return 1.0; }
    let harvest=can_harvest(tool,block);
    let mut speed=tool_speed(tool,block);
    speed *= 1.0 + 0.2*f32::from(ctx.haste);
    let fatigue=[1.0,0.3,0.09,0.0027,0.00081][usize::from(ctx.fatigue.min(4))];
    speed *= fatigue;
    if ctx.submerged && !ctx.aqua_affinity { speed/=5.0; }
    if !ctx.on_ground { speed/=5.0; }
    speed / block.hardness / if harvest {30.0}else{100.0}
}

#[derive(Debug,Clone,Copy,PartialEq)]
pub struct RayHit { pub pos:BlockPos, pub face:[i32;3], pub distance:f32 }
/// Amanatides-Woo voxel ray traversal, bounded by vanilla survival reach 4.5 blocks.
pub fn raycast<F:FnMut(BlockPos)->bool>(origin:Vec3, direction:Vec3, reach:f32, mut is_solid:F)->Option<RayHit> {
    let dir=direction.normalize_or_zero(); if dir==Vec3::ZERO || reach<=0.0 {return None;}
    let mut cell=BlockPos{x:origin.x.floor() as i32,y:origin.y.floor() as i32,z:origin.z.floor() as i32};
    let step=[dir.x.signum() as i32,dir.y.signum() as i32,dir.z.signum() as i32];
    let delta=[if dir.x==0.0 {f32::INFINITY}else{dir.x.abs().recip()},if dir.y==0.0 {f32::INFINITY}else{dir.y.abs().recip()},if dir.z==0.0 {f32::INFINITY}else{dir.z.abs().recip()}];
    let mut t=[if step[0]>0 {(cell.x as f32+1.0-origin.x)/dir.x}else if step[0]<0 {(cell.x as f32-origin.x)/dir.x}else{f32::INFINITY},if step[1]>0 {(cell.y as f32+1.0-origin.y)/dir.y}else if step[1]<0 {(cell.y as f32-origin.y)/dir.y}else{f32::INFINITY},if step[2]>0 {(cell.z as f32+1.0-origin.z)/dir.z}else if step[2]<0 {(cell.z as f32-origin.z)/dir.z}else{f32::INFINITY}];
    let mut distance=0.0; let mut face=[0,0,0];
    loop { if is_solid(cell) {return Some(RayHit{pos:cell,face,distance});} let axis=if t[0]<=t[1]&&t[0]<=t[2]{0}else if t[1]<=t[2]{1}else{2}; distance=t[axis]; if distance>reach {return None;} match axis {0=>cell.x+=step[0],1=>cell.y+=step[1],_=>cell.z+=step[2]}; face=[0,0,0]; face[axis]=-step[axis]; t[axis]+=delta[axis]; }
}

#[derive(Debug,Clone,Copy,PartialEq,Eq)]
pub enum MiningEvent { None, Started(BlockPos), Progress{stage:u8}, Broken(BlockPos), Cancelled }
#[derive(Debug,Clone,Copy,PartialEq)]
pub struct MiningController { target:Option<BlockPos>, progress:f32, delay_ticks:u8 }
impl Default for MiningController {fn default()->Self{Self{target:None,progress:0.0,delay_ticks:0}}}
impl MiningController {
    pub fn reset(&mut self)->MiningEvent {let had=self.target.take().is_some();self.progress=0.0;if had{MiningEvent::Cancelled}else{MiningEvent::None}}
    pub fn progress(&self)->f32 {self.progress.clamp(0.0,1.0)}
    pub fn tick(&mut self, hit:Option<(BlockPos,BlockInfo)>, held:bool, tool:HeldTool, ctx:MiningContext)->MiningEvent {
        if !held {return self.reset();}
        let Some((pos,block))=hit else{return self.reset();};
        if self.target!=Some(pos) {self.target=Some(pos);self.progress=0.0;}
        if self.delay_ticks>0 {self.delay_ticks-=1;return MiningEvent::None;}
        let damage=damage_per_tick(block,tool,ctx);
        if damage<=0.0 {return MiningEvent::None;}
        self.progress+=damage;
        if self.progress>=1.0 {self.target=None;self.progress=0.0;self.delay_ticks=5;MiningEvent::Broken(pos)}
        else {MiningEvent::Progress{stage:((self.progress*10.0).floor() as u8).min(9)}}
    }
}


#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn vanilla_stone_hardness_uses_harvest_divisor_and_tool_speed() {
        let stone = block_info(1, 0).unwrap();
        let wood_pick = HeldTool { kind: ToolKind::Pickaxe, tier: ToolTier::Wood, efficiency: 0 };
        let damage = damage_per_tick(stone, wood_pick, MiningContext::default());
        assert!((damage - (2.0 / 1.5 / 30.0)).abs() < 1.0e-6);
    }
    #[test]
    fn non_harvest_tool_uses_one_hundred_tick_divisor() {
        let diamond_ore = block_info(56, 0).unwrap();
        let hand = HeldTool::default();
        let damage = damage_per_tick(diamond_ore, hand, MiningContext::default());
        assert!((damage - (1.0 / 3.0 / 100.0)).abs() < 1.0e-7);
        assert!(!can_harvest(hand, diamond_ore));
    }
    #[test]
    fn releasing_attack_resets_server_mining_progress() {
        let mut controller = MiningController::default();
        let stone = block_info(1, 0).unwrap();
        let target = Some((BlockPos { x: 1, y: 64, z: 1 }, stone));
        let pick = HeldTool { kind: ToolKind::Pickaxe, tier: ToolTier::Wood, efficiency: 0 };
        assert!(matches!(controller.tick(target, true, pick, MiningContext::default()), MiningEvent::Progress { .. }));
        assert_eq!(controller.tick(target, false, pick, MiningContext::default()), MiningEvent::Cancelled);
        assert_eq!(controller.progress(), 0.0);
    }
}
