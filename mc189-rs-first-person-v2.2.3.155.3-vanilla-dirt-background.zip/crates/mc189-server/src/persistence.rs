//! Server-owned deferred Anvil persistence. The client submits immutable snapshots;
//! this worker serializes region writes and player-data patches off the 20 TPS loop.
use mc189_core::{Mc189Error, Result};
use mc189_storage::{load_mutable_chunk, save_mutable_chunks, ChunkData, NbtTag};
use crate::entity_item::{EntityItem, EntityItemSnapshot};
use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::sync::{mpsc::{self, Receiver, Sender}, Arc, Mutex};
use std::thread::{self, JoinHandle};

#[derive(Clone)]
pub struct DirtyChunkSnapshot { pub revision: u64, pub chunk: ChunkData }
#[derive(Clone)]
pub struct PlayerDataSnapshot { pub revision: u64, pub player_nbt_patch: NbtTag }
#[derive(Clone)]
pub struct EntityItemsSnapshot { pub revision: u64, pub entities: Vec<EntityItemSnapshot>, pub chunks: Vec<(i32, i32)>, pub origin_chunk_x: i32, pub origin_chunk_z: i32 }
pub struct WorldSaveRequest { pub snapshots: Vec<DirtyChunkSnapshot>, pub player: Option<PlayerDataSnapshot>, pub entities: Option<EntityItemsSnapshot>, pub final_flush: bool }
pub struct WorldSaveResult { pub saved: Vec<((i32, i32), u64)>, pub saved_player_revision: Option<u64>, pub saved_entity_revision: Option<u64>, pub final_flush: bool, pub error: Option<String> }

pub struct WorldPersistence {
    requests: Option<Sender<WorldSaveRequest>>,
    results: Receiver<WorldSaveResult>,
    worker: Option<JoinHandle<()>>,
}
impl WorldPersistence {
    pub fn start(world: PathBuf, world_io_lock: Arc<Mutex<()>>) -> Result<Self> {
        let (request_tx, request_rx) = mpsc::channel::<WorldSaveRequest>();
        let (result_tx, result_rx) = mpsc::channel::<WorldSaveResult>();
        let worker = thread::Builder::new().name("mc189-server-world-persistence".into()).spawn(move || {
            while let Ok(request) = request_rx.recv() {
                let started = std::time::Instant::now();
                let final_flush = request.final_flush;
                let mut saved = Vec::new();
                let mut saved_player_revision = None;
                let mut saved_entity_revision = None;
                let mut errors = Vec::new();
                match save_world_snapshot(&world, &world_io_lock, &request.snapshots, request.entities.as_ref()) {
                    Ok(()) => {
                        saved = request.snapshots.iter().map(|s| ((s.chunk.x_pos, s.chunk.z_pos), s.revision)).collect();
                        saved_entity_revision = request.entities.as_ref().map(|entities| entities.revision);
                    }
                    Err(error) => errors.push(format!("chunk/entity save: {error}")),
                }
                if let Some(player) = request.player.as_ref() {
                    let result = (|| -> Result<()> {
                        let _guard = world_io_lock.lock().map_err(|_| Mc189Error::InvalidData("world I/O lock was poisoned".into()))?;
                        mc189_storage::write_world_player_data(&world, &player.player_nbt_patch)
                    })();
                    match result { Ok(()) => saved_player_revision = Some(player.revision), Err(e) => errors.push(format!("player data save: {e}")) }
                }
                let error = (!errors.is_empty()).then(|| errors.join("; "));
                eprintln!("[server save] chunks={} player={} entities={} final={} elapsed={:.1}ms ok={}", request.snapshots.len(), request.player.is_some(), request.entities.is_some(), final_flush, started.elapsed().as_secs_f64()*1000.0, error.is_none());
                if result_tx.send(WorldSaveResult { saved, saved_player_revision, saved_entity_revision, final_flush, error }).is_err() { break; }
            }
            eprintln!("[server save] persistence worker stopped");
        }).map_err(|e| Mc189Error::InvalidData(format!("cannot start server persistence worker: {e}")))?;
        Ok(Self { requests: Some(request_tx), results: result_rx, worker: Some(worker) })
    }
    pub fn request_save(&self, request: WorldSaveRequest) -> Result<()> {
        self.requests.as_ref().ok_or_else(|| Mc189Error::InvalidData("server persistence is closing".into()))?
            .send(request).map_err(|_| Mc189Error::InvalidData("server persistence worker stopped".into()))
    }
    pub fn try_result(&self) -> std::result::Result<WorldSaveResult, mpsc::TryRecvError> { self.results.try_recv() }
}
impl Drop for WorldPersistence {
    fn drop(&mut self) {
        self.requests.take();
        if let Some(worker) = self.worker.take() { let _ = worker.join(); }
        eprintln!("[server save] persistence stopped; all queued writes have finished");
    }
}
fn save_world_snapshot(
    world: &Path,
    lock: &Mutex<()>,
    snapshots: &[DirtyChunkSnapshot],
    entities: Option<&EntityItemsSnapshot>,
) -> Result<()> {
    if snapshots.is_empty() && entities.is_none() { return Ok(()); }
    let _guard = lock.lock().map_err(|_| Mc189Error::InvalidData("world I/O lock was poisoned".into()))?;
    let mut mutable: HashMap<(i32, i32), mc189_storage::MutableChunk> = HashMap::new();
    for snapshot in snapshots {
        let key = (snapshot.chunk.x_pos, snapshot.chunk.z_pos);
        let mut chunk = load_mutable_chunk(world, key.0, key.1)?;
        chunk.apply_chunk_snapshot(&snapshot.chunk)?;
        mutable.insert(key, chunk);
    }
    if let Some(entity_snapshot) = entities {
        let mut grouped: HashMap<(i32, i32), Vec<NbtTag>> = HashMap::new();
        for entity in &entity_snapshot.entities {
            if !entity.position.is_finite() || !entity.velocity.is_finite() { continue; }
            let cx = (entity.position.x.floor() as i32).div_euclid(16);
            let cz = (entity.position.z.floor() as i32).div_euclid(16);
            grouped.entry((cx.saturating_add(entity_snapshot.origin_chunk_x), cz.saturating_add(entity_snapshot.origin_chunk_z))).or_default().push(entity_to_nbt(entity, entity_snapshot.origin_chunk_x, entity_snapshot.origin_chunk_z));
        }
        let mut chunk_keys: HashSet<(i32, i32)> = entity_snapshot.chunks.iter().copied().collect();
        chunk_keys.extend(grouped.keys().copied());
        for key in chunk_keys {
            let chunk = if let Some(chunk) = mutable.get_mut(&key) { chunk }
                else { mutable.entry(key).or_insert(load_mutable_chunk(world, key.0, key.1)?); mutable.get_mut(&key).unwrap() };
            chunk.replace_entity_nbt_list(grouped.remove(&key).unwrap_or_default())?;
        }
    }
    let mut chunks: Vec<_> = mutable.into_values().collect();
    save_mutable_chunks(world, &mut chunks)
}

fn entity_to_nbt(entity: &EntityItemSnapshot, origin_chunk_x: i32, origin_chunk_z: i32) -> NbtTag {
    let mut item = EntityItem {
        entity_id: entity.entity_id,
        item_id: entity.item_id,
        metadata: entity.metadata,
        count: entity.count,
        nbt_tag: entity.nbt_tag.clone(),
        previous_position: entity.position,
        position: entity.position,
        velocity: entity.velocity,
        age: entity.age,
        pickup_delay: entity.pickup_delay,
        hover_start: entity.hover_start,
        provisional: false,
    };
    let world_offset_x = (i64::from(origin_chunk_x) * 16) as f32;
    let world_offset_z = (i64::from(origin_chunk_z) * 16) as f32;
    item.position.x += world_offset_x;
    item.position.z += world_offset_z;
    item.previous_position = item.position;
    item.to_chunk_nbt()
}

#[cfg(test)]
mod tests {
    use super::*;
    use glam::Vec3;

    #[test]
    fn entity_nbt_uses_absolute_world_coordinates_for_negative_origins() {
        let snapshot = EntityItemSnapshot {
            entity_id: 44, item_id: 4, metadata: 2, count: 3, nbt_tag: None,
            previous_position: Vec3::ZERO, position: Vec3::new(-0.25, 70.0, 1.5),
            velocity: Vec3::new(0.1, 0.2, -0.1), age: 12, pickup_delay: 7, hover_start: 0.0,
        };
        let tag = entity_to_nbt(&snapshot, -2, 3);
        let (kind, pos) = tag.get("Pos").unwrap().as_list().unwrap();
        assert_eq!(kind, 6);
        let values: Vec<f64> = pos.iter().map(|v| match v { NbtTag::Double(x) => *x, _ => panic!("expected TAG_Double") }).collect();
        assert_eq!(values, vec![-32.25, 70.0, 49.5]);
    }
}
