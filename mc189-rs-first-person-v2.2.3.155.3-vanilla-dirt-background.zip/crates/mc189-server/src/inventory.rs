//! Server-owned vanilla 1.8.9 inventory data model and slot mutation rules.
//! GUI rendering stays in mc189-app; authoritative copies live in mc189-server.
use mc189_core::{Mc189Error, Result};
use mc189_storage::NbtTag;
const INVENTORY_SLOTS: usize = 36;
const HOTBAR_SLOTS: usize = 9;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ItemStack {
    /// Registry identifier, without the `minecraft:` namespace prefix.
    pub id: String,
    pub count: u16,
    pub damage: u16,
    /// Opaque vanilla ItemStack `tag` compound (enchants, custom names, attributes, etc.).
    /// The current GUI does not interpret every payload, but must never discard it.
    pub nbt_tag: Option<NbtTag>,
}

impl ItemStack {
    pub fn max_stack_size(&self) -> u16 {
        max_stack_size(&self.id)
    }

    fn compatible_with(&self, other: &Self) -> bool {
        self.id == other.id && self.damage == other.damage && self.nbt_tag == other.nbt_tag
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct PlayerInventory {
    /// MCP InventoryPlayer.mainInventory: slots 0-8 are the visible hotbar;
    /// slots 9-35 are the three inventory rows.
    pub slots: Vec<Option<ItemStack>>,
    /// InventoryPlayer.armorInventory uses boots, leggings, chestplate, helmet.
    pub armor_slots: Vec<Option<ItemStack>>,
    pub selected_hotbar: usize,
    pub cursor_stack: Option<ItemStack>,
}

impl Default for PlayerInventory {
    fn default() -> Self {
        Self { slots: vec![None; INVENTORY_SLOTS], armor_slots: vec![None; 4], selected_hotbar: 0, cursor_stack: None }
    }
}

impl PlayerInventory {
    /// Decode the InventoryPlayer fields used by Minecraft 1.8.9 from the
    /// single-player level.dat Data.Player compound.
    pub fn from_player_nbt(player: Option<&NbtTag>) -> Result<Self> {
        let mut inventory = Self::default();
        let Some(player) = player else { return Ok(inventory); };
        if player.as_compound().is_none() {
            return Err(Mc189Error::InvalidData("saved Player data is not an NBT compound".into()));
        }
        if let Some(tag) = player.get("Inventory") {
            let Some((element_type, entries)) = tag.as_list() else {
                return Err(Mc189Error::InvalidData("Player.Inventory is not an NBT list".into()));
            };
            // A brand-new vanilla NBTTagList has TAG_End (0) as its element
            // type until its first entry is appended. Accept that only when empty.
            if element_type != 10 && !(element_type == 0 && entries.is_empty()) {
                return Err(Mc189Error::InvalidData(format!("Player.Inventory list element type is {element_type}, expected compound")));
            }
            for entry in entries {
                let Some(slot_tag) = entry.get("Slot") else { continue; };
                let Some(slot_byte) = slot_tag.as_byte() else { continue; };
                let slot = slot_byte as u8;
                let Some(id) = entry.get("id").and_then(NbtTag::as_string) else { continue; };
                let Some(count) = entry.get("Count").and_then(NbtTag::as_byte) else { continue; };
                if count <= 0 || id.is_empty() || id == "minecraft:air" { continue; }
                let damage = entry.get("Damage").and_then(NbtTag::as_short).unwrap_or(0).max(0) as u16;
                let id = id.strip_prefix("minecraft:").unwrap_or(id).to_owned();
                let stack = ItemStack { id, count: count as u16, damage, nbt_tag: entry.get("tag").cloned() };
                if usize::from(slot) < INVENTORY_SLOTS {
                    inventory.slots[usize::from(slot)] = Some(stack);
                } else if (100..104).contains(&slot) {
                    inventory.armor_slots[usize::from(slot - 100)] = Some(stack);
                }
            }
        }
        if let Some(selected) = player.get("SelectedItemSlot") {
            if let Some(index) = selected.as_int() {
                inventory.selected_hotbar = index.clamp(0, (HOTBAR_SLOTS - 1) as i32) as usize;
            }
        }
        // GuiContainer's carried cursor stack is transient and is not part of
        // InventoryPlayer.writeToNBT in vanilla 1.8.9.
        inventory.cursor_stack = None;
        Ok(inventory)
    }

    /// Encode InventoryPlayer.mainInventory, armorInventory and currentItem with
    /// the vanilla NBT slot layout (+100 for armor). Storage merges this patch
    /// into the existing Data.Player compound so unrelated player state survives.
    pub fn to_player_nbt(&self) -> NbtTag {
        let mut entries = Vec::new();
        let mut append_stack = |slot: u8, stack: &ItemStack| {
            let id = if stack.id.starts_with("minecraft:") {
                stack.id.clone()
            } else {
                format!("minecraft:{}", stack.id)
            };
            let mut fields = vec![
                ("Slot".into(), NbtTag::Byte(slot as i8)),
                ("id".into(), NbtTag::String(id)),
                ("Count".into(), NbtTag::Byte(stack.count.min(127) as i8)),
                ("Damage".into(), NbtTag::Short(stack.damage.min(i16::MAX as u16) as i16)),
            ];
            if let Some(tag) = stack.nbt_tag.as_ref() { fields.push(("tag".into(), tag.clone())); }
            entries.push(NbtTag::Compound(fields));
        };
        for (slot, stack) in self.slots.iter().enumerate() {
            if let Some(stack) = stack { append_stack(slot as u8, stack); }
        }
        for (slot, stack) in self.armor_slots.iter().enumerate() {
            if let Some(stack) = stack { append_stack((slot + 100) as u8, stack); }
        }
        NbtTag::Compound(vec![
            ("Inventory".into(), NbtTag::List(if entries.is_empty() { 0 } else { 10 }, entries)),
            ("SelectedItemSlot".into(), NbtTag::Int(self.selected_hotbar.min(HOTBAR_SLOTS - 1) as i32)),
        ])
    }

    pub fn current_item(&self) -> Option<&ItemStack> {
        self.slots.get(self.selected_hotbar).and_then(Option::as_ref)
    }

    pub fn select_hotbar(&mut self, slot: usize) -> bool {
        if slot >= HOTBAR_SLOTS || self.selected_hotbar == slot { return false; }
        self.selected_hotbar = slot;
        true
    }

    /// Mirrors InventoryPlayer.addItemStackToInventory's merge-first behaviour.
    /// Returns the amount actually inserted; a full-inventory drop entity is not
    /// implemented yet, so the exact remainder is reported rather than discarded.
    pub fn insert(&mut self, stack: &ItemStack, amount: u16) -> u16 {
        let max_stack = stack.max_stack_size().max(1);
        let mut remaining = amount;
        for slot in &mut self.slots {
            if remaining == 0 { break; }
            if let Some(existing) = slot {
                if existing.compatible_with(stack) && existing.count < max_stack {
                    let moved = remaining.min(max_stack - existing.count);
                    existing.count += moved;
                    remaining -= moved;
                }
            }
        }
        for slot in &mut self.slots {
            if remaining == 0 { break; }
            if slot.is_none() {
                let moved = remaining.min(max_stack);
                *slot = Some(ItemStack { id: stack.id.clone(), count: moved, damage: stack.damage, nbt_tag: stack.nbt_tag.clone() });
                remaining -= moved;
            }
        }
        amount - remaining
    }

    /// Remove one item or the complete stack from a main/armor slot, returning
    /// an independent stack copy suitable for a world EntityItem drop.
    pub fn take_stack_for_drop(&mut self, slot_index: usize, drop_all: bool) -> Option<ItemStack> {
        let slot = if slot_index < INVENTORY_SLOTS {
            self.slots.get_mut(slot_index)?
        } else {
            self.armor_slots.get_mut(slot_index.checked_sub(INVENTORY_SLOTS)?)?
        };
        let current = slot.as_mut()?;
        let amount = if drop_all { current.count } else { current.count.min(1) };
        if amount == 0 { return None; }
        let dropped = ItemStack {
            id: current.id.clone(), count: amount, damage: current.damage,
            nbt_tag: current.nbt_tag.clone(),
        };
        current.count -= amount;
        if current.count == 0 { *slot = None; }
        Some(dropped)
    }

    /// Take the carried GuiContainer cursor stack for a server-owned world drop.
    pub fn take_cursor_for_drop(&mut self) -> Option<ItemStack> { self.cursor_stack.take() }

    pub fn click_stack(&mut self, slot_index: usize, right_click: bool) -> bool {
        let Some(slot) = self.slots.get_mut(slot_index) else { return false; };
        match (self.cursor_stack.take(), slot.take()) {
            (None, None) => false,
            (None, Some(mut target)) => {
                if right_click {
                    let take = target.count.div_ceil(2);
                    target.count -= take;
                    self.cursor_stack = Some(ItemStack { id: target.id.clone(), count: take, damage: target.damage, nbt_tag: target.nbt_tag.clone() });
                    if target.count > 0 { *slot = Some(target); }
                } else {
                    self.cursor_stack = Some(target);
                }
                true
            }
            (Some(cursor), None) => {
                if right_click {
                    self.cursor_stack = if cursor.count > 1 {
                        Some(ItemStack { id: cursor.id.clone(), count: cursor.count - 1, damage: cursor.damage, nbt_tag: cursor.nbt_tag.clone() })
                    } else { None };
                    *slot = Some(ItemStack { id: cursor.id, count: 1, damage: cursor.damage, nbt_tag: cursor.nbt_tag });
                } else {
                    *slot = Some(cursor);
                }
                true
            }
            (Some(mut cursor), Some(mut target)) if cursor.compatible_with(&target) => {
                let limit = target.max_stack_size();
                if right_click {
                    if target.count < limit {
                        target.count += 1;
                        cursor.count -= 1;
                    }
                } else {
                    let moved = cursor.count.min(limit.saturating_sub(target.count));
                    target.count += moved;
                    cursor.count -= moved;
                }
                *slot = Some(target);
                self.cursor_stack = (cursor.count > 0).then_some(cursor);
                true
            }
            (Some(cursor), Some(target)) => {
                // Container slot pickup swaps stacks when their slot limits allow it.
                if cursor.count <= target.max_stack_size() && target.count <= cursor.max_stack_size() {
                    *slot = Some(cursor);
                    self.cursor_stack = Some(target);
                } else {
                    *slot = Some(target);
                    self.cursor_stack = Some(cursor);
                }
                true
            }
        }
    }

    pub fn click_armor_stack(&mut self, armor_index: usize) -> bool {
        if armor_index >= self.armor_slots.len() { return false; }
        let Some(slot) = self.armor_slots.get_mut(armor_index) else { return false; };
        match (self.cursor_stack.take(), slot.take()) {
            (None, None) => false,
            (None, Some(target)) => { self.cursor_stack = Some(target); true }
            (Some(cursor), None) => {
                if cursor.count == 1 && armor_slot_accepts(&cursor.id, armor_index) {
                    *slot = Some(cursor);
                } else {
                    self.cursor_stack = Some(cursor);
                }
                true
            }
            (Some(cursor), Some(target)) => {
                if cursor.count == 1 && armor_slot_accepts(&cursor.id, armor_index) {
                    *slot = Some(cursor);
                    self.cursor_stack = Some(target);
                } else {
                    *slot = Some(target);
                    self.cursor_stack = Some(cursor);
                }
                true
            }
        }
    }

    pub fn shift_move_armor_to_inventory(&mut self, armor_index: usize) -> bool {
        if armor_index >= self.armor_slots.len() { return false; }
        let Some(stack) = self.armor_slots[armor_index].take() else { return false; };
        let inserted = self.insert(&stack, stack.count);
        if inserted < stack.count {
            self.armor_slots[armor_index] = Some(ItemStack { count: stack.count - inserted, ..stack });
        }
        true
    }

    pub fn shift_auto_equip(&mut self, source_index: usize) -> bool {
        let Some(stack) = self.slots.get(source_index).and_then(Option::as_ref).cloned() else { return false; };
        let Some(armor_index) = armor_slot_for_item(&stack.id) else { return false; };
        if stack.count != 1 || self.armor_slots[armor_index].is_some() { return false; }
        self.armor_slots[armor_index] = self.slots[source_index].take();
        true
    }

    pub fn shift_move_stack(&mut self, source_index: usize, target_start: usize, target_end: usize) -> bool {
        if source_index >= self.slots.len() || target_start >= target_end || target_end > self.slots.len() {
            return false;
        }
        let Some(mut stack) = self.slots[source_index].take() else { return false; };
        let max_stack = stack.max_stack_size().max(1);
        for index in target_start..target_end {
            if stack.count == 0 { break; }
            if let Some(target) = self.slots[index].as_mut() {
                if target.compatible_with(&stack) && target.count < max_stack {
                    let moved = stack.count.min(max_stack - target.count);
                    target.count += moved;
                    stack.count -= moved;
                }
            }
        }
        for index in target_start..target_end {
            if stack.count == 0 { break; }
            if self.slots[index].is_none() {
                let moved = stack.count.min(max_stack);
                self.slots[index] = Some(ItemStack { id: stack.id.clone(), count: moved, damage: stack.damage, nbt_tag: stack.nbt_tag.clone() });
                stack.count -= moved;
            }
        }
        if stack.count > 0 { self.slots[source_index] = Some(stack); }
        true
    }

}

fn armor_slot_for_item(id: &str) -> Option<usize> {
    if id.ends_with("_boots") { Some(0) }
    else if id.ends_with("_leggings") { Some(1) }
    else if id.ends_with("_chestplate") { Some(2) }
    else if id.ends_with("_helmet") || id == "skull" || id == "pumpkin" { Some(3) }
    else { None }
}

fn armor_slot_accepts(id: &str, armor_index: usize) -> bool {
    armor_slot_for_item(id) == Some(armor_index)
}

pub fn max_stack_size_for_item(id: &str) -> u16 {
    max_stack_size(id)
}

/// Stack cap for a legacy numeric item ID, used by server-side EntityItem merging.
pub fn max_stack_size_for_legacy_id(id: u16) -> u8 {
    legacy_item_name_from_numeric_id(id).map(max_stack_size).unwrap_or(64).min(64) as u8
}


fn legacy_numeric_item(id: u16) -> Option<&'static str> {
    // Numeric item/block IDs are accepted just like Item.getByNameOrId in 1.8.9.
    Some(match id {
        1 => "stone", 2 => "grass", 3 => "dirt", 4 => "cobblestone", 5 => "planks", 6 => "sapling", 7 => "bedrock",
        8 => "flowing_water", 9 => "water", 10 => "flowing_lava", 11 => "lava", 12 => "sand", 13 => "gravel", 14 => "gold_ore",
        15 => "iron_ore", 16 => "coal_ore", 17 => "log", 18 => "leaves", 19 => "sponge", 20 => "glass", 21 => "lapis_ore",
        22 => "lapis_block", 23 => "dispenser", 24 => "sandstone", 25 => "noteblock", 27 => "powered_rail", 28 => "detector_rail",
        29 => "sticky_piston", 30 => "web", 31 => "tallgrass", 32 => "deadbush", 33 => "piston", 34 => "piston_head", 35 => "wool", 37 => "yellow_flower", 38 => "red_flower",
        39 => "brown_mushroom", 40 => "red_mushroom", 41 => "gold_block", 42 => "iron_block", 43 => "double_stone_slab",
        44 => "stone_slab", 45 => "brick_block", 46 => "tnt", 47 => "bookshelf", 48 => "mossy_cobblestone", 49 => "obsidian",
        50 => "torch", 53 => "oak_stairs", 54 => "chest", 56 => "diamond_ore", 57 => "diamond_block", 58 => "crafting_table",
        61 => "furnace", 65 => "ladder", 67 => "stone_stairs", 71 => "iron_door", 78 => "snow_layer", 79 => "ice", 80 => "snow",
        81 => "cactus", 82 => "clay", 84 => "jukebox", 85 => "fence", 86 => "pumpkin", 87 => "netherrack", 88 => "soul_sand",
        89 => "glowstone", 95 => "stained_glass", 96 => "trapdoor", 97 => "monster_egg", 98 => "stonebrick", 101 => "iron_bars",
        102 => "glass_pane", 103 => "melon_block", 107 => "fence_gate", 108 => "brick_stairs", 109 => "stone_brick_stairs",
        112 => "nether_brick", 113 => "nether_brick_fence", 114 => "nether_brick_stairs", 116 => "enchanting_table", 117 => "brewing_stand",
        121 => "end_stone", 123 => "redstone_lamp", 126 => "wooden_slab", 128 => "sandstone_stairs", 129 => "emerald_ore", 130 => "ender_chest",
        133 => "emerald_block", 134 => "spruce_stairs", 135 => "birch_stairs", 136 => "jungle_stairs", 138 => "beacon", 139 => "cobblestone_wall",
        145 => "anvil", 146 => "trapped_chest", 152 => "redstone_block", 154 => "hopper", 155 => "quartz_block", 156 => "quartz_stairs",
        158 => "dropper", 159 => "stained_hardened_clay", 160 => "stained_glass_pane", 161 => "leaves2", 162 => "log2", 163 => "acacia_stairs",
        164 => "dark_oak_stairs", 165 => "slime_block", 166 => "barrier", 167 => "iron_trapdoor", 168 => "prismarine", 169 => "sea_lantern",
        170 => "hay_block", 171 => "carpet", 172 => "hardened_clay", 173 => "coal_block", 174 => "packed_ice", 175 => "double_plant",
        179 => "red_sandstone", 180 => "red_sandstone_stairs", 181 => "double_stone_slab2", 182 => "stone_slab2",
        183 => "spruce_fence_gate", 184 => "birch_fence_gate", 185 => "jungle_fence_gate", 186 => "dark_oak_fence_gate", 187 => "acacia_fence_gate",
        188 => "spruce_fence", 189 => "birch_fence", 190 => "jungle_fence", 191 => "dark_oak_fence", 192 => "acacia_fence",
        193 => "spruce_door", 194 => "birch_door", 195 => "jungle_door", 196 => "acacia_door", 197 => "dark_oak_door", 256 => "iron_shovel", 257 => "iron_pickaxe", 258 => "iron_axe", 259 => "flint_and_steel",
        260 => "apple", 261 => "bow", 262 => "arrow", 263 => "coal", 264 => "diamond", 265 => "iron_ingot", 266 => "gold_ingot",
        267 => "iron_sword", 268 => "wooden_sword", 269 => "wooden_shovel", 270 => "wooden_pickaxe", 271 => "wooden_axe", 272 => "stone_sword",
        273 => "stone_shovel", 274 => "stone_pickaxe", 275 => "stone_axe", 276 => "diamond_sword", 277 => "diamond_shovel", 278 => "diamond_pickaxe",
        279 => "diamond_axe", 280 => "stick", 281 => "bowl", 282 => "mushroom_stew", 283 => "golden_sword", 284 => "golden_shovel",
        285 => "golden_pickaxe", 286 => "golden_axe", 287 => "string", 288 => "feather", 289 => "gunpowder", 290 => "wooden_hoe",
        291 => "stone_hoe", 292 => "iron_hoe", 293 => "diamond_hoe", 294 => "golden_hoe", 295 => "wheat_seeds", 296 => "wheat", 297 => "bread",
        298 => "leather_helmet", 299 => "leather_chestplate", 300 => "leather_leggings", 301 => "leather_boots", 302 => "chainmail_helmet", 303 => "chainmail_chestplate", 304 => "chainmail_leggings", 305 => "chainmail_boots", 306 => "iron_helmet",
        307 => "iron_chestplate", 308 => "iron_leggings", 309 => "iron_boots", 310 => "diamond_helmet", 311 => "diamond_chestplate",
        312 => "diamond_leggings", 313 => "diamond_boots", 314 => "golden_helmet", 315 => "golden_chestplate", 316 => "golden_leggings", 317 => "golden_boots", 318 => "flint", 319 => "porkchop", 320 => "cooked_porkchop", 321 => "painting",
        322 => "golden_apple", 323 => "sign", 324 => "wooden_door", 325 => "bucket", 326 => "water_bucket", 327 => "lava_bucket",
        328 => "minecart", 329 => "saddle", 330 => "iron_door", 331 => "redstone", 332 => "snowball", 333 => "boat", 334 => "leather",
        335 => "milk_bucket", 336 => "brick", 337 => "clay_ball", 338 => "reeds", 339 => "paper", 340 => "book", 341 => "slime_ball",
        342 => "chest_minecart", 343 => "furnace_minecart", 344 => "egg", 345 => "compass", 346 => "fishing_rod", 347 => "clock", 348 => "glowstone_dust",
        349 => "fish", 350 => "cooked_fish", 351 => "dye", 352 => "bone", 353 => "sugar", 354 => "cake", 355 => "bed",
        356 => "repeater", 357 => "cookie", 358 => "map", 359 => "shears", 360 => "melon", 361 => "pumpkin_seeds", 362 => "melon_seeds",
        363 => "beef", 364 => "cooked_beef", 365 => "chicken", 366 => "cooked_chicken", 367 => "rotten_flesh", 368 => "ender_pearl",
        369 => "blaze_rod", 370 => "ghast_tear", 371 => "gold_nugget", 372 => "nether_wart", 373 => "potion", 374 => "glass_bottle",
        375 => "spider_eye", 376 => "fermented_spider_eye", 377 => "blaze_powder", 378 => "magma_cream", 379 => "brewing_stand",
        380 => "cauldron", 381 => "ender_eye", 382 => "speckled_melon", 383 => "spawn_egg", 384 => "experience_bottle", 385 => "fire_charge",
        386 => "writable_book", 387 => "written_book", 388 => "emerald", 389 => "item_frame", 390 => "flower_pot", 391 => "carrot",
        392 => "potato", 393 => "baked_potato", 394 => "poisonous_potato", 395 => "filled_map", 396 => "golden_carrot", 397 => "skull",
        398 => "carrot_on_a_stick", 399 => "nether_star", 400 => "pumpkin_pie", 401 => "fireworks", 402 => "firework_charge", 403 => "enchanted_book",
        404 => "comparator", 405 => "netherbrick", 406 => "quartz", 407 => "tnt_minecart", 408 => "hopper_minecart", 409 => "prismarine_shard",
        410 => "prismarine_crystals", 411 => "rabbit", 412 => "cooked_rabbit", 413 => "rabbit_stew", 414 => "rabbit_foot", 415 => "rabbit_hide",
        416 => "armor_stand", 417 => "iron_horse_armor", 418 => "golden_horse_armor", 419 => "diamond_horse_armor", 420 => "lead", 421 => "name_tag",
        423 => "mutton", 424 => "cooked_mutton", 425 => "banner", 427 => "spruce_door", 428 => "birch_door", 429 => "jungle_door", 430 => "acacia_door", 431 => "dark_oak_door",
        _ => return None,
    })
}

/// Resolve a legacy 1.8.9 numeric item/block ID back to the same registry name
/// used by ItemStack and dropped EntityItem rendering. Shared by pickup, drop,
/// and the world-item renderer so tools/armour are not limited to block drops.
pub fn legacy_item_name_from_numeric_id(id: u16) -> Option<&'static str> {
    legacy_numeric_item(id)
}

/// Resolve an InventoryUi registry name to its legacy 1.8.9 numeric Item ID.
/// Prefer item IDs above 255 when a block and its inventory item share a name
/// (for example, iron_door is item 330 rather than block 71).
pub fn legacy_numeric_id_from_item_name(raw: &str) -> Option<u16> {
    let name = raw.strip_prefix("minecraft:").unwrap_or(raw);
    if name == "redstone" { return Some(331); }
    (1_u16..=431).rev().find(|id| legacy_numeric_item(*id) == Some(name))
}


fn max_stack_size(id: &str) -> u16 {
    // Mirrors the per-item limits in the 1.8.9 item constructors. Filled and
    // empty buckets are size 1 in this version; doors remain ordinary stackable
    // block-items (64), whereas signs, snowballs, eggs and pearls use 16.
    if matches!(id,
        "wooden_sword" | "stone_sword" | "iron_sword" | "diamond_sword" | "golden_sword" |
        "wooden_shovel" | "stone_shovel" | "iron_shovel" | "diamond_shovel" | "golden_shovel" |
        "wooden_pickaxe" | "stone_pickaxe" | "iron_pickaxe" | "diamond_pickaxe" | "golden_pickaxe" |
        "wooden_axe" | "stone_axe" | "iron_axe" | "diamond_axe" | "golden_axe" |
        "wooden_hoe" | "stone_hoe" | "iron_hoe" | "diamond_hoe" | "golden_hoe" |
        "bow" | "fishing_rod" | "flint_and_steel" | "shears" | "carrot_on_a_stick" |
        "leather_helmet" | "leather_chestplate" | "leather_leggings" | "leather_boots" |
        "chainmail_helmet" | "chainmail_chestplate" | "chainmail_leggings" | "chainmail_boots" |
        "iron_helmet" | "iron_chestplate" | "iron_leggings" | "iron_boots" |
        "diamond_helmet" | "diamond_chestplate" | "diamond_leggings" | "diamond_boots" |
        "golden_helmet" | "golden_chestplate" | "golden_leggings" | "golden_boots" |
        "saddle" | "minecart" | "chest_minecart" | "furnace_minecart" | "tnt_minecart" |
        "hopper_minecart" | "command_block_minecart" | "boat" | "writable_book" |
        "enchanted_book" | "potion" | "splash_potion" |
        "water_bucket" | "lava_bucket" | "milk_bucket" | "bucket" |
        "mushroom_stew" | "rabbit_stew" | "cake" | "bed" | "record_13" | "record_cat" |
        "record_blocks" | "record_chirp" | "record_far" | "record_mall" | "record_mellohi" |
        "record_stal" | "record_strad" | "record_ward" | "record_11" | "record_wait" |
        "filled_map") { return 1; }
    if id == "written_book" { return 1; }
    if matches!(id,
        "snowball" | "egg" | "ender_pearl" | "sign" | "armor_stand" | "banner") { return 16; }
    64
}


#[cfg(test)]
mod tests {
    use super::*;

    fn stack(id: &str, count: u16) -> ItemStack {
        ItemStack { id: id.into(), count, damage: 0, nbt_tag: None }
    }

    #[test]
    fn legacy_entity_item_stack_caps_match_the_shared_item_registry() {
        assert_eq!(max_stack_size_for_legacy_id(278), 1); // diamond pickaxe
        assert_eq!(max_stack_size_for_legacy_id(387), 1); // written book
        assert_eq!(max_stack_size_for_legacy_id(323), 16); // sign
        assert_eq!(max_stack_size_for_legacy_id(332), 16); // snowball
        assert_eq!(max_stack_size_for_legacy_id(331), 64); // redstone dust
        assert_eq!(max_stack_size_for_legacy_id(4), 64); // cobblestone
    }

    #[test]
    fn server_inventory_uses_vanilla_hotbar_and_armor_layout() {
        let mut inventory = PlayerInventory::default();
        assert_eq!(inventory.slots.len(), 36);
        assert_eq!(inventory.armor_slots.len(), 4);
        assert!(inventory.select_hotbar(8));
        assert!(!inventory.select_hotbar(9));
        assert_eq!(inventory.selected_hotbar, 8);
    }

    #[test]
    fn server_inventory_merges_compatible_stacks_before_empty_slots() {
        let mut inventory = PlayerInventory::default();
        inventory.slots[0] = Some(stack("stone", 60));
        assert_eq!(inventory.insert(&stack("stone", 8), 8), 8);
        assert_eq!(inventory.slots[0].as_ref().unwrap().count, 64);
        assert_eq!(inventory.slots[1].as_ref().unwrap().count, 4);
    }

    #[test]
    fn server_container_clicks_mutate_cursor_and_slot_authoritatively() {
        let mut inventory = PlayerInventory::default();
        inventory.slots[0] = Some(stack("cobblestone", 9));
        assert!(inventory.click_stack(0, true));
        assert_eq!(inventory.cursor_stack.as_ref().unwrap().count, 5);
        assert_eq!(inventory.slots[0].as_ref().unwrap().count, 4);
        assert!(inventory.click_stack(1, false));
        assert_eq!(inventory.slots[1].as_ref().unwrap().count, 5);
        assert!(inventory.cursor_stack.is_none());
    }

    #[test]
    fn server_shift_click_merges_then_fills_hotbar() {
        let mut inventory = PlayerInventory::default();
        inventory.slots[9] = Some(stack("dirt", 70));
        assert!(inventory.shift_move_stack(9, 0, 9));
        assert!(inventory.slots[9].is_none());
        assert_eq!(inventory.slots[0].as_ref().unwrap().count, 64);
        assert_eq!(inventory.slots[1].as_ref().unwrap().count, 6);
    }

    #[test]
    fn cursor_stack_is_taken_only_by_the_server_drop_operation() {
        let mut inventory = PlayerInventory::default();
        inventory.cursor_stack = Some(ItemStack { id: "diamond".into(), count: 7, damage: 0, nbt_tag: None });
        let dropped = inventory.take_cursor_for_drop().unwrap();
        assert_eq!(dropped.count, 7);
        assert!(inventory.cursor_stack.is_none());
    }

}

/// Vanilla 1.8.9 Item.maxDamage values for damageable item registry entries.
pub fn max_durability_for_item_id(raw: &str) -> Option<u16> {
    let id = raw.rsplit(':').next().unwrap_or(raw);
    let value = match id {
        "wooden_pickaxe"|"wooden_axe"|"wooden_shovel"|"wooden_hoe"|"wooden_sword" => 59,
        "stone_pickaxe"|"stone_axe"|"stone_shovel"|"stone_hoe"|"stone_sword" => 131,
        "iron_pickaxe"|"iron_axe"|"iron_shovel"|"iron_hoe"|"iron_sword" => 250,
        "diamond_pickaxe"|"diamond_axe"|"diamond_shovel"|"diamond_hoe"|"diamond_sword" => 1561,
        "golden_pickaxe"|"golden_axe"|"golden_shovel"|"golden_hoe"|"golden_sword" => 32,
        "shears" => 238, "bow" => 384, "fishing_rod" => 64, "flint_and_steel" => 64,
        "carrot_on_a_stick" => 25,
        "leather_helmet" => 55, "leather_chestplate" => 80, "leather_leggings" => 75, "leather_boots" => 65,
        "chainmail_helmet"|"iron_helmet" => 165, "chainmail_chestplate"|"iron_chestplate" => 240,
        "chainmail_leggings"|"iron_leggings" => 225, "chainmail_boots"|"iron_boots" => 195,
        "diamond_helmet" => 363, "diamond_chestplate" => 528, "diamond_leggings" => 495, "diamond_boots" => 429,
        "golden_helmet" => 77, "golden_chestplate" => 112, "golden_leggings" => 105, "golden_boots" => 91,
        _ => return None,
    };
    Some(value)
}

impl PlayerInventory {
    /// Apply ItemStack.damageItem(1, player) to the selected stack after a non-zero-hardness block break.
    /// MCP 1.8.9 removes the stack when itemDamage becomes greater than maxDamage.
    pub fn damage_selected_item(&mut self, amount: u16) -> (bool, bool) {
        let index = self.selected_hotbar;
        let (next_damage, max_damage) = {
            let Some(stack) = self.slots.get(index).and_then(Option::as_ref) else { return (false, false); };
            let id = stack.id.rsplit(':').next().unwrap_or(&stack.id);
            // ItemTool and ItemShears lose durability in ItemStack.onBlockDestroyed;
            // swords, hoes, bows and armor use different callbacks and are not mined here.
            if !(id.ends_with("_pickaxe") || id.ends_with("_axe") || id.ends_with("_shovel") || id == "shears") { return (false, false); }
            let Some(max_damage) = max_durability_for_item_id(&stack.id) else { return (false, false); };
            (stack.damage.saturating_add(amount), max_damage)
        };
        if next_damage > max_damage {
            self.slots[index] = None;
            (true, true)
        } else {
            if let Some(stack) = self.slots[index].as_mut() { stack.damage = next_damage; }
            (true, false)
        }
    }
}

#[cfg(test)]
mod durability_tests {
    use super::*;
    #[test]
    fn vanilla_durability_registry_has_known_189_values() {
        assert_eq!(max_durability_for_item_id("diamond_pickaxe"), Some(1561));
        assert_eq!(max_durability_for_item_id("minecraft:iron_sword"), Some(250));
        assert_eq!(max_durability_for_item_id("stone"), None);
        assert_eq!(max_durability_for_item_id("diamond_chestplate"), Some(528));
    }
    #[test]
    fn selected_tool_takes_damage_and_breaks_after_maximum_plus_one() {
        let mut inventory=PlayerInventory::default();
        inventory.slots[0]=Some(ItemStack{id:"diamond_pickaxe".into(),count:1,damage:1560,nbt_tag:None});
        assert_eq!(inventory.damage_selected_item(1),(true,false));
        assert_eq!(inventory.slots[0].as_ref().unwrap().damage,1561);
        assert_eq!(inventory.damage_selected_item(1),(true,true));
        assert!(inventory.slots[0].is_none());
    }
    #[test]
    fn non_tool_items_are_not_damaged_by_block_break_callback() {
        let mut inventory=PlayerInventory::default();
        inventory.slots[0]=Some(ItemStack{id:"diamond_sword".into(),count:1,damage:0,nbt_tag:None});
        assert_eq!(inventory.damage_selected_item(1),(false,false));
        assert_eq!(inventory.slots[0].as_ref().unwrap().damage,0);
    }
}
