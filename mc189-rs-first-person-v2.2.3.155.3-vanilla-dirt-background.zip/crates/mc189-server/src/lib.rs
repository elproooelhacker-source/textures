//! Authoritative simulation and transport layer for the native Minecraft 1.8.9 recreation.
//! The renderer is deliberately not a dependency of this crate.
pub mod client;
pub mod mining;
pub mod drop_registry;
pub mod player;
pub mod persistence;
pub mod inventory;
pub mod entity_item;
pub mod protocol;
pub mod runtime;
pub const PROTOCOL_VERSION: u32 = 1;
pub const TICKS_PER_SECOND: u32 = 20;
pub const TICK_MILLIS: u64 = 1000 / TICKS_PER_SECOND as u64;
