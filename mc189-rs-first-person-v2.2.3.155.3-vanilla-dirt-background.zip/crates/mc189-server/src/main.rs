use std::path::PathBuf;
use std::time::{Duration, Instant};
use std::thread;
use mc189_core::{Mc189Error, Result};
use mc189_server::client::NetworkClient;
use mc189_server::protocol::{PlayerInputWire, ServerPacket};
use mc189_server::runtime::{run_dedicated_server, ServerConfig};

fn main() { if let Err(e)=run(){eprintln!("server error: {e}");std::process::exit(1);} }

fn run()->Result<()> {
    let mut args=std::env::args().skip(1);
    let Some(first)=args.next() else { return usage(); };
    if first=="--probe" {
        let address=args.next().ok_or_else(||Mc189Error::Usage("--probe requires an address".into()))?;
        let username=args.next().unwrap_or_else(||"RustProbe".into());
        return probe(&address,&username);
    }
    let mut world=if first=="--world" { Some(PathBuf::from(args.next().ok_or_else(||Mc189Error::Usage("--world requires a path".into()))?)) } else { return usage(); };
    let mut bind="0.0.0.0:25566".to_string(); let mut radius=5i32;
    while let Some(arg)=args.next(){match arg.as_str(){"--bind"=>bind=args.next().ok_or_else(||Mc189Error::Usage("--bind requires an address".into()))?,"--radius"=>radius=args.next().ok_or_else(||Mc189Error::Usage("--radius requires a number".into()))?.parse().map_err(|_|Mc189Error::Usage("invalid --radius".into()))?,"--help"|"-h"=>return usage(),other=>return Err(Mc189Error::Usage(format!("unknown argument {other:?}")))}}
    run_dedicated_server(ServerConfig{world_path:world.take().unwrap(),bind_address:bind,chunk_radius:radius})
}

fn probe(address:&str,username:&str)->Result<()> {
    let client=NetworkClient::connect(address,username)?;
    println!("[probe] connected to {address}; waiting for server welcome...");
    let started=Instant::now();let mut welcomed=false;let mut last_tick=None;let mut snapshots=0u32;let mut sequence=0u64;
    while started.elapsed()<Duration::from_secs(5) {
        match client.try_recv(){
            Ok(ServerPacket::Welcome{protocol,entity_id,tick_rate,server_tick,..})=>{welcomed=true;println!("[probe] welcome protocol={protocol} entity={entity_id} tick_rate={tick_rate} initial_tick={server_tick}");},
            Ok(ServerPacket::PlayerSnapshot{tick,acknowledged_input,position,velocity,on_ground,..})=>{snapshots+=1;last_tick=Some(tick);if snapshots==1{println!("[probe] authoritative snapshot tick={tick} pos={position:?} vel={velocity:?} grounded={on_ground}");}if snapshots==3{println!("[probe] received 3 authoritative snapshots; network path is alive");break;}let _=acknowledged_input;},
            Ok(ServerPacket::Pong{nonce,server_tick})=>println!("[probe] pong nonce={nonce} server_tick={server_tick}"),
            Ok(ServerPacket::Disconnect{reason})=>return Err(Mc189Error::InvalidData(format!("server disconnected probe: {reason}"))),
            Err(std::sync::mpsc::TryRecvError::Empty)=>{},
            Err(std::sync::mpsc::TryRecvError::Disconnected)=>return Err(Mc189Error::InvalidData("server closed the probe connection".into())),
        }
        if welcomed && sequence==0 {sequence=1;client.send_input(sequence,PlayerInputWire{forward:true,..Default::default()},0.0,0.0)?;}
        thread::sleep(Duration::from_millis(5));
    }
    if !welcomed||snapshots==0{return Err(Mc189Error::InvalidData("no welcome/snapshot received within five seconds".into()));}
    println!("[probe] success: {snapshots} snapshots received; last_server_tick={last_tick:?}");
    Ok(())
}

fn usage()->Result<()> {
    println!("Minecraft 1.8.9 Rust server / protocol probe\n\nDedicated server:\n  mc189-server --world <world-folder> [--bind 0.0.0.0:25566] [--radius 5]\n\nNetwork smoke test (while the server is running):\n  mc189-server --probe 127.0.0.1:25566 [username]");
    Ok(())
}
