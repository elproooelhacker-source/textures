use std::collections::HashMap;
use std::io::{BufRead,BufReader,Write};
use std::net::{TcpListener,TcpStream};
use std::path::{Path,PathBuf};
use std::sync::{Arc, Mutex};
use crate::persistence::{WorldPersistence, WorldSaveRequest, WorldSaveResult};
use std::collections::HashSet;
use crate::inventory::{PlayerInventory, ItemStack, max_stack_size_for_legacy_id, legacy_numeric_id_from_item_name};
use crate::entity_item::{EntityItem, EntityItemSnapshot, merge_nearby_for_searchers};
use std::sync::mpsc::{self,Sender,SyncSender,TrySendError};
use std::thread;
use std::time::{Duration,Instant};
use glam::Vec3;
use mc189_core::{Mc189Error,Result};
use mc189_storage::{decode_chunk,load_mutable_chunk,read_world_metadata,split_chunk_coordinate,ChunkData};
use crate::player::{self,BlockCollision,LoadedWorldCollision,PlayerInput,PlayerState};
use crate::mining::{self as mining_rules, MiningContext, MiningController, MiningEvent, held_tool_from_item_id};
use crate::drop_registry::{self, DropTool, JavaRandom};
use crate::protocol::{ClientPacket,ServerPacket};
use crate::{PROTOCOL_VERSION,TICK_MILLIS,TICKS_PER_SECOND};

#[derive(Debug,Clone,Copy,PartialEq,Eq,Default)]
pub struct TickAccumulator { pending_nanos:u128 }
impl TickAccumulator {
    pub const STEP_NANOS:u128=50_000_000;
    /// Never discards overdue simulation ticks. Under load, wall-clock progress slows rather than skipping world state.
    pub fn push_elapsed(&mut self,elapsed:Duration)->u32 {
        self.pending_nanos=self.pending_nanos.saturating_add(elapsed.as_nanos());
        let due=(self.pending_nanos/Self::STEP_NANOS).min(u128::from(u32::MAX)) as u32;
        self.pending_nanos-=u128::from(due)*Self::STEP_NANOS; due
    }
    pub fn interpolation_alpha(&self)->f32 {(self.pending_nanos as f64/Self::STEP_NANOS as f64).clamp(0.0,1.0) as f32}
}

#[derive(Debug,Clone)] pub struct ServerConfig { pub world_path:PathBuf,pub bind_address:String,pub chunk_radius:i32 }
struct PlayerSession { entity_id:u32,username:String,state:PlayerState,input:PlayerInput,jump_requested:bool,last_sequence:u64,welcomed:bool,outbound:SyncSender<ServerPacket> }
enum Incoming { Connected{player_id:u32,outbound:SyncSender<ServerPacket>},Packet{player_id:u32,packet:ClientPacket},Disconnected{player_id:u32} }

pub struct AuthoritativeWorld { pub tick:u64,pub collision:LoadedWorldCollision,spawn:Vec3,players:HashMap<u32,PlayerSession>,next_entity_id:u32 }
impl AuthoritativeWorld {
    pub fn load(world_path:&Path,chunk_radius:i32)->Result<Self> {
        if !(1..=12).contains(&chunk_radius) {return Err(Mc189Error::Usage("server chunk radius must be between 1 and 12".into()));}
        let meta=read_world_metadata(world_path)?;
        let (sx,sy,sz)=match(meta.spawn_x,meta.spawn_y,meta.spawn_z){(Some(x),Some(y),Some(z))=>(x,y,z),_=>return Err(Mc189Error::InvalidData("world level.dat has no complete spawn position".into()))};
        if !(0..256).contains(&sy){return Err(Mc189Error::InvalidData(format!("world spawn Y {sy} is outside 0..255")));}
        let world_spawn=Vec3::new(sx as f32+0.5,sy as f32,sz as f32+0.5);
        let center_x=sx.div_euclid(16); let center_z=sz.div_euclid(16);
        let mut chunks:HashMap<(i32,i32),ChunkData>=HashMap::new();
        for cz in center_z-chunk_radius..=center_z+chunk_radius {for cx in center_x-chunk_radius..=center_x+chunk_radius {
            let (rx,lx)=split_chunk_coordinate(cx); let (rz,lz)=split_chunk_coordinate(cz);
            let region=world_path.join("region").join(format!("r.{rx}.{rz}.mca"));
            if region.exists(){if let Ok(chunk)=decode_chunk(&region,lx,lz){chunks.insert((cx,cz),chunk);}}
        }}
        if chunks.is_empty(){return Err(Mc189Error::InvalidData("server could not load any Anvil chunks around world spawn".into()));}
        eprintln!("[server] loaded {} chunks around spawn ({center_x}, {center_z})",chunks.len());
        let collision = LoadedWorldCollision { chunks, origin_chunk_x:center_x, origin_chunk_z:center_z };
        let spawn_local = Vec3::new(world_spawn.x - (center_x * 16) as f32, world_spawn.y, world_spawn.z - (center_z * 16) as f32);
        let spawn = player::resolve_safe_spawn(spawn_local, &collision)
            .ok_or_else(|| Mc189Error::InvalidData("could not find a safe server spawn in the loaded chunks".into()))?;
        Ok(Self{tick:0,collision,spawn,players:HashMap::new(),next_entity_id:1})
    }
    fn connect(&mut self,id:u32,outbound:SyncSender<ServerPacket>){let entity_id=self.next_entity_id;self.next_entity_id=self.next_entity_id.wrapping_add(1).max(1);self.players.insert(id,PlayerSession{entity_id,username:format!("Player{id}"),state:PlayerState::at(self.spawn),input:PlayerInput::default(),jump_requested:false,last_sequence:0,welcomed:false,outbound});}
    fn handle_packet(&mut self,id:u32,packet:ClientPacket){
        match packet {
            ClientPacket::Hello{protocol,username}=>{
                if protocol!=PROTOCOL_VERSION {
                    if let Some(outbound)=self.players.get(&id).map(|session|session.outbound.clone()) {
                        let _=outbound.try_send(ServerPacket::Disconnect{reason:format!("protocol mismatch: client={protocol}, server={PROTOCOL_VERSION}")});
                    }
                    self.players.remove(&id);
                    return;
                }
                if let Some(session)=self.players.get_mut(&id) {
                    let name:String=username.chars().filter(|c|c.is_ascii_alphanumeric()||*c=='_').take(16).collect();
                    session.username=if name.is_empty(){format!("Player{id}")}else{name};
                    session.welcomed=true;
                    let server_tick=self.tick;
                    let origin_chunk_x=self.collision.origin_chunk_x;
                    let origin_chunk_z=self.collision.origin_chunk_z;
                    let _=session.outbound.try_send(ServerPacket::Welcome{protocol:PROTOCOL_VERSION,entity_id:session.entity_id,tick_rate:TICKS_PER_SECOND,server_tick,origin_chunk_x,origin_chunk_z});
                }
            }
            ClientPacket::Input{sequence,input,yaw,pitch}=>{
                if !yaw.is_finite()||!pitch.is_finite(){return;}
                if let Some(session)=self.players.get_mut(&id) {
                    if !session.welcomed||sequence<=session.last_sequence{return;}
                    session.last_sequence=sequence;
                    let next_input:PlayerInput=input.into();
                    session.jump_requested |= next_input.jump;
                    session.input=PlayerInput{jump:false,..next_input};
                    session.state.yaw=yaw;
                    session.state.pitch=pitch.clamp(-std::f32::consts::FRAC_PI_2,std::f32::consts::FRAC_PI_2);
                }
            }
            ClientPacket::Ping{nonce}=>{
                if let Some(session)=self.players.get(&id) {let _=session.outbound.try_send(ServerPacket::Pong{nonce,server_tick:self.tick});}
            }
        }
    }
    pub fn tick_once(&mut self){self.tick=self.tick.wrapping_add(1);let tick=self.tick;let collision=&self.collision;self.players.retain(|_,s|{
        if !s.welcomed{return true;}
        let mut tick_input=s.input;
        tick_input.jump=s.jump_requested;
        s.jump_requested=false;
        player::tick(&mut s.state,tick_input,0.05,collision);let p=s.state;
        let packet=ServerPacket::PlayerSnapshot{tick,acknowledged_input:s.last_sequence,position:p.position.to_array(),velocity:p.velocity.to_array(),yaw:p.yaw,pitch:p.pitch,on_ground:p.on_ground,in_water:p.in_water,in_lava:p.in_lava};
        match s.outbound.try_send(packet){Ok(())=>true,Err(TrySendError::Full(_))=>true,Err(TrySendError::Disconnected(_))=>false}
    });}
    pub fn player_count(&self)->usize{self.players.values().filter(|p|p.welcomed).count()}
}

/// Dedicated headless process. Socket I/O runs on per-connection threads; all player physics is advanced only here at 20 TPS.
pub fn run_dedicated_server(config:ServerConfig)->Result<()> {
    let mut world=AuthoritativeWorld::load(&config.world_path,config.chunk_radius)?;
    let listener=TcpListener::bind(&config.bind_address).map_err(|e|Mc189Error::InvalidData(format!("cannot bind {}: {e}",config.bind_address)))?;listener.set_nonblocking(true)?;
    eprintln!("[server] listening on {} | protocol={} | target={} TPS | step={} ms",config.bind_address,PROTOCOL_VERSION,TICKS_PER_SECOND,TICK_MILLIS);
    let (tx,rx)=mpsc::channel::<Incoming>();let mut next_id=1u32;let mut last=Instant::now();let mut deadline=last+Duration::from_millis(TICK_MILLIS);let mut clock=TickAccumulator::default();
    loop {
        loop {match listener.accept(){Ok((stream,address))=>{let id=next_id;next_id=next_id.wrapping_add(1).max(1);eprintln!("[server] connection {id} from {address}");spawn_client_io(id,stream,tx.clone())?;},Err(e) if e.kind()==std::io::ErrorKind::WouldBlock=>break,Err(e)=>return Err(e.into())}}
        while let Ok(m)=rx.try_recv(){match m{Incoming::Connected{player_id,outbound}=>world.connect(player_id,outbound),Incoming::Packet{player_id,packet}=>world.handle_packet(player_id,packet),Incoming::Disconnected{player_id}=>if let Some(p)=world.players.remove(&player_id){eprintln!("[server] {} disconnected",p.username);}}}
        let now=Instant::now();let due=clock.push_elapsed(now.saturating_duration_since(last));last=now;for _ in 0..due{world.tick_once();}
        if due>0&&world.tick%100==0{eprintln!("[server] tick={} players={} chunks={} (20 TPS target)",world.tick,world.player_count(),world.collision.chunks.len());}
        let now=Instant::now();if now<deadline{thread::sleep(deadline-now);}else if now.duration_since(deadline)>Duration::from_millis(250){eprintln!("[server] tick loop behind by {} ms; preserving backlog",now.duration_since(deadline).as_millis());}deadline+=Duration::from_millis(TICK_MILLIS);
    }
}
fn spawn_client_io(id:u32,stream:TcpStream,incoming:Sender<Incoming>)->Result<()> {
    stream.set_nodelay(true)?;let writer=stream.try_clone()?;let (out_tx,out_rx)=mpsc::sync_channel::<ServerPacket>(8);incoming.send(Incoming::Connected{player_id:id,outbound:out_tx}).map_err(|_|Mc189Error::InvalidData("server simulation loop stopped".into()))?;
    thread::Builder::new().name(format!("mc189-net-write-{id}")).spawn(move||{let mut w=writer;while let Ok(p)=out_rx.recv(){let Ok(mut b)=serde_json::to_vec(&p)else{continue;};b.push(b'\n');if w.write_all(&b).is_err(){break;}let _=w.flush();}}).map_err(|e|Mc189Error::InvalidData(format!("cannot start client writer: {e}")))?;
    let reader_tx=incoming.clone();thread::Builder::new().name(format!("mc189-net-read-{id}")).spawn(move||{for line in BufReader::new(stream).lines(){let Ok(line)=line else{break;};if line.len()>16*1024{break;}match serde_json::from_str::<ClientPacket>(&line){Ok(packet)=>if reader_tx.send(Incoming::Packet{player_id:id,packet}).is_err(){break;},Err(e)=>eprintln!("[server] rejected malformed packet from {id}: {e}")}}let _=reader_tx.send(Incoming::Disconnected{player_id:id});}).map_err(|e|Mc189Error::InvalidData(format!("cannot start client reader: {e}")))?;Ok(())
}

#[cfg(test)]mod tests{
    use super::*;
    #[test]fn twenty_ticks_per_second(){let mut c=TickAccumulator::default();let mut n=0;for _ in 0..10{n+=c.push_elapsed(Duration::from_millis(100));}assert_eq!(n,20);assert_eq!(c.interpolation_alpha(),0.0);}
    #[test]fn fractional_remainder_is_preserved(){let mut c=TickAccumulator::default();assert_eq!(c.push_elapsed(Duration::from_millis(125)),2);assert!((c.interpolation_alpha()-0.5).abs()<1e-6);assert_eq!(c.push_elapsed(Duration::from_millis(25)),1);}
    fn pickup_test_entity(entity_id:u64,count:u8)->EntityItem {
        EntityItem { entity_id, item_id:264, metadata:0, count, nbt_tag:None,
            previous_position:glam::Vec3::ZERO, position:glam::Vec3::ZERO,
            velocity:glam::Vec3::ZERO, age:20, pickup_delay:0, hover_start:0.0, provisional:false }
    }
    #[test]fn authoritative_pickup_transfers_inventory_and_removes_entity() {
        let mut inventory=PlayerInventory::default();
        let mut items=vec![pickup_test_entity(1,5)];
        let events=transfer_overlapping_items(&mut items,&mut inventory,glam::Vec3::ZERO);
        assert_eq!(events.len(),1); assert_eq!(events[0].count,5);
        assert_eq!(inventory.slots[0].as_ref().unwrap().id,"diamond");
        assert_eq!(inventory.slots[0].as_ref().unwrap().count,5);
        assert!(items.is_empty());
    }
    #[test]fn authoritative_pickup_preserves_remainder_when_inventory_has_partial_room() {
        let mut inventory=PlayerInventory::default();
        inventory.slots[0]=Some(crate::inventory::ItemStack{id:"diamond".into(),count:63,damage:0,nbt_tag:None});
        let mut items=vec![pickup_test_entity(1,5)];
        let events=transfer_overlapping_items(&mut items,&mut inventory,glam::Vec3::ZERO);
        assert_eq!(events[0].count,1); assert_eq!(inventory.slots[0].as_ref().unwrap().count,64);
        assert_eq!(items.len(),1); assert_eq!(items[0].count,4);
    }
    #[test]fn authoritative_pickup_does_not_award_when_inventory_is_full() {
        let mut inventory=PlayerInventory::default();
        for slot in &mut inventory.slots { *slot=Some(crate::inventory::ItemStack{id:"stone".into(),count:64,damage:0,nbt_tag:None}); }
        let mut items=vec![pickup_test_entity(1,5)];
        let events=transfer_overlapping_items(&mut items,&mut inventory,glam::Vec3::ZERO);
        assert!(events.is_empty()); assert_eq!(items.len(),1); assert_eq!(items[0].count,5);
    }
    #[test]fn authoritative_pickup_respects_delay_and_provisional_state() {
        let mut inventory=PlayerInventory::default();
        let mut delayed=pickup_test_entity(1,5); delayed.pickup_delay=1;
        let mut provisional=pickup_test_entity(2,5); provisional.provisional=true;
        let mut items=vec![delayed,provisional];
        assert!(transfer_overlapping_items(&mut items,&mut inventory,glam::Vec3::ZERO).is_empty());
        assert_eq!(items.len(),2); assert!(inventory.slots.iter().all(Option::is_none));
    }
    #[test]fn inventory_drop_give_and_clear_are_processed_by_integrated_server(){
        let mut chunks=HashMap::new();
        chunks.insert((0,0),ChunkData{x_pos:0,z_pos:0,sections:Vec::new(),biomes:None,height_map:None});
        let collision=LoadedWorldCollision{chunks,origin_chunk_x:0,origin_chunk_z:0};
        let test_world=std::env::temp_dir().join(format!("mc189-integrated-inventory-command-test-{}",std::process::id()));
        let mut inventory=PlayerInventory::default();
        inventory.slots[0]=Some(ItemStack{id:"diamond".into(),count:3,damage:0,nbt_tag:None});
        let server=IntegratedServer::start_with_seed(collision,PlayerState::at(Vec3::new(8.0,64.0,8.0)),inventory,test_world,Arc::new(Mutex::new(())),0).unwrap();
        let wait_for=|server:&IntegratedServer, predicate:&dyn Fn(&IntegratedSnapshot)->bool| {
            let deadline=Instant::now()+Duration::from_secs(2);
            loop {
                while let Ok(snapshot)=server.try_snapshot() { if predicate(&snapshot) { return snapshot; } }
                assert!(Instant::now()<deadline,"integrated server did not publish requested inventory command");
                thread::sleep(Duration::from_millis(5));
            }
        };
        let _initial=wait_for(&server,&|snapshot|snapshot.inventory.is_some());
        server.drop_inventory_slot(0,false).unwrap();
        let dropped=wait_for(&server,&|snapshot|snapshot.inventory.as_ref().and_then(|inv|inv.slots[0].as_ref()).is_some_and(|stack|stack.count==2)
            && snapshot.entities.iter().any(|entity|entity.item_id==264&&entity.count==1));
        assert_eq!(dropped.inventory.unwrap().slots[0].as_ref().unwrap().count,2);
        server.give_inventory_item("diamond".into(),5,0).unwrap();
        let given=wait_for(&server,&|snapshot|snapshot.inventory.as_ref().and_then(|inv|inv.slots[0].as_ref()).is_some_and(|stack|stack.count==7));
        assert_eq!(given.inventory.unwrap().slots[0].as_ref().unwrap().count,7);
        server.clear_inventory().unwrap();
        let cleared=wait_for(&server,&|snapshot|snapshot.inventory.as_ref().is_some_and(|inv|inv.slots.iter().all(Option::is_none)
            &&inv.armor_slots.iter().all(Option::is_none)&&inv.cursor_stack.is_none()));
        assert!(cleared.inventory.unwrap().slots.iter().all(Option::is_none));
    }

    #[test]fn integrated_server_publishes_authoritative_twenty_tps_snapshots(){
        let mut chunks=HashMap::new();
        chunks.insert((0,0),ChunkData{x_pos:0,z_pos:0,sections:Vec::new(),biomes:None,height_map:None});
        let collision=LoadedWorldCollision{chunks,origin_chunk_x:0,origin_chunk_z:0};
        let test_world = std::env::temp_dir().join(format!("mc189-integrated-server-test-world-{}", std::process::id()));
        let server=IntegratedServer::start_with_seed(collision,PlayerState::at(Vec3::new(8.0,64.0,8.0)),PlayerInventory::default(),test_world,Arc::new(Mutex::new(())),0).unwrap();
        let deadline=Instant::now()+Duration::from_millis(500);
        loop {
            if let Ok(snapshot)=server.try_snapshot(){
                assert!(snapshot.tick>=1);
                assert!(snapshot.inventory.is_some(), "initial server inventory must be replicated to the client");
                break;
            }
            assert!(Instant::now()<deadline,"integrated server did not publish a 20 TPS snapshot");
            thread::sleep(Duration::from_millis(5));
        }
    }
}


/// Server-only equivalent of EntityItem.onCollideWithPlayer. The inventory
/// insertion result is authoritative; partial transfers leave the exact remainder
/// on the entity, while a full inventory leaves both states untouched.
fn transfer_overlapping_items(
    items: &mut Vec<EntityItem>,
    inventory: &mut PlayerInventory,
    player_feet: glam::Vec3,
) -> Vec<AuthoritativePickup> {
    let mut pickups = Vec::new();
    for item in items.iter_mut() {
        if !item.is_in_pickup_range(player_feet) { continue; }
        let Some(item_name) = crate::inventory::legacy_item_name_from_numeric_id(item.item_id) else { continue; };
        let offered = u16::from(item.count);
        let stack = crate::inventory::ItemStack {
            id: item_name.to_owned(), count: offered, damage: item.metadata,
            nbt_tag: item.nbt_tag.clone(),
        };
        let inserted = inventory.insert(&stack, offered);
        if inserted == 0 { continue; }
        pickups.push(AuthoritativePickup {
            entity_id: item.entity_id, item_id: item.item_id, metadata: item.metadata,
            count: inserted, position: item.position, age: item.age,
        });
        item.count = item.count.saturating_sub(inserted.min(u16::from(u8::MAX)) as u8);
    }
    items.retain(|item| item.count > 0);
    pickups
}

/// Snapshot published by the in-process integrated server to its graphical client.
#[derive(Debug, Clone)]
pub struct IntegratedSnapshot {
    pub tick: u64,
    pub acknowledged_input: u64,
    pub player: PlayerState,
    /// Authoritative inventory replica for the graphical client.
    pub inventory: Option<PlayerInventory>,
    /// Full authoritative world-item entity state for visual interpolation.
    pub entities: Vec<EntityItemSnapshot>,
    /// Confirmed server-side transfers, retained until a snapshot is delivered.
    pub pickups: Vec<AuthoritativePickup>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct AuthoritativePickup {
    pub entity_id: u64,
    pub item_id: u16,
    pub metadata: u16,
    pub count: u16,
    pub position: glam::Vec3,
    pub age: u16,
}

#[derive(Debug, Clone)]
pub struct AuthoritativeMiningEvent {
    pub event: MiningEvent,
    /// Original state captured by the server before it commits a broken block to air.
    pub target: Option<crate::mining::BlockPos>,
    pub broken_block: Option<(u16, u8)>,
    /// Server entity IDs spawned for this break; used only to roll back a rejected edit transaction.
    pub spawned_entity_ids: Vec<u64>,
    /// True when ItemStack.damageItem broke the selected tool on this block break.
    pub broken_tool: bool,
}

enum IntegratedCommand {
    Input { sequence: u64, input: PlayerInput, yaw: f32, pitch: f32 },
    ReplaceChunk(ChunkData),
    RemoveChunk { chunk_x: i32, chunk_z: i32 },
    SetBlock { x: i32, y: i32, z: i32, id: u16, metadata: u8 },
    MiningIntent { held: bool },
    InventorySelectHotbar { slot: usize },
    InventoryClickSlot { slot: usize, right_click: bool, shift: bool },
    InventoryDropSlot { slot: usize, drop_all: bool },
    InventoryDropCursor,
    InventoryGive { item_id: String, count: u16, damage: u16 },
    InventoryClear,
    RemoveEntityItems { entity_ids: Vec<u64> },
    CommitEntityItems { entity_ids: Vec<u64> },
    Shutdown,
}

/// In-process server used by single-player. It runs on its own thread at 20 TPS;
/// the winit/render loop only sends inputs and consumes snapshots.
pub struct IntegratedServer {
    commands: Sender<IntegratedCommand>,
    snapshots: std::sync::mpsc::Receiver<IntegratedSnapshot>,
    mining_events: std::sync::mpsc::Receiver<AuthoritativeMiningEvent>,
    worker: Option<thread::JoinHandle<()>>,
    persistence: WorldPersistence,
}

impl IntegratedServer {
    pub fn start(collision: LoadedWorldCollision, initial_player: PlayerState, initial_inventory: PlayerInventory, world_path: PathBuf, world_io_lock: Arc<Mutex<()>>) -> Result<Self> {
        let world_seed = read_world_metadata(&world_path)?.random_seed.unwrap_or(0) as u64;
        Self::start_with_seed(collision, initial_player, initial_inventory, world_path, world_io_lock, world_seed)
    }

    fn start_with_seed(collision: LoadedWorldCollision, initial_player: PlayerState, initial_inventory: PlayerInventory, world_path: PathBuf, world_io_lock: Arc<Mutex<()>>, world_seed: u64) -> Result<Self> {
        let entity_world_path = world_path.clone();
        let mut initial_entity_items = Vec::new();
        let mut entity_chunk_coords: HashSet<(i32, i32)> = collision.chunks.keys().copied().collect();
        let mut next_loaded_id = 1_u64;
        for &(chunk_x, chunk_z) in &entity_chunk_coords {
            match load_mutable_chunk(&world_path, chunk_x, chunk_z) {
                Ok(chunk) => for tag in chunk.entity_nbt_list() {
                    if let Some(mut item) = EntityItem::from_chunk_nbt(&tag, next_loaded_id) {
                        item.position.x -= (i64::from(collision.origin_chunk_x) * 16) as f32;
                        item.position.z -= (i64::from(collision.origin_chunk_z) * 16) as f32;
                        item.previous_position = item.position;
                        next_loaded_id = next_loaded_id.max(item.entity_id.saturating_add(1));
                        if !initial_entity_items.iter().any(|existing: &EntityItem| existing.entity_id == item.entity_id) {
                            initial_entity_items.push(item);
                        }
                    }
                },
                Err(error) => eprintln!("[entity load] could not inspect chunk ({chunk_x},{chunk_z}): {error}"),
            }
        }
        eprintln!("[entity load] restored {} EntityItem(s) from {} loaded chunk(s)", initial_entity_items.len(), entity_chunk_coords.len());
        let persistence = WorldPersistence::start(world_path, world_io_lock)?;
        let (command_tx, command_rx) = mpsc::channel::<IntegratedCommand>();
        let (snapshot_tx, snapshot_rx) = mpsc::sync_channel::<IntegratedSnapshot>(2);
        let (mining_event_tx, mining_event_rx) = mpsc::channel::<AuthoritativeMiningEvent>();
        let worker = thread::Builder::new().name("mc189-integrated-server-20tps".into()).spawn(move || {
            let mut collision = collision;
            let mut player = initial_player;
            let mut inventory = initial_inventory;
            let mut inventory_revision = 1_u64;
            let mut published_inventory_revision = 0_u64;
            let mut input = PlayerInput::default();
            let mut jump_requested = false;
            let mut acknowledged_input = 0_u64;
            let mut mining_controller = MiningController::default();
            let mut mining_held = false;
            let mut world_rng = JavaRandom::new(world_seed);
            let mut entity_items: Vec<EntityItem> = initial_entity_items;
            let mut pending_pickups: Vec<AuthoritativePickup> = Vec::new();
            let mut next_item_entity_id = next_loaded_id;
            let mut tick = 0_u64;
            let step = Duration::from_millis(TICK_MILLIS);
            let mut deadline = Instant::now() + step;
            eprintln!("[integrated server] started | target={} TPS | step={} ms | loaded_chunks={}", TICKS_PER_SECOND, TICK_MILLIS, collision.chunks.len());
            loop {
                let now = Instant::now();
                if now >= deadline {
                    // Catch up by executing every overdue simulation tick. Never
                    // skip authoritative movement because a frame or OS thread stalled.
                    while Instant::now() >= deadline {
                        tick = tick.wrapping_add(1);
                        let mut tick_input = input;
                        tick_input.jump = jump_requested;
                        jump_requested = false;
                        player::tick(&mut player, tick_input, 0.05, &collision);
                        // EntityItem.onUpdate is advanced only by the authoritative 20 TPS thread.
                        let mut item_searchers = Vec::new();
                        for item in &mut entity_items { if item.tick(&collision) { item_searchers.push(item.entity_id); } }
                        if !item_searchers.is_empty() {
                            merge_nearby_for_searchers(&mut entity_items, &item_searchers, |item_id| max_stack_size_for_legacy_id(item_id));
                        }
                        entity_items.retain(|item| !item.is_expired() && item.count > 0);
                        // EntityItem.onCollideWithPlayer: only the integrated server
                        // tests the authoritative player AABB, transfers inventory, and
                        // removes/reduces the world entity. The renderer cannot award items.
                        let picked_up = transfer_overlapping_items(&mut entity_items, &mut inventory, player.position);
                        if !picked_up.is_empty() {
                            inventory_revision = inventory_revision.wrapping_add(picked_up.len() as u64);
                            pending_pickups.extend(picked_up);
                        }
                        // ItemInWorldManager.updateBlockRemoving / PlayerControllerMP damage
                        // now execute on the authoritative server tick, not the render thread.
                        let mining_hit = if mining_held {
                            let eye = player.eye_position();
                            let direction = player.look_direction();
                            mining_rules::raycast(eye, direction, 4.5, |pos| collision.is_solid(pos.x, pos.y, pos.z))
                                .and_then(|hit| collision.loaded_state_at(hit.pos.x, hit.pos.y, hit.pos.z)
                                    .and_then(|(id, meta)| mining_rules::block_info(id, meta).map(|info| (hit.pos, info))))
                        } else { None };
                        let context = MiningContext { on_ground: player.on_ground, submerged: player.in_water, ..MiningContext::default() };
                        let mining_target = mining_hit.map(|(pos, _)| pos);
                        // The selected tool is resolved from the server-owned inventory,
                        // never accepted as a client-supplied descriptor.
                        let mining_tool = held_tool_from_item_id(inventory.current_item().map(|stack| stack.id.as_str()));
                        let mining_event = mining_controller.tick(mining_hit, mining_held, mining_tool, context);
                        if mining_event != MiningEvent::None {
                            let mut broken_block = None;
                            let mut drops = Vec::new();
                            let mut spawned_entity_ids = Vec::new();
                            let mut broken_tool = false;
                            if let MiningEvent::Broken(pos) = mining_event {
                                // Capture the pre-break state, resolve drops with the
                                // server-owned Java RNG, then commit air at this tick.
                                broken_block = collision.loaded_state_at(pos.x, pos.y, pos.z);
                                if let Some((block_id, metadata)) = broken_block {
                                    if let Some(info) = mining_rules::block_info(block_id, metadata) {
                                        if mining_rules::can_harvest(mining_tool, info) {
                                            let drop_tool = DropTool { kind: mining_tool.kind, tier: mining_tool.tier, shears: mining_tool.kind == mining_rules::ToolKind::Shears };
                                            let (_, resolved) = drop_registry::resolve_drops_with_rng(block_id, metadata, drop_tool, 0, false, &mut world_rng);
                                            drops = resolved;
                                        }
                                    }
                                }
                                if let Err(error) = collision.set_block_local(pos.x, pos.y, pos.z, 0, 0) {
                                    eprintln!("[integrated server] rejected mined block at {:?}: {error}", pos);
                                    broken_block = None;
                                    drops.clear();
                                } else {
                                    // ItemStack.onBlockDestroyed damages the held item once
                                    // for every successfully broken block with non-zero hardness.
                                    if broken_block.and_then(|(id, meta)| mining_rules::block_info(id, meta)).is_some_and(|info| info.hardness != 0.0) {
                                        let (changed, broke) = inventory.damage_selected_item(1);
                                        if changed { inventory_revision = inventory_revision.wrapping_add(1); }
                                        broken_tool = broke;
                                    }
                                    // Block.spawnAsEntity + EntityItem construction stay on the server.
                                    for drop in drops.iter().copied() {
                                        if let Some(entity) = EntityItem::spawn_from_drop(next_item_entity_id, pos, drop, &mut world_rng) {
                                            spawned_entity_ids.push(next_item_entity_id);
                                            next_item_entity_id = next_item_entity_id.wrapping_add(1).max(1);
                                            entity_items.push(entity);
                                        }
                                    }
                                }
                            }
                            let _ = mining_event_tx.send(AuthoritativeMiningEvent { event: mining_event, target: mining_target, broken_block, spawned_entity_ids, broken_tool });
                        }
                        let inventory_changed = inventory_revision != published_inventory_revision;
                        let inventory_snapshot = inventory_changed.then(|| inventory.clone());
                        let entity_snapshots = entity_items.iter().map(EntityItem::snapshot).collect();
                        if snapshot_tx.try_send(IntegratedSnapshot {
                            tick, acknowledged_input, player, inventory: inventory_snapshot,
                            entities: entity_snapshots, pickups: pending_pickups.clone(),
                        }).is_ok() {
                            if inventory_changed { published_inventory_revision = inventory_revision; }
                            pending_pickups.clear();
                        }
                        if tick % 100 == 0 { eprintln!("[integrated server] tick={tick} | authoritative player position=({:.2},{:.2},{:.2})", player.position.x, player.position.y, player.position.z); }
                        deadline += step;
                    }
                    continue;
                }
                match command_rx.recv_timeout(deadline.saturating_duration_since(now)) {
                    Ok(IntegratedCommand::Input { sequence, input: next, yaw, pitch }) => {
                        if sequence > acknowledged_input && yaw.is_finite() && pitch.is_finite() {
                            acknowledged_input = sequence;
                            jump_requested |= next.jump;
                            input = PlayerInput { jump: false, ..next };
                            player.yaw = yaw;
                            player.pitch = pitch.clamp(-std::f32::consts::FRAC_PI_2, std::f32::consts::FRAC_PI_2);
                        }
                    }
                    Ok(IntegratedCommand::ReplaceChunk(chunk)) => {
                        let key = (chunk.x_pos, chunk.z_pos);
                        if entity_chunk_coords.insert(key) {
                            match load_mutable_chunk(&entity_world_path, key.0, key.1) {
                                Ok(saved_chunk) => for tag in saved_chunk.entity_nbt_list() {
                                    if let Some(mut item) = EntityItem::from_chunk_nbt(&tag, next_item_entity_id) {
                                        item.position.x -= (i64::from(collision.origin_chunk_x) * 16) as f32;
                                        item.position.z -= (i64::from(collision.origin_chunk_z) * 16) as f32;
                                        item.previous_position = item.position;
                                        next_item_entity_id = next_item_entity_id.max(item.entity_id.saturating_add(1));
                                        if !entity_items.iter().any(|existing| existing.entity_id == item.entity_id) { entity_items.push(item); }
                                    }
                                },
                                Err(error) => eprintln!("[entity load] could not restore streamed chunk ({},{}): {error}", key.0, key.1),
                            }
                        }
                        collision.chunks.insert(key, chunk);
                    }
                    Ok(IntegratedCommand::RemoveChunk { chunk_x, chunk_z }) => {
                        collision.chunks.remove(&(chunk_x, chunk_z));
                    }
                    Ok(IntegratedCommand::SetBlock { x, y, z, id, metadata }) => {
                        if let Err(error) = collision.set_block_local(x, y, z, id, metadata) {
                            eprintln!("[integrated server] rejected block state update ({x},{y},{z}): {error}");
                        }
                    }
                    Ok(IntegratedCommand::MiningIntent { held }) => { mining_held = held; }
                    Ok(IntegratedCommand::InventorySelectHotbar { slot }) => {
                        if inventory.select_hotbar(slot) { inventory_revision = inventory_revision.wrapping_add(1); }
                    }
                    Ok(IntegratedCommand::RemoveEntityItems { entity_ids }) => {
                        entity_items.retain(|item| !entity_ids.contains(&item.entity_id));
                    }
                    Ok(IntegratedCommand::CommitEntityItems { entity_ids }) => {
                        for item in &mut entity_items { if entity_ids.contains(&item.entity_id) { item.provisional = false; } }
                    }
                    Ok(IntegratedCommand::InventoryClickSlot { slot, right_click, shift }) => {
                        let changed = if shift {
                            if slot >= 36 { inventory.shift_move_armor_to_inventory(slot - 36) }
                            else if inventory.shift_auto_equip(slot) { true }
                            else if slot < 9 { inventory.shift_move_stack(slot, 9, 36) }
                            else { inventory.shift_move_stack(slot, 0, 9) }
                        } else if slot >= 36 { inventory.click_armor_stack(slot - 36) }
                        else { inventory.click_stack(slot, right_click) };
                        if changed { inventory_revision = inventory_revision.wrapping_add(1); }
                    }
                    Ok(IntegratedCommand::InventoryDropSlot { slot, drop_all }) => {
                        if slot < 40 {
                            if let Some(stack) = inventory.take_stack_for_drop(slot, drop_all) {
                                if let Some(item_id) = legacy_numeric_id_from_item_name(&stack.id) {
                                    let amount = stack.count.min(64) as u8;
                                    if let Some(entity) = EntityItem::spawn_from_player_drop(
                                        next_item_entity_id, item_id, stack.damage, amount, stack.nbt_tag.clone(), player,
                                    ) {
                                        next_item_entity_id = next_item_entity_id.wrapping_add(1).max(1);
                                        entity_items.push(entity);
                                        if stack.count > u16::from(amount) {
                                            let remainder = stack.count - u16::from(amount);
                                            let _ = inventory.insert(&ItemStack { count: remainder, ..stack.clone() }, remainder);
                                        }
                                        inventory_revision = inventory_revision.wrapping_add(1);
                                    } else if slot < 36 { inventory.slots[slot] = Some(stack); }
                                    else { inventory.armor_slots[slot - 36] = Some(stack); }
                                } else if slot < 36 { inventory.slots[slot] = Some(stack); }
                                else { inventory.armor_slots[slot - 36] = Some(stack); }
                            }
                        }
                    }
                    Ok(IntegratedCommand::InventoryDropCursor) => {
                        if let Some(stack) = inventory.take_cursor_for_drop() {
                            if let Some(item_id) = legacy_numeric_id_from_item_name(&stack.id) {
                                let amount = stack.count.min(64) as u8;
                                if let Some(entity) = EntityItem::spawn_from_player_drop(
                                    next_item_entity_id, item_id, stack.damage, amount, stack.nbt_tag.clone(), player,
                                ) {
                                    next_item_entity_id = next_item_entity_id.wrapping_add(1).max(1);
                                    entity_items.push(entity);
                                    if stack.count > u16::from(amount) {
                                        inventory.cursor_stack = Some(ItemStack { count: stack.count - u16::from(amount), ..stack });
                                    }
                                    inventory_revision = inventory_revision.wrapping_add(1);
                                } else { inventory.cursor_stack = Some(stack); }
                            } else { inventory.cursor_stack = Some(stack); }
                        }
                    }
                    Ok(IntegratedCommand::InventoryGive { item_id, count, damage }) => {
                        if (1..=64).contains(&count) && legacy_numeric_id_from_item_name(&item_id).is_some() {
                            let stack = ItemStack { id: item_id, count, damage, nbt_tag: None };
                            let inserted = inventory.insert(&stack, count);
                            if inserted > 0 { inventory_revision = inventory_revision.wrapping_add(1); }
                            // CommandGive drops any uninserted remainder into the world instead
                            // of deleting it when the inventory is full or the item stacks to 1.
                            let mut remaining = count - inserted;
                            if remaining > 0 {
                                if let Some(numeric_id) = legacy_numeric_id_from_item_name(&stack.id) {
                                    let stack_limit = u16::from(max_stack_size_for_legacy_id(numeric_id).max(1));
                                    while remaining > 0 {
                                        let amount = remaining.min(stack_limit).min(u16::from(u8::MAX)) as u8;
                                        if let Some(entity) = EntityItem::spawn_from_player_drop(
                                            next_item_entity_id, numeric_id, stack.damage, amount, stack.nbt_tag.clone(), player,
                                        ) {
                                            next_item_entity_id = next_item_entity_id.wrapping_add(1).max(1);
                                            entity_items.push(entity);
                                            remaining -= u16::from(amount);
                                        } else { break; }
                                    }
                                }
                            }
                        }
                    }
                    Ok(IntegratedCommand::InventoryClear) => {
                        let changed = inventory.slots.iter().any(Option::is_some)
                            || inventory.armor_slots.iter().any(Option::is_some)
                            || inventory.cursor_stack.is_some();
                        if changed {
                            inventory.slots.fill(None);
                            inventory.armor_slots.fill(None);
                            inventory.cursor_stack = None;
                            inventory_revision = inventory_revision.wrapping_add(1);
                        }
                    }
                    Ok(IntegratedCommand::Shutdown) | Err(mpsc::RecvTimeoutError::Disconnected) => break,
                    Err(mpsc::RecvTimeoutError::Timeout) => {}
                }
            }
            eprintln!("[integrated server] stopped after {tick} authoritative ticks");
        }).map_err(|error| Mc189Error::InvalidData(format!("cannot start integrated 20 TPS server: {error}")))?;
        Ok(Self { commands: command_tx, snapshots: snapshot_rx, mining_events: mining_event_rx, worker: Some(worker), persistence })
    }

    pub fn send_input(&self, sequence: u64, input: PlayerInput, yaw: f32, pitch: f32) -> Result<()> {
        self.commands.send(IntegratedCommand::Input { sequence, input, yaw, pitch })
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }

    pub fn replace_chunk(&self, chunk: ChunkData) -> Result<()> {
        self.commands.send(IntegratedCommand::ReplaceChunk(chunk))
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }

    pub fn remove_chunk(&self, chunk_x: i32, chunk_z: i32) -> Result<()> {
        self.commands.send(IntegratedCommand::RemoveChunk { chunk_x, chunk_z })
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }

    pub fn set_block(&self, x: i32, y: i32, z: i32, id: u16, metadata: u8) -> Result<()> {
        self.commands.send(IntegratedCommand::SetBlock { x, y, z, id, metadata })
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }

    pub fn select_hotbar(&self, slot: usize) -> Result<()> {
        self.commands.send(IntegratedCommand::InventorySelectHotbar { slot })
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }

    pub fn click_inventory_slot(&self, slot: usize, right_click: bool, shift: bool) -> Result<()> {
        if slot >= 40 { return Err(Mc189Error::Usage("inventory slot index must be 0..39".into())); }
        self.commands.send(IntegratedCommand::InventoryClickSlot { slot, right_click, shift })
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }

    pub fn drop_inventory_slot(&self, slot: usize, drop_all: bool) -> Result<()> {
        if slot >= 40 { return Err(Mc189Error::Usage("inventory drop slot must be 0..39".into())); }
        self.commands.send(IntegratedCommand::InventoryDropSlot { slot, drop_all })
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }
    pub fn drop_inventory_cursor(&self) -> Result<()> {
        self.commands.send(IntegratedCommand::InventoryDropCursor)
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }
    pub fn give_inventory_item(&self, item_id: String, count: u16, damage: u16) -> Result<()> {
        if !(1..=64).contains(&count) || damage > 32767 || legacy_numeric_id_from_item_name(&item_id).is_none() {
            return Err(Mc189Error::Usage("invalid /give item, count, or metadata".into()));
        }
        self.commands.send(IntegratedCommand::InventoryGive { item_id, count, damage })
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }
    pub fn clear_inventory(&self) -> Result<()> {
        self.commands.send(IntegratedCommand::InventoryClear)
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }

    /// Roll back provisional entities if the corresponding world-edit transaction is rejected.
    pub fn remove_entity_items(&self, entity_ids: Vec<u64>) -> Result<()> {
        if entity_ids.is_empty() { return Ok(()); }
        self.commands.send(IntegratedCommand::RemoveEntityItems { entity_ids })
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }

    /// Mark provisional block-drop entities as committed after the matching in-memory block edit succeeds.
    pub fn commit_entity_items(&self, entity_ids: Vec<u64>) -> Result<()> {
        if entity_ids.is_empty() { return Ok(()); }
        self.commands.send(IntegratedCommand::CommitEntityItems { entity_ids })
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }

    pub fn try_snapshot(&self) -> std::result::Result<IntegratedSnapshot, std::sync::mpsc::TryRecvError> {
        self.snapshots.try_recv()
    }

    /// Send attack intent; target selection and block hardness are recomputed by the server.
    pub fn set_mining_intent(&self, held: bool) -> Result<()> {
        self.commands.send(IntegratedCommand::MiningIntent { held })
            .map_err(|_| Mc189Error::InvalidData("integrated server has stopped".into()))
    }

    pub fn try_mining_event(&self) -> std::result::Result<AuthoritativeMiningEvent, std::sync::mpsc::TryRecvError> {
        self.mining_events.try_recv()
    }

    /// The integrated server is the sole Anvil writer for the active single-player session.
    pub fn request_save(&self, request: WorldSaveRequest) -> Result<()> { self.persistence.request_save(request) }
    pub fn try_save_result(&self) -> std::result::Result<WorldSaveResult, std::sync::mpsc::TryRecvError> { self.persistence.try_result() }
}

impl Drop for IntegratedServer {
    fn drop(&mut self) {
        eprintln!("[integrated server] shutdown requested; stopping 20 TPS simulation...");
        let _ = self.commands.send(IntegratedCommand::Shutdown);
        if let Some(worker) = self.worker.take() { let _ = worker.join(); }
        // `persistence` is dropped immediately after this method. Its Drop closes
        // the request channel and joins the disk writer, so no Anvil write survives
        // the integrated-server/world-session lifetime.
        eprintln!("[integrated server] simulation joined; draining persistence service...");
    }
}
