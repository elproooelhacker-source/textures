//! Deterministic first-person player physics for classic Minecraft worlds.
//! Coordinates are world-space blocks; `position` is the centre of the player's feet.
use glam::Vec3;
use mc189_core::{Mc189Error, Result};
use mc189_storage::{read_world_metadata, ChunkData};
use std::collections::HashMap;
use std::path::Path;

pub const PLAYER_WIDTH: f32 = 0.6;
pub const PLAYER_HEIGHT: f32 = 1.8;
pub const PLAYER_EYE_HEIGHT: f32 = 1.62;
pub const WALK_SPEED: f32 = 4.317;
pub const JUMP_SPEED: f32 = 8.4;
pub const GRAVITY: f32 = 32.0;
pub const TERMINAL_VELOCITY: f32 = 78.4;
const COLLISION_EPSILON: f32 = 1.0e-4;
const MAX_SWEEP_STEP: f32 = 0.2;
const GROUND_ACCELERATION: f32 = 28.0;
const AIR_ACCELERATION: f32 = 8.0;
const GROUND_FRICTION: f32 = 24.0;
const JUMP_BUFFER_SECONDS: f32 = 0.14;
const COYOTE_SECONDS: f32 = 0.10;
const GROUND_PROBE_DISTANCE: f32 = 0.035;

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct PlayerInput {
    pub forward: bool,
    pub backward: bool,
    pub left: bool,
    pub right: bool,
    /// One-shot jump request used by the classic jump buffer.
    pub jump: bool,
    /// Held jump key; in liquids this is used for continuous swimming strokes.
    pub jump_held: bool,
    pub sprint: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FluidKind { Water, Lava }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct FluidCell {
    pub kind: FluidKind,
    pub level: u8,
}

impl FluidCell {
    /// BlockLiquid.getLiquidHeightPercent from vanilla 1.8.9.
    pub fn surface_height(self) -> f32 {
        let level = if self.level >= 8 { 0 } else { self.level };
        1.0 - (f32::from(level) + 1.0) / 9.0
    }
    fn effective_level(self) -> i32 { if self.level >= 8 { 0 } else { i32::from(self.level) } }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PlayerState {
    /// Feet-centre position in world coordinates.
    pub position: Vec3,
    pub velocity: Vec3,
    pub yaw: f32,
    pub pitch: f32,
    pub on_ground: bool,
    pub in_water: bool,
    pub in_lava: bool,
    jump_buffer: f32,
    coyote_time: f32,
}

impl PlayerState {
    pub fn at(position: Vec3) -> Self {
        Self { position, velocity: Vec3::ZERO, yaw: 0.0, pitch: 0.0, on_ground: false, in_water: false, in_lava: false, jump_buffer: 0.0, coyote_time: 0.0 }
    }
    pub fn eye_position(self) -> Vec3 { self.position + Vec3::Y * PLAYER_EYE_HEIGHT }
    pub fn look_direction(self) -> Vec3 {
        let cp = self.pitch.cos();
        Vec3::new(-self.yaw.sin() * cp, -self.pitch.sin(), self.yaw.cos() * cp).normalize_or_zero()
    }
}

/// Local-space collision box for a legacy block. Coordinates are relative to the
/// block's integer corner; boxes may extend above the block cell (classic fences).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct BlockCollisionBox {
    pub min: [f32; 3],
    pub max: [f32; 3],
}

impl BlockCollisionBox {
    pub const FULL_CUBE: Self = Self { min: [0.0, 0.0, 0.0], max: [1.0, 1.0, 1.0] };
    fn new(min: [f32; 3], max: [f32; 3]) -> Self { Self { min, max } }
}

/// Collision query for legacy blocks. The default preserves the existing test-world
/// contract; loaded Anvil worlds override collision_boxes for non-cubic shapes.
pub trait BlockCollision {
    fn is_solid(&self, x: i32, y: i32, z: i32) -> bool;
    fn collision_boxes(&self, x: i32, y: i32, z: i32) -> Vec<BlockCollisionBox> {
        if self.is_solid(x, y, z) { vec![BlockCollisionBox::FULL_CUBE] } else { Vec::new() }
    }
    /// True when this cell is a legacy stair block; used only to allow the
    /// two consecutive half-steps needed to traverse a one-block stair model.
    fn is_stair_at(&self, _x: i32, _y: i32, _z: i32) -> bool { false }
    /// Returns the legacy liquid state at a block position. Test worlds can leave
    /// this at its default; loaded Anvil worlds provide IDs and metadata.
    fn fluid_at(&self, _x: i32, _y: i32, _z: i32) -> Option<FluidCell> { None }
    /// Vanilla block slipperiness used by Entity.moveEntity friction.
    fn slipperiness_at(&self, _x: i32, _y: i32, _z: i32) -> f32 { 0.6 }
    fn is_full_cube_at(&self, x: i32, y: i32, z: i32) -> bool {
        self.collision_boxes(x,y,z).iter().any(|shape| shape.min == [0.0,0.0,0.0] && shape.max == [1.0,1.0,1.0])
    }
    /// Flow vector contributed by a liquid block (BlockLiquid.modifyAcceleration).
    fn fluid_flow_at(&self, _x: i32, _y: i32, _z: i32, _cell: FluidCell) -> Vec3 { Vec3::ZERO }
}

#[derive(Debug, Clone, Copy, Default)]
struct FluidContact {
    water: bool,
    /// Entity#isInLava: contracted material bounds, used for lava contact state.
    lava: bool,
    /// Entity#handleLavaMovement: the uncontracted body AABB, used by travel.
    lava_movement: bool,
    flow: Vec3,
}

fn effective_fluid_level(cell: FluidCell) -> i32 { cell.effective_level() }

/// Reproduces BlockLiquid.getFlowVector's neighbor-level gradient and falling
/// liquid downward bias. The result is normalized exactly once per liquid cell.
fn liquid_flow_at<C: BlockCollision>(world: &C, x: i32, y: i32, z: i32, cell: FluidCell) -> Vec3 {
    let current = effective_fluid_level(cell);
    let mut flow = Vec3::ZERO;
    for (dx, dz) in [(0, -1), (0, 1), (-1, 0), (1, 0)] {
        let nx = x + dx;
        let nz = z + dz;
        let neighbor = world.fluid_at(nx, y, nz).filter(|other| other.kind == cell.kind);
        if let Some(other) = neighbor {
            let delta = effective_fluid_level(other) - current;
            flow += Vec3::new(dx as f32 * delta as f32, 0.0, dz as f32 * delta as f32);
        } else if !world.is_solid(nx, y, nz) {
            if let Some(below) = world.fluid_at(nx, y - 1, nz).filter(|other| other.kind == cell.kind) {
                let delta = effective_fluid_level(below) - (current - 8);
                flow += Vec3::new(dx as f32 * delta as f32, 0.0, dz as f32 * delta as f32);
            }
        }
    }
    if cell.level >= 8 {
        let blocked_drop = [(0, -1), (0, 1), (-1, 0), (1, 0)].into_iter().any(|(dx, dz)| {
            world.is_solid(x + dx, y, z + dz) || world.is_solid(x + dx, y + 1, z + dz)
        });
        if blocked_drop {
            flow = flow.normalize_or_zero() + Vec3::new(0.0, -6.0, 0.0);
        }
    }
    flow.normalize_or_zero()
}

fn sample_fluid_contact<C: BlockCollision>(feet: Vec3, world: &C) -> FluidContact {
    // Liquid movement/contact is based on the actual player body volume. The
    // previous approximation extended the water/lava query 0.4 blocks below
    // the feet, which made shore contact trigger before the body reached liquid.
    let half = PLAYER_WIDTH * 0.5;
    let water_min_x = (feet.x - half + 0.001).floor() as i32;
    let water_max_x = (feet.x + half - 0.001).floor() as i32;
    let water_min_z = (feet.z - half + 0.001).floor() as i32;
    let water_max_z = (feet.z + half - 0.001).floor() as i32;
    let lava_half = half - 0.1;
    let lava_min_x = (feet.x - lava_half + 0.001).floor() as i32;
    let lava_max_x = (feet.x + lava_half - 0.001).floor() as i32;
    let lava_min_z = (feet.z - lava_half + 0.001).floor() as i32;
    let lava_max_z = (feet.z + lava_half - 0.001).floor() as i32;
    // Use the unexpanded body AABB: touching a liquid block only below the
    // feet must not switch movement into swimming while standing on the shore.
    let water_box_min_y = feet.y + 0.001;
    let water_box_max_y = feet.y + PLAYER_HEIGHT - 0.001;
    let water_min_y = water_box_min_y.floor() as i32;
    let water_max_y = water_box_max_y.floor() as i32;

    // Lava contact uses the narrowed horizontal body footprint but, like water,
    // must intersect the liquid surface vertically rather than merely lie above it.
    let lava_box_min_y = feet.y + 0.001;
    let lava_box_max_y = feet.y + PLAYER_HEIGHT - 0.001;
    let lava_min_y = lava_box_min_y.floor() as i32;
    let lava_max_y = lava_box_max_y.floor() as i32;
    let body_min_y = feet.y.floor() as i32;
    let body_max_y = (feet.y + PLAYER_HEIGHT - 0.001).floor() as i32;
    let body_min_x = (feet.x - half + 0.001).floor() as i32;
    let body_max_x = (feet.x + half - 0.001).floor() as i32;
    let body_min_z = (feet.z - half + 0.001).floor() as i32;
    let body_max_z = (feet.z + half - 0.001).floor() as i32;

    let mut contact = FluidContact::default();
    let mut flow_samples = 0_u32;

    for y in water_min_y..=water_max_y {
        for z in water_min_z..=water_max_z {
            for x in water_min_x..=water_max_x {
                let Some(cell) = world.fluid_at(x, y, z) else { continue; };
                if cell.kind != FluidKind::Water { continue; }
                let surface = y as f32 + cell.surface_height();
                if water_box_max_y > y as f32 && water_box_min_y < surface {
                    contact.water = true;
                    contact.flow += liquid_flow_at(world, x, y, z, cell);
                    flow_samples += 1;
                }
            }
        }
    }
    for y in lava_min_y..=lava_max_y {
        for z in lava_min_z..=lava_max_z {
            for x in lava_min_x..=lava_max_x {
                if let Some(cell) = world.fluid_at(x, y, z).filter(|cell| cell.kind == FluidKind::Lava) {
                    let surface = y as f32 + cell.surface_height();
                    if lava_box_max_y > y as f32 && lava_box_min_y < surface {
                        contact.lava = true;
                    }
                }
            }
        }
    }
    'body: for y in body_min_y..=body_max_y {
        for z in body_min_z..=body_max_z {
            for x in body_min_x..=body_max_x {
                if let Some(cell) = world.fluid_at(x, y, z).filter(|cell| cell.kind == FluidKind::Lava) {
                    let surface = y as f32 + cell.surface_height();
                    if feet.y + PLAYER_HEIGHT - 0.001 > y as f32 && feet.y + 0.001 < surface {
                        contact.lava_movement = true;
                        break 'body;
                    }
                }
            }
        }
    }
    if flow_samples > 0 { contact.flow = contact.flow.normalize_or_zero(); }
    contact
}

/// One fixed-step simulation. Call at 1/20 s for classic 1.8.9 movement timing.
pub fn tick<C: BlockCollision>(player: &mut PlayerState, input: PlayerInput, dt: f32, world: &C) {
    let dt = dt.clamp(0.0, 0.05);
    if dt == 0.0 { return; }

    let mut wish = Vec3::ZERO;
    if input.forward { wish.z += 1.0; }
    if input.backward { wish.z -= 1.0; }
    if input.right { wish.x += 1.0; }
    if input.left { wish.x -= 1.0; }
    if wish.length_squared() > 1.0 { wish = wish.normalize(); }

    // Match the camera's screen-space right vector: at yaw=0, right is -X
    // in this renderer's right-handed view convention.
    let (sin, cos) = player.yaw.sin_cos();
    let world_wish = Vec3::new(-wish.x * cos - wish.z * sin, 0.0, -wish.x * sin + wish.z * cos);
    let fluid = sample_fluid_contact(player.position, world);
    player.in_water = fluid.water;
    player.in_lava = fluid.lava;
    let lava_movement = fluid.lava_movement;
    let in_liquid = player.in_water || lava_movement;

    if in_liquid {
        // MCP 1.8.9 EntityLivingBase#moveEntityWithHeading calls
        // moveFlying(strafe, forward, 0.02F) in both liquids. This simulation
        // stores velocity in blocks/second, whereas vanilla stores blocks/tick:
        // 0.02 blocks/tick becomes +0.4 blocks/second per tick (8.0 * dt).
        player.velocity.x += world_wish.x * (8.0 * dt);
        player.velocity.z += world_wish.z * (8.0 * dt);
        // World#handleMaterialAcceleration adds normalized water flow * 0.014
        // blocks/tick. Convert that tick impulse to this seconds-based velocity.
        if player.in_water { player.velocity += fluid.flow * (5.6 * dt); }
        // EntityLivingBase#updateAITick / handleJumpLava add +0.04 blocks/tick.
        if input.jump_held { player.velocity.y += 16.0 * dt; }
        player.on_ground = false;
        player.jump_buffer = 0.0;
        player.coyote_time = 0.0;
    } else {
        let speed = WALK_SPEED * if input.sprint { 1.3 } else { 1.0 };
        let target = world_wish * speed;
        let acceleration = if player.on_ground { GROUND_ACCELERATION } else { AIR_ACCELERATION };
        let max_change = acceleration * dt;
        for axis in [0_usize, 2_usize] {
            let desired = target[axis];
            let current = player.velocity[axis];
            let rate = if desired.abs() < 1.0e-5 && player.on_ground { GROUND_FRICTION * dt } else { max_change };
            player.velocity[axis] = current + (desired - current).clamp(-rate, rate);
        }
        player.velocity.y = (player.velocity.y - GRAVITY * dt).max(-TERMINAL_VELOCITY);
        if input.jump { player.jump_buffer = JUMP_BUFFER_SECONDS; }
        else { player.jump_buffer = (player.jump_buffer - dt).max(0.0); }
        if player.on_ground { player.coyote_time = COYOTE_SECONDS; }
        else { player.coyote_time = (player.coyote_time - dt).max(0.0); }
    }
    let old_y = player.position.y;
    let collided_x = move_axis(player, 0, player.velocity.x * dt, world);
    let collided_z = move_axis(player, 2, player.velocity.z * dt, world);
    let collided_horizontally = collided_x || collided_z;

    // Refresh support before consuming a buffered jump. The previous implementation
    // only discovered the floor after a downward movement step, which made jump
    // depend on the exact first-frame/fixed-step ordering after spawn or landing.
    player.on_ground = !in_liquid && player.velocity.y <= 0.0
        && has_ground_support(player.position, world);

    if !in_liquid && player.jump_buffer > 0.0 && (player.on_ground || player.coyote_time > 0.0) {
        player.velocity.y = JUMP_SPEED;
        player.on_ground = false;
        player.coyote_time = 0.0;
        player.jump_buffer = 0.0;
    }

    let vertical = player.velocity.y * dt;
    let vertical_collision = move_axis(player, 1, vertical, world);
    if vertical_collision && vertical < 0.0 && !in_liquid {
        player.on_ground = true;
        player.coyote_time = COYOTE_SECONDS;
    }
    if in_liquid {
        // Vanilla moves first, then applies per-tick drag (0.8 water / 0.5
        // lava) and subtracts 0.02 blocks/tick from vertical motion. Convert
        // the gravity impulse to blocks/second: -0.4 per tick, or -8.0 * dt.
        let drag = if player.in_water { 0.8_f32 } else { 0.5_f32 }.powf(dt * 20.0);
        player.velocity.x *= drag;
        player.velocity.y *= drag;
        player.velocity.z *= drag;
        player.velocity.y -= 8.0 * dt;

        // EntityLivingBase#moveEntityWithHeading (1.8.9) lets the player climb
        // out of a liquid when horizontal movement hits a wall but a 0.6-block
        // upward offset would be clear of both solid blocks and liquid. Vanilla
        // stores motion in blocks/tick; this engine stores blocks/second.
        // The vanilla +0.3 motionY therefore becomes +6.0 blocks/second.
        if in_liquid && collided_horizontally {
            let vanilla_offset = Vec3::new(
                player.velocity.x / 20.0,
                player.velocity.y / 20.0 + 0.6 - (player.position.y - old_y),
                player.velocity.z / 20.0,
            );
            if is_offset_position_in_liquid(player.position, vanilla_offset, world) {
                player.velocity.y = 6.0;
            }
        }
    }
}

/// Entity#isOffsetPositionInLiquid: the translated player AABB must be free of
/// collision boxes and must not intersect any liquid block (not just its surface).
fn is_offset_position_in_liquid<C: BlockCollision>(feet: Vec3, offset: Vec3, world: &C) -> bool {
    let candidate = feet + offset;
    if intersects_solid(candidate, world) { return false; }
    let half = PLAYER_WIDTH * 0.5;
    let min_x = (candidate.x - half + COLLISION_EPSILON).floor() as i32;
    let max_x = (candidate.x + half - COLLISION_EPSILON).floor() as i32;
    let min_y = (candidate.y + COLLISION_EPSILON).floor() as i32;
    let max_y = (candidate.y + PLAYER_HEIGHT - COLLISION_EPSILON).floor() as i32;
    let min_z = (candidate.z - half + COLLISION_EPSILON).floor() as i32;
    let max_z = (candidate.z + half - COLLISION_EPSILON).floor() as i32;
    for y in min_y..=max_y {
        for z in min_z..=max_z {
            for x in min_x..=max_x {
                if world.fluid_at(x, y, z).is_some() { return false; }
            }
        }
    }
    true
}

/// True when the player's collision box would touch a solid block after a tiny
/// downward probe. This does not mutate the player or its velocity.
pub fn has_ground_support(feet: Vec3, world: &impl BlockCollision) -> bool {
    !intersects_solid(feet, world)
        && intersects_solid(feet - Vec3::Y * GROUND_PROBE_DISTANCE, world)
}

/// Moves along one axis and returns whether a solid block stopped the movement.
const STEP_HEIGHT: f32 = 0.5;

fn move_axis<C: BlockCollision>(player: &mut PlayerState, axis: usize, delta: f32, world: &C) -> bool {
    if delta.abs() < f32::EPSILON { return false; }
    let steps = (delta.abs() / MAX_SWEEP_STEP).ceil().max(1.0) as usize;
    let step = delta / steps as f32;
    for _ in 0..steps {
        let mut candidate = player.position;
        candidate[axis] += step;
        if intersects_solid(candidate, world) {
            // Entity.stepHeight in vanilla 1.8.9 is 0.5 blocks. Try stepping up
            // before clamping horizontal movement; full-height walls still fail this
            // clearance test, while stair half-boxes can be climbed naturally.
            if axis != 1 && (player.on_ground || has_ground_support(player.position, world)) {
                let mut raised = player.position;
                raised.y += STEP_HEIGHT;
                if !intersects_solid(raised, world) {
                    let mut raised_candidate = raised;
                    raised_candidate[axis] += step;
                    if !intersects_solid(raised_candidate, world) {
                        player.position = raised_candidate;
                        continue;
                    }
                }

                // A stair is made from a lower half and an upper half. If the
                // player's 0.6-block-wide body straddles that internal edge, the
                // 0.5-step candidate can still touch the upper half. Permit the
                // second half-step only when the attempted path overlaps a stair;
                // regular full blocks still cannot be climbed like ladders.
                let candidate_has_stair = candidate_overlaps_stair(candidate, world);
                if candidate_has_stair {
                    let mut raised_full = player.position;
                    raised_full.y += 2.0 * STEP_HEIGHT;
                    if !intersects_solid(raised_full, world) {
                        let mut raised_candidate = raised_full;
                        raised_candidate[axis] += step;
                        if !intersects_solid(raised_candidate, world) {
                            player.position = raised_candidate;
                            continue;
                        }
                    }
                }
            }
            // Refine the last safe position instead of leaving the player one sweep
            // increment away from a surface. This keeps floor contact numerically stable.
            let mut low = 0.0_f32;
            let mut high = 1.0_f32;
            for _ in 0..18 {
                let mid = (low + high) * 0.5;
                let mut probe = player.position;
                probe[axis] += step * mid;
                if intersects_solid(probe, world) { high = mid; } else { low = mid; }
            }
            player.position[axis] += step * low;
            if axis == 1 { player.velocity.y = 0.0; }
            else { player.velocity[axis] = 0.0; }
            return true;
        }
        player.position = candidate;
    }
    false
}

fn candidate_overlaps_stair(feet: Vec3, world: &impl BlockCollision) -> bool {
    let half = PLAYER_WIDTH * 0.5;
    let min_x = (feet.x - half + COLLISION_EPSILON).floor() as i32;
    let max_x = (feet.x + half - COLLISION_EPSILON).floor() as i32;
    let min_y = (feet.y + COLLISION_EPSILON).floor() as i32;
    let max_y = (feet.y + PLAYER_HEIGHT - COLLISION_EPSILON).floor() as i32;
    let min_z = (feet.z - half + COLLISION_EPSILON).floor() as i32;
    let max_z = (feet.z + half - COLLISION_EPSILON).floor() as i32;
    (min_y..=max_y).any(|y| {
        (min_z..=max_z).any(|z| (min_x..=max_x).any(|x| world.is_stair_at(x, y, z)))
    })
}

fn intersects_solid(feet: Vec3, world: &impl BlockCollision) -> bool {
    let half = PLAYER_WIDTH * 0.5;
    let min = Vec3::new(feet.x - half + COLLISION_EPSILON, feet.y + COLLISION_EPSILON, feet.z - half + COLLISION_EPSILON);
    let max = Vec3::new(feet.x + half - COLLISION_EPSILON, feet.y + PLAYER_HEIGHT - COLLISION_EPSILON, feet.z + half - COLLISION_EPSILON);
    // Fence collision boxes can rise 0.5 blocks above their own cell, so include
    // the cell immediately below the player's lowest occupied cell.
    let min_y = (min.y.floor() as i32 - 1).max(-1);
    for y in min_y..=max.y.floor() as i32 {
        for z in min.z.floor() as i32..=max.z.floor() as i32 {
            for x in min.x.floor() as i32..=max.x.floor() as i32 {
                for shape in world.collision_boxes(x, y, z) {
                    let box_min = Vec3::new(x as f32 + shape.min[0], y as f32 + shape.min[1], z as f32 + shape.min[2]);
                    let box_max = Vec3::new(x as f32 + shape.max[0], y as f32 + shape.max[1], z as f32 + shape.max[2]);
                    if min.x < box_max.x && max.x > box_min.x
                        && min.y < box_max.y && max.y > box_min.y
                        && min.z < box_max.z && max.z > box_min.z {
                        return true;
                    }
                }
            }
        }
    }
    false
}


/// Collision view over the currently loaded chunk window. Player coordinates are
/// local to the window; missing horizontal chunks are treated as a boundary wall.
#[derive(Clone)]
pub struct LoadedWorldCollision {
    pub chunks: HashMap<(i32, i32), ChunkData>,
    pub origin_chunk_x: i32,
    pub origin_chunk_z: i32,
}

impl LoadedWorldCollision {
    /// Change a block in the live collision/world snapshot. Coordinates are local to
    /// the session origin chunk, matching PlayerState and the renderer's region space.
    /// Persistence is deliberately handled by the world-edit transaction layer.
    pub fn set_block_local(&mut self, x: i32, y: i32, z: i32, id: u16, metadata: u8) -> mc189_core::Result<(u16, u8)> {
        if !(0..256).contains(&y) {
            return Err(mc189_core::Mc189Error::Usage("world block Y must be within 0..255".into()));
        }
        let world_x = i64::from(self.origin_chunk_x) * 16 + i64::from(x);
        let world_z = i64::from(self.origin_chunk_z) * 16 + i64::from(z);
        let chunk_x = i32::try_from(world_x.div_euclid(16)).map_err(|_| mc189_core::Mc189Error::InvalidData("chunk X overflow".into()))?;
        let chunk_z = i32::try_from(world_z.div_euclid(16)).map_err(|_| mc189_core::Mc189Error::InvalidData("chunk Z overflow".into()))?;
        let chunk = self.chunks.get_mut(&(chunk_x, chunk_z)).ok_or_else(|| mc189_core::Mc189Error::InvalidData(format!("cannot edit unloaded chunk ({chunk_x},{chunk_z})")))?;
        chunk.set_block(world_x.rem_euclid(16) as u8, y as u8, world_z.rem_euclid(16) as u8, id, metadata)
    }

    pub fn loaded_state_at(&self, x: i32, y: i32, z: i32) -> Option<(u16, u8)> {
        if !(0..256).contains(&y) { return None; }
        let world_x = i64::from(self.origin_chunk_x) * 16 + i64::from(x);
        let world_z = i64::from(self.origin_chunk_z) * 16 + i64::from(z);
        let cx = i32::try_from(world_x.div_euclid(16)).ok()?;
        let cz = i32::try_from(world_z.div_euclid(16)).ok()?;
        let chunk = self.chunks.get(&(cx, cz))?;
        let lx = world_x.rem_euclid(16) as u8;
        let lz = world_z.rem_euclid(16) as u8;
        let id = chunk.block_id_at(lx, y as u8, lz).unwrap_or(0);
        let metadata = chunk.block_metadata_at(lx, y as u8, lz).unwrap_or(0);
        Some((id, metadata))
    }

    /// Return the currently decoded vanilla light levels (sky, block) at a
    /// session-local block coordinate. Unloaded chunks deliberately return None.
    pub fn light_at_local(&self, x: i32, y: i32, z: i32) -> Option<(u8, u8)> {
        if !(0..256).contains(&y) { return None; }
        let world_x = i64::from(self.origin_chunk_x) * 16 + i64::from(x);
        let world_z = i64::from(self.origin_chunk_z) * 16 + i64::from(z);
        let cx = i32::try_from(world_x.div_euclid(16)).ok()?;
        let cz = i32::try_from(world_z.div_euclid(16)).ok()?;
        let chunk = self.chunks.get(&(cx, cz))?;
        chunk.light_at(world_x.rem_euclid(16) as u8, y as u8, world_z.rem_euclid(16) as u8)
    }

    fn state_or_air(&self, x: i32, y: i32, z: i32) -> (u16, u8) {
        self.loaded_state_at(x, y, z).unwrap_or((0, 0))
    }
}

impl BlockCollision for LoadedWorldCollision {
    fn is_solid(&self, x: i32, y: i32, z: i32) -> bool {
        !self.collision_boxes(x, y, z).is_empty()
    }

    fn is_stair_at(&self, x: i32, y: i32, z: i32) -> bool {
        self.loaded_state_at(x, y, z).is_some_and(|(id, _)| is_stair_block(id))
    }

    fn slipperiness_at(&self, x: i32, y: i32, z: i32) -> f32 {
        match self.loaded_state_at(x, y, z).map(|state| state.0).unwrap_or(0) {
            79 | 174 | 212 => 0.98, // ice, packed ice, frosted ice
            165 => 0.8,            // slime block
            _ => 0.6,
        }
    }

    fn fluid_flow_at(&self, x: i32, y: i32, z: i32, cell: FluidCell) -> Vec3 {
        liquid_flow_at(self, x, y, z, cell)
    }

    fn collision_boxes(&self, x: i32, y: i32, z: i32) -> Vec<BlockCollisionBox> {
        if y < 0 { return vec![BlockCollisionBox::FULL_CUBE]; }
        if y >= 256 { return Vec::new(); }
        // An unloaded horizontal chunk remains a solid safety boundary, as before.
        let Some((id, metadata)) = self.loaded_state_at(x, y, z) else {
            return vec![BlockCollisionBox::FULL_CUBE];
        };
        if id == 0 { return Vec::new(); }
        if is_stair_block(id) { return stair_collision_boxes(metadata); }
        if is_half_slab_block(id) { return vec![slab_collision_box(metadata)]; }
        if is_trapdoor_block(id) { return vec![trapdoor_collision_box(metadata)]; }
        if is_fence_block(id) {
            let east = fence_connects_to(self.state_or_air(x + 1, y, z).0);
            let west = fence_connects_to(self.state_or_air(x - 1, y, z).0);
            let north = fence_connects_to(self.state_or_air(x, y, z - 1).0);
            let south = fence_connects_to(self.state_or_air(x, y, z + 1).0);
            let min_x = if west { 0.0 } else { 0.375 };
            let max_x = if east { 1.0 } else { 0.625 };
            let min_z = if north { 0.0 } else { 0.375 };
            let max_z = if south { 1.0 } else { 0.625 };
            return vec![BlockCollisionBox::new([min_x, 0.0, min_z], [max_x, 1.5, max_z])];
        }
        if is_fence_gate(id) {
            if metadata & 0x04 != 0 { return Vec::new(); }
            // Fence-gate metadata 0/2 faces north/south (bar spans X); 1/3
            // faces east/west (bar spans Z). The closed gate is 1.5 blocks high.
            return if metadata & 0x01 == 0 {
                vec![BlockCollisionBox::new([0.0, 0.0, 0.375], [1.0, 1.5, 0.625])]
            } else {
                vec![BlockCollisionBox::new([0.375, 0.0, 0.0], [0.625, 1.5, 1.0])]
            };
        }
        if is_door_block(id) {
            let below = self.state_or_air(x, y - 1, z);
            let above = self.state_or_air(x, y + 1, z);
            return vec![door_collision_box(id, metadata, below, above)];
        }
        if is_player_solid_legacy_block(id) { return vec![BlockCollisionBox::FULL_CUBE]; }
        Vec::new()
    }

    fn fluid_at(&self, x: i32, y: i32, z: i32) -> Option<FluidCell> {
        if !(0..256).contains(&y) { return None; }
        let (id, level) = self.loaded_state_at(x, y, z)?;
        let kind = match id { 8 | 9 => FluidKind::Water, 10 | 11 => FluidKind::Lava, _ => return None };
        Some(FluidCell { kind, level })
    }
}

/// Legacy blocks which obstruct player movement. Partial geometry is handled
/// by the collision shape registry above; this predicate covers remaining cubes.
/// Finds a safe feet-height above the saved X/Z spawn column. The level.dat
/// spawn Y is a block coordinate, not a guarantee that the player's 1.8-block
/// body is clear there. Search upward first (the common buried-spawn case),
/// then downward for worlds whose saved spawn is above the terrain.
pub fn resolve_safe_spawn(spawn: Vec3, world: &impl BlockCollision) -> Option<Vec3> {
    let x = spawn.x.floor() as i32;
    let z = spawn.z.floor() as i32;
    let preferred_y = spawn.y.floor().clamp(1.0, 254.0) as i32;
    let is_standable = |feet_y: i32| {
        world.is_solid(x, feet_y - 1, z)
            && !world.is_solid(x, feet_y, z)
            && !world.is_solid(x, feet_y + 1, z)
    };
    for y in preferred_y..=254 {
        if is_standable(y) {
            return Some(Vec3::new(spawn.x, y as f32, spawn.z));
        }
    }
    for y in (1..preferred_y).rev() {
        if is_standable(y) {
            return Some(Vec3::new(spawn.x, y as f32, spawn.z));
        }
    }
    None
}

pub fn is_player_solid_legacy_block(id: u16) -> bool {
    matches!(id,
        1|2|3|4|5|7|12|13|14|15|16|17|18|20|21|22|24|35|41|42|43|45|46|47|48|49|
        52|53|56|57|58|61|62|64|67|71|73|74|79|80|82|85|86|87|89|91|95|97|98|107|108|109|
        110|112|113|114|121|123|124|125|128|129|133|134|135|136|138|152|153|155|156|159|161|
        162|163|164|165|166|168|169|170|172|173|174|179|180|183|184|185|186|187|188|189|190|191|192|
        193|194|195|196|197|204)
}

fn is_stair_block(id: u16) -> bool {
    matches!(id, 53 | 67 | 108 | 109 | 114 | 128 | 134 | 135 | 136 | 156 | 163 | 164 | 180)
}
fn is_fence_block(id: u16) -> bool { matches!(id, 85 | 113 | 188..=192) }
fn is_fence_gate(id: u16) -> bool { matches!(id, 107 | 183..=187) }
fn is_door_block(id: u16) -> bool { matches!(id, 64 | 71 | 193..=197) }
fn is_half_slab_block(id: u16) -> bool { matches!(id, 44 | 126 | 182 | 205) }
fn is_trapdoor_block(id: u16) -> bool { matches!(id, 96 | 167) }

fn slab_collision_box(metadata: u8) -> BlockCollisionBox {
    if metadata & 0x08 != 0 {
        BlockCollisionBox::new([0.0, 0.5, 0.0], [1.0, 1.0, 1.0])
    } else {
        BlockCollisionBox::new([0.0, 0.0, 0.0], [1.0, 0.5, 1.0])
    }
}

/// BlockTrapDoor.setBounds from MCP 1.8.9: closed panels occupy the top or
/// bottom 3/16; open panels stand vertically on the metadata-selected edge.
fn trapdoor_collision_box(metadata: u8) -> BlockCollisionBox {
    let top_half = metadata & 0x08 != 0;
    let open = metadata & 0x04 != 0;
    if !open {
        return if top_half {
            BlockCollisionBox::new([0.0, 0.8125, 0.0], [1.0, 1.0, 1.0])
        } else {
            BlockCollisionBox::new([0.0, 0.0, 0.0], [1.0, 0.1875, 1.0])
        };
    }
    match metadata & 0x03 {
        0 => BlockCollisionBox::new([0.0, 0.0, 0.8125], [1.0, 1.0, 1.0]), // north
        1 => BlockCollisionBox::new([0.0, 0.0, 0.0], [1.0, 1.0, 0.1875]), // south
        2 => BlockCollisionBox::new([0.8125, 0.0, 0.0], [1.0, 1.0, 1.0]), // west
        _ => BlockCollisionBox::new([0.0, 0.0, 0.0], [0.1875, 1.0, 1.0]), // east
    }
}

fn stair_collision_boxes(metadata: u8) -> Vec<BlockCollisionBox> {
    let top_half = metadata & 0x04 != 0;
    let (base_min_y, base_max_y, step_min_y, step_max_y) = if top_half {
        (0.5, 1.0, 0.0, 0.5)
    } else {
        (0.0, 0.5, 0.5, 1.0)
    };
    let (step_min_x, step_max_x, step_min_z, step_max_z) = match metadata & 0x03 {
        0 => (0.5, 1.0, 0.0, 1.0), // facing east
        1 => (0.0, 0.5, 0.0, 1.0), // facing west
        2 => (0.0, 1.0, 0.5, 1.0), // facing south
        _ => (0.0, 1.0, 0.0, 0.5), // facing north
    };
    vec![
        BlockCollisionBox::new([0.0, base_min_y, 0.0], [1.0, base_max_y, 1.0]),
        BlockCollisionBox::new([step_min_x, step_min_y, step_min_z], [step_max_x, step_max_y, step_max_z]),
    ]
}

fn fence_connects_to(id: u16) -> bool {
    is_fence_block(id) || is_fence_gate(id) || matches!(id,
        1|2|3|4|5|7|12|13|14|15|16|17|21|22|24|41|42|43|45|46|47|48|49|56|57|58|
        61|62|73|74|80|82|86|87|88|89|91|98|103|110|112|121|123|124|125|129|133|138|
        152|153|155|159|162|165|166|168|169|170|172|173|174|179)
}

fn door_collision_box(id: u16, metadata: u8, below: (u16, u8), above: (u16, u8)) -> BlockCollisionBox {
    let lower_meta = if metadata & 0x08 != 0 && below.0 == id { below.1 } else if metadata & 0x08 == 0 { metadata } else { 0 };
    let upper_meta = if metadata & 0x08 != 0 { metadata } else if above.0 == id { above.1 } else { 0 };
    let facing = lower_meta & 0x03;
    let open = lower_meta & 0x04 != 0;
    let hinge_right = upper_meta & 0x01 != 0;
    let rotation = if !open { facing } else if hinge_right { (facing + 3) & 3 } else { (facing + 1) & 3 };
    match rotation {
        0 => BlockCollisionBox::new([0.0, 0.0, 0.0], [0.1875, 1.0, 1.0]),
        1 => BlockCollisionBox::new([0.0, 0.0, 0.0], [1.0, 1.0, 0.1875]),
        2 => BlockCollisionBox::new([0.8125, 0.0, 0.0], [1.0, 1.0, 1.0]),
        _ => BlockCollisionBox::new([0.0, 0.0, 0.8125], [1.0, 1.0, 1.0]),
    }
}

/// Reads the actual vanilla spawn from level.dat. Does not alter the world.
pub fn load_world_spawn(world: &Path) -> Result<Vec3> {
    let meta = read_world_metadata(world)?;
    let (x, y, z) = match (meta.spawn_x, meta.spawn_y, meta.spawn_z) {
        (Some(x), Some(y), Some(z)) => (x, y, z),
        _ => return Err(Mc189Error::InvalidData("level.dat does not contain a complete SpawnX/SpawnY/SpawnZ tuple".into())),
    };
    if !(0..256).contains(&y) { return Err(Mc189Error::InvalidData(format!("world spawn Y is outside classic build height: {y}"))); }
    Ok(Vec3::new(x as f32 + 0.5, y as f32, z as f32 + 0.5))
}

#[cfg(test)]
mod tests {
    use super::*;
    struct FloorAndWall;
    impl BlockCollision for FloorAndWall {
        fn is_solid(&self, x:i32,y:i32,z:i32)->bool { y < 0 || (x == 2 && y >= 0 && y < 4 && z == 0) }
    }
    struct LiquidPool { kind: FluidKind, level: u8 }
    impl BlockCollision for LiquidPool {
        fn is_solid(&self, _x: i32, y: i32, _z: i32) -> bool { y < 0 }
        fn fluid_at(&self, _x: i32, y: i32, _z: i32) -> Option<FluidCell> {
            (y == 0).then_some(FluidCell { kind: self.kind, level: self.level })
        }
    }

    #[test]
    fn vanilla_liquid_height_matches_block_liquid_metadata() {
        assert!((FluidCell { kind: FluidKind::Water, level: 0 }.surface_height() - 8.0 / 9.0).abs() < 1e-6);
        assert!((FluidCell { kind: FluidKind::Water, level: 7 }.surface_height() - 1.0 / 9.0).abs() < 1e-6);
        assert!((FluidCell { kind: FluidKind::Lava, level: 8 }.surface_height() - 8.0 / 9.0).abs() < 1e-6);
    }

    #[test]
    fn player_detects_water_and_can_swim_up_without_solid_collision() {
        let water = LiquidPool { kind: FluidKind::Water, level: 0 };
        let mut player = PlayerState::at(Vec3::new(0.5, 0.2, 0.5));
        tick(&mut player, PlayerInput { forward: true, jump_held: true, ..Default::default() }, 0.05, &water);
        assert!(player.in_water);
        assert!(!player.in_lava);
        assert!(player.velocity.y > 0.0, "held jump must produce upward swimming motion");
        assert!(player.position.z > 0.5, "water remains traversable rather than a solid wall");
    }

    #[test]
    fn lava_contact_does_not_trigger_when_metadata_surface_is_below_feet() {
        let lava = LiquidPool { kind: FluidKind::Lava, level: 7 };
        let mut player = PlayerState::at(Vec3::new(0.5, 0.6, 0.5));
        tick(&mut player, PlayerInput::default(), 0.05, &lava);
        assert!(
            !player.in_lava,
            "level-7 lava surface is below the player's feet and must not trigger contact"
        );
    }

    #[test]
    fn liquid_neighbor_level_gradient_pushes_player_with_the_current() {
        struct Current;
        impl BlockCollision for Current {
            fn is_solid(&self, _x: i32, y: i32, _z: i32) -> bool { y < 0 }
            fn fluid_at(&self, x: i32, y: i32, z: i32) -> Option<FluidCell> {
                if y != 0 { return None; }
                match (x, z) {
                    (0, 0) => Some(FluidCell { kind: FluidKind::Water, level: 0 }),
                    (1, 0) => Some(FluidCell { kind: FluidKind::Water, level: 1 }),
                    _ => None,
                }
            }
        }
        let mut player = PlayerState::at(Vec3::new(0.5, 0.2, 0.5));
        tick(&mut player, PlayerInput::default(), 0.05, &Current);
        assert!(player.in_water);
        assert!((player.velocity.x - 0.224).abs() < 1.0e-5, "vanilla water current adds 0.014 blocks/tick before 0.8 drag");
    }

    #[test]
    fn standing_at_water_shore_does_not_enter_water_before_body_intersects_surface() {
        let water = LiquidPool { kind: FluidKind::Water, level: 0 };
        // The full water surface is at y=8/9. Feet at y=1.0 are above it;
        // the old artificial 0.4-block downward expansion falsely detected water.
        let mut player = PlayerState::at(Vec3::new(0.5, 1.0, 0.5));
        tick(&mut player, PlayerInput::default(), 0.05, &water);
        assert!(!player.in_water, "water below the feet must not activate swimming");
    }

    #[test]
    fn vanilla_water_wall_exit_applies_the_small_upward_step() {
        struct WaterShoreWall;
        impl BlockCollision for WaterShoreWall {
            fn is_solid(&self, x: i32, y: i32, _z: i32) -> bool {
                y < 0 || (x >= 1 && y >= 0 && y < 4)
            }
            fn fluid_at(&self, x: i32, y: i32, _z: i32) -> Option<FluidCell> {
                (x <= 0 && y == 0).then_some(FluidCell { kind: FluidKind::Water, level: 0 })
            }
        }
        let world = WaterShoreWall;
        let mut player = PlayerState::at(Vec3::new(0.5, 0.45, 0.5));
        player.velocity.x = 8.0;
        tick(&mut player, PlayerInput::default(), 0.05, &world);
        assert!(player.in_water, "the player begins this tick in the water");
        assert!(player.position.x < 0.71, "the shore wall must stop horizontal motion");
        assert!((player.velocity.y - 6.0).abs() < 1.0e-5,
            "vanilla's 0.3 blocks/tick exit impulse is 6 blocks/second here");
    }

    #[test]
    fn vanilla_lava_wall_exit_uses_the_same_upward_step_as_water() {
        struct LavaShoreWall;
        impl BlockCollision for LavaShoreWall {
            fn is_solid(&self, x: i32, y: i32, _z: i32) -> bool {
                y < 0 || (x >= 1 && y >= 0 && y < 4)
            }
            fn fluid_at(&self, x: i32, y: i32, _z: i32) -> Option<FluidCell> {
                (x <= 0 && y == 0).then_some(FluidCell { kind: FluidKind::Lava, level: 0 })
            }
        }
        let world = LavaShoreWall;
        let mut player = PlayerState::at(Vec3::new(0.5, 0.45, 0.5));
        player.velocity.x = 8.0;
        tick(&mut player, PlayerInput::default(), 0.05, &world);
        assert!(player.in_lava);
        assert!((player.velocity.y - 6.0).abs() < 1.0e-5,
            "vanilla applies the same 0.3 blocks/tick wall-exit impulse in lava");
    }

    #[test]
    fn water_does_not_apply_exit_hop_without_horizontal_collision() {
        let water = LiquidPool { kind: FluidKind::Water, level: 0 };
        let mut player = PlayerState::at(Vec3::new(0.5, 0.45, 0.5));
        tick(&mut player, PlayerInput::default(), 0.05, &water);
        assert!(player.in_water);
        assert!(player.velocity.y < 0.0, "ordinary water movement keeps vanilla gravity");
    }

    #[test]
    fn water_exit_probe_requires_the_offset_body_to_be_free_of_liquid() {
        struct DeepWaterWall;
        impl BlockCollision for DeepWaterWall {
            fn is_solid(&self, x: i32, y: i32, _z: i32) -> bool {
                y < 0 || (x >= 1 && y >= 0 && y < 4)
            }
            fn fluid_at(&self, x: i32, y: i32, _z: i32) -> Option<FluidCell> {
                (x <= 0 && (0..=1).contains(&y)).then_some(FluidCell { kind: FluidKind::Water, level: 0 })
            }
        }
        let world = DeepWaterWall;
        let mut player = PlayerState::at(Vec3::new(0.5, 0.2, 0.5));
        player.velocity.x = 8.0;
        tick(&mut player, PlayerInput::default(), 0.05, &world);
        assert!(player.in_water);
        assert!(player.velocity.y < 0.0, "the upward offset still intersects deep water");
    }

    #[test]
    fn water_contact_begins_when_the_body_reaches_the_liquid_surface() {
        let water = LiquidPool { kind: FluidKind::Water, level: 0 };
        let mut player = PlayerState::at(Vec3::new(0.5, 0.85, 0.5));
        tick(&mut player, PlayerInput::default(), 0.05, &water);
        assert!(player.in_water, "the body intersects the 8/9-high source water surface");
    }

    #[test]
    fn lava_movement_requires_actual_intersection_with_the_liquid_surface() {
        let lava = LiquidPool { kind: FluidKind::Lava, level: 0 };
        let mut above = PlayerState::at(Vec3::new(0.5, 1.0, 0.5));
        tick(&mut above, PlayerInput::default(), 0.05, &lava);
        assert!(!above.in_lava, "lava below the feet must not trigger liquid movement");

        let mut touching = PlayerState::at(Vec3::new(0.5, 0.85, 0.5));
        tick(&mut touching, PlayerInput::default(), 0.05, &lava);
        assert!(touching.in_lava, "lava movement begins once the body intersects the surface");
    }

    #[test]
    fn water_uses_vanilla_move_flying_acceleration_in_seconds_based_units() {
        let water = LiquidPool { kind: FluidKind::Water, level: 0 };
        let mut player = PlayerState::at(Vec3::new(0.5, 0.2, 0.5));
        tick(&mut player, PlayerInput { forward: true, ..Default::default() }, 0.05, &water);
        // Vanilla adds 0.02 blocks/tick before movement, then applies 0.8 drag.
        assert!((player.position.z - 0.52).abs() < 1.0e-5);
        assert!((player.velocity.z - 0.32).abs() < 1.0e-5);
    }

    #[test]
    fn water_gravity_and_held_jump_match_vanilla_tick_impulses() {
        let water = LiquidPool { kind: FluidKind::Water, level: 0 };
        let mut sinking = PlayerState::at(Vec3::new(0.5, 0.2, 0.5));
        tick(&mut sinking, PlayerInput::default(), 0.05, &water);
        assert!((sinking.velocity.y + 0.4).abs() < 1.0e-5);

        let mut swimming = PlayerState::at(Vec3::new(0.5, 0.2, 0.5));
        tick(&mut swimming, PlayerInput { jump_held: true, ..Default::default() }, 0.05, &water);
        assert!((swimming.position.y - 0.24).abs() < 1.0e-5);
        assert!((swimming.velocity.y - 0.24).abs() < 1.0e-5);
    }

    #[test]
    fn lava_uses_vanilla_half_drag_and_gravity_impulse() {
        let lava = LiquidPool { kind: FluidKind::Lava, level: 0 };
        let mut player = PlayerState::at(Vec3::new(0.5, 0.2, 0.5));
        player.velocity.x = 2.0;
        tick(&mut player, PlayerInput::default(), 0.05, &lava);
        assert!((player.velocity.x - 1.0).abs() < 1.0e-5);
        assert!((player.velocity.y + 0.4).abs() < 1.0e-5);
    }

    #[test]
    fn held_jump_in_lava_uses_the_same_vanilla_upward_impulse() {
        let lava = LiquidPool { kind: FluidKind::Lava, level: 0 };
        let mut player = PlayerState::at(Vec3::new(0.5, 0.2, 0.5));
        tick(&mut player, PlayerInput { jump_held: true, ..Default::default() }, 0.05, &lava);
        assert!((player.position.y - 0.24).abs() < 1.0e-5);
        // +0.04 motion, then 0.5 drag, then -0.02 gravity = zero.
        assert!(player.velocity.y.abs() < 1.0e-5);
    }

    #[test]
    fn lava_is_detected_and_uses_stronger_motion_drag_than_water() {
        let water = LiquidPool { kind: FluidKind::Water, level: 0 };
        let lava = LiquidPool { kind: FluidKind::Lava, level: 0 };
        let mut in_water = PlayerState::at(Vec3::new(0.5, 0.2, 0.5));
        let mut in_lava = in_water;
        in_water.velocity.x = 2.0;
        in_lava.velocity.x = 2.0;
        tick(&mut in_water, PlayerInput::default(), 0.05, &water);
        tick(&mut in_lava, PlayerInput::default(), 0.05, &lava);
        assert!(in_lava.in_lava && !in_lava.in_water);
        assert!(in_water.in_water && !in_water.in_lava);
        assert!(in_lava.velocity.x.abs() < in_water.velocity.x.abs());
    }

    #[test] fn loaded_collision_uses_negative_chunk_coordinates_and_missing_chunks_as_walls() {
        use mc189_storage::ChunkSection;
        let mut ids = vec![0_u16; 4096];
        ids[0] = 1;
        ids[1] = 9;
        ids[2] = 10;
        let mut metadata = vec![0; 4096];
        metadata[1] = 3;
        metadata[2] = 8;
        let section = ChunkSection { y: 0, block_ids: ids, metadata, block_light: None, sky_light: None };
        let chunk = ChunkData { x_pos: -1, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new(); chunks.insert((-1,0), chunk);
        let world = LoadedWorldCollision { chunks, origin_chunk_x: -1, origin_chunk_z: 0 };
        assert!(world.is_solid(0,0,0));
        assert!(world.is_solid(-1,0,0));
        assert!(!world.is_solid(0,1,0));
        assert_eq!(world.fluid_at(1,0,0), Some(FluidCell { kind: FluidKind::Water, level: 3 }));
        assert_eq!(world.fluid_at(2,0,0), Some(FluidCell { kind: FluidKind::Lava, level: 8 }));
        assert!(world.is_solid(16,0,0));
        assert!(world.is_solid(0,-1,0));
    }

    #[test]
    fn pumpkins_are_solid_but_mushrooms_remain_non_solid() {
        assert!(is_player_solid_legacy_block(86)); // pumpkin
        assert!(is_player_solid_legacy_block(204)); // double purpur slab
        assert!(is_player_solid_legacy_block(91)); // jack o'lantern
        assert!(!is_player_solid_legacy_block(39)); // brown mushroom
        assert!(!is_player_solid_legacy_block(40)); // red mushroom
    }

    #[test]
    fn loaded_collision_uses_partial_shapes_for_stairs_slabs_trapdoors_fences_doors_and_sea_lanterns() {
        use mc189_storage::ChunkSection;
        let mut ids = vec![0_u16; 4096];
        let mut metadata = vec![0_u8; 4096];
        let index = |x: usize, y: usize, z: usize| (y << 8) | (z << 4) | x;
        ids[index(1, 0, 1)] = 53;  // oak stair, facing east
        metadata[index(1, 0, 1)] = 0;
        ids[index(2, 0, 1)] = 85;  // oak fence
        ids[index(3, 0, 1)] = 64;  // lower oak door
        metadata[index(3, 0, 1)] = 0;
        ids[index(3, 1, 1)] = 64;  // upper oak door
        metadata[index(3, 1, 1)] = 8;
        ids[index(4, 0, 1)] = 169; // sea lantern
        ids[index(5, 0, 1)] = 44;  // bottom stone slab
        ids[index(6, 0, 1)] = 126; // top wooden slab
        metadata[index(6, 0, 1)] = 8;
        ids[index(7, 0, 1)] = 96;  // closed bottom trapdoor
        ids[index(8, 0, 1)] = 167; // open trapdoor, north edge
        metadata[index(8, 0, 1)] = 4;
        let section = ChunkSection { y: 0, block_ids: ids, metadata, block_light: None, sky_light: None };
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let world = LoadedWorldCollision { chunks: HashMap::from([((0, 0), chunk)]), origin_chunk_x: 0, origin_chunk_z: 0 };
        assert_eq!(world.collision_boxes(1, 0, 1).len(), 2);
        assert!((world.collision_boxes(2, 0, 1)[0].max[1] - 1.5).abs() < 1.0e-6);
        assert!((world.collision_boxes(3, 0, 1)[0].max[0] - 0.1875).abs() < 1.0e-6);
        assert!(world.is_solid(4, 0, 1), "sea lantern remains a full collision cube");
        assert!((world.collision_boxes(5, 0, 1)[0].max[1] - 0.5).abs() < 1.0e-6,
            "bottom slab collision must be one half-block high");
        assert!((world.collision_boxes(6, 0, 1)[0].min[1] - 0.5).abs() < 1.0e-6,
            "top slab collision must occupy the upper half");
        assert!((world.collision_boxes(7, 0, 1)[0].max[1] - 0.1875).abs() < 1.0e-6,
            "closed trapdoor collision must be 3/16 thick");
        assert!((world.collision_boxes(8, 0, 1)[0].min[2] - 0.8125).abs() < 1.0e-6,
            "open north-facing trapdoor must be vertical on the north edge");
    }

    #[test]
    fn horizontal_motion_can_step_up_stair_half_boxes() {
        struct StairObstacle;
        impl BlockCollision for StairObstacle {
            fn is_solid(&self, x: i32, y: i32, z: i32) -> bool { y < 0 || (x == 1 && y == 0 && z == 0) }
            fn collision_boxes(&self, x: i32, y: i32, z: i32) -> Vec<BlockCollisionBox> {
                if y < 0 { vec![BlockCollisionBox::FULL_CUBE] }
                else if (x, y, z) == (1, 0, 0) { stair_collision_boxes(0) }
                else { Vec::new() }
            }
            fn is_stair_at(&self, x: i32, y: i32, z: i32) -> bool { (x, y, z) == (1, 0, 0) }
        }
        let mut player = PlayerState::at(Vec3::new(0.5, 0.0, 0.5));
        player.on_ground = true;
        move_axis(&mut player, 0, 1.3, &StairObstacle);
        assert!(player.position.x > 1.5, "player should pass over the stair's raised half");
        assert!(player.position.y >= 1.0 - 1.0e-4, "successive 0.5-block steps should reach the top tread");
    }

    #[test] fn safe_spawn_moves_above_a_buried_saved_spawn() {
        struct RaisedFloor;
        impl BlockCollision for RaisedFloor {
            fn is_solid(&self, _x: i32, y: i32, _z: i32) -> bool { (60..=69).contains(&y) }
        }
        let saved = Vec3::new(-255.5, 64.0, 244.5);
        let safe = resolve_safe_spawn(saved, &RaisedFloor).expect("surface above buried spawn");
        assert_eq!(safe, Vec3::new(-255.5, 70.0, 244.5));
    }

    #[test] fn safe_spawn_finds_ground_below_an_overhigh_saved_spawn() {
        struct LowFloor;
        impl BlockCollision for LowFloor {
            fn is_solid(&self, _x: i32, y: i32, _z: i32) -> bool { y == 9 }
        }
        let safe = resolve_safe_spawn(Vec3::new(1.5, 30.0, 1.5), &LowFloor).unwrap();
        assert_eq!(safe.y, 10.0);
    }

    #[test] fn player_dimensions_and_eye_height_match_classic_player() {
        let p=PlayerState::at(Vec3::new(1.5,0.0,1.5));
        assert!((PLAYER_WIDTH-0.6).abs()<1e-6); assert!((PLAYER_HEIGHT-1.8).abs()<1e-6);
        assert!((p.eye_position().y-1.62).abs()<1e-6);
    }
    #[test] fn ground_probe_detects_support_without_moving_player() {
        let feet = Vec3::new(0.5, 0.0, 0.5);
        assert!(has_ground_support(feet, &FloorAndWall));
        assert!(!has_ground_support(feet + Vec3::Y * 0.2, &FloorAndWall));
    }

    #[test] fn buffered_jump_activates_when_ground_support_is_present() {
        let mut p = PlayerState::at(Vec3::new(0.5, 0.0, 0.5));
        tick(&mut p, PlayerInput { jump: true, ..Default::default() }, 0.05, &FloorAndWall);
        assert!(p.velocity.y > 0.0, "jump should start on supported floor");
        assert!(!p.on_ground);
    }

    #[test] fn gravity_lands_on_floor_and_sets_ground_flag() {
        let mut p=PlayerState::at(Vec3::new(0.5,2.0,0.5));
        for _ in 0..100 { tick(&mut p,PlayerInput::default(),0.05,&FloorAndWall); }
        assert!(p.on_ground); assert!(p.position.y.abs()<0.001); assert_eq!(p.velocity.y,0.0);
    }
    #[test] fn jump_only_starts_from_ground_and_returns_to_floor() {
        let mut p=PlayerState::at(Vec3::new(0.5,0.0,0.5)); p.on_ground=true;
        tick(&mut p,PlayerInput{jump:true,..Default::default()},0.05,&FloorAndWall);
        assert!(p.position.y>0.0); assert!(p.velocity.y>0.0);
        // A single jump press: holding jump would trigger another jump on landing.
        for _ in 0..100 { tick(&mut p,PlayerInput::default(),0.05,&FloorAndWall); }
        assert!(p.on_ground); assert!(p.position.y.abs()<0.001);
    }
    #[test] fn horizontal_collision_stops_at_wall_without_tunnelling() {
        // Start close enough that this tick reaches the wall at x=2.
        let mut p=PlayerState::at(Vec3::new(1.6,0.0,0.5)); p.on_ground=true;
        tick(&mut p,PlayerInput{left:true,..Default::default()},0.05,&FloorAndWall);
        assert!(p.position.x < 1.71);
    }
    #[test] fn diagonal_motion_is_normalized_and_yaw_rotates_it() {
        let mut a=PlayerState::at(Vec3::new(0.5,0.0,0.5)); a.on_ground=true;
        tick(&mut a,PlayerInput{forward:true,right:true,..Default::default()},0.05,&FloorAndWall);
        let horizontal=a.velocity.length(); assert!(horizontal > 0.0 && horizontal < WALK_SPEED);
        let mut b=PlayerState::at(Vec3::new(0.5,0.0,0.5)); b.yaw=std::f32::consts::FRAC_PI_2; b.on_ground=true;
        tick(&mut b,PlayerInput{forward:true,..Default::default()},0.05,&FloorAndWall);
        assert!(b.velocity.x < 0.0);
    }
    #[test] fn jump_buffer_survives_until_first_ground_contact() {
        let mut p=PlayerState::at(Vec3::new(0.5,0.03,0.5));
        tick(&mut p,PlayerInput{jump:true,..Default::default()},0.05,&FloorAndWall);
        for _ in 0..3 { tick(&mut p,PlayerInput::default(),0.05,&FloorAndWall); }
        assert!(p.velocity.y > 0.0 || p.position.y > 0.1, "buffered jump should trigger on landing");
    }

    #[test] fn lateral_controls_follow_screen_space_right_and_left() {
        let mut left=PlayerState::at(Vec3::new(0.5,0.0,0.5)); left.on_ground=true;
        tick(&mut left,PlayerInput{left:true,..Default::default()},0.05,&FloorAndWall);
        let mut right=PlayerState::at(Vec3::new(0.5,0.0,0.5)); right.on_ground=true;
        tick(&mut right,PlayerInput{right:true,..Default::default()},0.05,&FloorAndWall);
        assert!(left.velocity.x > 0.0);
        assert!(right.velocity.x < 0.0);
    }

}
