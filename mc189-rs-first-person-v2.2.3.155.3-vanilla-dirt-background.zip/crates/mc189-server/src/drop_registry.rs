//! Minecraft Java 1.8.9 legacy block drop registry.
//!
//! This module deliberately models block drops separately from hardness and
//! mining progress. IDs are the 1.8.9 legacy numeric block/item IDs.
use crate::mining::{ToolKind, ToolTier};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct DropTool { pub kind: ToolKind, pub tier: ToolTier, pub shears: bool }
impl Default for DropTool { fn default()->Self { Self { kind:ToolKind::Hand, tier:ToolTier::None, shears:false } } }
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ItemDrop { pub item_id:u16, pub metadata:u8, pub count:u8 }
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DropStatus { Known, NoDrop, Unknown }

// java.util.Random, as used by World.rand in 1.8.9. The caller must supply
// the actual Java Random seed/state at the point the vanilla method is called;
// a per-block derived seed is NOT equivalent to the world's shared RNG stream.
const JAVA_MULTIPLIER: u64 = 0x5DEECE66D;
const JAVA_ADDEND: u64 = 0xB;
const JAVA_MASK: u64 = (1u64 << 48) - 1;
#[derive(Clone, Debug)]
pub struct JavaRandom { seed: u64 }
impl JavaRandom {
    pub fn new(seed: u64) -> Self { Self { seed: (seed ^ JAVA_MULTIPLIER) & JAVA_MASK } }
    /// Construct from java.util.Random's already-scrambled 48-bit internal state.
    pub fn from_internal_state(state: u64) -> Self { Self { seed: state & JAVA_MASK } }
    fn next_bits(&mut self, bits: u32) -> u32 {
        self.seed = self.seed.wrapping_mul(JAVA_MULTIPLIER).wrapping_add(JAVA_ADDEND) & JAVA_MASK;
        (self.seed >> (48 - bits)) as u32
    }
    pub fn next_int(&mut self, bound: u32) -> u32 {
        assert!(bound > 0 && bound <= i32::MAX as u32);
        if bound.is_power_of_two() { return ((bound as u64 * self.next_bits(31) as u64) >> 31) as u32; }
        loop {
            let bits = self.next_bits(31) as i32;
            let value = bits % bound as i32;
            if bits.wrapping_sub(value).wrapping_add(bound as i32 - 1) >= 0 { return value as u32; }
        }
    }
    pub fn next_float(&mut self) -> f32 { (self.next_bits(24) as f32) / ((1u32 << 24) as f32) }
    fn below(&mut self, n: u32) -> u32 { self.next_int(n) }
}
fn silk_eligible(id:u16)->bool { !matches!(id,0|6|8|9|10|11|20|23|25|26|27|28|31|32|34|36|37|38|39|40|50|51|54|55|59|60|61|62|63|64|65|66|68|69|70|71|72|75|76|77|78|83|84|90|93|94|104|105|106|111|115|117|119|127|130|131|132|137|138|140|141|142|143|144|146|149|150|151|154|157|158|166|171|175|176|177|178|179|180|181|182|183|184|185|186|187|193|194|195|196|197) }

/// Resolve drops for a block break. `fortune` is clamped to 3. Silk Touch
/// returns the block item only for blocks whose vanilla behavior permits it.
pub fn resolve_drops(id:u16, meta:u8, tool:DropTool, fortune:u8, silk_touch:bool, seed:u64)->(DropStatus,Vec<ItemDrop>) {
    let mut rng=JavaRandom::new(seed);
    resolve_drops_with_rng(id,meta,tool,fortune,silk_touch,&mut rng)
}

/// Stateful entry point for a future World.rand integration. Reusing the same
/// generator across calls preserves vanilla's shared random stream.
pub fn resolve_drops_with_rng(id:u16, meta:u8, tool:DropTool, fortune:u8, silk_touch:bool, rng:&mut JavaRandom)->(DropStatus,Vec<ItemDrop>) {
    let f=fortune.min(3) as u32;
    let one=|item,metadata,count| vec![ItemDrop{item_id:item,metadata,count}];
    if id==0 { return (DropStatus::NoDrop,vec![]); }
    // BlockDeadBush.getItemDropped returns null; only its custom harvestBlock
    // path with shears creates the dead-bush item. Preserve that distinction.
    if id==32 && !tool.shears { return (DropStatus::NoDrop,vec![]); }
    // IDs absent from the 1.8.9 legacy registry must never silently become blocks.
    if id>197 { return (DropStatus::Unknown,vec![]); }
    if matches!(id,7|8|9|10|11|36|51|90|119|120|166) {
        return (DropStatus::NoDrop,vec![]);
    }
    if silk_touch && silk_eligible(id) {
        let silk_meta=match id {5=>meta&7,17|162=>meta&3,18=>meta&3,161=>meta&1,_=>meta};
        return (DropStatus::Known,one(id,silk_meta,1));
    }
    let drops=match id {
        1=>one(4,0,1), 2=>one(3,0,1), 3=>one(3,if meta&3==1{1}else if meta&3==2{2}else{0},1),
        6=>if rng.below(20)==0 {one(6,meta&3,1)}else{vec![]},
        12=>one(12,if meta&1==1{1}else{0},1),
        // BlockGravel.getItemDropped: one roll, denominator 10 - 3*fortune.
        13=>if rng.next_int((10u32.saturating_sub(3*f)).max(1))==0 {one(318,0,1)}else{one(13,0,1)},
        // BlockOre returns the ore block item for iron/gold; smelting is a
        // later furnace action. Fortune does not multiply those self-drops.
        14=>one(14,0,1), 15=>one(15,0,1), 16=>ore_drop(16, f, rng),
        17=>one(17,meta&3,1),
        18=>if tool.shears {one(18,meta&3,1)} else { leaf_drops(18,meta,f,rng) },
        20=>one(0,0,0), 21=>ore_drop(21, f, rng), 22=>one(22,0,1),
        24=>if meta&3==2 {one(13,0,1)}else{one(24,0,1)}, 25=>one(25,0,1),
        26=>one(355,0,1), 30=>one(287,0,1),
        31=>if tool.shears {one(31,meta&3,1)}else{tall_grass_drops(f,rng)},
        32=>if tool.shears {one(32,0,1)}else{vec![]}, 34=>one(324,0,1), 35=>one(35,meta&15,1), 37=>one(37,0,1), 38=>one(38,meta,1),
        39=>one(39,0,1),40=>one(40,0,1), 46=>one(46,0,1), 47=>one(47,0,1),
        48=>one(48,0,1),49=>one(49,0,1), 50=>one(50,0,1), 51=>vec![], 55=>one(331,0,1),
        // Crop IDs: wheat=59, carrots=141, potatoes=142.
        59=>crop_drops(295,296,meta,f,rng),
        115=>nether_wart_drops(meta,f,rng),
        127=>cocoa_drops(meta),
        141=>crop_drops(391,391,meta,f,rng),
        142=>potato_drops(meta,f,rng),
        52=>one(0,0,0), 78=>snow_layer_drops(meta), 80=>one(332,0,4),
        82=>one( clay_ball_item(),0,4), 86=>one(86,0,1),
        103=>melon_drops(f,rng), 106=>if tool.shears {one(106,0,1)}else{vec![]},
        132=>one(287,0,1), 175=>double_plant_drops(meta,tool,rng),
        53..=197=>generic_drop(id,meta,tool,rng,f),
        _=>generic_drop(id,meta,tool,rng,f),
    };
    // The following status check only inspects the collection; it does not
    // constrain the iterator item type, so spell out the vanilla drop payload.
    let drops: Vec<ItemDrop> = drops.into_iter().filter(|d|d.item_id!=0&&d.count>0).collect();
    let status = if matches!(id, 7|8|9|10|11|20|36|51|52|90|119|120|166) { DropStatus::NoDrop }
        else if !drops.is_empty() || matches!(id,1|2|3|6|12|13|14|15|16|17|18|21|22|24|25|26|30|31|32|34|35|37|38|39|40|46|47|48|49|50|55|56|59|73|74|79|82|83|89|98|103|106|110|111|115|121|127|129|132|141|142|153|155|159|161|162|165|172|173|174|175|179|180|181|182) { DropStatus::Known }
        else { DropStatus::Unknown };
    (status,drops)
}
fn ore_drop(id:u16, fortune:u32, r:&mut JavaRandom)->Vec<ItemDrop>{
    // BlockOre 1.8.9: Fortune applies only when the item differs from the
    // block item. Lapis quantity is rolled after the Fortune multiplier.
    let item = match id { 16=>263, 21=>351, 56=>264, 129=>388, 153=>406, _=>return vec![] };
    let mut multiplier=1u32;
    if fortune>0 {
        let bonus=r.next_int(fortune+2) as i32 - 1;
        multiplier=(bonus.max(0) as u32)+1;
    }
    let base=if id==21 { 4+r.next_int(5) } else { 1 };
    vec![ItemDrop{item_id:item,metadata:if id==21{4}else{0},count:(base*multiplier).min(u8::MAX as u32) as u8}]
}
fn generic_drop(id:u16,meta:u8,tool:DropTool,r:&mut JavaRandom,fortune:u32)->Vec<ItemDrop>{
    let single=|item,metadata| vec![ItemDrop{item_id:item,metadata,count:1}];
    match id {
        27|28=>single(66,0), 30=>single(287,0),
        56=>ore_drop(56,fortune,r), 73|74=>{let base=4+r.below(2);let bonus=if fortune>0{r.below(fortune+1)}else{0};vec![ItemDrop{item_id:redstone_dust(),metadata:0,count:(base+bonus).min(8) as u8}]},
        79=>single(79,0), 82=>vec![ItemDrop{item_id:337,metadata:0,count:4}],
        83=>single( reeds(),0),
        // BlockGlowstone: base 2..4, then nextInt(fortune+1), clamp 1..4.
        89=>{let base=2+r.next_int(3);let bonus=r.next_int(fortune+1);vec![ItemDrop{item_id:glowstone_dust(),metadata:0,count:(base+bonus).clamp(1,4) as u8}]},
        95=>vec![], 97=>vec![], 98=>single(98,meta&3), 103=>single( melon_slice(),0).into_iter().map(|mut d|{d.count=1;d}).collect(),
        110=>single( mycelium_or_dirt(),0), 111=>single(111,0), 121=>single(121,0), 129=>ore_drop(129,fortune,r),
        153=>ore_drop(153,fortune,r), 155=>single(155,meta&3), 159=>single(159,meta&15),
        161=>if tool.shears {single(161,(meta&1)+4)}else{leaf_drops(161,meta,fortune,r)},
        162=>single(162,meta&1), 165=>single(165,0), 172=>single(172,0), 173=>single(263,1), 174=>single(174,0),
        175=>single(175,meta), 179=>single(179,meta&3), 180=>single(180,0), 181=>single(181,0),182=>single(182,0),
        _=>vec![],
    }
}


/// BlockSnow (ID 78): harvestBlock bypasses quantityDropped (which is zero)
/// and directly spawns layers + 1 snowballs. Metadata stores layers - 1.
fn snow_layer_drops(meta:u8)->Vec<ItemDrop>{
    vec![ItemDrop{item_id:332,metadata:0,count:((meta&7)+2).min(9)}]
}

/// BlockDoublePlant (ID 175). Metadata bit 3 marks the upper half; the lower
/// half's low three bits are EnumPlantType (sunflower=0, syringa=1, grass=2,
/// fern=3, rose=4, paeonia=5). The upper half never creates an ordinary drop.
/// Shears on a lower grass/fern half use BlockDoublePlant.onHarvest and spawn
/// two tall-grass items, not a double-plant item.
fn double_plant_drops(meta:u8,tool:DropTool,r:&mut JavaRandom)->Vec<ItemDrop>{
    if meta&8!=0 { return Vec::new(); }
    let variant=meta&7;
    if tool.shears && (variant==2 || variant==3) {
        return vec![ItemDrop{item_id:31,metadata:if variant==2{1}else{2},count:2}];
    }
    match variant {
        2 => if r.next_int(8)==0 {vec![ItemDrop{item_id:295,metadata:0,count:1}]} else {Vec::new()},
        3 => Vec::new(),
        0|1|4|5 => vec![ItemDrop{item_id:175,metadata:variant,count:1}],
        _ => Vec::new(),
    }
}

/// BlockMelon: quantityDropped is 3 + nextInt(5), then Fortune adds
/// nextInt(fortune + 1), capped at nine. Both RNG calls are significant.
fn melon_drops(fortune:u32,r:&mut JavaRandom)->Vec<ItemDrop>{
    let base=3+r.next_int(5);
    let bonus=r.next_int(fortune+1);
    vec![ItemDrop{item_id:360,metadata:0,count:(base+bonus).min(9) as u8}]
}
fn clay_ball_item()->u16{337}

/// BlockNetherWart (block ID 115): age occupies the low two metadata bits.
/// Immature wart returns one wart; mature wart returns 2..4 plus the
/// Fortune bonus roll. Item ID 372 is Nether Wart.
fn nether_wart_drops(meta:u8,fortune:u32,r:&mut JavaRandom)->Vec<ItemDrop>{
    let count=if meta&3>=3 {
        2+r.next_int(3)+r.next_int(fortune+1)
    } else { 1 };
    vec![ItemDrop{item_id:372,metadata:0,count:count.min(u8::MAX as u32) as u8}]
}

/// BlockCocoa (block ID 127): age is encoded in metadata bits 2..3.
/// Cocoa beans are dye item 351, damage 3; mature pods yield three.
fn cocoa_drops(meta:u8)->Vec<ItemDrop>{
    let age=(meta>>2)&3;
    vec![ItemDrop{item_id:351,metadata:3,count:if age>=2 {3}else{1}}]
}

/// BlockLeaves.dropBlockAsItemWithChance: sapling roll first, then the
/// subclass apple roll. Metadata low bits identify the leaf variant.
fn leaf_drops(id:u16,meta:u8,fortune:u32,r:&mut JavaRandom)->Vec<ItemDrop>{
    let variant=if id==18 {meta&3} else {(meta&1)+4};
    let base_chance=if id==18 && variant==3 {40u32}else{20u32};
    let sapling_denominator=if fortune>0 {(base_chance.saturating_sub(2u32<<fortune)).max(10)}else{base_chance};
    let mut out=Vec::new();
    if r.next_int(sapling_denominator)==0 {
        out.push(ItemDrop{item_id:6,metadata:variant,count:1});
    }
    // Only oak leaves (old leaves metadata 0) have the apple subclass drop.
    if id==18 && variant==0 {
        let apple_denominator=if fortune>0 {(200u32.saturating_sub(10u32<<fortune)).max(40)}else{200};
        if r.next_int(apple_denominator)==0 {out.push(ItemDrop{item_id:260,metadata:0,count:1});}
    }
    out
}

/// BlockTallGrass: quantity is rolled first; each item roll independently
/// succeeds only when nextInt(8)==0. Fortune changes the number of trials.
fn tall_grass_drops(fortune:u32,r:&mut JavaRandom)->Vec<ItemDrop>{
    let trials=1+r.next_int(fortune*2+1);
    let mut count=0u8;
    for _ in 0..trials { if r.next_int(8)==0 {count=count.saturating_add(1);} }
    if count==0 {Vec::new()} else {vec![ItemDrop{item_id:295,metadata:0,count}]}
}

/// BlockCrops uses the age-7 crop item; mature wheat additionally performs
/// 3+fortune seed trials. Immature crops drop only their seed/crop item.
fn crop_drops(seed_item:u16,crop_item:u16,age:u8,fortune:u32,r:&mut JavaRandom)->Vec<ItemDrop>{
    let mature=age>=7;
    let mut out=vec![ItemDrop{item_id:if mature{crop_item}else{seed_item},metadata:0,count:1}];
    if mature && seed_item!=crop_item {
        let mut seeds=0u8;
        for _ in 0..(3+fortune) {if r.next_int(15)<=age as u32 {seeds=seeds.saturating_add(1);}}
        if seeds>0 {out.push(ItemDrop{item_id:seed_item,metadata:0,count:seeds});}
    }
    out
}
fn potato_drops(age:u8,fortune:u32,r:&mut JavaRandom)->Vec<ItemDrop>{
    let mut out=crop_drops(392,392,age,fortune,r);
    if age>=7 && r.next_int(50)==0 {out.push(ItemDrop{item_id: poison_potato_item(),metadata:0,count:1});}
    out
}
fn poison_potato_item()->u16{394}

fn nether_wart()->u16{ nether_wart_id() } fn nether_wart_id()->u16{372} fn dye_item()->u16{351} fn carrot_item()->u16{ carrot_id() } fn carrot_id()->u16{391} fn potato_item()->u16{392} fn skull_item()->u16{397} fn compare_item()->u16{404} fn rail_item()->u16{27} fn banner_item()->u16{425} fn redstone_dust()->u16{331} fn reeds()->u16{338} fn glowstone_dust()->u16{ glowstone_dust_id() } fn glowstone_dust_id()->u16{348} fn melon_slice()->u16{360} fn mycelium_or_dirt()->u16{3}

#[cfg(test)] mod tests {
 use super::*;
 #[test] fn stone_drops_cobblestone_not_stone(){let(_,d)=resolve_drops(1,0,DropTool::default(),0,false,1);assert_eq!(d,vec![ItemDrop{item_id:4,metadata:0,count:1}]);}
 #[test] fn diamond_ore_drops_diamond(){let(_,d)=resolve_drops(56,0,DropTool{kind:ToolKind::Pickaxe,tier:ToolTier::Iron,shears:false},0,false,1);assert_eq!(d[0].item_id,264);}
 #[test] fn iron_and_gold_ore_drop_the_ore_block_not_ingots(){let(_,iron)=resolve_drops(15,0,DropTool::default(),3,false,1);let(_,gold)=resolve_drops(14,0,DropTool::default(),3,false,1);assert_eq!(iron[0].item_id,15);assert_eq!(gold[0].item_id,14);assert_eq!(iron[0].count,1);assert_eq!(gold[0].count,1);}
 #[test] fn obsidian_drops_obsidian(){let(_,d)=resolve_drops(49,0,DropTool::default(),0,false,1);assert_eq!(d[0].item_id,49);}
 #[test] fn glass_has_no_drop_without_silk_touch(){assert_eq!(resolve_drops(20,0,DropTool::default(),0,false,1).0,DropStatus::NoDrop);}
 #[test] fn unknown_ids_are_not_guessed(){assert_eq!(resolve_drops(250,0,DropTool::default(),0,false,0).0,DropStatus::Unknown);}
 #[test] fn silk_touch_stone_returns_stone(){let(_,d)=resolve_drops(1,0,DropTool::default(),0,true,1);assert_eq!(d[0].item_id,1);}
 #[test] fn air_has_no_drop(){assert_eq!(resolve_drops(0,0,DropTool::default(),0,false,0).0,DropStatus::NoDrop);}
 #[test] fn java_random_matches_java_util_random_seed_zero(){let mut r=JavaRandom::new(0);assert_eq!(r.next_int(100),60);assert!((r.next_float()-0.831441).abs()<0.000001);assert_eq!(r.next_int(100),29);let mut q=JavaRandom::new(0);assert!((q.next_float()-0.73096776).abs()<0.000001);}
 #[test] fn lapis_ore_uses_java_random_and_fortune_multiplier(){let mut r=JavaRandom::new(0);let d=ore_drop(21,0,&mut r);assert!((4..=8).contains(&d[0].count));assert_eq!(d[0].item_id,351);assert_eq!(d[0].metadata,4);}

 #[test] fn gravel_uses_fortune_dependent_flint_chance(){
   let mut found_flint=false; let mut found_gravel=false;
   for seed in 0..128 { let(_,d)=resolve_drops(13,0,DropTool::default(),0,false,seed); if d[0].item_id==318{found_flint=true}else{found_gravel=true;} }
   assert!(found_flint&&found_gravel);
 }
 #[test] fn oak_leaves_have_separate_sapling_and_apple_rolls(){
   let mut saw_sapling=false; let mut saw_apple=false;
   for seed in 0..5000 { let(_,d)=resolve_drops(18,0,DropTool::default(),0,false,seed); saw_sapling|=d.iter().any(|x|x.item_id==6); saw_apple|=d.iter().any(|x|x.item_id==260); }
   assert!(saw_sapling&&saw_apple);
 }
 #[test] fn jungle_leaves_use_forty_base_sapling_chance_and_variant_meta(){
   let mut saw=false; for seed in 0..5000 {let(_,d)=resolve_drops(18,3,DropTool::default(),0,false,seed);if !d.is_empty(){assert_eq!(d[0].item_id,6);assert_eq!(d[0].metadata,3);saw=true;break;}} assert!(saw);
 }
 #[test] fn tall_grass_is_one_in_eight_not_guaranteed(){
   let mut none=false;let mut seed=false;for s in 0..100 {let(_,d)=resolve_drops(31,1,DropTool::default(),0,false,s);none|=d.is_empty();seed|=d.iter().any(|x|x.item_id==295);}assert!(none&&seed);
 }
 #[test] fn shears_harvest_tall_grass_preserving_variant(){let(_,d)=resolve_drops(31,2,DropTool{kind:ToolKind::Shears,tier:ToolTier::None,shears:true},0,false,0);assert_eq!(d,vec![ItemDrop{item_id:31,metadata:2,count:1}]);}
 #[test] fn mature_wheat_drops_wheat_and_extra_seed_rolls(){
   let(_,d)=resolve_drops(59,7,DropTool::default(),0,false,0);assert_eq!(d[0].item_id,296);assert!(d.iter().all(|x|x.item_id==296||x.item_id==295));
 }
 #[test] fn immature_wheat_drops_seeds_not_wheat(){let(_,d)=resolve_drops(59,6,DropTool::default(),0,false,0);assert_eq!(d,vec![ItemDrop{item_id:295,metadata:0,count:1}]);}
 #[test] fn mature_potato_can_add_poisonous_potato(){let mut saw=false;for seed in 0..5000{let(_,d)=resolve_drops(142,7,DropTool::default(),0,false,seed);if d.iter().any(|x|x.item_id==394){saw=true;break;}}assert!(saw);}
 #[test] fn new_leaves_drop_acacia_or_dark_oak_sapling_metadata(){let mut found=[false,false];for meta in 0..=1{for seed in 0..5000{let(_,d)=resolve_drops(161,meta,DropTool::default(),0,false,seed);if let Some(x)=d.first(){assert_eq!(x.item_id,6);assert_eq!(x.metadata,meta+4);found[meta as usize]=true;break;}}}assert!(found.into_iter().all(|x|x));}
 #[test] fn shears_preserve_new_leaf_item_variant_metadata(){for meta in 0..=1{let(_,d)=resolve_drops(161,meta,DropTool{kind:ToolKind::Shears,tier:ToolTier::None,shears:true},0,false,0);assert_eq!(d[0].metadata,meta+4);}}
 #[test] fn silk_touch_old_and_new_leaves_returns_leaf_block_item(){for (id,meta,expected) in [(18,3,3),(161,1,1)]{let(_,d)=resolve_drops(id,meta,DropTool::default(),0,true,0);assert_eq!(d,vec![ItemDrop{item_id:id,metadata:expected,count:1}]);}}
 #[test] fn glowstone_fortune_is_clamped_to_four_and_uses_two_rng_calls(){
   let mut r=JavaRandom::new(4);let expected=(2+r.next_int(3)+r.next_int(4)).clamp(1,4) as u8;
   let(_,d)=resolve_drops(89,0,DropTool::default(),3,false,4);assert_eq!(d[0].count,expected);
 }
 #[test] fn dead_bush_does_not_drop_itself_without_shears(){
   assert_eq!(resolve_drops(32,0,DropTool::default(),0,false,0),(DropStatus::NoDrop,vec![]));
   let shears=DropTool{kind:ToolKind::Shears,tier:ToolTier::None,shears:true};
   assert_eq!(resolve_drops(32,0,shears,0,false,0),(DropStatus::Known,vec![ItemDrop{item_id:32,metadata:0,count:1}]));
 }
 #[test] fn unsupported_legacy_block_is_not_guessed_as_itself(){assert_eq!(resolve_drops(54,0,DropTool::default(),0,false,0).0,DropStatus::Unknown);}
 #[test] fn redstone_fortune_uses_two_vanilla_random_rolls(){let mut r=JavaRandom::new(0);let base=4+r.next_int(2);let bonus=r.next_int(4);assert!((4..=8).contains(&(base+bonus)));}

 #[test] fn immature_nether_wart_drops_one_wart(){let(_,d)=resolve_drops(115,2,DropTool::default(),3,false,0);assert_eq!(d,vec![ItemDrop{item_id:372,metadata:0,count:1}]);}
 #[test] fn mature_nether_wart_drops_wart_with_fortune_range(){for fortune in 0u8..=3{for seed in 0..100{let(_,d)=resolve_drops(115,3,DropTool::default(),fortune,false,seed);assert_eq!(d[0].item_id,372);assert!((2u8..=(4u8+fortune)).contains(&d[0].count));}}}
 #[test] fn cocoa_age_selects_one_or_three_beans(){for (meta,count) in [(0,1),(4,1),(8,3),(12,3)]{let(_,d)=resolve_drops(127,meta,DropTool::default(),3,false,0);assert_eq!(d,vec![ItemDrop{item_id:351,metadata:3,count}]);}}

 #[test] fn snow_layer_harvest_uses_layers_plus_one(){
   for meta in 0..8 {let(_,d)=resolve_drops(78,meta,DropTool::default(),0,false,0);assert_eq!(d,vec![ItemDrop{item_id:332,metadata:0,count:meta+2}]);}
 }
 #[test] fn snow_block_drops_four_snowballs(){let(_,d)=resolve_drops(80,0,DropTool::default(),3,false,0);assert_eq!(d,vec![ItemDrop{item_id:332,metadata:0,count:4}]);}
 #[test] fn double_plant_upper_half_never_drops(){for variant in 0..6{let(_,d)=resolve_drops(175,variant|8,DropTool::default(),0,false,0);assert!(d.is_empty());}}
 #[test] fn double_plant_grass_and_fern_follow_distinct_drop_rules(){
   assert!(resolve_drops(175,3,DropTool::default(),0,false,0).1.is_empty());
   // Java Random's first nextInt(8) is correlated for small adjacent seeds;
   // sample a broad deterministic range instead of assuming 100 tiny seeds
   // include the successful branch.
   let mut saw_seed=false;for seed in 0..5000{let(_,d)=resolve_drops(175,2,DropTool::default(),0,false,seed);saw_seed|=d.iter().any(|x|x.item_id==295);}assert!(saw_seed);
 }
 #[test] fn double_plant_shears_convert_grass_and_fern_to_two_tall_grass(){
   let shears=DropTool{kind:ToolKind::Shears,tier:ToolTier::None,shears:true};
   for (variant,meta) in [(2,1),(3,2)]{let(_,d)=resolve_drops(175,variant,shears,0,false,0);assert_eq!(d,vec![ItemDrop{item_id:31,metadata:meta,count:2}]);}
 }
 #[test] fn double_plant_flower_variants_drop_their_own_metadata(){for variant in [0,1,4,5]{let(_,d)=resolve_drops(175,variant,DropTool::default(),0,false,0);assert_eq!(d,vec![ItemDrop{item_id:175,metadata:variant,count:1}]);}}
 #[test] fn melon_quantity_and_fortune_follow_mcp_call_order(){
   for fortune in 0u8..=3{for seed in 0..100{let mut r=JavaRandom::new(seed);let expected=(3+r.next_int(5)+r.next_int(u32::from(fortune)+1)).min(9) as u8;let(_,d)=resolve_drops(103,0,DropTool::default(),fortune,false,seed);assert_eq!(d[0].count,expected);}}
 }
 #[test] fn cobweb_silk_touch_returns_the_web_block(){let(_,d)=resolve_drops(30,0,DropTool::default(),0,true,0);assert_eq!(d,vec![ItemDrop{item_id:30,metadata:0,count:1}]);}
 #[test] fn vine_requires_shears_and_then_drops_one_vine(){
   assert_eq!(resolve_drops(106,0,DropTool::default(),0,false,0),(DropStatus::Known,vec![]));
   let shears=DropTool{kind:ToolKind::Shears,tier:ToolTier::None,shears:true};
   assert_eq!(resolve_drops(106,0,shears,0,false,0).1,vec![ItemDrop{item_id:106,metadata:0,count:1}]);
 }
 #[test] fn clay_block_drops_four_clay_balls(){let(_,d)=resolve_drops(82,0,DropTool::default(),0,false,0);assert_eq!(d,vec![ItemDrop{item_id:337,metadata:0,count:4}]);}
 #[test] fn cobweb_drops_string_without_silk_touch(){let(_,d)=resolve_drops(30,0,DropTool::default(),0,false,0);assert_eq!(d,vec![ItemDrop{item_id:287,metadata:0,count:1}]);}

}
