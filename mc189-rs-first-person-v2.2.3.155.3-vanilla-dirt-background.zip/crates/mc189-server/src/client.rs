use std::io::{BufRead,BufReader,Write};use std::net::{Shutdown,TcpStream};use std::sync::mpsc::{self,Receiver,Sender,TryRecvError};use std::thread;use mc189_core::{Mc189Error,Result};use crate::protocol::{ClientPacket,PlayerInputWire,ServerPacket};use crate::PROTOCOL_VERSION;
/// Network adapter for the native renderer. It deliberately has no window/GPU dependency.
pub struct NetworkClient{outbound:Sender<ClientPacket>,inbound:Receiver<ServerPacket>,shutdown_stream:TcpStream}
impl NetworkClient{
 pub fn connect(address:&str,username:&str)->Result<Self>{let stream=TcpStream::connect(address).map_err(|e|Mc189Error::InvalidData(format!("cannot connect to {address}: {e}")))?;stream.set_nodelay(true)?;let mut writer=stream.try_clone()?;let shutdown_stream=stream.try_clone()?;let reader=BufReader::new(stream);let(tx,rx)=mpsc::channel::<ClientPacket>();let(itx,irx)=mpsc::channel::<ServerPacket>();write_packet(&mut writer,&ClientPacket::Hello{protocol:PROTOCOL_VERSION,username:username.chars().take(16).collect()})?;
  thread::Builder::new().name("mc189-client-net-write".into()).spawn(move||{let mut w=writer;while let Ok(p)=rx.recv(){if write_packet(&mut w,&p).is_err(){break;}}}).map_err(|e|Mc189Error::InvalidData(format!("cannot start client writer: {e}")))?;
  thread::Builder::new().name("mc189-client-net-read".into()).spawn(move||{let mut r=reader;loop{let mut line=String::new();match r.read_line(&mut line){Ok(0)=>break,Ok(_)=>{if line.len()>16*1024{break;}if let Ok(p)=serde_json::from_str::<ServerPacket>(&line){if itx.send(p).is_err(){break;}}},Err(_)=>break}}}).map_err(|e|Mc189Error::InvalidData(format!("cannot start client reader: {e}")))?;Ok(Self{outbound:tx,inbound:irx,shutdown_stream})}
 pub fn send_input(&self,sequence:u64,input:PlayerInputWire,yaw:f32,pitch:f32)->Result<()>{self.outbound.send(ClientPacket::Input{sequence,input,yaw,pitch}).map_err(|_|Mc189Error::InvalidData("server connection is closed".into()))}
 pub fn ping(&self,nonce:u64)->Result<()>{self.outbound.send(ClientPacket::Ping{nonce}).map_err(|_|Mc189Error::InvalidData("server connection is closed".into()))}
 pub fn try_recv(&self)->std::result::Result<ServerPacket,TryRecvError>{self.inbound.try_recv()}
}
fn write_packet(w:&mut impl Write,p:&ClientPacket)->Result<()>{let mut b=serde_json::to_vec(p).map_err(|e|Mc189Error::InvalidData(format!("cannot encode packet: {e}")))?;b.push(b'\n');w.write_all(&b)?;w.flush()?;Ok(())}

impl Drop for NetworkClient { fn drop(&mut self) { let _ = self.shutdown_stream.shutdown(Shutdown::Both); } }
