//! Deterministic seed primitives used by the Minecraft Java 1.8.9 world generator.
//!
//! This module intentionally ports the two distinct random streams used by
//! vanilla: `java.util.Random` and the custom `GenLayer` LCG. They are not
//! interchangeable.

/// Resolve the text entered in the vanilla world seed field.
///
/// Minecraft 1.8.9 first attempts Java `Long.parseLong`; if that fails, it uses
/// `String.hashCode()` (UTF-16 code units, signed 32-bit) widened to i64.
pub fn parse_vanilla_seed(input: &str) -> i64 {
    if let Ok(value) = input.parse::<i64>() {
        return value;
    }

    let mut hash = 0_i32;
    for unit in input.encode_utf16() {
        hash = hash.wrapping_mul(31).wrapping_add(i32::from(unit));
    }
    i64::from(hash)
}

/// The 48-bit linear-congruential generator used by `java.util.Random`.
#[derive(Debug, Clone)]
pub struct JavaRandom {
    seed: u64,
}

impl JavaRandom {
    const MULTIPLIER: u64 = 0x5DEECE66D;
    const ADDEND: u64 = 0xB;
    const MASK: u64 = (1_u64 << 48) - 1;

    pub fn new(seed: i64) -> Self {
        Self { seed: ((seed as u64) ^ Self::MULTIPLIER) & Self::MASK }
    }

    fn next_bits(&mut self, bits: u32) -> u32 {
        self.seed = self.seed.wrapping_mul(Self::MULTIPLIER).wrapping_add(Self::ADDEND) & Self::MASK;
        (self.seed >> (48 - bits)) as u32
    }

    pub fn next_int(&mut self, bound: u32) -> Option<u32> {
        if bound == 0 || bound > i32::MAX as u32 { return None; }
        if bound.is_power_of_two() {
            return Some(((u64::from(bound) * u64::from(self.next_bits(31))) >> 31) as u32);
        }
        loop {
            let bits = self.next_bits(31);
            let value = bits % bound;
            // java.util.Random rejects signed-int overflow in bits - value + (bound - 1).
            if (bits as i32).wrapping_sub(value as i32).wrapping_add((bound - 1) as i32) >= 0 {
                return Some(value);
            }
        }
    }

    pub fn next_long(&mut self) -> i64 {
        let high = i64::from(self.next_bits(32) as i32);
        let low = i64::from(self.next_bits(32) as i32);
        (high << 32).wrapping_add(low)
    }

    /// Matches java.util.Random.nextBoolean() and consumes exactly one bit.
    pub fn next_boolean(&mut self) -> bool { self.next_bits(1) != 0 }

    pub fn next_float(&mut self) -> f32 { self.next_bits(24) as f32 / (1_u32 << 24) as f32 }
    pub fn next_double(&mut self) -> f64 {
        let high = u64::from(self.next_bits(26));
        let low = u64::from(self.next_bits(27));
        ((high << 27) + low) as f64 / (1_u64 << 53) as f64
    }
}

/// Exact random stream used inside vanilla `GenLayer` biome generation.
#[derive(Debug, Clone)]
pub struct GenLayerRandom {
    base_seed: i64,
    world_gen_seed: i64,
    chunk_seed: i64,
}

impl GenLayerRandom {
    const MULTIPLIER: i64 = 6364136223846793005;
    const ADDEND: i64 = 1442695040888963407;

    pub fn new(base_seed: i64) -> Self {
        let mut layer = Self { base_seed: 0, world_gen_seed: 0, chunk_seed: 0 };
        let mut value = base_seed;
        for _ in 0..3 {
            value = value.wrapping_mul(value.wrapping_mul(Self::MULTIPLIER).wrapping_add(Self::ADDEND)).wrapping_add(base_seed);
        }
        layer.base_seed = value;
        layer
    }

    pub fn init_world_gen_seed(&mut self, seed: i64) {
        self.world_gen_seed = seed;
        for _ in 0..3 {
            self.world_gen_seed = self.world_gen_seed
                .wrapping_mul(self.world_gen_seed.wrapping_mul(Self::MULTIPLIER).wrapping_add(Self::ADDEND))
                .wrapping_add(self.base_seed);
        }
    }

    pub fn init_chunk_seed(&mut self, x: i64, z: i64) {
        self.chunk_seed = self.world_gen_seed;
        self.chunk_seed = self.chunk_seed.wrapping_mul(self.chunk_seed.wrapping_mul(Self::MULTIPLIER).wrapping_add(Self::ADDEND)).wrapping_add(x);
        self.chunk_seed = self.chunk_seed.wrapping_mul(self.chunk_seed.wrapping_mul(Self::MULTIPLIER).wrapping_add(Self::ADDEND)).wrapping_add(z);
        self.chunk_seed = self.chunk_seed.wrapping_mul(self.chunk_seed.wrapping_mul(Self::MULTIPLIER).wrapping_add(Self::ADDEND)).wrapping_add(x);
        self.chunk_seed = self.chunk_seed.wrapping_mul(self.chunk_seed.wrapping_mul(Self::MULTIPLIER).wrapping_add(Self::ADDEND)).wrapping_add(z);
    }

    pub fn next_int(&mut self, bound: i32) -> i32 {
        assert!(bound > 0, "GenLayer nextInt bound must be positive");
        let value = ((self.chunk_seed >> 24) % i64::from(bound)) as i32;
        let result = if value < 0 { value + bound } else { value };
        self.chunk_seed = self.chunk_seed.wrapping_mul(self.chunk_seed.wrapping_mul(Self::MULTIPLIER).wrapping_add(Self::ADDEND)).wrapping_add(self.world_gen_seed);
        result
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vanilla_seed_text_uses_long_then_java_string_hash() {
        assert_eq!(parse_vanilla_seed("123456789"), 123456789);
        assert_eq!(parse_vanilla_seed(""), 0);
        assert_eq!(parse_vanilla_seed("Hello world"), -832992604);
        assert_eq!(parse_vanilla_seed(" 123 "), 31062094);
        assert_eq!(parse_vanilla_seed("😀"), 1772899);
        assert_eq!(parse_vanilla_seed("-9223372036854775808"), i64::MIN);
    }

    #[test]
    fn java_random_matches_jdk_sequence_for_seed_zero() {
        let mut rng = JavaRandom::new(0);
        let values: Vec<u32> = (0..5).map(|_| rng.next_int(100).unwrap()).collect();
        assert_eq!(values, [60, 48, 29, 47, 15]);
    }

    #[test]
    fn java_random_power_of_two_bound_matches_jdk() {
        let mut rng = JavaRandom::new(0);
        assert_eq!(rng.next_int(16), Some(11));
    }

    #[test]
    fn genlayer_stream_is_repeatable_and_coordinate_sensitive() {
        let mut a = GenLayerRandom::new(200);
        let mut b = GenLayerRandom::new(200);
        a.init_world_gen_seed(123456789);
        b.init_world_gen_seed(123456789);
        a.init_chunk_seed(-12, 34);
        b.init_chunk_seed(-12, 34);
        let seq_a: Vec<i32> = (0..8).map(|_| a.next_int(1000)).collect();
        let seq_b: Vec<i32> = (0..8).map(|_| b.next_int(1000)).collect();
        assert_eq!(seq_a, seq_b);
        let mut c = GenLayerRandom::new(200);
        c.init_world_gen_seed(123456789);
        c.init_chunk_seed(-11, 34);
        assert_ne!(seq_a[0], c.next_int(1000));
    }
}

/// Biome identifiers used by the Java 1.8.9 overworld generator.
pub mod biome_id {
    pub const OCEAN: i32 = 0;
    pub const PLAINS: i32 = 1;
    pub const DESERT: i32 = 2;
    pub const EXTREME_HILLS: i32 = 3;
    pub const FOREST: i32 = 4;
    pub const TAIGA: i32 = 5;
    pub const SWAMPLAND: i32 = 6;
    pub const RIVER: i32 = 7;
    pub const HELL: i32 = 8;
    pub const SKY: i32 = 9;
    pub const FROZEN_OCEAN: i32 = 10;
    pub const FROZEN_RIVER: i32 = 11;
    pub const ICE_PLAINS: i32 = 12;
    pub const ICE_MOUNTAINS: i32 = 13;
    pub const MUSHROOM_ISLAND: i32 = 14;
    pub const MUSHROOM_ISLAND_SHORE: i32 = 15;
    pub const BEACH: i32 = 16;
    pub const DESERT_HILLS: i32 = 17;
    pub const FOREST_HILLS: i32 = 18;
    pub const TAIGA_HILLS: i32 = 19;
    pub const SMALL_MOUNTAINS: i32 = 20;
    pub const JUNGLE: i32 = 21;
    pub const JUNGLE_HILLS: i32 = 22;
    pub const JUNGLE_EDGE: i32 = 23;
    pub const DEEP_OCEAN: i32 = 24;
    pub const STONE_BEACH: i32 = 25;
    pub const COLD_BEACH: i32 = 26;
    pub const BIRCH_FOREST: i32 = 27;
    pub const BIRCH_FOREST_HILLS: i32 = 28;
    pub const ROOFED_FOREST: i32 = 29;
    pub const COLD_TAIGA: i32 = 30;
    pub const COLD_TAIGA_HILLS: i32 = 31;
    pub const MEGA_TAIGA: i32 = 32;
    pub const MEGA_TAIGA_HILLS: i32 = 33;
    pub const MEGA_SPRUCE_TAIGA_MUTATED: i32 = 160;
    pub const EXTREME_HILLS_PLUS: i32 = 34;
    pub const SAVANNA: i32 = 35;
    pub const SAVANNA_PLATEAU: i32 = 36;
    pub const MESA: i32 = 37;
    pub const MESA_PLATEAU_F: i32 = 38;
    pub const MESA_PLATEAU: i32 = 39;
}

/// Climate properties needed by the 1.8.9 snow, ice and precipitation passes.
/// Temperatures and rainfall are the base values configured by BiomeGenBase.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct BiomeClimate {
    pub temperature: f32,
    pub rainfall: f32,
    pub has_precipitation: bool,
}

impl BiomeClimate {
    /// Vanilla's BiomeGenBase.getFloatTemperature adjustment above y=64.
    #[inline]
    pub fn temperature_at(self, y: i32) -> f32 {
        if y > 64 { self.temperature - (y - 64) as f32 * 0.001_666_67 } else { self.temperature }
    }

    /// The threshold used by vanilla's snow/ice checks (`< 0.15F`).
    #[inline]
    pub fn can_freeze_at(self, y: i32) -> bool {
        self.has_precipitation && self.temperature_at(y) < 0.15
    }

    #[inline]
    pub fn can_snow_at(self, y: i32) -> bool { self.can_freeze_at(y) }
}

/// Base climate table for the registered 1.8.9 overworld biomes.
pub fn biome_climate(id: i32) -> Option<BiomeClimate> {
    use biome_id::*;
    let (temperature, rainfall, has_precipitation) = match id {
        OCEAN | DEEP_OCEAN => (0.5, 0.5, true),
        PLAINS => (0.8, 0.4, true),
        DESERT | DESERT_HILLS => (2.0, 0.0, false),
        EXTREME_HILLS | EXTREME_HILLS_PLUS | SMALL_MOUNTAINS => (0.2, 0.3, true),
        FOREST | FOREST_HILLS | BIRCH_FOREST | BIRCH_FOREST_HILLS | ROOFED_FOREST => (0.7, 0.8, true),
        TAIGA | TAIGA_HILLS => (0.25, 0.8, true),
        SWAMPLAND => (0.8, 0.9, true),
        RIVER => (0.5, 0.5, true),
        FROZEN_OCEAN | FROZEN_RIVER | ICE_PLAINS | ICE_MOUNTAINS => (0.0, 0.5, true),
        MUSHROOM_ISLAND | MUSHROOM_ISLAND_SHORE => (0.9, 1.0, true),
        BEACH => (0.8, 0.4, true),
        JUNGLE | JUNGLE_HILLS | JUNGLE_EDGE => (0.95, 0.9, true),
        STONE_BEACH => (0.2, 0.3, true),
        COLD_BEACH => (0.05, 0.3, true),
        COLD_TAIGA | COLD_TAIGA_HILLS => (-0.5, 0.4, true),
        MEGA_TAIGA | MEGA_TAIGA_HILLS => (0.3, 0.8, true),
        SAVANNA | SAVANNA_PLATEAU => (1.2, 0.0, false),
        MESA | MESA_PLATEAU_F | MESA_PLATEAU => (2.0, 0.0, false),
        _ => return None,
    };
    Some(BiomeClimate { temperature, rainfall, has_precipitation })
}

/// A deterministic biome raster. Coordinates are block coordinates; `get` is
/// safe for negative world positions and returns `None` outside this raster.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BiomeMap {
    pub origin_x: i32,
    pub origin_z: i32,
    pub width: usize,
    pub height: usize,
    pub ids: Vec<i32>,
}

impl BiomeMap {
    pub fn get(&self, x: i32, z: i32) -> Option<i32> {
        let lx = x.checked_sub(self.origin_x)?;
        let lz = z.checked_sub(self.origin_z)?;
        if lx < 0 || lz < 0 || lx as usize >= self.width || lz as usize >= self.height { return None; }
        self.ids.get(lz as usize * self.width + lx as usize).copied()
    }
}

#[derive(Clone)]
struct LayerGrid { x: i32, z: i32, w: usize, h: usize, data: Vec<i32> }
impl LayerGrid {
    fn at(&self, x: i32, z: i32) -> i32 {
        let ix = (x - self.x) as usize; let iz = (z - self.z) as usize;
        self.data[iz * self.w + ix]
    }
}

fn layer_random(base: i64, world: i64, x: i64, z: i64, bound: i32) -> i32 {
    let mut r = GenLayerRandom::new(base); r.init_world_gen_seed(world); r.init_chunk_seed(x, z); r.next_int(bound)
}
fn choose2(a: i32, b: i32, r: i32) -> i32 { if r == 0 { a } else { b } }
fn mode_or_random(a: i32, b: i32, c: i32, d: i32, r: i32) -> i32 {
    if b == c && c == d { b } else if a == b && a == c { a } else if a == b && a == d { a }
    else if a == c && a == d { a } else if a == b && c != d { a } else if a == c && b != d { a }
    else if a == d && b != c { a } else if b == c && a != d { b } else if b == d && a != c { b }
    else if c == d && a != b { c } else { [a,b,c,d][r as usize] }
}
fn zoom_grid(parent: &LayerGrid, base: i64, world: i64, fuzzy: bool) -> LayerGrid {
    let nx = parent.x * 2; let nz = parent.z * 2; let nw = parent.w * 2 - 1; let nh = parent.h * 2 - 1;
    let mut out = vec![0; nw * nh];
    for z in 0..parent.h - 1 { for x in 0..parent.w - 1 {
        let px = parent.x + x as i32; let pz = parent.z + z as i32;
        let a=parent.at(px,pz); let b=parent.at(px+1,pz); let c=parent.at(px,pz+1); let d=parent.at(px+1,pz+1);
        let ox=x*2; let oz=z*2; out[oz*nw+ox]=a;
        let r=layer_random(base,world,i64::from(px*2),i64::from(pz*2),2);
        out[oz*nw+ox+1]=if fuzzy {choose2(a,b,r)} else {a};
        out[(oz+1)*nw+ox]=if fuzzy {choose2(a,c,layer_random(base,world,i64::from(px*2),i64::from(pz*2+1),2))} else {a};
        let rr=layer_random(base,world,i64::from(px*2+1),i64::from(pz*2+1),4);
        out[(oz+1)*nw+ox+1]=if fuzzy { [a,b,c,d][rr as usize] } else { mode_or_random(a,b,c,d,rr) };
    }}
    LayerGrid{x:nx,z:nz,w:nw,h:nh,data:out}
}

/// Generate the overworld biome climate/zoom pipeline from a vanilla seed.
/// This is the first biome-generation milestone: it reproduces the Java seed
/// streams and deterministic island/zoom/climate selection. The later 1.8.9
/// hills, shore, river-mix and Voronoi stages are deliberately separate work.
pub fn generate_biome_map(seed: i64, origin_x: i32, origin_z: i32, width: usize, height: usize) -> BiomeMap {
    use self::biome_id as b;
    assert!(width > 0 && height > 0 && width <= 4096 && height <= 4096);
    // Nine zoom levels expand the initial 1/512-resolution island raster to blocks.
    let min_x = origin_x.div_euclid(512) - 8; let min_z = origin_z.div_euclid(512) - 8;
    let cells_x = (width as i32 + 511).div_euclid(512) + 18;
    let cells_z = (height as i32 + 511).div_euclid(512) + 18;
    let mut grid = LayerGrid{x:min_x,z:min_z,w:cells_x as usize,h:cells_z as usize,data:vec![0;(cells_x*cells_z) as usize]};
    for z in 0..grid.h { for x in 0..grid.w {
        let wx=grid.x+x as i32; let wz=grid.z+z as i32;
        grid.data[z*grid.w+x]=if layer_random(1,seed,i64::from(wx),i64::from(wz),10)==0 {1} else {b::OCEAN};
    }}
    // Vanilla's early island expansion and zoom stages (before biome assignment).
    grid=zoom_grid(&grid,2000,seed,true);
    for (base,passes) in [(1_i64,1_usize),(2001,1),(2,1),(50,1),(70,1)] {
        for _ in 0..passes {
            let mut next=grid.clone();
            for z in 1..grid.h-1 { for x in 1..grid.w-1 {
                let idx=z*grid.w+x; let v=grid.data[idx];
                let wx=grid.x+x as i32; let wz=grid.z+z as i32;
                let north=grid.data[idx-grid.w]; let south=grid.data[idx+grid.w]; let west=grid.data[idx-1]; let east=grid.data[idx+1];
                if v==b::OCEAN && [north,south,west,east].iter().any(|&q| q!=b::OCEAN) && layer_random(base,seed,i64::from(wx),i64::from(wz),3)==0 { next.data[idx]=1; }
                else if v!=b::OCEAN && [north,south,west,east].iter().any(|&q| q==b::OCEAN) && layer_random(base,seed,i64::from(wx),i64::from(wz),5)==0 { next.data[idx]=b::OCEAN; }
            }} grid=next;
        }
    }
    // Four zooms bring the climate raster to the biome-selection scale.
    for base in [2001_i64, 2002, 2003, 2004] { grid=zoom_grid(&grid,base,seed,false); }
    // Assign the vanilla 1.8.9 climate biome pools at the current scale.
    let mut biomes=grid.clone();
    for z in 0..grid.h { for x in 0..grid.w {
        let idx=z*grid.w+x; let v=grid.data[idx]; if v==b::OCEAN { biomes.data[idx]=b::OCEAN; continue; }
        let wx=grid.x+x as i32; let wz=grid.z+z as i32;
        let climate=layer_random(200,seed,i64::from(wx),i64::from(wz),6);
        biomes.data[idx]=match climate { 0=>[b::DESERT,b::DESERT,b::DESERT,b::SAVANNA,b::SAVANNA,b::PLAINS][layer_random(200,seed,i64::from(wx)+1,i64::from(wz),6) as usize], 1=>[b::FOREST,b::ROOFED_FOREST,b::EXTREME_HILLS,b::PLAINS,b::BIRCH_FOREST,b::SWAMPLAND][layer_random(201,seed,i64::from(wx),i64::from(wz),6) as usize], 2=>[b::FOREST,b::EXTREME_HILLS,b::TAIGA,b::PLAINS][layer_random(202,seed,i64::from(wx),i64::from(wz),4) as usize], _=>[b::ICE_PLAINS,b::ICE_PLAINS,b::ICE_PLAINS,b::COLD_TAIGA][layer_random(203,seed,i64::from(wx),i64::from(wz),4) as usize] };
    }}
    // Zoom to block resolution and crop exactly the requested rectangle.
    let mut final_grid=biomes;
    for i in 0..4 { final_grid=zoom_grid(&final_grid,1000+i,seed,false); }
    let mut ids=Vec::with_capacity(width*height);
    for z in 0..height { for x in 0..width {
        let bx=origin_x+x as i32; let bz=origin_z+z as i32;
        let gx=bx; let gz=bz;
        let lx=(gx-final_grid.x) as usize; let lz=(gz-final_grid.z) as usize;
        ids.push(final_grid.data[lz*final_grid.w+lx]);
    }}
    BiomeMap{origin_x,origin_z,width,height,ids}
}

/// Vanilla 1.8.9 improved gradient-noise generator (`NoiseGeneratorImproved`).
/// The permutation table and floating-point evaluation order follow MCP 1.8.9.
#[derive(Debug, Clone)]
pub struct ImprovedNoise {
    permutations: [usize; 512],
    x_coord: f64,
    y_coord: f64,
    z_coord: f64,
}

impl ImprovedNoise {
    pub fn new(random: &mut JavaRandom) -> Self {
        let mut permutations = [0usize; 512];
        let x_coord = random.next_double() * 256.0;
        let y_coord = random.next_double() * 256.0;
        let z_coord = random.next_double() * 256.0;
        for (i, p) in permutations.iter_mut().take(256).enumerate() { *p = i; }
        for i in 0..256 {
            let j = i + random.next_int((256 - i) as u32).expect("positive vanilla shuffle bound") as usize;
            permutations.swap(i, j);
            permutations[i + 256] = permutations[i];
        }
        Self { permutations, x_coord, y_coord, z_coord }
    }

    #[inline] fn fade(t: f64) -> f64 { t * t * t * (t * (t * 6.0 - 15.0) + 10.0) }
    #[inline] fn lerp(t: f64, a: f64, b: f64) -> f64 { a + t * (b - a) }
    #[inline] fn grad(hash: usize, x: f64, y: f64, z: f64) -> f64 {
        let h = hash & 15;
        let u = if h < 8 { x } else { y };
        let v = if h < 4 { y } else if h == 12 || h == 14 { x } else { z };
        (if h & 1 == 0 { u } else { -u }) + (if h & 2 == 0 { v } else { -v })
    }
    #[inline] fn grad_xz(hash: usize, x: f64, z: f64) -> f64 {
        const GX: [f64; 16] = [1.0,-1.0,1.0,-1.0,1.0,-1.0,1.0,-1.0,0.0,0.0,0.0,0.0,1.0,0.0,-1.0,0.0];
        const GZ: [f64; 16] = [0.0,0.0,0.0,0.0,1.0,1.0,-1.0,-1.0,1.0,1.0,-1.0,-1.0,0.0,1.0,0.0,-1.0];
        let h = hash & 15;
        GX[h] * x + GZ[h] * z
    }

    /// Adds vanilla improved noise into `output`; indexing is x-major, then z, then y.
    pub fn add_noise(&self, output: &mut [f64], x_offset: f64, y_offset: f64, z_offset: f64,
        x_size: usize, y_size: usize, z_size: usize, x_scale: f64, y_scale: f64,
        z_scale: f64, noise_scale: f64) {
        assert_eq!(output.len(), x_size * y_size * z_size);
        let inverse = 1.0 / noise_scale;
        let mut index = 0usize;
        for x_i in 0..x_size {
            let mut x = x_offset + x_i as f64 * x_scale + self.x_coord;
            let mut xi = x as i32;
            if x < xi as f64 { xi -= 1; }
            let x_hash = (xi & 255) as usize;
            x -= xi as f64;
            let xf = Self::fade(x);
            for z_i in 0..z_size {
                let mut z = z_offset + z_i as f64 * z_scale + self.z_coord;
                let mut zi = z as i32;
                if z < zi as f64 { zi -= 1; }
                let z_hash = (zi & 255) as usize;
                z -= zi as f64;
                let zf = Self::fade(z);
                let aa = self.permutations[self.permutations[x_hash] + z_hash];
                let ba = self.permutations[self.permutations[x_hash + 1] + z_hash];
                let ab = self.permutations[self.permutations[x_hash] + z_hash + 1];
                let bb = self.permutations[self.permutations[x_hash + 1] + z_hash + 1];
                if y_size == 1 {
                    let n0 = Self::lerp(xf, Self::grad_xz(aa, x, z), Self::grad_xz(ba, x - 1.0, z));
                    let n1 = Self::lerp(xf, Self::grad_xz(ab, x, z - 1.0), Self::grad_xz(bb, x - 1.0, z - 1.0));
                    output[index] += Self::lerp(zf, n0, n1) * inverse;
                    index += 1;
                } else {
                    for y_i in 0..y_size {
                        let mut y = y_offset + y_i as f64 * y_scale + self.y_coord;
                        let mut yi = y as i32;
                        if y < yi as f64 { yi -= 1; }
                        let y_hash = (yi & 255) as usize;
                        y -= yi as f64;
                        let yf = Self::fade(y);
                        let aaa = self.permutations[aa + y_hash];
                        let aba = self.permutations[ab + y_hash];
                        let baa = self.permutations[ba + y_hash];
                        let bba = self.permutations[bb + y_hash];
                        let aab = self.permutations[aa + y_hash + 1];
                        let abb = self.permutations[ab + y_hash + 1];
                        let bab = self.permutations[ba + y_hash + 1];
                        let bbb = self.permutations[bb + y_hash + 1];
                        let x00 = Self::lerp(xf, Self::grad(aaa, x, y, z), Self::grad(baa, x - 1.0, y, z));
                        let x10 = Self::lerp(xf, Self::grad(aba, x, y - 1.0, z), Self::grad(bba, x - 1.0, y - 1.0, z));
                        let x01 = Self::lerp(xf, Self::grad(aab, x, y, z - 1.0), Self::grad(bab, x - 1.0, y, z - 1.0));
                        let x11 = Self::lerp(xf, Self::grad(abb, x, y - 1.0, z - 1.0), Self::grad(bbb, x - 1.0, y - 1.0, z - 1.0));
                        let z0 = Self::lerp(yf, x00, x10);
                        let z1 = Self::lerp(yf, x01, x11);
                        output[index] += Self::lerp(zf, z0, z1) * inverse;
                        index += 1;
                    }
                }
            }
        }
    }
}

/// Multi-octave wrapper matching `NoiseGeneratorOctaves` in Java 1.8.9.
#[derive(Debug, Clone)]
pub struct OctaveNoise { generators: Vec<ImprovedNoise> }

impl OctaveNoise {
    pub fn new(random: &mut JavaRandom, octaves: usize) -> Self {
        let generators = (0..octaves).map(|_| ImprovedNoise::new(random)).collect();
        Self { generators }
    }

    pub fn generate(&self, x_offset: i32, y_offset: i32, z_offset: i32,
        x_size: usize, y_size: usize, z_size: usize,
        x_scale: f64, y_scale: f64, z_scale: f64) -> Vec<f64> {
        let mut output = vec![0.0; x_size * y_size * z_size];
        let mut octave_scale = 1.0;
        for generator in &self.generators {
            let mut x = x_offset as f64 * octave_scale * x_scale;
            let y = y_offset as f64 * octave_scale * y_scale;
            let mut z = z_offset as f64 * octave_scale * z_scale;
            let floor_x = x.floor() as i64;
            let floor_z = z.floor() as i64;
            x -= floor_x as f64;
            z -= floor_z as f64;
            let wrapped_x = floor_x % 16_777_216;
            let wrapped_z = floor_z % 16_777_216;
            x += wrapped_x as f64;
            z += wrapped_z as f64;
            generator.add_noise(&mut output, x, y, z, x_size, y_size, z_size,
                x_scale * octave_scale, y_scale * octave_scale, z_scale * octave_scale, octave_scale);
            octave_scale /= 2.0;
        }
        output
    }

    pub fn generate_xz(&self, x_offset: i32, z_offset: i32, x_size: usize, z_size: usize,
        x_scale: f64, z_scale: f64) -> Vec<f64> {
        self.generate(x_offset, 10, z_offset, x_size, 1, z_size, x_scale, 1.0, z_scale)
    }
}

/// Vanilla 2D simplex octave used by `NoiseGeneratorPerlin` for surface variation.
#[derive(Debug, Clone)]
pub struct SimplexNoise {
    permutations: [usize; 512],
    x_coord: f64,
    y_coord: f64,
}

impl SimplexNoise {
    const GRADIENTS: [[f64; 2]; 12] = [
        [1.0,1.0],[-1.0,1.0],[1.0,-1.0],[-1.0,-1.0],
        [1.0,0.0],[-1.0,0.0],[1.0,0.0],[-1.0,0.0],
        [0.0,1.0],[0.0,-1.0],[0.0,1.0],[0.0,-1.0],
    ];
    pub fn new(random: &mut JavaRandom) -> Self {
        let x_coord=random.next_double()*256.0;
        let y_coord=random.next_double()*256.0;
        // The third offset is consumed by the vanilla 3D-capable Simplex object.
        let _z_coord=random.next_double()*256.0;
        let mut p=[0usize;512];
        for (i,v) in p.iter_mut().take(256).enumerate(){*v=i;}
        for i in 0..256 {
            let j=i+random.next_int((256-i) as u32).unwrap() as usize;
            p.swap(i,j); p[i+256]=p[i];
        }
        Self{permutations:p,x_coord,y_coord}
    }
    #[inline] fn floor(v:f64)->i32 { if v>0.0 {v as i32} else {(v as i32)-1} }
    #[inline] fn dot(g:[f64;2],x:f64,y:f64)->f64 {g[0]*x+g[1]*y}
    #[inline] fn contribution(g:[f64;2],x:f64,y:f64)->f64 {
        let mut t=0.5-x*x-y*y;
        if t<0.0 {0.0} else {t*=t;t*t*Self::dot(g,x,y)}
    }
    pub fn noise(&self,x:f64,y:f64)->f64 {
        let f2=0.5*(3.0_f64.sqrt()-1.0);
        let g2=(3.0-3.0_f64.sqrt())/6.0;
        let skew=(x+y)*f2;
        let i=Self::floor(x+skew); let j=Self::floor(y+skew);
        let unskew=(i+j) as f64*g2;
        let x0=x-(i as f64-unskew); let y0=y-(j as f64-unskew);
        let (i1,j1)=if x0>y0 {(1usize,0usize)} else {(0,1)};
        let x1=x0-i1 as f64+g2; let y1=y0-j1 as f64+g2;
        let x2=x0-1.0+2.0*g2; let y2=y0-1.0+2.0*g2;
        let ii=(i&255) as usize; let jj=(j&255) as usize;
        let gi0=self.permutations[ii+self.permutations[jj]]%12;
        let gi1=self.permutations[ii+i1+self.permutations[jj+j1]]%12;
        let gi2=self.permutations[ii+1+self.permutations[jj+1]]%12;
        70.0*(Self::contribution(Self::GRADIENTS[gi0],x0,y0)+Self::contribution(Self::GRADIENTS[gi1],x1,y1)+Self::contribution(Self::GRADIENTS[gi2],x2,y2))
    }
    fn add(&self,out:&mut [f64],x_offset:f64,z_offset:f64,x_size:usize,z_size:usize,x_scale:f64,z_scale:f64,amplitude:f64){
        let mut index=0;
        for z in 0..z_size { let zz=(z_offset+z as f64)*z_scale+self.y_coord;
            for x in 0..x_size { let xx=(x_offset+x as f64)*x_scale+self.x_coord;
                out[index]+=self.noise(xx,zz)*amplitude; index+=1;
            }
        }
    }
}

/// Four-octave `NoiseGeneratorPerlin` surface field (MCP 1.8.9).
#[derive(Debug, Clone)]
pub struct PerlinNoise { octaves: Vec<SimplexNoise> }
impl PerlinNoise {
    pub fn new(random:&mut JavaRandom,count:usize)->Self { Self{octaves:(0..count).map(|_|SimplexNoise::new(random)).collect()} }
    pub fn generate(&self,x:f64,z:f64,width:usize,height:usize,x_scale:f64,z_scale:f64,persistence:f64)->Vec<f64>{
        let mut out=vec![0.0;width*height]; let mut frequency=1.0; let mut amplitude=1.0;
        for octave in &self.octaves { octave.add(&mut out,x,z,width,height,x_scale*frequency,z_scale*frequency,0.55/amplitude); frequency*=persistence*0.5; amplitude*=0.5; }
        out
    }
    pub fn octave_count(&self)->usize {self.octaves.len()}
}

/// Terrain noise streams initialized in the exact order used by the vanilla
/// `ChunkProviderGenerate` constructor. `surface_perlin` is represented separately:
/// its four Simplex octaves consume the same Java RNG calls as the ImprovedNoise
/// permutation setup, but are not exposed as an ImprovedNoise substitute.
#[derive(Debug, Clone)]
pub struct TerrainNoiseSet {
    pub lower_limit: OctaveNoise,
    pub upper_limit: OctaveNoise,
    pub main: OctaveNoise,
    pub depth_noise: OctaveNoise,
    pub noise_gen5: OctaveNoise,
    pub mob_spawner: OctaveNoise,
    surface_perlin: PerlinNoise,
}

impl TerrainNoiseSet {
    pub fn new(seed: i64) -> Self {
        let mut random = JavaRandom::new(seed);
        let lower_limit = OctaveNoise::new(&mut random, 16);
        let upper_limit = OctaveNoise::new(&mut random, 16);
        let main = OctaveNoise::new(&mut random, 8);
        // NoiseGeneratorPerlin(random, 4), preserving the vanilla RNG stream.
        let surface_perlin = PerlinNoise::new(&mut random, 4);
        let noise_gen5 = OctaveNoise::new(&mut random, 10);
        let depth_noise = OctaveNoise::new(&mut random, 16);
        let mob_spawner = OctaveNoise::new(&mut random, 8);
        Self { lower_limit, upper_limit, main, depth_noise, noise_gen5, mob_spawner, surface_perlin }
    }

    pub fn surface_perlin_octaves(&self) -> usize { self.surface_perlin.octave_count() }
    pub fn surface_noise(&self, x:f64, z:f64, width:usize, height:usize, x_scale:f64, z_scale:f64, persistence:f64)->Vec<f64>{
        self.surface_perlin.generate(x,z,width,height,x_scale,z_scale,persistence)
    }
}

/// Vanilla biome terrain parameters consumed by `ChunkProviderGenerate`.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct BiomeTerrain {
    pub min_height: f32,
    pub max_height: f32,
}

impl BiomeTerrain {
    pub const PLAINS: Self = Self { min_height: 0.1, max_height: 0.3 };
    pub const OCEAN: Self = Self { min_height: -1.0, max_height: 0.1 };
}

/// The terrain-shaping subset of `ChunkProviderSettings` (vanilla defaults).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TerrainSettings {
    pub coordinate_scale: f32,
    pub height_scale: f32,
    pub main_noise_scale_x: f32,
    pub main_noise_scale_y: f32,
    pub main_noise_scale_z: f32,
    pub depth_noise_scale_x: f32,
    pub depth_noise_scale_z: f32,
    pub depth_noise_scale_exponent: f32,
    pub biome_depth_offset: f32,
    pub biome_depth_weight: f32,
    pub biome_scale_offset: f32,
    pub biome_scale_weight: f32,
    pub base_size: f32,
    pub stretch_y: f32,
    pub lower_limit_scale: f32,
    pub upper_limit_scale: f32,
    pub sea_level: i32,
}

impl Default for TerrainSettings {
    fn default() -> Self {
        Self {
            coordinate_scale: 684.412, height_scale: 684.412,
            main_noise_scale_x: 80.0, main_noise_scale_y: 160.0, main_noise_scale_z: 80.0,
            depth_noise_scale_x: 200.0, depth_noise_scale_z: 200.0, depth_noise_scale_exponent: 0.5,
            biome_depth_offset: 0.0, biome_depth_weight: 1.0,
            biome_scale_offset: 0.0, biome_scale_weight: 1.0,
            base_size: 8.5, stretch_y: 12.0,
            lower_limit_scale: 512.0, upper_limit_scale: 512.0, sea_level: 63,
        }
    }
}

/// Density lattice produced by the 1.8.9 `ChunkProviderGenerate.func_147423_a`.
/// Layout is `(x * 5 + z) * 33 + y`, matching the vanilla interpolation loop.
#[derive(Debug, Clone, PartialEq)]
pub struct TerrainDensity {
    pub values: Vec<f64>,
}

impl TerrainDensity {
    pub fn get(&self, x: usize, y: usize, z: usize) -> f64 {
        self.values[(x * 5 + z) * 33 + y]
    }
}

impl TerrainNoiseSet {
    /// Port of vanilla's 5×33×5 density field. `biomes` is the 10×10 generation
    /// biome neighborhood returned for `(chunk_x*4-2, chunk_z*4-2)`.
    pub fn density_field(
        &self,
        chunk_x: i32,
        chunk_z: i32,
        biomes: &[BiomeTerrain],
        settings: TerrainSettings,
        amplified: bool,
    ) -> Option<TerrainDensity> {
        if biomes.len() != 100 { return None; }
        let x0 = chunk_x.checked_mul(4)?;
        let z0 = chunk_z.checked_mul(4)?;
        let depth = self.depth_noise.generate_xz(
            x0, z0, 5, 5,
            f64::from(settings.depth_noise_scale_x),
            f64::from(settings.depth_noise_scale_z),
        );
        let f = f64::from(settings.coordinate_scale);
        let f1 = f64::from(settings.height_scale);
        let main = self.main.generate(
            x0, 0, z0, 5, 33, 5,
            f / f64::from(settings.main_noise_scale_x),
            f1 / f64::from(settings.main_noise_scale_y),
            f / f64::from(settings.main_noise_scale_z),
        );
        let lower = self.lower_limit.generate(x0, 0, z0, 5, 33, 5, f, f1, f);
        let upper = self.upper_limit.generate(x0, 0, z0, 5, 33, 5, f, f1, f);
        let mut output = vec![0.0; 825];
        let mut index = 0;

        for x in 0..5 {
            for z in 0..5 {
                let center = biomes[(x + 2) + (z + 2) * 10];
                let mut weighted_scale = 0.0_f32;
                let mut weighted_depth = 0.0_f32;
                let mut total_weight = 0.0_f32;
                for dz in -2_i32..=2 {
                    for dx in -2_i32..=2 {
                        let neighbor = biomes[(x as i32 + dx + 2) as usize
                            + (z as i32 + dz + 2) as usize * 10];
                        let mut biome_depth = settings.biome_depth_offset
                            + neighbor.min_height * settings.biome_depth_weight;
                        let mut biome_scale = settings.biome_scale_offset
                            + neighbor.max_height * settings.biome_scale_weight;
                        if amplified && biome_depth > 0.0 {
                            biome_depth = 1.0 + biome_depth * 2.0;
                            biome_scale = 1.0 + biome_scale * 4.0;
                        }
                        let mut weight = 10.0_f32
                            / ((dx * dx + dz * dz) as f32 + 0.2).sqrt();
                        if neighbor.min_height > center.min_height { weight *= 0.5; }
                        let weight = weight / (biome_depth + 2.0);
                        weighted_scale += biome_scale * weight;
                        weighted_depth += biome_depth * weight;
                        total_weight += weight;
                    }
                }
                weighted_scale = weighted_scale / total_weight;
                weighted_depth = weighted_depth / total_weight;
                weighted_scale = weighted_scale * 0.9 + 0.1;
                weighted_depth = (weighted_depth * 4.0 - 1.0) / 8.0;

                let mut depth_value = depth[x * 5 + z] / 8000.0;
                if depth_value < 0.0 { depth_value = -depth_value * 0.3; }
                depth_value = depth_value * 3.0 - 2.0;
                if depth_value < 0.0 {
                    depth_value /= 2.0;
                    if depth_value < -1.0 { depth_value = -1.0; }
                    depth_value /= 1.4;
                    depth_value /= 2.0;
                } else {
                    if depth_value > 1.0 { depth_value = 1.0; }
                    depth_value /= 8.0;
                }
                let adjusted_depth = f64::from(weighted_depth) + depth_value * 0.2;
                let adjusted_depth = adjusted_depth * f64::from(settings.base_size) / 8.0;
                let vertical_offset = f64::from(settings.base_size) + adjusted_depth * 4.0;
                for y in 0..33 {
                    let mut vertical = (y as f64 - vertical_offset)
                        * f64::from(settings.stretch_y) * 128.0 / 256.0
                        / f64::from(weighted_scale);
                    if vertical < 0.0 { vertical *= 4.0; }
                    let lo = lower[index] / f64::from(settings.lower_limit_scale);
                    let hi = upper[index] / f64::from(settings.upper_limit_scale);
                    let blend = (main[index] / 10.0 + 1.0) / 2.0;
                    let clamped = blend.clamp(0.0, 1.0);
                    let mut density = lo + (hi - lo) * clamped - vertical;
                    if y > 29 {
                        let fade = ((y - 29) as f32 / 3.0) as f64;
                        density = density * (1.0 - fade) + -10.0 * fade;
                    }
                    output[index] = density;
                    index += 1;
                }
            }
        }
        Some(TerrainDensity { values: output })
    }
}

/// Block-level output of vanilla's 4×8×4 interpolation, before biome surface replacement.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum TerrainBlock {
    Air = 0, Stone = 1, Water = 2, Grass = 3, Dirt = 4, Sand = 5,
    Gravel = 6, Mycelium = 7, Bedrock = 8, Lava = 9,
    CoalOre = 10, IronOre = 11, GoldOre = 12, RedstoneOre = 13,
    DiamondOre = 14, LapisOre = 15, DirtOre = 16, GravelOre = 17,
    Granite = 18, Diorite = 19, Andesite = 20, Clay = 21,
    OakLog = 22, BirchLog = 23, OakLeaves = 24, BirchLeaves = 25,
    SpruceLog = 26, SpruceLeaves = 27,
    DarkOakLog = 28, DarkOakLeaves = 29, Podzol = 30, JungleLog = 31, JungleLeaves = 32, VineNorth = 33, VineEast = 34, VineSouth = 35, VineWest = 36, OakLogX = 37, OakLogZ = 38,
    MushroomBrown0 = 39, MushroomRed0 = 50,
    MushroomBrown1 = 40, MushroomRed1 = 51,
    MushroomBrown2 = 41, MushroomRed2 = 52,
    MushroomBrown3 = 42, MushroomRed3 = 53,
    MushroomBrown4 = 43, MushroomRed4 = 54,
    MushroomBrown5 = 44, MushroomRed5 = 55,
    MushroomBrown6 = 45, MushroomRed6 = 56,
    MushroomBrown7 = 46, MushroomRed7 = 57,
    MushroomBrown8 = 47, MushroomRed8 = 58,
    MushroomBrown9 = 48, MushroomRed9 = 59,
    MushroomBrown10 = 49, MushroomRed10 = 60,
    Dandelion = 61, Poppy = 62, BlueOrchid = 63, Allium = 64, Houstonia = 65,
    RedTulip = 66, OrangeTulip = 67, WhiteTulip = 68, PinkTulip = 69,
    OxeyeDaisy = 70, TallGrass = 71, Fern = 72, DeadBush = 73,
    BrownMushroom = 74, RedMushroom = 75, Reed = 76, Cactus = 77,
    Waterlily = 78, Pumpkin = 79, Melon = 80,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TerrainPrimer { blocks: Vec<TerrainBlock> }

impl TerrainBlock {
    /// Legacy numeric block ID and metadata used by the 1.8.9 Anvil format.
    pub fn legacy_id_metadata(self) -> (u16, u8) {
        match self {
            Self::Air => (0, 0), Self::Stone => (1, 0), Self::Grass => (2, 0),
            Self::Dirt | Self::DirtOre => (3, 0),
            Self::Bedrock => (7, 0), Self::Water => (9, 0), Self::Lava => (11, 0),
            Self::Sand => (12, 0), Self::Gravel | Self::GravelOre => (13, 0),
            Self::GoldOre => (14, 0), Self::IronOre => (15, 0), Self::CoalOre => (16, 0),
            Self::LapisOre => (21, 0), Self::DiamondOre => (56, 0), Self::RedstoneOre => (73, 0),
            Self::Granite => (1, 1), Self::Diorite => (1, 3), Self::Andesite => (1, 5),
            Self::Mycelium => (110, 0), Self::Clay => (82, 0),
            Self::OakLog => (17, 0), Self::BirchLog => (17, 2), Self::SpruceLog => (17, 1),
            Self::OakLeaves => (18, 4), Self::BirchLeaves => (18, 6), Self::SpruceLeaves => (18, 5),
            Self::DarkOakLog => (162, 1), Self::DarkOakLeaves => (161, 1), Self::Podzol => (3, 2), Self::JungleLog => (17, 3), Self::JungleLeaves => (18, 3), Self::VineNorth => (106, 4), Self::VineEast => (106, 8), Self::VineSouth => (106, 1), Self::VineWest => (106, 2), Self::OakLogX => (17, 4), Self::OakLogZ => (17, 8), Self::MushroomBrown0 => (99, 0), Self::MushroomRed0 => (100, 0), Self::MushroomBrown1 => (99, 1), Self::MushroomRed1 => (100, 1), Self::MushroomBrown2 => (99, 2), Self::MushroomRed2 => (100, 2), Self::MushroomBrown3 => (99, 3), Self::MushroomRed3 => (100, 3), Self::MushroomBrown4 => (99, 4), Self::MushroomRed4 => (100, 4), Self::MushroomBrown5 => (99, 5), Self::MushroomRed5 => (100, 5), Self::MushroomBrown6 => (99, 6), Self::MushroomRed6 => (100, 6), Self::MushroomBrown7 => (99, 7), Self::MushroomRed7 => (100, 7), Self::MushroomBrown8 => (99, 8), Self::MushroomRed8 => (100, 8), Self::MushroomBrown9 => (99, 9), Self::MushroomRed9 => (100, 9), Self::MushroomBrown10 => (99, 10), Self::MushroomRed10 => (100, 10),
            Self::Dandelion => (37, 0), Self::Poppy => (38, 0), Self::BlueOrchid => (38, 1),
            Self::Allium => (38, 2), Self::Houstonia => (38, 3), Self::RedTulip => (38, 4),
            Self::OrangeTulip => (38, 5), Self::WhiteTulip => (38, 6), Self::PinkTulip => (38, 7),
            Self::OxeyeDaisy => (38, 8), Self::TallGrass => (31, 1), Self::Fern => (31, 2),
            Self::DeadBush => (32, 0), Self::BrownMushroom => ( 39, 0),
            Self::RedMushroom => ( 40, 0), Self::Reed => (83, 0),
            Self::Cactus => (81, 0), Self::Waterlily => (111, 0), Self::Pumpkin => (86, 0), Self::Melon => (103, 0),
        }
    }
}

impl Default for TerrainPrimer {
    fn default() -> Self { Self { blocks: vec![TerrainBlock::Air; 16 * 16 * 256] } }
}

impl TerrainPrimer {
    #[inline]
    fn index(x: usize, y: usize, z: usize) -> usize { (x * 16 + z) * 256 + y }
    pub fn get(&self, x: usize, y: usize, z: usize) -> Option<TerrainBlock> {
        if x >= 16 || y >= 256 || z >= 16 { return None; }
        Some(self.blocks[Self::index(x, y, z)])
    }
    pub fn blocks(&self) -> &[TerrainBlock] { &self.blocks }
    pub fn set(&mut self, x: usize, y: usize, z: usize, block: TerrainBlock) -> bool {
        if x >= 16 || y >= 256 || z >= 16 { return false; }
        self.blocks[Self::index(x, y, z)] = block;
        true
    }
}

/// A 3x3 neighborhood of chunk primers used while populating one origin chunk.
/// Vanilla WorldGenMinable may write beyond the 16x16 source chunk; retaining
/// adjacent primers prevents those blocks from being silently clipped.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TerrainPopulationRegion {
    center_chunk_x: i32,
    center_chunk_z: i32,
    chunks: Vec<TerrainPrimer>,
}

impl TerrainPopulationRegion {
    pub fn new(center_chunk_x: i32, center_chunk_z: i32) -> Self {
        Self { center_chunk_x, center_chunk_z, chunks: (0..9).map(|_| TerrainPrimer::default()).collect() }
    }

    fn slot(&self, chunk_x: i32, chunk_z: i32) -> Option<usize> {
        let dx = chunk_x - self.center_chunk_x;
        let dz = chunk_z - self.center_chunk_z;
        if !(-1..=1).contains(&dx) || !(-1..=1).contains(&dz) { return None; }
        Some(((dz + 1) * 3 + (dx + 1)) as usize)
    }

    pub fn set_chunk(&mut self, chunk_x: i32, chunk_z: i32, primer: TerrainPrimer) -> bool {
        let Some(slot) = self.slot(chunk_x, chunk_z) else { return false; };
        self.chunks[slot] = primer;
        true
    }

    pub fn chunk(&self, chunk_x: i32, chunk_z: i32) -> Option<&TerrainPrimer> {
        self.slot(chunk_x, chunk_z).map(|slot| &self.chunks[slot])
    }

    pub fn chunk_mut(&mut self, chunk_x: i32, chunk_z: i32) -> Option<&mut TerrainPrimer> {
        let slot = self.slot(chunk_x, chunk_z)?;
        Some(&mut self.chunks[slot])
    }

    pub fn center(&self) -> &TerrainPrimer { self.chunk(self.center_chunk_x, self.center_chunk_z).expect("center is in region") }
    pub fn center_mut(&mut self) -> &mut TerrainPrimer { self.chunk_mut(self.center_chunk_x, self.center_chunk_z).expect("center is in region") }

    fn get_world(&self, x: i32, y: i32, z: i32) -> Option<TerrainBlock> {
        if !(0..256).contains(&y) { return None; }
        let cx = x.div_euclid(16); let cz = z.div_euclid(16);
        self.chunk(cx, cz)?.get(x.rem_euclid(16) as usize, y as usize, z.rem_euclid(16) as usize)
    }

    fn set_world(&mut self, x: i32, y: i32, z: i32, block: TerrainBlock) -> bool {
        if !(0..256).contains(&y) { return false; }
        let cx = x.div_euclid(16); let cz = z.div_euclid(16);
        let Some(chunk) = self.chunk_mut(cx, cz) else { return false; };
        chunk.set(x.rem_euclid(16) as usize, y as usize, z.rem_euclid(16) as usize, block)
    }

    // Mirrors World.getTopSolidOrLiquidBlock: find the highest movement-
    // blocking block (excluding leaves, which are not represented here) and
    // return the block position immediately above it. In ocean columns this
    // is commonly the first water block, which is what WorldGenSand expects.
    fn top_solid_or_liquid_y(&self, x: i32, z: i32) -> Option<i32> {
        for y in (0..256).rev() {
            let block = self.get_world(x, y, z)?;
            let blocks_movement = matches!(block, TerrainBlock::Stone | TerrainBlock::Grass | TerrainBlock::Dirt
                | TerrainBlock::Sand | TerrainBlock::Gravel | TerrainBlock::Mycelium | TerrainBlock::Bedrock
                | TerrainBlock::CoalOre | TerrainBlock::IronOre | TerrainBlock::GoldOre | TerrainBlock::RedstoneOre
                | TerrainBlock::DiamondOre | TerrainBlock::LapisOre | TerrainBlock::DirtOre | TerrainBlock::GravelOre | TerrainBlock::Podzol
                | TerrainBlock::Granite | TerrainBlock::Diorite | TerrainBlock::Andesite | TerrainBlock::Clay
                | TerrainBlock::OakLog | TerrainBlock::OakLogX | TerrainBlock::OakLogZ | TerrainBlock::BirchLog | TerrainBlock::SpruceLog | TerrainBlock::DarkOakLog | TerrainBlock::JungleLog);
            if blocks_movement { return Some((y + 1).min(255)); }
        }
        Some(0)
    }

    /// Mirrors World.getHeight: first air position above the highest non-air block.
    fn height_y(&self, x: i32, z: i32) -> Option<i32> {
        for y in (0..256).rev() {
            let block = self.get_world(x, y, z)?;
            if block != TerrainBlock::Air { return Some((y + 1).min(255)); }
        }
        Some(0)
    }
}

/// Vanilla 1.8.9 trilinear density interpolation. Empty space below sea level
/// becomes water; the caller can later apply biome surface blocks and carvers.
pub fn interpolate_terrain(density: &TerrainDensity, sea_level: i32) -> TerrainPrimer {
    let mut primer = TerrainPrimer::default();
    for cell_x in 0..4 {
        for cell_z in 0..4 {
            let i00 = (cell_x * 5 + cell_z) * 33;
            let i01 = (cell_x * 5 + cell_z + 1) * 33;
            let i10 = ((cell_x + 1) * 5 + cell_z) * 33;
            let i11 = ((cell_x + 1) * 5 + cell_z + 1) * 33;
            for sub_y in 0..32 {
                let mut a = density.values[i00 + sub_y];
                let mut b = density.values[i01 + sub_y];
                let mut c = density.values[i10 + sub_y];
                let mut d = density.values[i11 + sub_y];
                let da = (density.values[i00 + sub_y + 1] - a) * 0.125;
                let db = (density.values[i01 + sub_y + 1] - b) * 0.125;
                let dc = (density.values[i10 + sub_y + 1] - c) * 0.125;
                let dd = (density.values[i11 + sub_y + 1] - d) * 0.125;
                for sub_x in 0..4 {
                    let mut left = a;
                    let mut right = b;
                    let mut left_dy = da;
                    let mut right_dy = db;
                    let step_left = (c - a) * 0.25;
                    let step_right = (d - b) * 0.25;
                    let step_left_dy = (dc - da) * 0.25;
                    let step_right_dy = (dd - db) * 0.25;
                    let step_z = (right - left) * 0.25;
                    let step_z_dy = (right_dy - left_dy) * 0.25;
                    let mut value_z = left - step_z;
                    let mut dy_z = left_dy - step_z_dy;
                    for sub_z in 0..4 {
                        value_z += step_z;
                        dy_z += step_z_dy;
                        let mut value = value_z;
                        let vertical_step = dy_z;
                        for dy in 0..8 {
                            let yy = sub_y * 8 + dy;
                            let block = if value > 0.0 { TerrainBlock::Stone }
                                else if (yy as i32) < sea_level { TerrainBlock::Water }
                                else { TerrainBlock::Air };
                            primer.blocks[TerrainPrimer::index(cell_x * 4 + sub_x, yy, cell_z * 4 + sub_z)] = block;
                            value += vertical_step;
                        }
                    }
                    a += step_left;
                    b += step_right;
                }
            }
        }
    }
    primer
}


/// Applies the 1.8.9 biome top/filler pass to a completed terrain primer.
/// `biome_ids` is the 16×16 block-biome raster in z*16+x order, as returned
/// by WorldChunkManager.loadBlockGeneratorData. Chunk random is seeded with
/// the same constants used by ChunkProviderGenerate.provideChunk.
pub fn replace_biome_surfaces(
    noise: &TerrainNoiseSet,
    _world_seed: i64,
    chunk_x: i32,
    chunk_z: i32,
    biome_ids: &[i32],
    sea_level: i32,
    primer: &mut TerrainPrimer,
) -> bool {
    if biome_ids.len() != 256 { return false; }
    let stone_noise = noise.surface_noise(
        f64::from(chunk_x) * 16.0,
        f64::from(chunk_z) * 16.0,
        16, 16, 0.0625, 0.0625, 1.0,
    );
    let mut random = JavaRandom::new(
        i64::from(chunk_x).wrapping_mul(341_873_128_712)
            .wrapping_add(i64::from(chunk_z).wrapping_mul(132_897_987_541)),
    );
    // Vanilla's biome loop is x-major; each biome consumes its own random
    // bedrock draws while traversing y from 255 down to 0.
    for x in 0..16 {
        for z in 0..16 {
            let biome = biome_ids[z * 16 + x];
            let (top, filler) = biome_surface_blocks(biome);
            let noise_value = stone_noise[z * 16 + x];
            let thickness = (noise_value / 3.0 + 3.0 + random.next_double() * 0.25) as i32;
            let mut remaining = -1_i32;
            for y in (0..256).rev() {
                if y <= random.next_int(5).unwrap_or(0) as usize {
                    primer.set(x, y, z, TerrainBlock::Bedrock);
                } else {
                    match primer.get(x, y, z) {
                        Some(TerrainBlock::Air) => { remaining = -1; }
                        Some(TerrainBlock::Stone) => {
                            if remaining == -1 {
                                if thickness <= 0 {
                                    primer.set(x, y, z, TerrainBlock::Air);
                                } else if (y as i32) >= sea_level - 1 {
                                    primer.set(x, y, z, top);
                                    remaining = thickness;
                                } else {
                                    primer.set(x, y, z, filler);
                                    remaining = thickness;
                                }
                            } else if remaining > 0 {
                                remaining -= 1;
                                primer.set(x, y, z, filler);
                            }
                        }
                        _ => {}
                    }
                }
            }
        }
    }
    true
}

/// Carves deterministic underground cave tunnels into a generated 1.8.9 terrain
/// primer. Source chunks in the vanilla MapGenBase range (8 chunks) are visited
/// in z-major/x-major order and use the same world-seed odd multipliers.
/// The tunnel walker follows the 1.8.9 cave path rules; water-border checks
/// prevent openings from cutting directly into ocean or river columns.
pub fn carve_caves(world_seed: i64, chunk_x: i32, chunk_z: i32, primer: &mut TerrainPrimer) -> usize {
    let mut carved = 0usize;
    let mut world_rng = JavaRandom::new(world_seed);
    let x_mul = (world_rng.next_long() / 2) * 2 + 1;
    let z_mul = (world_rng.next_long() / 2) * 2 + 1;
    for source_z in (chunk_z - 8)..=(chunk_z + 8) {
        for source_x in (chunk_x - 8)..=(chunk_x + 8) {
            let chunk_seed = i64::from(source_x).wrapping_mul(x_mul)
                .wrapping_add(i64::from(source_z).wrapping_mul(z_mul)) ^ world_seed;
            let mut rng = JavaRandom::new(chunk_seed);
            let mut count = rng.next_int(15).unwrap_or(0);
            count = rng.next_int(count + 1).unwrap_or(0);
            count = rng.next_int(count + 1).unwrap_or(0);
            if rng.next_int(7) != Some(0) { count = 0; }
            for _ in 0..count {
                let x = f64::from(source_x * 16 + rng.next_int(16).unwrap_or(0) as i32);
                let inner_height_bound = rng.next_int(120).unwrap_or(0) + 8;
                let y = f64::from(rng.next_int(inner_height_bound).unwrap_or(0));
                let z = f64::from(source_z * 16 + rng.next_int(16).unwrap_or(0) as i32);
                let branches = if rng.next_int(4) == Some(0) { 1 + rng.next_int(4).unwrap_or(0) } else { 1 };
                for _ in 0..branches {
                    let yaw = rng.next_float() * std::f32::consts::TAU;
                    let pitch = (rng.next_float() - 0.5) * 0.25;
                    let mut width = rng.next_float() * 2.0 + rng.next_float();
                    if rng.next_int(10) == Some(0) {
                        width *= rng.next_float() * rng.next_float() * 3.0 + 1.0;
                    }
                    let length = 32 + rng.next_int(48).unwrap_or(0) as usize;
                    let mut px = x; let mut py = y; let mut pz = z;
                    let mut yaw_f = yaw; let mut pitch_f = pitch;
                    let mut yaw_drift = 0.0f32; let mut pitch_drift = 0.0f32;
                    let mut local_rng = JavaRandom::new(rng.next_long());
                    for step in 0..length {
                        let radius = 1.5 + (step as f64 * std::f64::consts::PI / length as f64).sin() * f64::from(width);
                        px += f64::from(yaw_f.cos() * pitch_f.cos());
                        py += f64::from(pitch_f.sin());
                        pz += f64::from(yaw_f.sin() * pitch_f.cos());
                        pitch_f = pitch_f * 0.7 + pitch_drift * 0.1;
                        yaw_f += yaw_drift * 0.1;
                        pitch_drift = pitch_drift * 0.9 + (local_rng.next_float() - local_rng.next_float()) * local_rng.next_float() * 2.0;
                        yaw_drift = yaw_drift * 0.75 + (local_rng.next_float() - local_rng.next_float()) * local_rng.next_float() * 4.0;
                        let dx = px - f64::from(chunk_x * 16 + 8);
                        let dz = pz - f64::from(chunk_z * 16 + 8);
                        let remaining = (length - step) as f64;
                        if dx * dx + dz * dz - remaining * remaining > (f64::from(width) + 18.0).powi(2) { break; }
                        let min_x = ((px - radius).floor() as i32 - chunk_x * 16).clamp(0, 16);
                        let max_x = ((px + radius).floor() as i32 - chunk_x * 16 + 1).clamp(0, 16);
                        let min_z = ((pz - radius).floor() as i32 - chunk_z * 16).clamp(0, 16);
                        let max_z = ((pz + radius).floor() as i32 - chunk_z * 16 + 1).clamp(0, 16);
                        let min_y = (py - radius * 0.65).floor().clamp(1.0, 255.0) as usize;
                        let max_y = (py + radius * 0.65).ceil().clamp(1.0, 255.0) as usize;
                        let mut touches_water = false;
                        'water: for xx in min_x..max_x { for zz in min_z..max_z { for yy in min_y.saturating_sub(1)..=(max_y + 1).min(255) {
                            if primer.get(xx as usize, yy, zz as usize) == Some(TerrainBlock::Water) { touches_water = true; break 'water; }
                        }}};
                        if touches_water { continue; }
                        for xx in min_x..max_x { for zz in min_z..max_z {
                            let nx = (f64::from(chunk_x * 16 + xx) + 0.5 - px) / radius;
                            let nz = (f64::from(chunk_z * 16 + zz) + 0.5 - pz) / radius;
                            if nx * nx + nz * nz >= 1.0 { continue; }
                            for yy in (min_y..=max_y).rev() {
                                let ny = (yy as f64 - 0.5 - py) / (radius * 0.65);
                                if nx * nx + ny * ny + nz * nz < 1.0 {
                                    if matches!(primer.get(xx as usize, yy, zz as usize), Some(TerrainBlock::Stone | TerrainBlock::Dirt | TerrainBlock::Grass | TerrainBlock::Gravel | TerrainBlock::Sand | TerrainBlock::Mycelium)) {
                                        let block = if yy < 10 { TerrainBlock::Lava } else { TerrainBlock::Air };
                                        primer.set(xx as usize, yy, zz as usize, block);
                                        carved += 1;
                                    }
                                }
                            }
                        }}
                    }
                }
            }
        }
    }
    carved
}

/// Carves the vanilla-style ravine pass into a chunk primer. Source chunks are
/// visited in MapGenBase's 17x17 neighborhood; the path profile and random
/// perturbations follow MCP 1.8.9 MapGenRavine.func_180707_a.
pub fn carve_ravines(world_seed: i64, chunk_x: i32, chunk_z: i32, primer: &mut TerrainPrimer) -> usize {
    let mut world_rng = JavaRandom::new(world_seed);
    let x_mul = (world_rng.next_long() / 2).wrapping_mul(2).wrapping_add(1);
    let z_mul = (world_rng.next_long() / 2).wrapping_mul(2).wrapping_add(1);
    let mut carved = 0usize;
    for source_z in (chunk_z - 8)..=(chunk_z + 8) {
        for source_x in (chunk_x - 8)..=(chunk_x + 8) {
            let seed = i64::from(source_x).wrapping_mul(x_mul)
                .wrapping_add(i64::from(source_z).wrapping_mul(z_mul)) ^ world_seed;
            let mut rng = JavaRandom::new(seed);
            if rng.next_int(50) != Some(0) { continue; }
            let mut x = f64::from(source_x * 16 + rng.next_int(16).unwrap_or(0) as i32);
            let height_bound = rng.next_int(40).unwrap_or(0) + 8;
            let mut y = f64::from(rng.next_int(height_bound).unwrap_or(0) as i32 + 20);
            let mut z = f64::from(source_z * 16 + rng.next_int(16).unwrap_or(0) as i32);
            let yaw = rng.next_float() * std::f32::consts::TAU;
            let pitch = (rng.next_float() - 0.5) * 2.0 / 8.0;
            let width = (rng.next_float() * 2.0 + rng.next_float()) * 2.0;
            let path_seed = rng.next_long();
            let mut path_rng = JavaRandom::new(path_seed);
            let mut profile = [1.0f64; 256];
            let mut scale = 1.0f32;
            for j in 0..256 {
                if j == 0 || path_rng.next_int(3) == Some(0) {
                    scale = 1.0 + path_rng.next_float() * path_rng.next_float();
                }
                profile[j] = f64::from(scale * scale);
            }
            let center_x = f64::from(chunk_x * 16 + 8);
            let center_z = f64::from(chunk_z * 16 + 8);
            let mut yaw_f = yaw;
            let mut pitch_f = pitch;
            let mut yaw_drift = 0.0f32;
            let mut pitch_drift = 0.0f32;
            let length = 112usize;
            for step in 0..length {
                let envelope = (step as f32 * std::f32::consts::PI / length as f32).sin();
                let mut horizontal_radius = 1.5 + f64::from(envelope * width);
                let mut vertical_radius = horizontal_radius * 3.0;
                horizontal_radius *= f64::from(path_rng.next_float() * 0.25 + 0.75);
                vertical_radius *= f64::from(path_rng.next_float() * 0.25 + 0.75);
                let cp = pitch_f.cos();
                x += f64::from(yaw_f.cos() * cp);
                y += f64::from(pitch_f.sin());
                z += f64::from(yaw_f.sin() * cp);
                pitch_f *= 0.7;
                pitch_f += pitch_drift * 0.05;
                yaw_f += yaw_drift * 0.05;
                pitch_drift *= 0.8;
                yaw_drift *= 0.5;
                pitch_drift += (path_rng.next_float() - path_rng.next_float()) * path_rng.next_float() * 2.0;
                yaw_drift += (path_rng.next_float() - path_rng.next_float()) * path_rng.next_float() * 4.0;
                let dx = x - center_x;
                let dz = z - center_z;
                let remaining = (length - step) as f64;
                if dx * dx + dz * dz - remaining * remaining > (f64::from(width) + 18.0).powi(2) { break; }
                if x < center_x - 16.0 - horizontal_radius * 2.0 || x > center_x + 16.0 + horizontal_radius * 2.0
                    || z < center_z - 16.0 - horizontal_radius * 2.0 || z > center_z + 16.0 + horizontal_radius * 2.0 { continue; }
                let min_x = ((x - horizontal_radius).floor() as i32 - chunk_x * 16 - 1).clamp(0, 16);
                let max_x = ((x + horizontal_radius).floor() as i32 - chunk_x * 16 + 1).clamp(0, 16);
                let min_z = ((z - horizontal_radius).floor() as i32 - chunk_z * 16 - 1).clamp(0, 16);
                let max_z = ((z + horizontal_radius).floor() as i32 - chunk_z * 16 + 1).clamp(0, 16);
                let min_y = (y - vertical_radius).floor().clamp(1.0, 248.0) as usize;
                let max_y = (y + vertical_radius).floor().clamp(1.0, 248.0) as usize;
                let mut water = false;
                'check: for xx in min_x..max_x { for zz in min_z..max_z {
                    for yy in (min_y.saturating_sub(1))..=(max_y + 1).min(255) {
                        if primer.get(xx as usize, yy, zz as usize) == Some(TerrainBlock::Water) { water = true; break 'check; }
                    }
                }}
                if water { continue; }
                for xx in min_x..max_x { for zz in min_z..max_z {
                    let nx = (f64::from(chunk_x * 16 + xx) + 0.5 - x) / horizontal_radius;
                    let nz = (f64::from(chunk_z * 16 + zz) + 0.5 - z) / horizontal_radius;
                    if nx * nx + nz * nz >= 1.0 { continue; }
                    for yy in (min_y..=max_y).rev() {
                        let ny = (yy as f64 - 0.5 - y) / vertical_radius;
                        if (nx * nx + nz * nz) * profile[yy] + ny * ny / 6.0 < 1.0 {
                            match primer.get(xx as usize, yy, zz as usize) {
                                Some(TerrainBlock::Stone | TerrainBlock::Dirt | TerrainBlock::Grass) => {
                                    if yy < 10 { primer.set(xx as usize, yy, zz as usize, TerrainBlock::Lava); }
                                    else {
                                        let was_grass = primer.get(xx as usize, yy, zz as usize) == Some(TerrainBlock::Grass);
                                        primer.set(xx as usize, yy, zz as usize, TerrainBlock::Air);
                                        if was_grass && yy > 0 && primer.get(xx as usize, yy - 1, zz as usize) == Some(TerrainBlock::Dirt) {
                                            primer.set(xx as usize, yy - 1, zz as usize, TerrainBlock::Grass);
                                        }
                                    }
                                    carved += 1;
                                }
                                _ => {}
                            }
                        }
                    }
                }}
            }
        }
    }
    carved
}

/// Statistics from the vanilla 1.8.9 overworld ore population pass.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct OrePopulationStats {
    pub dirt: usize, pub gravel: usize, pub diorite: usize, pub granite: usize,
    pub andesite: usize, pub coal: usize, pub iron: usize, pub gold: usize,
    pub redstone: usize, pub diamond: usize, pub lapis: usize,
}

/// Minecraft 1.8.9 MathHelper.sin lookup. The index calculation deliberately
/// uses f32 multiplication by the same 10430.378F constant as MCP; the table
/// value is the f32-rounded sine of index * 2PI / 65536.
#[inline]
pub fn minecraft_math_helper_sin(value: f32) -> f32 {
    let index = ((value * 10_430.378_f32) as i32) & 65_535;
    ((f64::from(index) * std::f64::consts::PI * 2.0 / 65_536.0).sin()) as f32
}

/// Minecraft 1.8.9 MathHelper.cos lookup, using the same quarter-turn offset.
#[inline]
pub fn minecraft_math_helper_cos(value: f32) -> f32 {
    let index = ((value * 10_430.378_f32 + 16_384.0_f32) as i32) & 65_535;
    ((f64::from(index) * std::f64::consts::PI * 2.0 / 65_536.0).sin()) as f32
}

/// Places one vanilla WorldGenMinable vein. This ports the ellipsoid walk in
/// MCP WorldGenMinable.generate, including MathHelper's 65,536-entry sine
/// lookup semantics, Java float/double promotion, and stone predicate.
fn generate_vanilla_ore_vein(
    region: &mut TerrainPopulationRegion, rng: &mut JavaRandom,
    origin_x: i32, origin_y: i32, origin_z: i32,
    size: i32, ore: TerrainBlock,
) -> usize {
    if size <= 0 { return 0; }
    let angle = rng.next_float() * std::f32::consts::PI;
    let sin = minecraft_math_helper_sin(angle);
    let cos = minecraft_math_helper_cos(angle);
    let d0 = f64::from((origin_x + 8) as f32 + sin * size as f32 / 8.0);
    let d1 = f64::from((origin_x + 8) as f32 - sin * size as f32 / 8.0);
    let d2 = f64::from((origin_z + 8) as f32 + cos * size as f32 / 8.0);
    let d3 = f64::from((origin_z + 8) as f32 - cos * size as f32 / 8.0);
    let d4 = f64::from(origin_y + rng.next_int(3).unwrap_or(0) as i32 - 2);
    let d5 = f64::from(origin_y + rng.next_int(3).unwrap_or(0) as i32 - 2);
    let mut placed = 0usize;
    for i in 0..size {
        let t = i as f32 / size as f32;
        let x = d0 + (d1 - d0) * f64::from(t);
        let y = d4 + (d5 - d4) * f64::from(t);
        let z = d2 + (d3 - d2) * f64::from(t);
        let radius_random = rng.next_double() * f64::from(size) / 16.0;
        let radius = f64::from(minecraft_math_helper_sin(std::f32::consts::PI * t) + 1.0) * radius_random + 1.0;
        let min_x = (x - radius / 2.0).floor() as i32;
        let min_y = (y - radius / 2.0).floor() as i32;
        let min_z = (z - radius / 2.0).floor() as i32;
        let max_x = (x + radius / 2.0).floor() as i32;
        let max_y = (y + radius / 2.0).floor() as i32;
        let max_z = (z + radius / 2.0).floor() as i32;
        for wx in min_x..=max_x {
            let nx = (f64::from(wx) + 0.5 - x) / (radius / 2.0);
            if nx * nx >= 1.0 { continue; }
            for wy in min_y..=max_y {
                let ny = (f64::from(wy) + 0.5 - y) / (radius / 2.0);
                if nx * nx + ny * ny >= 1.0 { continue; }
                for wz in min_z..=max_z {
                    let nz = (f64::from(wz) + 0.5 - z) / (radius / 2.0);
                    if nx * nx + ny * ny + nz * nz >= 1.0 { continue; }
                    if region.get_world(wx, wy, wz) == Some(TerrainBlock::Stone)
                        && region.set_world(wx, wy, wz, ore)
                    {
                        placed += 1;
                    }
                }
            }
        }
    }
    placed
}

/// Convenience wrapper that initializes the chunk population seed and runs
/// the default ore sequence. It is useful for deterministic isolated tests,
/// but does not replay structures/lakes/dungeons that may consume the shared
/// population RNG before BiomeGenBase.decorate in a full vanilla chunk.
pub fn vanilla_chunk_population_seed(world_seed: i64, chunk_x: i32, chunk_z: i32) -> i64 {
    let mut seed_rng = JavaRandom::new(world_seed);
    let x_mul = seed_rng.next_long() / 2 * 2 + 1;
    let z_mul = seed_rng.next_long() / 2 * 2 + 1;
    (i64::from(chunk_x).wrapping_mul(x_mul)
        .wrapping_add(i64::from(chunk_z).wrapping_mul(z_mul))) ^ world_seed
}

/// Convenience single-chunk API. Adjacent chunks are initialized as air, so
/// callers needing boundary-faithful writes should use the region API below.
pub fn populate_overworld_ores(
    world_seed: i64, chunk_x: i32, chunk_z: i32, primer: &mut TerrainPrimer,
) -> OrePopulationStats {
    let mut region = TerrainPopulationRegion::new(chunk_x, chunk_z);
    region.set_chunk(chunk_x, chunk_z, std::mem::take(primer));
    let stats = populate_overworld_ores_in_region(world_seed, chunk_x, chunk_z, &mut region);
    *primer = std::mem::replace(region.center_mut(), TerrainPrimer::default());
    stats
}

/// Populates ores with a complete 3x3 chunk neighborhood, preserving vein
/// blocks that cross chunk borders exactly as WorldGenMinable does in a World.
pub fn populate_overworld_ores_in_region(
    world_seed: i64, chunk_x: i32, chunk_z: i32, region: &mut TerrainPopulationRegion,
) -> OrePopulationStats {
    let mut rng = JavaRandom::new(vanilla_chunk_population_seed(world_seed, chunk_x, chunk_z));
    populate_overworld_ores_in_region_with_rng(&mut rng, chunk_x, chunk_z, region)
}

/// Compatibility API for callers that only have one chunk primer. It retains
/// the original single-chunk semantics while sharing the same RNG path.
pub fn populate_overworld_ores_with_rng(
    rng: &mut JavaRandom, chunk_x: i32, chunk_z: i32, primer: &mut TerrainPrimer,
) -> OrePopulationStats {
    let mut region = TerrainPopulationRegion::new(chunk_x, chunk_z);
    region.set_chunk(chunk_x, chunk_z, std::mem::take(primer));
    let stats = populate_overworld_ores_in_region_with_rng(rng, chunk_x, chunk_z, &mut region);
    *primer = std::mem::replace(region.center_mut(), TerrainPrimer::default());
    stats
}

/// Runs BiomeDecorator.generateOres using the shared Java Random stream and
/// a writable 3x3 chunk neighborhood. The stream is neither cloned nor reset.
pub fn populate_overworld_ores_in_region_with_rng(
    rng: &mut JavaRandom, chunk_x: i32, chunk_z: i32, region: &mut TerrainPopulationRegion,
) -> OrePopulationStats {
    let base_x = chunk_x * 16;
    let base_z = chunk_z * 16;
    let mut stats = OrePopulationStats::default();
    let mut run = |count: u32, min_y: i32, max_y: i32, size: i32, block: TerrainBlock| -> usize {
        let mut total = 0;
        let (lo, hi) = if max_y < min_y { (max_y, min_y) }
            else if max_y == min_y { if min_y < 255 { (min_y, max_y + 1) } else { (min_y - 1, max_y) } }
            else { (min_y, max_y) };
        for _ in 0..count {
            let x = base_x + rng.next_int(16).unwrap_or(0) as i32;
            let y = rng.next_int((hi - lo) as u32).unwrap_or(0) as i32 + lo;
            let z = base_z + rng.next_int(16).unwrap_or(0) as i32;
            total += generate_vanilla_ore_vein(region, rng, x, y, z, size, block);
        }
        total
    };
    stats.dirt = run(10, 0, 256, 33, TerrainBlock::DirtOre);
    stats.gravel = run(8, 0, 256, 33, TerrainBlock::GravelOre);
    stats.diorite = run(10, 0, 80, 33, TerrainBlock::Diorite);
    stats.granite = run(10, 0, 80, 33, TerrainBlock::Granite);
    stats.andesite = run(10, 0, 80, 33, TerrainBlock::Andesite);
    stats.coal = run(20, 0, 128, 17, TerrainBlock::CoalOre);
    stats.iron = run(20, 0, 64, 9, TerrainBlock::IronOre);
    stats.gold = run(2, 0, 32, 9, TerrainBlock::GoldOre);
    stats.redstone = run(8, 0, 16, 8, TerrainBlock::RedstoneOre);
    stats.diamond = run(1, 0, 16, 8, TerrainBlock::DiamondOre);
    drop(run); // release the closure's mutable borrow before the special lapis pass
    for _ in 0..1 {
        let x = base_x + rng.next_int(16).unwrap_or(0) as i32;
        let spread = 16_u32;
        let y = rng.next_int(spread).unwrap_or(0) as i32
            + rng.next_int(spread).unwrap_or(0) as i32 + 16 - 16;
        let z = base_z + rng.next_int(16).unwrap_or(0) as i32;
        stats.lapis += generate_vanilla_ore_vein(region, rng, x, y, z, 7, TerrainBlock::LapisOre);
    }
    stats
}

/// Port of the substrate-patch portion of `BiomeDecorator.genDecorations`.
/// This intentionally handles only the three vanilla patch families that run
/// immediately after ores: sand (3 attempts), clay (1), and gravel-as-sand (1).
/// Tree/flower/grass decoration and the exact world height-map are separate stages.
pub fn decorate_overworld_substrate_patches(
    rng: &mut JavaRandom, chunk_x: i32, chunk_z: i32, region: &mut TerrainPopulationRegion,
) -> SubstratePatchStats {
    let base_x = chunk_x * 16;
    let base_z = chunk_z * 16;
    let mut stats = SubstratePatchStats::default();
    for _ in 0..3 {
        let x = base_x + rng.next_int(16).unwrap_or(0) as i32 + 8;
        let z = base_z + rng.next_int(16).unwrap_or(0) as i32 + 8;
        if let Some(y) = region.top_solid_or_liquid_y(x, z) {
            if generate_vanilla_substrate_patch(region, rng, x, y, z, 7, TerrainBlock::Sand, false) { stats.sand += 1; }
        }
    }
    for _ in 0..1 {
        let x = base_x + rng.next_int(16).unwrap_or(0) as i32 + 8;
        let z = base_z + rng.next_int(16).unwrap_or(0) as i32 + 8;
        if let Some(y) = region.top_solid_or_liquid_y(x, z) {
            if generate_vanilla_substrate_patch(region, rng, x, y, z, 4, TerrainBlock::Clay, true) { stats.clay += 1; }
        }
    }
    for _ in 0..1 {
        let x = base_x + rng.next_int(16).unwrap_or(0) as i32 + 8;
        let z = base_z + rng.next_int(16).unwrap_or(0) as i32 + 8;
        if let Some(y) = region.top_solid_or_liquid_y(x, z) {
            if generate_vanilla_substrate_patch(region, rng, x, y, z, 6, TerrainBlock::Gravel, false) { stats.gravel += 1; }
        }
    }
    stats
}

#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub struct SubstratePatchStats { pub sand: usize, pub clay: usize, pub gravel: usize }

/// Shared shape used by MCP `WorldGenClay` and `WorldGenSand`. The generator
/// first checks for water, then consumes exactly one radius draw and visits
/// the circular X/Z footprint and the vertical +/-1 or +/-2 band.
fn generate_vanilla_substrate_patch(
    region: &mut TerrainPopulationRegion, rng: &mut JavaRandom,
    x: i32, y: i32, z: i32, radius: u32, replacement: TerrainBlock, clay: bool,
) -> bool {
    if region.get_world(x, y, z) != Some(TerrainBlock::Water) { return false; }
    let r = rng.next_int(radius - 2).unwrap_or(0) as i32 + 2;
    let vertical = if clay { 1 } else { 2 };
    for wx in (x-r)..=(x+r) {
        for wz in (z-r)..=(z+r) {
            let dx=wx-x; let dz=wz-z;
            if dx*dx + dz*dz > r*r { continue; }
            for wy in (y-vertical)..=(y+vertical) {
                let old = region.get_world(wx,wy,wz);
                let replace = if clay { old == Some(TerrainBlock::Dirt) || old == Some(TerrainBlock::Clay) }
                    else { old == Some(TerrainBlock::Dirt) || old == Some(TerrainBlock::Grass) };
                if replace { region.set_world(wx,wy,wz,replacement); }
            }
        }
    }
    true
}

/// Runs the currently ported vanilla `BiomeDecorator` prefix in source order:
/// generateOres -> sand patches -> clay patch -> gravel-as-sand patch.
/// The caller must provide the shared chunk-population RNG and loaded 3x3 region.
pub fn populate_overworld_ores_and_substrate_with_rng(
    rng: &mut JavaRandom, chunk_x: i32, chunk_z: i32, region: &mut TerrainPopulationRegion,
) -> (OrePopulationStats, SubstratePatchStats) {
    let ores = populate_overworld_ores_in_region_with_rng(rng, chunk_x, chunk_z, region);
    let patches = decorate_overworld_substrate_patches(rng, chunk_x, chunk_z, region);
    (ores, patches)
}

/// Statistics for the tree stage of BiomeDecorator.genDecorations.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub struct TreePopulationStats { pub attempts: usize, pub oak: usize, pub birch: usize, pub big_tree: usize, pub mega_jungle: usize, pub jungle: usize, pub jungle_shrub: usize, pub spruce_taiga1: usize, pub spruce_taiga2: usize, pub mega_pine: usize, pub dark_oak: usize, pub failed: usize }

/// Runs the vanilla tree-attempt prefix for the supported forest and ordinary taiga families.
/// IDs 5/19/30/31 use the exact Taiga1/Taiga2 selector; mega-taiga species
/// remain intentionally deferred.
pub fn decorate_overworld_trees(
    rng: &mut JavaRandom, chunk_x: i32, chunk_z: i32, biome_id: i32,
    region: &mut TerrainPopulationRegion,
) -> TreePopulationStats {
    use self::biome_id as b;
    let (trees_per_chunk, forest_kind) = match biome_id {
        b::FOREST | b::FOREST_HILLS => (10_i32, 0_u8),
        b::BIRCH_FOREST | b::BIRCH_FOREST_HILLS => (10_i32, 2_u8),
        b::TAIGA | b::TAIGA_HILLS | b::COLD_TAIGA | b::COLD_TAIGA_HILLS | b::MEGA_TAIGA | b::MEGA_TAIGA_HILLS | b::MEGA_SPRUCE_TAIGA_MUTATED => (10_i32, 3_u8),
        b::JUNGLE | b::JUNGLE_HILLS => (50_i32, 4_u8),
        b::JUNGLE_EDGE => (2_i32, 5_u8),
        b::ROOFED_FOREST => return decorate_roofed_forest_trees(rng, chunk_x, chunk_z, region),
        _ => return TreePopulationStats::default(),
    };
    let mut count = trees_per_chunk;
    if rng.next_int(10) == Some(0) { count += 1; }
    let mut stats = TreePopulationStats { attempts: count as usize, ..Default::default() };
    let base_x = chunk_x * 16;
    let base_z = chunk_z * 16;
    for _ in 0..count {
        let x = base_x + rng.next_int(16).unwrap_or(0) as i32 + 8;
        let z = base_z + rng.next_int(16).unwrap_or(0) as i32 + 8;
        let pos_y = region.height_y(x, z).unwrap_or(0);
        if forest_kind == 4 || forest_kind == 5 {
            // BiomeGenJungle.genBigTreeChance: 1/10 big-tree branch (not yet ported),
            // then 1/2 shrub, then (only non-edge) 1/3 mega jungle, else WorldGenTrees.
            if rng.next_int(10) == Some(0) {
                if generate_vanilla_big_tree(region, rng, x, pos_y, z) { stats.big_tree += 1; } else { stats.failed += 1; }
                continue;
            }
            if rng.next_int(2) == Some(0) {
                if generate_vanilla_jungle_shrub(region, rng, x, pos_y, z) { stats.jungle_shrub += 1; } else { stats.failed += 1; }
                continue;
            }
            if forest_kind == 4 && rng.next_int(3) == Some(0) {
                if generate_vanilla_mega_jungle(region, rng, x, pos_y, z) { stats.mega_jungle += 1; } else { stats.failed += 1; }
                continue;
            }
            let min_height = 4 + rng.next_int(7).unwrap_or(0) as i32;
            if generate_vanilla_jungle_tree(region, rng, x, pos_y, z, min_height) { stats.jungle += 1; } else { stats.failed += 1; }
            continue;
        }
        if forest_kind == 3 {
            // BiomeGenTaiga(type 0/1/2) selector, preserving every conditional draw.
            let mega_biome = biome_id == b::MEGA_TAIGA || biome_id == b::MEGA_TAIGA_HILLS || biome_id == b::MEGA_SPRUCE_TAIGA_MUTATED;
            if mega_biome && rng.next_int(3) == Some(0) {
                // Type 1 uses mega pine 12/13 of the time; type 2 always uses
                // the base-height variant. Both share WorldGenMegaPineTree.
                let use_base_height = biome_id == b::MEGA_SPRUCE_TAIGA_MUTATED || rng.next_int(13) == Some(0);
                let generated = generate_vanilla_mega_pine_tree(region, rng, x, pos_y, z, use_base_height);
                if generated { stats.mega_pine += 1; } else { stats.failed += 1; }
            } else {
                let taiga1 = rng.next_int(3) == Some(0);
                let generated = if taiga1 { generate_vanilla_taiga1(region, rng, x, pos_y, z) }
                    else { generate_vanilla_taiga2(region, rng, x, pos_y, z) };
                if generated { if taiga1 { stats.spruce_taiga1 += 1; } else { stats.spruce_taiga2 += 1; } }
                else { stats.failed += 1; }
            }
            continue;
        }
        let birch = if forest_kind == 2 { true } else { rng.next_int(5) == Some(0) };
        // Forest subclass selection is handled in the forest-specific stage;
        // ordinary forest and birch species remain the supported generators.
        let generated = if birch { generate_vanilla_birch_tree(region, rng, x, pos_y, z) }
            else { generate_vanilla_oak_tree(region, rng, x, pos_y, z) };
        if generated { if birch { stats.birch += 1; } else { stats.oak += 1; } }
        else { stats.failed += 1; }
    }
    stats
}


/// MCP WorldGenTaiga1: narrow lower trunk, widening spruce crown.
fn generate_vanilla_taiga1(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, x: i32, y: i32, z: i32) -> bool {
    let height = rng.next_int(5).unwrap_or(0) as i32 + 7;
    let crown_start = height - rng.next_int(2).unwrap_or(0) as i32 - 3;
    let crown_depth = height - crown_start;
    let max_radius = 1 + rng.next_int((crown_depth + 1) as u32).unwrap_or(0) as i32;
    if y < 1 || y + height + 1 > 256 { return false; }
    for yy in y..=y+1+height {
        let radius = if yy-y < crown_start { 0 } else { max_radius };
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            if !tree_replaceable(region.get_world(xx,yy,zz)) { return false; }
        }}
    }
    if !matches!(region.get_world(x,y-1,z),Some(TerrainBlock::Grass|TerrainBlock::Dirt)) || y >= 256-height-1 { return false; }
    region.set_world(x,y-1,z,TerrainBlock::Dirt);
    let mut radius=0;
    for yy in (y+crown_start..=y+height).rev() {
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            let dx=xx-x; let dz=zz-z;
            if dx.abs()!=radius || dz.abs()!=radius || radius<=0 {
                if matches!(region.get_world(xx,yy,zz),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves)) {
                    region.set_world(xx,yy,zz,TerrainBlock::SpruceLeaves);
                }
            }
        }}
        if radius>=1 && yy==y+crown_start+1 { radius-=1; }
        else if radius<max_radius { radius+=1; }
    }
    for dy in 0..height-1 {
        if matches!(region.get_world(x,y+dy,z),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves)) {
            region.set_world(x,y+dy,z,TerrainBlock::SpruceLog);
        }
    }
    true
}

/// MCP WorldGenTaiga2: layered conical spruce crown with randomized top/bottom widths.
fn generate_vanilla_taiga2(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, x: i32, y: i32, z: i32) -> bool {
    let height = rng.next_int(4).unwrap_or(0) as i32 + 6;
    let crown_bottom = 1 + rng.next_int(2).unwrap_or(0) as i32;
    let crown_depth = height-crown_bottom;
    let max_radius = 2 + rng.next_int(2).unwrap_or(0) as i32;
    if y < 1 || y+height+1>256 { return false; }
    for yy in y..=y+1+height {
        let radius=if yy-y<crown_bottom {0} else {max_radius};
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            if !matches!(region.get_world(xx,yy,zz),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves)) { return false; }
        }}
    }
    if !matches!(region.get_world(x,y-1,z),Some(TerrainBlock::Grass|TerrainBlock::Dirt)) || y>=256-height-1 { return false; }
    region.set_world(x,y-1,z,TerrainBlock::Dirt);
    let mut radius=rng.next_int(2).unwrap_or(0) as i32;
    let mut step=1; let mut previous=0;
    for layer in 0..=crown_depth {
        let yy=y+height-layer;
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            let dx=xx-x; let dz=zz-z;
            if dx.abs()!=radius || dz.abs()!=radius || radius<=0 {
                if matches!(region.get_world(xx,yy,zz),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves)) {
                    region.set_world(xx,yy,zz,TerrainBlock::SpruceLeaves);
                }
            }
        }}
        if radius>=step { radius=previous; previous=1; step+=1; if step>max_radius {step=max_radius;} }
        else { radius+=1; }
    }
    let trunk_trim=rng.next_int(3).unwrap_or(0) as i32;
    for dy in 0..height-trunk_trim {
        if matches!(region.get_world(x,y+dy,z),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves)) {
            region.set_world(x,y+dy,z,TerrainBlock::SpruceLog);
        }
    }
    true
}

/// MCP WorldGenMegaPineTree(false, useBaseHeight), backed by WorldGenHugeTrees.
/// Includes its 2x2 trunk, circular layered crown, and post-generation podzol pass.
fn generate_vanilla_mega_pine_tree(
    region: &mut TerrainPopulationRegion, rng: &mut JavaRandom,
    x: i32, y: i32, z: i32, use_base_height: bool,
) -> bool {
    // WorldGenHugeTrees.func_150533_a: nextInt(3)+13, then nextInt(15).
    let height = 13 + rng.next_int(3).unwrap_or(0) as i32
        + rng.next_int(15).unwrap_or(0) as i32;
    if y < 1 || y + height + 1 > 256 { return false; }
    // WorldGenHugeTrees.func_175926_c: base radius 1, radius 2 above it.
    for dy in 0..=height + 1 {
        let radius = if dy == 0 { 1 } else { 2 };
        for dx in -radius..=radius { for dz in -radius..=radius {
            if !tree_replaceable(region.get_world(x + dx, y + dy, z + dz)) { return false; }
        }}
    }
    // WorldGenHugeTrees.func_175927_a validates a 2x2 grass/dirt base.
    for dx in 0..=1 { for dz in 0..=1 {
        if !matches!(region.get_world(x + dx, y - 1, z + dz), Some(TerrainBlock::Grass | TerrainBlock::Dirt)) { return false; }
    }}
    for dx in 0..=1 { for dz in 0..=1 { region.set_world(x + dx, y - 1, z + dz, TerrainBlock::Dirt); }}

    // WorldGenMegaPineTree.func_150541_c.
    let crown_height = rng.next_int(5).unwrap_or(0) as i32 + if use_base_height { 13 } else { 3 };
    let mut previous_radius = 0;
    for yy in (y + height - crown_height..=y + height).rev() {
        let remaining = y + height - yy;
        let mut radius = ((remaining as f32 / crown_height as f32) * 3.5).floor() as i32;
        if remaining > 0 && radius == previous_radius && yy & 1 == 0 { radius += 1; }
        place_mega_pine_leaf_layer(region, x, yy, z, radius);
        previous_radius = radius;
    }
    // WorldGenMegaPineTree.generate writes a 2x2 trunk for all but the top layer.
    for dy in 0..height {
        if matches!(region.get_world(x, y + dy, z), Some(TerrainBlock::Air | TerrainBlock::OakLeaves | TerrainBlock::BirchLeaves | TerrainBlock::SpruceLeaves | TerrainBlock::DarkOakLeaves)) {
            region.set_world(x, y + dy, z, TerrainBlock::SpruceLog);
        }
        if dy < height - 1 {
            for (dx, dz) in [(1,0),(1,1),(0,1)] {
                if matches!(region.get_world(x+dx,y+dy,z+dz),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::DarkOakLeaves)) {
                    region.set_world(x+dx,y+dy,z+dz,TerrainBlock::SpruceLog);
                }
            }
        }
    }
    // WorldGenMegaPineTree.func_180711_a: four guaranteed podzol patches,
    // then five random edge samples. This hook runs only after generate=true.
    for (dx,dz) in [(-1,-1),(2,-1),(-1,2),(2,2)] {
        mega_pine_podzol_patch(region,x+dx,y,z+dz);
    }
    for _ in 0..5 {
        let j = rng.next_int(64).unwrap_or(0) as i32;
        let k = j % 8; let l = j / 8;
        if k == 0 || k == 7 || l == 0 || l == 7 {
            mega_pine_podzol_patch(region,x-3+k,y,z-3+l);
        }
    }
    true
}

fn place_mega_pine_leaf_layer(region: &mut TerrainPopulationRegion, x: i32, y: i32, z: i32, radius: i32) {
    let rr = radius * radius;
    for dx in -radius..=radius+1 { for dz in -radius..=radius+1 {
        let a=dx; let b=dz; let c=dx-1; let d=dz-1;
        if a*a+b*b<=rr || c*c+d*d<=rr || a*a+d*d<=rr || c*c+b*b<=rr {
            if matches!(region.get_world(x+dx,y,z+dz),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::DarkOakLeaves)) {
                region.set_world(x+dx,y,z+dz,TerrainBlock::SpruceLeaves);
            }
        }
    }}
}

fn mega_pine_podzol_patch(region: &mut TerrainPopulationRegion, x: i32, y: i32, z: i32) {
    for dx in -2_i32..=2_i32 { for dz in -2_i32..=2_i32 {
        if dx.abs()==2 && dz.abs()==2 { continue; }
        for dy in ( -3..=2).rev() {
            match region.get_world(x+dx,y+dy,z+dz) {
                Some(TerrainBlock::Grass|TerrainBlock::Dirt) => { region.set_world(x+dx,y+dy,z+dz,TerrainBlock::Podzol); break; }
                Some(TerrainBlock::Air) => {},
                Some(_) if dy < 0 => break,
                Some(_) => {},
                None => break,
            }
        }
    }}
}

/// MCP WorldGenBigTree(false). Its private java.util.Random is seeded from exactly
/// one nextLong() of the population stream, as in the original implementation.
fn generate_vanilla_big_tree(region: &mut TerrainPopulationRegion, population_rng: &mut JavaRandom, x: i32, y: i32, z: i32) -> bool {
    let mut rng = JavaRandom::new(population_rng.next_long());
    let mut height_limit = 5 + rng.next_int(12).unwrap_or(0) as i32;
    if !matches!(region.get_world(x,y-1,z),Some(TerrainBlock::Grass|TerrainBlock::Dirt)) { return false; }
    if let Some(obstruction) = big_tree_line_distance(region, (x,y,z), (x,y+height_limit-1,z)) {
        if obstruction < 6 { return false; }
        height_limit = obstruction;
    }
    let height = ((height_limit as f64 * 0.618) as i32).min(height_limit-1);
    let node_count = (1.382 + (height_limit as f64 / 13.0).powi(2)) as i32;
    let node_count = node_count.max(1);
    let mut nodes: Vec<((i32,i32,i32),i32)> = Vec::new();
    let top_y = y + height;
    let mut k = height_limit - 4;
    nodes.push(((x,y+k,z),top_y));
    while k >= 0 {
        let layer = big_tree_layer_size(height_limit,k);
        if layer >= 0.0 {
            for _ in 0..node_count {
                let d0 = layer as f64 * (rng.next_float() as f64 + 0.328);
                let angle = rng.next_float() as f64 * 2.0 * std::f64::consts::PI;
                let bx = x + (d0 * angle.sin() + 0.5).floor() as i32;
                let bz = z + (d0 * angle.cos() + 0.5).floor() as i32;
                let by = y + k - 1;
                if big_tree_line_clear(region,(bx,by,bz),(bx,by+4,bz)) {
                    let dx=x-bx; let dz=z-bz;
                    let target=((by as f64 - ((dx*dx+dz*dz) as f64).sqrt()*0.381).min(top_y as f64)) as i32;
                    if big_tree_line_clear(region,(x,target,z),(bx,by,bz)) { nodes.push(((bx,by,bz),target)); }
                }
            }
        }
        k-=1;
    }
    // Leaves first, as in WorldGenBigTree.generate().
    for (pos,_) in &nodes {
        for layer in 0..4 {
            let radius: i32=if layer==0 || layer==3 {2} else {3};
            for dx in -radius..=radius { for dz in -radius..=radius {
                if ((dx.abs() as f64+0.5).powi(2)+(dz.abs() as f64+0.5).powi(2)) <= (radius as f64).powi(2) {
                    let q=(pos.0+dx,pos.1+layer,pos.2+dz);
                    if matches!(region.get_world(q.0,q.1,q.2),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::DarkOakLeaves|TerrainBlock::JungleLeaves)) { region.set_world(q.0,q.1,q.2,TerrainBlock::OakLeaves); }
                }
            }}
        }
    }
    // Branches to leaf-node bases, then central trunk.
    for (pos,base_y) in &nodes {
        let start=(x,*base_y,z);
        if start != *pos && (*base_y-y) as f64 >= height_limit as f64*0.2 { big_tree_draw_line(region,start,*pos,TerrainBlock::OakLog); }
    }
    big_tree_draw_line(region,(x,y,z),(x,y+height,z),TerrainBlock::OakLog);
    true
}

fn big_tree_layer_size(height_limit:i32, layer:i32)->f32 {
    if (layer as f32) < height_limit as f32*0.3 { return -1.0; }
    let half=height_limit as f32/2.0; let d=half-layer as f32;
    if d.abs()>=half { return if d==0.0 {half*0.5} else {0.0}; }
    (half*half-d*d).sqrt()*0.5
}

fn big_tree_line_distance(region:&TerrainPopulationRegion,a:(i32,i32,i32),b:(i32,i32,i32))->Option<i32> {
    let dx=b.0-a.0; let dy=b.1-a.1; let dz=b.2-a.2;
    let steps=dx.abs().max(dy.abs()).max(dz.abs());
    if steps==0 { return None; }
    let fx=dx as f32/steps as f32; let fy=dy as f32/steps as f32; let fz=dz as f32/steps as f32;
    for i in 0..=steps {
        let q=(a.0+(0.5_f32+i as f32*fx).floor() as i32,a.1+(0.5_f32+i as f32*fy).floor() as i32,a.2+(0.5_f32+i as f32*fz).floor() as i32);
        if !tree_replaceable(region.get_world(q.0,q.1,q.2)) { return Some(i); }
    }
    None
}
fn big_tree_line_clear(region:&TerrainPopulationRegion,a:(i32,i32,i32),b:(i32,i32,i32))->bool { big_tree_line_distance(region,a,b).is_none() }

fn big_tree_draw_line(region:&mut TerrainPopulationRegion,a:(i32,i32,i32),b:(i32,i32,i32),block:TerrainBlock) {
    let dx=b.0-a.0; let dy=b.1-a.1; let dz=b.2-a.2;
    let steps=dx.abs().max(dy.abs()).max(dz.abs());
    if steps==0 { region.set_world(a.0,a.1,a.2,block); return; }
    let fx=dx as f32/steps as f32; let fy=dy as f32/steps as f32; let fz=dz as f32/steps as f32;
    for i in 0..=steps {
        let q=(a.0+(0.5_f32+i as f32*fx).floor() as i32,a.1+(0.5_f32+i as f32*fy).floor() as i32,a.2+(0.5_f32+i as f32*fz).floor() as i32);
        let placed = if block == TerrainBlock::OakLog {
            let ax=(q.0-a.0).abs(); let az=(q.2-a.2).abs();
            if ax.max(az)==0 { TerrainBlock::OakLog } else if ax>=az { TerrainBlock::OakLogX } else { TerrainBlock::OakLogZ }
        } else { block };
        region.set_world(q.0,q.1,q.2,placed);
    }
}

/// MCP WorldGenMegaJungle(false, 10, 20, jungle log, jungle leaves).
fn generate_vanilla_mega_jungle(region:&mut TerrainPopulationRegion,rng:&mut JavaRandom,x:i32,y:i32,z:i32)->bool {
    let height=10+rng.next_int(3).unwrap_or(0) as i32+rng.next_int(20).unwrap_or(0) as i32;
    if y<1 || y+height+1>256 { return false; }
    for dy in 0..=height+1 { let r=if dy==0 {1} else {2}; for dx in -r..=r { for dz in -r..=r { if !tree_replaceable(region.get_world(x+dx,y+dy,z+dz)) { return false; } } } }
    if !matches!(region.get_world(x,y-1,z),Some(TerrainBlock::Grass|TerrainBlock::Dirt)) || y<2 { return false; }
    for (dx,dz) in [(0,0),(1,0),(0,1),(1,1)] { region.set_world(x+dx,y-1,z+dz,TerrainBlock::Dirt); }
    // WorldGenMegaJungle.func_175930_c: three circular crown layers at top-2..top.
    for layer in -2..=0 {
        let radius=2+1-layer;
        let yy=y+height+layer;
        for dx in -radius..=radius+1 { for dz in -radius..=radius+1 {
            let ax=dx-1; let az=dz-1;
            if dx*dx+dz*dz<=radius*radius || ax*ax+az*az<=radius*radius || dx*dx+az*az<=radius*radius || ax*ax+dz*dz<=radius*radius {
                let q=(x+dx,yy,z+dz); if matches!(region.get_world(q.0,q.1,q.2),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::JungleLeaves)) { region.set_world(q.0,q.1,q.2,TerrainBlock::JungleLeaves); }
            }
        }}
    }
    // Source order: first branch level, then one angle, five wood positions, crown size.
    let mut branch_y=y+height-2-rng.next_int(4).unwrap_or(0) as i32;
    while branch_y>y+height/2 {
        let angle=rng.next_float()*std::f32::consts::PI*2.0;
        let mut bx=x+(0.5+mc_cos(angle)*4.0) as i32;
        let mut bz=z+(0.5+mc_sin(angle)*4.0) as i32;
        for i in 0..5 {
            bx=x+(1.5+mc_cos(angle)*i as f32) as i32;
            bz=z+(1.5+mc_sin(angle)*i as f32) as i32;
            region.set_world(bx,branch_y-3+i/2,bz,TerrainBlock::JungleLog);
        }
        let crown=1+rng.next_int(2).unwrap_or(0) as i32;
        for yy in branch_y-crown..=branch_y {
            let layer=yy-branch_y; let radius=1-layer;
            for dx in -radius..=radius { for dz in -radius..=radius {
                if dx*dx+dz*dz<=radius*radius && matches!(region.get_world(bx+dx,yy,bz+dz),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::JungleLeaves)) { region.set_world(bx+dx,yy,bz+dz,TerrainBlock::JungleLeaves); }
            }}
        }
        branch_y-=2+rng.next_int(4).unwrap_or(0) as i32;
    }
    // Main 2x2 trunk and conditional vine attachments.
    for dy in 0..height {
        let positions=[(x,y+dy,z),(x+1,y+dy,z),(x+1,y+dy,z+1),(x,y+dy,z+1)];
        for (idx,(tx,ty,tz)) in positions.into_iter().enumerate() {
            if idx==0 || dy<height-1 {
                if tree_replaceable(region.get_world(tx,ty,tz)) { region.set_world(tx,ty,tz,TerrainBlock::JungleLog); }
                if dy>0 {
                    let attachments=match idx {0=>[(tx-1,ty,tz,TerrainBlock::VineEast),(tx,ty,tz-1,TerrainBlock::VineSouth)],1=>[(tx+1,ty,tz,TerrainBlock::VineWest),(tx,ty,tz-1,TerrainBlock::VineSouth)],2=>[(tx+1,ty,tz,TerrainBlock::VineWest),(tx,ty,tz+1,TerrainBlock::VineNorth)],_=>[(tx-1,ty,tz,TerrainBlock::VineEast),(tx,ty,tz+1,TerrainBlock::VineNorth)]};
                    for (vx,vy,vz,vine) in attachments { if rng.next_int(3).unwrap_or(0)>0 && region.get_world(vx,vy,vz)==Some(TerrainBlock::Air) { region.set_world(vx,vy,vz,vine); } }
                }
            }
        }
    }
    // Leaf-face vines: scan crown volume and consume four independent draws per leaf.
    for yy in y+height-3..=y+height { let rel=yy-(y+height); let radius=2-rel/2; for dx in -radius..=radius { for dz in -radius..=radius {
        if !matches!(region.get_world(x+dx,yy,z+dz),Some(TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::DarkOakLeaves|TerrainBlock::JungleLeaves)) { continue; }
        for (vx,vz,vine) in [(x+dx-1,z+dz,TerrainBlock::VineEast),(x+dx+1,z+dz,TerrainBlock::VineWest),(x+dx,z+dz-1,TerrainBlock::VineSouth),(x+dx,z+dz+1,TerrainBlock::VineNorth)] {
            if rng.next_int(4)==Some(0) && region.get_world(vx,yy,vz)==Some(TerrainBlock::Air) { let mut vy=yy; for _ in 0..5 { if region.get_world(vx,vy,vz)!=Some(TerrainBlock::Air) { break; } region.set_world(vx,vy,vz,vine); vy-=1; } }
        }
    }}}
    true
}

#[inline]
fn mc_sin(angle:f32)->f32 { minecraft_math_helper_sin(angle) }
#[inline]
fn mc_cos(angle:f32)->f32 { minecraft_math_helper_sin(angle+std::f32::consts::FRAC_PI_2) }

/// MCP WorldGenTrees(false, 4..10, jungle wood/leaves, vinesGrow=true).
/// The tree's leaf and trunk passes retain their conditional JavaRandom draws.
fn generate_vanilla_jungle_tree(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, x: i32, y: i32, z: i32, min_height: i32) -> bool {
    let height = rng.next_int(3).unwrap_or(0) as i32 + min_height;
    if y < 1 || y + height + 1 > 256 { return false; }
    for yy in y..=y+1+height {
        let radius = if yy == y { 0 } else if yy >= y+1+height-2 { 2 } else { 1 };
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            if !tree_replaceable(region.get_world(xx,yy,zz)) { return false; }
        }}
    }
    if !matches!(region.get_world(x,y-1,z),Some(TerrainBlock::Grass|TerrainBlock::Dirt)) || y >= 256-height-1 { return false; }
    region.set_world(x,y-1,z,TerrainBlock::Dirt);
    for yy in y-3+height..=y+height {
        let i4=yy-(y+height); let radius=1-i4/2;
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            let dx=xx-x; let dz=zz-z;
            if dx.abs()!=radius || dz.abs()!=radius || rng.next_int(2)!=Some(0) || i4==0 {
                if matches!(region.get_world(xx,yy,zz),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::DarkOakLeaves|TerrainBlock::JungleLeaves|TerrainBlock::VineNorth|TerrainBlock::VineEast|TerrainBlock::VineSouth|TerrainBlock::VineWest)) {
                    region.set_world(xx,yy,zz,TerrainBlock::JungleLeaves);
                }
            }
        }}
    }
    for dy in 0..height {
        if matches!(region.get_world(x,y+dy,z),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::DarkOakLeaves|TerrainBlock::JungleLeaves|TerrainBlock::VineNorth|TerrainBlock::VineEast|TerrainBlock::VineSouth|TerrainBlock::VineWest)) {
            region.set_world(x,y+dy,z,TerrainBlock::JungleLog);
            if dy>0 {
                // WorldGenTrees vinesGrow trunk attachments: nextInt(3)>0 then air test.
                for (dx,dz,vine) in [(-1,0,TerrainBlock::VineEast),(1,0,TerrainBlock::VineWest),(0,-1,TerrainBlock::VineSouth),(0,1,TerrainBlock::VineNorth)] {
                    if rng.next_int(3).unwrap_or(0)>0 && region.get_world(x+dx,y+dy,z+dz)==Some(TerrainBlock::Air) {
                        region.set_world(x+dx,y+dy,z+dz,vine);
                    }
                }
            }
        }
    }
    // Leaf-edge vines. The vanilla generator scans its leaf envelope and draws
    // independently for each of the four faces; vines extend down at most four blocks.
    for yy in y-3+height..=y+height {
        let i4=yy-(y+height); let radius=2-i4/2;
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            if !matches!(region.get_world(xx,yy,zz),Some(TerrainBlock::JungleLeaves)) { continue; }
            for (dx,dz,vine) in [(-1,0,TerrainBlock::VineEast),(1,0,TerrainBlock::VineWest),(0,-1,TerrainBlock::VineSouth),(0,1,TerrainBlock::VineNorth)] {
                if rng.next_int(4)==Some(0) && region.get_world(xx+dx,yy,zz+dz)==Some(TerrainBlock::Air) {
                    let mut vy=yy;
                    for _ in 0..5 {
                        if region.get_world(xx+dx,vy,zz+dz)!=Some(TerrainBlock::Air) { break; }
                        region.set_world(xx+dx,vy,zz+dz,vine);
                        vy-=1;
                    }
                }
            }
        }}
    }
    // Cocoa pod placement is intentionally deferred; the vanilla RNG branch is
    // variable and will be ported with the cocoa block-state representation.
    if rng.next_int(5)==Some(0) && height>5 {
        for layer in 0..2 { for _facing in 0..4 {
            if rng.next_int((4-layer) as u32)==Some(0) { let _age=rng.next_int(3); }
        }}
    }
    true
}

/// MCP WorldGenShrub with jungle log and oak leaves.
fn generate_vanilla_jungle_shrub(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, x: i32, mut y: i32, z: i32) -> bool {
    while y>0 && matches!(region.get_world(x,y,z),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::DarkOakLeaves|TerrainBlock::JungleLeaves)) { y-=1; }
    if !matches!(region.get_world(x,y,z),Some(TerrainBlock::Grass|TerrainBlock::Dirt)) { return true; }
    y+=1;
    region.set_world(x,y,z,TerrainBlock::JungleLog);
    for dy in 0..=2 {
        let radius: i32=2-dy;
        for dx in -radius..=radius { for dz in -radius..=radius {
            if dx.abs()!=radius || dz.abs()!=radius || rng.next_int(2)!=Some(0) {
                if matches!(region.get_world(x+dx,y+dy,z+dz),Some(TerrainBlock::Air)) { region.set_world(x+dx,y+dy,z+dz,TerrainBlock::OakLeaves); }
            }
        }}
    }
    true
}

#[inline]
fn tree_replaceable(block: Option<TerrainBlock>) -> bool {
    matches!(block,Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::DarkOakLeaves|TerrainBlock::Grass|TerrainBlock::Dirt|TerrainBlock::OakLog|TerrainBlock::BirchLog|TerrainBlock::SpruceLog|TerrainBlock::DarkOakLog|TerrainBlock::OakLogX|TerrainBlock::OakLogZ|TerrainBlock::JungleLog|TerrainBlock::JungleLeaves|TerrainBlock::VineNorth|TerrainBlock::VineEast|TerrainBlock::VineSouth|TerrainBlock::VineWest))
}

/// MCP WorldGenTrees(false): exact height/clearance/leaf-layer/trunk random
/// sequence for the ordinary oak tree, omitting only world notifications.
fn generate_vanilla_oak_tree(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, x: i32, y: i32, z: i32) -> bool {
    let height = rng.next_int(3).unwrap_or(0) as i32 + 4;
    if y < 1 || y + height + 1 > 256 { return false; }
    for yy in y..=y + 1 + height {
        let radius = if yy == y { 0 } else if yy >= y + 1 + height - 2 { 2 } else { 1 };
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            let Some(block) = region.get_world(xx, yy, zz) else { return false; };
            if !matches!(block, TerrainBlock::Air | TerrainBlock::Grass | TerrainBlock::Dirt | TerrainBlock::OakLog | TerrainBlock::BirchLog | TerrainBlock::SpruceLog | TerrainBlock::OakLeaves | TerrainBlock::BirchLeaves | TerrainBlock::SpruceLeaves) { return false; }
        }}
    }
    if !matches!(region.get_world(x, y-1, z), Some(TerrainBlock::Grass | TerrainBlock::Dirt)) || y >= 256-height-1 { return false; }
    region.set_world(x, y-1, z, TerrainBlock::Dirt);
    for yy in y-3+height..=y+height {
        let layer = yy-(y+height);
        let radius = 1-layer/2;
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            let dx=xx-x; let dz=zz-z;
            if dx.abs()!=radius || dz.abs()!=radius || (rng.next_int(2)!=Some(0) && layer!=0) {
                if matches!(region.get_world(xx,yy,zz), Some(TerrainBlock::Air | TerrainBlock::OakLeaves | TerrainBlock::BirchLeaves | TerrainBlock::SpruceLeaves)) {
                    region.set_world(xx,yy,zz,TerrainBlock::OakLeaves);
                }
            }
        }}
    }
    for dy in 0..height {
        if matches!(region.get_world(x,y+dy,z), Some(TerrainBlock::Air | TerrainBlock::OakLeaves | TerrainBlock::BirchLeaves | TerrainBlock::SpruceLeaves)) {
            region.set_world(x,y+dy,z,TerrainBlock::OakLog);
        }
    }
    true
}

/// MCP WorldGenForest(false,false): birch tree used by forest and birch biomes.
fn generate_vanilla_birch_tree(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, x: i32, y: i32, z: i32) -> bool {
    let height = rng.next_int(3).unwrap_or(0) as i32 + 5;
    if y < 1 || y + height + 1 > 256 { return false; }
    for yy in y..=y+1+height {
        let radius = if yy == y { 0 } else if yy >= y+1+height-2 { 2 } else { 1 };
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            let Some(block)=region.get_world(xx,yy,zz) else { return false; };
            if !matches!(block,TerrainBlock::Air|TerrainBlock::Grass|TerrainBlock::Dirt|TerrainBlock::OakLog|TerrainBlock::OakLogX|TerrainBlock::OakLogZ|TerrainBlock::BirchLog|TerrainBlock::SpruceLog|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves) { return false; }
        }}
    }
    if !matches!(region.get_world(x,y-1,z),Some(TerrainBlock::Grass|TerrainBlock::Dirt)) || y>=256-height-1 { return false; }
    region.set_world(x,y-1,z,TerrainBlock::Dirt);
    for yy in y-3+height..=y+height {
        let layer=yy-(y+height); let radius=1-layer/2;
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            let dx=xx-x; let dz=zz-z;
            if dx.abs()!=radius || dz.abs()!=radius || (rng.next_int(2)!=Some(0) && layer!=0) {
                if matches!(region.get_world(xx,yy,zz),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves)) { region.set_world(xx,yy,zz,TerrainBlock::BirchLeaves); }
            }
        }}
    }
    for dy in 0..height {
        if matches!(region.get_world(x,y+dy,z),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves)) { region.set_world(x,y+dy,z,TerrainBlock::BirchLog); }
    }
    true
}


/// Roofed Forest's special 4x4 tree placement loop from BiomeGenForest.decorate.
/// The 20-way mushroom branch is deliberately skipped as mushroom generators
/// are not yet part of the feature pipeline; its random draw is still consumed.
fn decorate_roofed_forest_trees(rng: &mut JavaRandom, chunk_x: i32, chunk_z: i32, region: &mut TerrainPopulationRegion) -> TreePopulationStats {
    let mut stats = TreePopulationStats::default();
    let bx=chunk_x*16; let bz=chunk_z*16;
    for ix in 0..4 { for iz in 0..4 {
        let x=bx+ix*4+9+rng.next_int(3).unwrap_or(0) as i32;
        let z=bz+iz*4+9+rng.next_int(3).unwrap_or(0) as i32;
        let y=region.height_y(x,z).unwrap_or(0);
        stats.attempts+=1;
        if rng.next_int(20)==Some(0) {
            // Vanilla creates a big mushroom here. Keep the branch's generator
            // boundary explicit until WorldGenBigMushroom is ported.
            stats.failed+=1;
            continue;
        }
        // BiomeGenForest(type=3).genBigTreeChance(Random): canopy for 2/3;
        // otherwise fall through to the vanilla oak/birch selector.
        let tree_kind=if rng.next_int(3).unwrap_or(0)>0 { 2 } else if rng.next_int(5).unwrap_or(0)!=0 { 0 } else { 1 };
        let ok=if tree_kind==2 { generate_vanilla_canopy_tree(region,rng,x,y,z) }
            else if tree_kind==1 { generate_vanilla_birch_tree(region,rng,x,y,z) }
            else { generate_vanilla_oak_tree(region,rng,x,y,z) };
        if ok { if tree_kind==2 {stats.dark_oak+=1;} else if tree_kind==1 {stats.birch+=1;} else {stats.oak+=1;} }
        else {stats.failed+=1;}
    }}
    stats
}

/// MCP WorldGenCanopyTree(false), including its 2x2 trunk, offset crown,
/// random horizontal bend, branch roots, and dark-oak leaf metadata.
fn generate_vanilla_canopy_tree(region:&mut TerrainPopulationRegion,rng:&mut JavaRandom,x:i32,y:i32,z:i32)->bool {
    let height=rng.next_int(3).unwrap_or(0) as i32 + rng.next_int(2).unwrap_or(0) as i32 + 6;
    if y<1 || y+height+1>=256 {return false;}
    if !matches!(region.get_world(x,y-1,z),Some(TerrainBlock::Grass|TerrainBlock::Dirt)) {return false;}
    // func_181638_a: clearance radii 0, 1, then 2 in the top two layers.
    for dy in 0..=height+1 {
        let r=if dy==0 {0} else if dy>=height-1 {2} else {1};
        for dx in -r..=r {for dz in -r..=r {
            if !tree_replaceable(region.get_world(x+dx,y+dy,z+dz)) {return false;}
        }}
    }
    for dx in 0..=1 {for dz in 0..=1 {region.set_world(x+dx,y-1,z+dz,TerrainBlock::Dirt);}}
    let facing=rng.next_int(4).unwrap_or(0) as i32;
    let (fx,fz)=match facing {0=>(0,-1),1=>(1,0),2=>(0,1),_=>(-1,0)};
    let bend_start=height-rng.next_int(4).unwrap_or(0) as i32;
    let mut bend_left=2-rng.next_int(3).unwrap_or(0) as i32;
    let mut tx=x; let mut tz=z; let crown_y=y+height-1;
    for dy in 0..height {
        if dy>=bend_start && bend_left>0 {tx+=fx;tz+=fz;bend_left-=1;}
        let yy=y+dy;
        if matches!(region.get_world(tx,yy,tz),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::DarkOakLeaves)) {
            for dx in 0..=1 {for dz in 0..=1 {set_dark_oak_log_if_replaceable(region,tx+dx,yy,tz+dz);}}
        }
    }
    // Two crown layers around the terminal 2x2 trunk; this is the symmetric
    // four-quadrant placement from MCP's func_150526_a loops.
    for dx in -2..=0 {for dz in -2..=0 {
        set_dark_oak_leaf_if_air(region,tx+dx,crown_y-1,tz+dz);
        set_dark_oak_leaf_if_air(region,tx+1-dx,crown_y-1,tz+dz);
        set_dark_oak_leaf_if_air(region,tx+dx,crown_y-1,tz+1-dz);
        set_dark_oak_leaf_if_air(region,tx+1-dx,crown_y-1,tz+1-dz);
        if (dx > -2 || dz > -1) && (dx != -1 || dz != -2) {
            set_dark_oak_leaf_if_air(region,tx+dx,crown_y+1,tz+dz);
            set_dark_oak_leaf_if_air(region,tx+1-dx,crown_y+1,tz+dz);
            set_dark_oak_leaf_if_air(region,tx+dx,crown_y+1,tz+1-dz);
            set_dark_oak_leaf_if_air(region,tx+1-dx,crown_y+1,tz+1-dz);
        }
    }}
    if rng.next_int(2)==Some(0) {for dx in 0..=1 {for dz in 0..=1 {set_dark_oak_leaf_if_air(region,tx+dx,crown_y+2,tz+dz);}}}
    for dx in -3_i32..=4_i32 {for dz in -3_i32..=4_i32 {
        let corner=(dx==-3||dx==4)&&(dz==-3||dz==4);
        if !corner && (dx.abs()<3 || dz.abs()<3) {set_dark_oak_leaf_if_air(region,tx+dx,crown_y,tz+dz);}
    }}
    // Four by four branch candidate positions. Each eligible candidate draws
    // nextInt(3); successful branches then draw their length and place foliage.
    for bx in -1..=2 {for bz in -1..=2 {
        if (bx<0||bx>1||bz<0||bz>1) && rng.next_int(3)==Some(0) {
            let len=rng.next_int(3).unwrap_or(0) as i32+2;
            for n in 0..len {set_dark_oak_log_if_replaceable(region,x+bx,y+height-2-n,z+bz);}
            for dx in -1..=1 {for dz in -1..=1 {set_dark_oak_leaf_if_air(region,tx+bx+dx,crown_y,tz+bz+dz);}}
            for dx in -2_i32..=2_i32 {for dz in -2_i32..=2_i32 {if dx.abs()!=2||dz.abs()!=2 {set_dark_oak_leaf_if_air(region,tx+bx+dx,crown_y-1,tz+bz+dz);}}}
        }
    }}
    true
}
fn set_dark_oak_log_if_replaceable(r:&mut TerrainPopulationRegion,x:i32,y:i32,z:i32){if tree_replaceable(r.get_world(x,y,z)){r.set_world(x,y,z,TerrainBlock::DarkOakLog);}}
fn set_dark_oak_leaf_if_air(r:&mut TerrainPopulationRegion,x:i32,y:i32,z:i32){if r.get_world(x,y,z)==Some(TerrainBlock::Air){r.set_world(x,y,z,TerrainBlock::DarkOakLeaves);}}

/// Ordered ported prefix: ores -> sand/clay/gravel -> forest tree attempts.
pub fn populate_overworld_ores_substrate_trees_with_rng(
    rng: &mut JavaRandom, chunk_x: i32, chunk_z: i32, biome_id: i32,
    region: &mut TerrainPopulationRegion,
) -> (OrePopulationStats, SubstratePatchStats, TreePopulationStats) {
    let (ores, patches) = populate_overworld_ores_and_substrate_with_rng(rng, chunk_x, chunk_z, region);
    let trees = decorate_overworld_trees(rng, chunk_x, chunk_z, biome_id, region);
    (ores, patches, trees)
}

/// Statistics for the vanilla big-mushroom decoration pass.
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
pub struct BigMushroomStats { pub attempts: usize, pub brown: usize, pub red: usize, pub failed: usize }

/// Places one MCP 1.8.9 WorldGenBigMushroom. Ok(true) means red,
/// Ok(false) means brown; Err means placement failed or the RNG draw failed.
pub fn generate_vanilla_big_mushroom(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, mushroom_type_red: &mut Option<bool>, x: i32, y: i32, z: i32) -> Result<bool, ()> {
    // WorldGenBigMushroom retains the randomly selected block in its instance.
    let red = match *mushroom_type_red { Some(value) => value, None => { let value=rng.next_boolean(); *mushroom_type_red=Some(value); value } };
    let height = rng.next_int(3).ok_or(())? as i32 + 4;
    if y < 1 || y + height + 1 >= 256 { return Err(()); }
    for yy in y..=y+1+height {
        let radius = if yy <= y+3 { 0 } else { 3 };
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            if !matches!(region.get_world(xx,yy,zz), Some(TerrainBlock::Air | TerrainBlock::OakLeaves | TerrainBlock::BirchLeaves | TerrainBlock::SpruceLeaves | TerrainBlock::DarkOakLeaves | TerrainBlock::JungleLeaves)) { return Err(()); }
        }}
    }
    if !matches!(region.get_world(x,y-1,z),Some(TerrainBlock::Dirt|TerrainBlock::Grass|TerrainBlock::Mycelium)) { return Err(()); }
    let cap_bottom = if red { y+height-3 } else { y+height };
    for yy in cap_bottom..=y+height {
        let radius = if red { if yy < y+height { 2 } else { 1 } } else { 3 };
        for xx in x-radius..=x+radius { for zz in z-radius..=z+radius {
            let mut meta = 5i32;
            if xx == x-radius { meta -= 1; } else if xx == x+radius { meta += 1; }
            if zz == z-radius { meta -= 3; } else if zz == z+radius { meta += 3; }
            if (red || yy < y+height) && (xx == x-radius || xx == x+radius) && (zz == z-radius || zz == z+radius) { continue; }
            if !red || yy < y+height {
                if xx == x-radius+1 && zz == z-radius { meta=1; }
                if xx == x-radius && zz == z-radius+1 { meta=1; }
                if xx == x+radius-1 && zz == z-radius { meta=3; }
                if xx == x+radius && zz == z-radius+1 { meta=3; }
                if xx == x-radius+1 && zz == z+radius { meta=7; }
                if xx == x-radius && zz == z+radius-1 { meta=7; }
                if xx == x+radius-1 && zz == z+radius { meta=9; }
                if xx == x+radius && zz == z+radius-1 { meta=9; }
            }
            if meta == 5 && yy < y+height { meta=0; }
            if y >= y+height-1 || meta != 0 {
                let replaceable = matches!(region.get_world(xx,yy,zz),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::DarkOakLeaves|TerrainBlock::JungleLeaves));
                if replaceable {
                    let b = if red { match meta {0=>TerrainBlock::MushroomRed0,1=>TerrainBlock::MushroomRed1,2=>TerrainBlock::MushroomRed2,3=>TerrainBlock::MushroomRed3,4=>TerrainBlock::MushroomRed4,5=>TerrainBlock::MushroomRed5,6=>TerrainBlock::MushroomRed6,7=>TerrainBlock::MushroomRed7,8=>TerrainBlock::MushroomRed8,9=>TerrainBlock::MushroomRed9,_=>TerrainBlock::MushroomRed10} } else { match meta {0=>TerrainBlock::MushroomBrown0,1=>TerrainBlock::MushroomBrown1,2=>TerrainBlock::MushroomBrown2,3=>TerrainBlock::MushroomBrown3,4=>TerrainBlock::MushroomBrown4,5=>TerrainBlock::MushroomBrown5,6=>TerrainBlock::MushroomBrown6,7=>TerrainBlock::MushroomBrown7,8=>TerrainBlock::MushroomBrown8,9=>TerrainBlock::MushroomBrown9,_=>TerrainBlock::MushroomBrown10} };
                    region.set_world(xx,yy,zz,b);
                }
            }
        }}
    }
    for dy in 0..height {
        if matches!(region.get_world(x,y+dy,z),Some(TerrainBlock::Air|TerrainBlock::OakLeaves|TerrainBlock::BirchLeaves|TerrainBlock::SpruceLeaves|TerrainBlock::DarkOakLeaves|TerrainBlock::JungleLeaves)) {
            region.set_world(x,y+dy,z,if red {TerrainBlock::MushroomRed10} else {TerrainBlock::MushroomBrown10});
        }
    }
    Ok(red)
}

/// Vanilla BiomeDecorator bigMushroomsPerChunk loop; call after tree attempts.
pub fn decorate_overworld_big_mushrooms(rng: &mut JavaRandom, chunk_x: i32, chunk_z: i32, count: usize, region: &mut TerrainPopulationRegion) -> BigMushroomStats {
    let mut stats=BigMushroomStats { attempts:count, ..Default::default() };
    let mut mushroom_type_red=None; // retained by the vanilla generator instance
    for _ in 0..count {
        let x=chunk_x*16+rng.next_int(16).unwrap_or(0) as i32+8;
        let z=chunk_z*16+rng.next_int(16).unwrap_or(0) as i32+8;
        let y=region.height_y(x,z).unwrap_or(0);
        match generate_vanilla_big_mushroom(region,rng,&mut mushroom_type_red,x,y,z) { Ok(true)=>stats.red+=1, Ok(false)=>stats.brown+=1, Err(())=>stats.failed+=1 }
    }
    stats
}

/// Ordered BiomeDecorator prefix through the big-mushroom stage: ores,
/// substrate patches, trees, then big mushrooms. The mushroom count is supplied
/// from the biome's `bigMushroomsPerChunk` field (normally zero; mushroom island: one).
pub fn populate_overworld_prefix_with_big_mushrooms(
    rng: &mut JavaRandom, chunk_x: i32, chunk_z: i32, biome_id: i32, big_mushroom_count: usize,
    region: &mut TerrainPopulationRegion,
) -> (OrePopulationStats, SubstratePatchStats, TreePopulationStats, BigMushroomStats) {
    let (ores, patches, trees) = populate_overworld_ores_substrate_trees_with_rng(rng, chunk_x, chunk_z, biome_id, region);
    let mushrooms = decorate_overworld_big_mushrooms(rng, chunk_x, chunk_z, big_mushroom_count, region);
    (ores, patches, trees, mushrooms)
}

/// Result of the terrain-generation stage of an overworld chunk. This is the
/// ordered `ChunkProviderGenerate.provideChunk` terrain pipeline only; feature
/// population (ores, trees, lakes, structures, snow placement) is a later pass.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct GeneratedTerrainChunk {
    pub chunk_x: i32,
    pub chunk_z: i32,
    pub primer: TerrainPrimer,
    pub carved_cave_blocks: usize,
    pub carved_ravine_blocks: usize,
}

/// Runs the currently ported terrain stages in vanilla provider order:
/// density lattice -> 4x8x4 interpolation -> biome top/filler replacement ->
/// cave carver -> ravine carver. The caller supplies the 10x10 biome-height
/// neighborhood and the 16x16 block-biome raster from the biome manager.
///
/// This is an integration boundary, not a claim of bit-identical generation:
/// specialized mesa/ice biome surfaces and the exact cave/ravine RNG walkers
/// still require additional source-level parity work.
pub fn generate_overworld_terrain_chunk(
    noise: &TerrainNoiseSet,
    world_seed: i64,
    chunk_x: i32,
    chunk_z: i32,
    biome_height_neighborhood: &[BiomeTerrain],
    block_biome_ids: &[i32],
    settings: TerrainSettings,
    amplified: bool,
) -> Option<GeneratedTerrainChunk> {
    if biome_height_neighborhood.len() != 100 || block_biome_ids.len() != 256 {
        return None;
    }
    let density = noise.density_field(
        chunk_x, chunk_z, biome_height_neighborhood, settings, amplified,
    )?;
    let mut primer = interpolate_terrain(&density, settings.sea_level);
    if !replace_biome_surfaces(
        noise, world_seed, chunk_x, chunk_z, block_biome_ids,
        settings.sea_level, &mut primer,
    ) {
        return None;
    }
    // ChunkProviderGenerate invokes cave generation before ravine generation.
    let carved_cave_blocks = carve_caves(world_seed, chunk_x, chunk_z, &mut primer);
    let carved_ravine_blocks = carve_ravines(world_seed, chunk_x, chunk_z, &mut primer);
    Some(GeneratedTerrainChunk {
        chunk_x, chunk_z, primer, carved_cave_blocks, carved_ravine_blocks,
    })
}

/// Fully composed terrain plus the vanilla default ore population pass.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct GeneratedPopulatedChunk {
    pub terrain: GeneratedTerrainChunk,
    pub ores: OrePopulationStats,
}

/// Convenience entry point for the two currently implemented phases:
/// terrain/carvers and isolated default ore population. This is not a full
/// vanilla `populate()` replay: structure/lake/dungeon prelude and subsequent
/// biome decoration are still separate integration work.
pub fn generate_overworld_chunk_with_ores(
    noise: &TerrainNoiseSet, world_seed: i64, chunk_x: i32, chunk_z: i32,
    biome_height_neighborhood: &[BiomeTerrain], block_biome_ids: &[i32],
    settings: TerrainSettings, amplified: bool,
) -> Option<GeneratedPopulatedChunk> {
    let mut terrain = generate_overworld_terrain_chunk(
        noise, world_seed, chunk_x, chunk_z, biome_height_neighborhood,
        block_biome_ids, settings, amplified,
    )?;
    let ores = populate_overworld_ores(world_seed, chunk_x, chunk_z, &mut terrain.primer);
    Some(GeneratedPopulatedChunk { terrain, ores })
}

/// The base biome surface states for the 1.8.9 overworld. Specialized mesa,
/// ice, and stone-beach strata are intentionally left for their own biome
/// generators rather than being approximated as ordinary grassland.
fn biome_surface_blocks(id: i32) -> (TerrainBlock, TerrainBlock) {
    use biome_id::*;
    match id {
        DESERT | DESERT_HILLS | BEACH | COLD_BEACH => (TerrainBlock::Sand, TerrainBlock::Sand),
        STONE_BEACH | EXTREME_HILLS | EXTREME_HILLS_PLUS | SMALL_MOUNTAINS => (TerrainBlock::Stone, TerrainBlock::Stone),
        MUSHROOM_ISLAND | MUSHROOM_ISLAND_SHORE => (TerrainBlock::Mycelium, TerrainBlock::Dirt),
        OCEAN | DEEP_OCEAN | FROZEN_OCEAN | RIVER | FROZEN_RIVER => (TerrainBlock::Grass, TerrainBlock::Dirt),
        _ => (TerrainBlock::Grass, TerrainBlock::Dirt),
    }
}

#[cfg(test)]
mod math_helper_compat_tests {
    use super::*;

    #[test]
    fn sine_and_cosine_match_vanilla_cardinal_table_entries() {
        let half_pi = std::f32::consts::FRAC_PI_2;
        let pi = std::f32::consts::PI;
        assert_eq!(minecraft_math_helper_sin(0.0), 0.0);
        assert_eq!(minecraft_math_helper_sin(half_pi), 1.0);
        assert_eq!(minecraft_math_helper_sin(pi), 0.0);
        assert_eq!(minecraft_math_helper_sin(-half_pi), -1.0);
        assert_eq!(minecraft_math_helper_cos(0.0), 1.0);
        assert_eq!(minecraft_math_helper_cos(half_pi), 0.0);
        assert_eq!(minecraft_math_helper_cos(pi), -1.0);
    }

    #[test]
    fn lookup_is_periodic_at_vanilla_table_resolution() {
        let value = 0.731_f32;
        let period = std::f32::consts::PI * 2.0;
        assert_eq!(minecraft_math_helper_sin(value), minecraft_math_helper_sin(value + period));
        assert_eq!(minecraft_math_helper_cos(value), minecraft_math_helper_cos(value + period));
    }
}

#[cfg(test)]
mod ore_population_tests {
    use super::*;

    #[test]
    fn ore_population_is_deterministic_and_only_replaces_stone() {
        let mut a = TerrainPrimer::default();
        let mut b = TerrainPrimer::default();
        for x in 0..16 { for z in 0..16 { for y in 1..80 {
            a.set(x, y, z, TerrainBlock::Stone);
            b.set(x, y, z, TerrainBlock::Stone);
        }}}
        let sa = populate_overworld_ores(123456789, -2, 3, &mut a);
        let sb = populate_overworld_ores(123456789, -2, 3, &mut b);
        assert_eq!(sa, sb);
        assert_eq!(a, b);
        assert!(a.blocks().iter().any(|v| matches!(v, TerrainBlock::CoalOre | TerrainBlock::IronOre | TerrainBlock::GoldOre | TerrainBlock::RedstoneOre | TerrainBlock::DiamondOre | TerrainBlock::LapisOre)));
        assert!(a.blocks().iter().all(|v| *v != TerrainBlock::Water));
    }

    #[test]
    fn ore_blocks_map_to_vanilla_legacy_ids_and_metadata() {
        assert_eq!(TerrainBlock::CoalOre.legacy_id_metadata(), (16, 0));
        assert_eq!(TerrainBlock::DiamondOre.legacy_id_metadata(), (56, 0));
        assert_eq!(TerrainBlock::Granite.legacy_id_metadata(), (1, 1));
        assert_eq!(TerrainBlock::Diorite.legacy_id_metadata(), (1, 3));
        assert_eq!(TerrainBlock::Andesite.legacy_id_metadata(), (1, 5));
        assert_eq!(TerrainBlock::OakLog.legacy_id_metadata(), (17, 0));
        assert_eq!(TerrainBlock::BirchLog.legacy_id_metadata(), (17, 2));
        assert_eq!(TerrainBlock::OakLeaves.legacy_id_metadata(), (18, 4));
        assert_eq!(TerrainBlock::BirchLeaves.legacy_id_metadata(), (18, 6));
    }

    #[test]
    fn ore_population_accepts_a_continuing_shared_random_stream() {
        let mut a = TerrainPrimer::default();
        let mut b = TerrainPrimer::default();
        for x in 0..16 { for z in 0..16 { for y in 1..80 {
            a.set(x, y, z, TerrainBlock::Stone);
            b.set(x, y, z, TerrainBlock::Stone);
        }}}
        let mut rng_a = JavaRandom::new(987654321);
        let mut rng_b = JavaRandom::new(987654321);
        // Model random values consumed by an earlier population prelude.
        for _ in 0..37 { let _ = rng_a.next_int(256); let _ = rng_b.next_int(256); }
        let sa = populate_overworld_ores_with_rng(&mut rng_a, 2, -3, &mut a);
        let sb = populate_overworld_ores_with_rng(&mut rng_b, 2, -3, &mut b);
        assert_eq!(sa, sb);
        assert_eq!(a, b);
    }

    #[test]
    fn mega_taiga_uses_mega_pine_and_podzol_legacy_state_deterministically() {
        assert_eq!(TerrainBlock::Podzol.legacy_id_metadata(), (3, 2));
        let mut a=TerrainPopulationRegion::new(0,0); let mut b=TerrainPopulationRegion::new(0,0);
        for r in [&mut a,&mut b] { let mut p=TerrainPrimer::default(); for x in 0..16 { for z in 0..16 { for y in 58..=63 { p.set(x,y,z,if y==63 {TerrainBlock::Grass}else{TerrainBlock::Dirt}); }}} r.set_chunk(0,0,p); }
        let mut ra=JavaRandom::new(991827); let mut rb=JavaRandom::new(991827);
        let sa=decorate_overworld_trees(&mut ra,0,0,biome_id::MEGA_TAIGA,&mut a);
        let sb=decorate_overworld_trees(&mut rb,0,0,biome_id::MEGA_TAIGA,&mut b);
        assert_eq!(sa,sb); assert_eq!(a,b); assert_eq!(sa.attempts,10);
    }

    #[test]
    fn jungle_tree_states_match_legacy_ids_and_population_is_deterministic() {
        assert_eq!(TerrainBlock::JungleLog.legacy_id_metadata(), (17, 3));
        assert_eq!(TerrainBlock::JungleLeaves.legacy_id_metadata(), (18, 3));
        assert_eq!(TerrainBlock::VineNorth.legacy_id_metadata(), (106, 4));
        assert_eq!(TerrainBlock::VineEast.legacy_id_metadata(), (106, 8));
        let mut a = TerrainPopulationRegion::new(0, 0);
        let mut b = TerrainPopulationRegion::new(0, 0);
        for cx in -1..=1 { for cz in -1..=1 {
            let mut pa = TerrainPrimer::default();
            let mut pb = TerrainPrimer::default();
            for x in 0..16 { for z in 0..16 {
                pa.set(x, 63, z, TerrainBlock::Grass);
                pb.set(x, 63, z, TerrainBlock::Grass);
                for y in 0..63 { pa.set(x,y,z,TerrainBlock::Dirt); pb.set(x,y,z,TerrainBlock::Dirt); }
            }}
            a.set_chunk(cx,cz,pa); b.set_chunk(cx,cz,pb);
        }}
        let mut ra = JavaRandom::new(918273);
        let mut rb = JavaRandom::new(918273);
        let sa = decorate_overworld_trees(&mut ra,0,0,biome_id::JUNGLE,&mut a);
        let sb = decorate_overworld_trees(&mut rb,0,0,biome_id::JUNGLE,&mut b);
        assert_eq!(sa,sb);
        assert_eq!(a,b);
        assert!(sa.attempts == 50 || sa.attempts == 51);
    }

    #[test]
    fn taiga_tree_generators_are_deterministic_and_use_spruce_legacy_states() {
        assert_eq!(TerrainBlock::SpruceLog.legacy_id_metadata(), (17, 1));
        assert_eq!(TerrainBlock::SpruceLeaves.legacy_id_metadata(), (18, 5));
        let mut a = TerrainPopulationRegion::new(0,0);
        let mut b = TerrainPopulationRegion::new(0,0);
        for region in [&mut a, &mut b] {
            let mut primer=TerrainPrimer::default();
            for x in 0..16 { for z in 0..16 { for y in 60..=63 { primer.set(x,y,z,if y==63 {TerrainBlock::Grass} else {TerrainBlock::Dirt}); }}}
            region.set_chunk(0,0,primer);
        }
        let mut ra=JavaRandom::new(887766); let mut rb=JavaRandom::new(887766);
        let sa=decorate_overworld_trees(&mut ra,0,0,biome_id::TAIGA,&mut a);
        let sb=decorate_overworld_trees(&mut rb,0,0,biome_id::TAIGA,&mut b);
        assert_eq!(sa,sb); assert_eq!(a,b);
        let mut expected_rng=JavaRandom::new(887766);
        let expected_attempts=10 + if expected_rng.next_int(10)==Some(0) {1} else {0};
        assert_eq!(sa.attempts,expected_attempts);
    }

    #[test]
    fn dark_oak_legacy_states_and_roofed_forest_are_deterministic() {
        assert_eq!(TerrainBlock::DarkOakLog.legacy_id_metadata(),(162,1));
        assert_eq!(TerrainBlock::DarkOakLeaves.legacy_id_metadata(),(161,1));
        let mut a=TerrainPopulationRegion::new(0,0); let mut b=TerrainPopulationRegion::new(0,0);
        for r in [&mut a,&mut b] { let mut p=TerrainPrimer::default(); for x in 0..16 {for z in 0..16 {for y in 60..=63 {p.set(x,y,z,if y==63 {TerrainBlock::Grass}else{TerrainBlock::Dirt});}}} r.set_chunk(0,0,p); }
        let mut ra=JavaRandom::new(123456);let mut rb=JavaRandom::new(123456);
        let sa=decorate_overworld_trees(&mut ra,0,0,biome_id::ROOFED_FOREST,&mut a);
        let sb=decorate_overworld_trees(&mut rb,0,0,biome_id::ROOFED_FOREST,&mut b);
        assert_eq!(sa,sb);assert_eq!(a,b);assert_eq!(sa.attempts,16);
    }

    #[test]
    fn substrate_patch_requires_water_and_preserves_random_stream_on_failed_attempt() {
        let mut region = TerrainPopulationRegion::new(0, 0);
        let mut primer = TerrainPrimer::default();
        primer.set(8, 40, 8, TerrainBlock::Stone);
        assert!(region.set_chunk(0, 0, primer));
        let mut rng = JavaRandom::new(123);
        let mut expected = JavaRandom::new(123);
        assert!(!generate_vanilla_substrate_patch(&mut region, &mut rng, 8, 40, 8, 7, TerrainBlock::Sand, false));
        assert_eq!(rng.next_int(1000), expected.next_int(1000));
    }

    #[test]
    fn population_seed_matches_vanilla_java_long_arithmetic() {
        let seed = 123456789i64;
        let actual = vanilla_chunk_population_seed(seed, -2, 3);
        let mut java = JavaRandom::new(seed);
        let x_mul = java.next_long() / 2 * 2 + 1;
        let z_mul = java.next_long() / 2 * 2 + 1;
        let expected = ((-2i64).wrapping_mul(x_mul).wrapping_add(3i64.wrapping_mul(z_mul))) ^ seed;
        assert_eq!(actual, expected);
    }

    #[test]
    fn ore_veins_write_across_chunk_boundaries_when_neighbor_is_loaded() {
        let mut region = TerrainPopulationRegion::new(0, 0);
        for cx in -1..=1 { for cz in -1..=1 {
            let mut primer = TerrainPrimer::default();
            for x in 0..16 { for z in 0..16 { for y in 1..80 { primer.set(x,y,z,TerrainBlock::Stone); }}}
            assert!(region.set_chunk(cx, cz, primer));
        }}
        // Force a narrow, almost axis-aligned vein centered at x=23 world
        // coordinates. Its ellipsoid crosses from chunk 0 into chunk 1.
        let mut rng = JavaRandom::new(1_463_169_890);
        let placed = generate_vanilla_ore_vein(&mut region, &mut rng, 15, 40, 8, 33, TerrainBlock::CoalOre);
        assert!(placed > 0);
        assert!(region.chunk(1, 0).unwrap().blocks().iter().any(|b| *b == TerrainBlock::CoalOre));
    }

    #[test]
    fn ore_population_respects_world_chunk_offsets() {
        let mut a = TerrainPrimer::default();
        let mut b = TerrainPrimer::default();
        for x in 0..16 { for z in 0..16 { for y in 1..80 { a.set(x,y,z,TerrainBlock::Stone); b.set(x,y,z,TerrainBlock::Stone); }}}
        populate_overworld_ores(99, 0, 0, &mut a);
        populate_overworld_ores(99, 1, 0, &mut b);
        assert_ne!(a, b);
    }
}

#[cfg(test)]
mod terrain_density_tests {
    use super::*;

    #[test]
    fn density_field_is_825_values_and_repeatable() {
        let biomes = vec![BiomeTerrain::PLAINS; 100];
        let a = TerrainNoiseSet::new(1234).density_field(0, 0, &biomes, TerrainSettings::default(), false).unwrap();
        let b = TerrainNoiseSet::new(1234).density_field(0, 0, &biomes, TerrainSettings::default(), false).unwrap();
        assert_eq!(a.values.len(), 825);
        assert_eq!(a, b);
        assert!(a.values.iter().all(|v| v.is_finite()));
    }

    #[test]
    fn density_field_changes_with_chunk_coordinates() {
        let biomes = vec![BiomeTerrain::PLAINS; 100];
        let noise = TerrainNoiseSet::new(987654321);
        let a = noise.density_field(0, 0, &biomes, TerrainSettings::default(), false).unwrap();
        let b = noise.density_field(1, 0, &biomes, TerrainSettings::default(), false).unwrap();
        assert_ne!(a, b);
    }

    #[test]
    fn density_field_rejects_wrong_biome_neighborhood() {
        let noise = TerrainNoiseSet::new(0);
        assert!(noise.density_field(0, 0, &[BiomeTerrain::PLAINS; 25], TerrainSettings::default(), false).is_none());
    }

    #[test]
    fn interpolation_fills_solid_and_sea_level_blocks() {
        let density = TerrainDensity { values: vec![1.0; 825] };
        let solid = interpolate_terrain(&density, 63);
        assert_eq!(solid.get(0, 0, 0), Some(TerrainBlock::Stone));
        assert_eq!(solid.get(15, 255, 15), Some(TerrainBlock::Stone));

        let empty = TerrainDensity { values: vec![-1.0; 825] };
        let ocean = interpolate_terrain(&empty, 63);
        assert_eq!(ocean.get(0, 62, 0), Some(TerrainBlock::Water));
        assert_eq!(ocean.get(0, 63, 0), Some(TerrainBlock::Air));
    }

    #[test]
    fn biome_surface_replaces_stone_and_places_bedrock_deterministically() {
        let noise = TerrainNoiseSet::new(12345);
        let density = TerrainDensity { values: vec![1.0; 825] };
        let mut a = interpolate_terrain(&density, 63);
        let mut b = a.clone();
        assert!(replace_biome_surfaces(&noise, 12345, 0, 0, &[biome_id::PLAINS; 256], 63, &mut a));
        assert!(replace_biome_surfaces(&noise, 12345, 0, 0, &[biome_id::PLAINS; 256], 63, &mut b));
        assert_eq!(a, b);
        assert_eq!(a.get(0, 0, 0), Some(TerrainBlock::Bedrock));
        assert!(a.blocks().contains(&TerrainBlock::Grass));
        assert!(a.blocks().contains(&TerrainBlock::Dirt));
    }

    #[test]
    fn cave_carving_is_seeded_and_changes_solid_terrain() {
        let mut a = TerrainPrimer::default();
        let mut b = TerrainPrimer::default();
        for x in 0..16 { for z in 0..16 { for y in 1..80 { a.set(x, y, z, TerrainBlock::Stone); b.set(x, y, z, TerrainBlock::Stone); } } }
        let carved_a = carve_caves(1234567, 0, 0, &mut a);
        let carved_b = carve_caves(1234567, 0, 0, &mut b);
        assert_eq!(carved_a, carved_b);
        assert_eq!(a, b);
        assert!(carved_a > 0);
        assert!(a.blocks().iter().any(|block| *block == TerrainBlock::Air));
    }

    #[test]
    fn biome_climate_matches_snow_and_precipitation_thresholds() {
        let ice = biome_climate(biome_id::ICE_PLAINS).unwrap();
        assert!(ice.can_snow_at(64));
        let plains = biome_climate(biome_id::PLAINS).unwrap();
        assert!(!plains.can_snow_at(64));
        assert!(plains.can_snow_at(500));
        let desert = biome_climate(biome_id::DESERT).unwrap();
        assert!(!desert.has_precipitation);
        assert!(!desert.can_freeze_at(255));
    }

    #[test]
    fn biome_surface_rejects_invalid_biome_raster() {
        let noise = TerrainNoiseSet::new(0);
        let mut primer = TerrainPrimer::default();
        assert!(!replace_biome_surfaces(&noise, 0, 0, 0, &[biome_id::PLAINS; 16], 63, &mut primer));
    }

    #[test]
    fn integrated_chunk_pipeline_is_repeatable_and_rejects_bad_biome_inputs() {
        let noise_a = TerrainNoiseSet::new(24680);
        let noise_b = TerrainNoiseSet::new(24680);
        let heights = [BiomeTerrain::PLAINS; 100];
        let ids = [biome_id::PLAINS; 256];
        let a = generate_overworld_terrain_chunk(
            &noise_a, 24680, 0, 0, &heights, &ids, TerrainSettings::default(), false,
        ).unwrap();
        let b = generate_overworld_terrain_chunk(
            &noise_b, 24680, 0, 0, &heights, &ids, TerrainSettings::default(), false,
        ).unwrap();
        assert_eq!(a, b);
        assert_eq!(a.primer.blocks().len(), 16 * 16 * 256);
        assert!(generate_overworld_terrain_chunk(
            &noise_a, 24680, 0, 0, &[BiomeTerrain::PLAINS; 25], &ids,
            TerrainSettings::default(), false,
        ).is_none());
    }

    #[test]
    fn ravine_carving_is_seeded_and_carves_vertical_elliptical_valleys() {
        let mut a = TerrainPrimer::default();
        let mut b = TerrainPrimer::default();
        for x in 0..16 { for z in 0..16 { for y in 1..100 { a.set(x,y,z,TerrainBlock::Stone); b.set(x,y,z,TerrainBlock::Stone); } } }
        let ca = carve_ravines(987654321, 0, 0, &mut a);
        let cb = carve_ravines(987654321, 0, 0, &mut b);
        assert_eq!(ca, cb);
        assert_eq!(a, b);
        assert!(ca > 0);
        assert!(a.blocks().iter().any(|b| *b == TerrainBlock::Air));
    }


    #[test]
    fn forest_tree_stage_places_oak_and_birch_blocks_deterministically() {
        let mut a = TerrainPopulationRegion::new(0, 0);
        let mut b = TerrainPopulationRegion::new(0, 0);
        for region in [&mut a, &mut b] {
            for cx in -1..=1 { for cz in -1..=1 {
                let primer=region.chunk_mut(cx,cz).unwrap();
                for x in 0..16 { for z in 0..16 { primer.set(x, 63, z, TerrainBlock::Grass); }}
            }}
        }
        let mut ra=JavaRandom::new(0x189);
        let mut rb=JavaRandom::new(0x189);
        let sa=decorate_overworld_trees(&mut ra,0,0,biome_id::FOREST,&mut a);
        let sb=decorate_overworld_trees(&mut rb,0,0,biome_id::FOREST,&mut b);
        assert_eq!(sa,sb);
        assert_eq!(a,b);
        assert!(a.chunks.iter().flat_map(|c| c.blocks()).any(|v| matches!(v,TerrainBlock::OakLog|TerrainBlock::BirchLog)));
    }

    #[test]
    fn big_tree_log_axis_metadata_matches_legacy_log_states() {
        assert_eq!(TerrainBlock::OakLog.legacy_id_metadata(), (17, 0));
        assert_eq!(TerrainBlock::OakLogX.legacy_id_metadata(), (17, 4));
        assert_eq!(TerrainBlock::OakLogZ.legacy_id_metadata(), (17, 8));
    }

    #[test]
    fn jungle_specialized_trees_are_deterministic_and_place_species_blocks() {
        let mut a = TerrainPopulationRegion::new(0, 0);
        let mut b = TerrainPopulationRegion::new(0, 0);
        for region in [&mut a, &mut b] {
            for cx in -1..=1 { for cz in -1..=1 {
                let primer=region.chunk_mut(cx,cz).unwrap();
                for x in 0..16 { for z in 0..16 { primer.set(x, 63, z, TerrainBlock::Grass); }}
            }}
        }
        let mut ra=JavaRandom::new(0x151189);
        let mut rb=JavaRandom::new(0x151189);
        let ga=generate_vanilla_mega_jungle(&mut a,&mut ra,8,64,8);
        let gb=generate_vanilla_mega_jungle(&mut b,&mut rb,8,64,8);
        assert_eq!(ga,gb);
        assert_eq!(a,b);
        assert!(a.chunks.iter().flat_map(|c|c.blocks()).any(|v| *v==TerrainBlock::JungleLog));

        let mut c=TerrainPopulationRegion::new(0,0);
        let mut d=TerrainPopulationRegion::new(0,0);
        for region in [&mut c,&mut d] {
            for cx in -1..=1 { for cz in -1..=1 {
                let primer=region.chunk_mut(cx,cz).unwrap();
                for x in 0..16 { for z in 0..16 { primer.set(x,63,z,TerrainBlock::Grass); }}
            }}
        }
        let mut rc=JavaRandom::new(0x151190);
        let mut rd=JavaRandom::new(0x151190);
        let gc=generate_vanilla_big_tree(&mut c,&mut rc,8,64,8);
        let gd=generate_vanilla_big_tree(&mut d,&mut rd,8,64,8);
        assert_eq!(gc,gd);
        assert_eq!(c,d);
        if gc { assert!(c.chunks.iter().flat_map(|c|c.blocks()).any(|v| *v==TerrainBlock::OakLog)); }
    }

    #[test]
    fn unsupported_biome_does_not_consume_tree_random_stream() {
        let mut a=JavaRandom::new(77); let mut b=JavaRandom::new(77);
        let mut region=TerrainPopulationRegion::new(0,0);
        let stats=decorate_overworld_trees(&mut a,0,0,biome_id::PLAINS,&mut region);
        assert_eq!(stats.attempts,0);
        assert_eq!(a.next_int(100),b.next_int(100));
    }

}


/// MCP WorldGenFlowers patch: exactly 64 candidate positions and six bounded
/// random draws per candidate (x/y/z as independent nextInt differences).
/// Flower selection is supplied by the biome's flower-noise selector.
pub fn generate_vanilla_flower_patch(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, x: i32, y: i32, z: i32, flower: TerrainBlock) -> usize {
    let mut placed=0;
    for _ in 0..64 {
        let px=x+rng.next_int(8).unwrap_or(0) as i32-rng.next_int(8).unwrap_or(0) as i32;
        let py=y+rng.next_int(4).unwrap_or(0) as i32-rng.next_int(4).unwrap_or(0) as i32;
        let pz=z+rng.next_int(8).unwrap_or(0) as i32-rng.next_int(8).unwrap_or(0) as i32;
        if region.get_world(px,py,pz)==Some(TerrainBlock::Air)
            && matches!(region.get_world(px,py-1,pz),Some(TerrainBlock::Grass|TerrainBlock::Dirt))
            && region.set_world(px,py,pz,flower) { placed+=1; }
    }
    placed
}

/// MCP WorldGenDeadBush: descend through air/leaves to ground, then four tries.
pub fn generate_vanilla_dead_bush(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, x: i32, mut y: i32, z: i32) -> usize {
    while y>0 && region.get_world(x,y,z)==Some(TerrainBlock::Air) { y-=1; }
    let mut placed=0;
    for _ in 0..4 {
        let px=x+rng.next_int(8).unwrap_or(0) as i32-rng.next_int(8).unwrap_or(0) as i32;
        let py=y+rng.next_int(4).unwrap_or(0) as i32-rng.next_int(4).unwrap_or(0) as i32;
        let pz=z+rng.next_int(8).unwrap_or(0) as i32-rng.next_int(8).unwrap_or(0) as i32;
        if region.get_world(px,py,pz)==Some(TerrainBlock::Air)
            && matches!(region.get_world(px,py-1,pz),Some(TerrainBlock::Sand|TerrainBlock::Dirt|TerrainBlock::Grass))
            && region.set_world(px,py,pz,TerrainBlock::DeadBush) { placed+=1; }
    }
    placed
}

/// MCP WorldGenReed. Water adjacency is checked on the four horizontal sides
/// of the supporting block; the inner height loop retains vanilla's RNG order.
pub fn generate_vanilla_reed(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, x: i32, y: i32, z: i32) -> usize {
    let mut placed=0;
    for _ in 0..20 {
        let px=x+rng.next_int(4).unwrap_or(0) as i32-rng.next_int(4).unwrap_or(0) as i32;
        let pz=z+rng.next_int(4).unwrap_or(0) as i32-rng.next_int(4).unwrap_or(0) as i32;
        if region.get_world(px,y,pz)!=Some(TerrainBlock::Air) { continue; }
        let support=y-1;
        let water=[(-1,0),(1,0),(0,-1),(0,1)].iter().any(|(dx,dz)| region.get_world(px+dx,support,pz+dz)==Some(TerrainBlock::Water));
        if !water || !matches!(region.get_world(px,support,pz),Some(TerrainBlock::Grass|TerrainBlock::Dirt|TerrainBlock::Sand)) { continue; }
        let inner=rng.next_int(3).unwrap_or(0)+1;
        let height=2+rng.next_int(inner).unwrap_or(0) as i32;
        for dy in 0..height {
            if region.set_world(px,y+dy,pz,TerrainBlock::Reed) { placed+=1; }
        }
    }
    placed
}

/// MCP WorldGenCactus: ten attempts; height draw occurs only after an air test.
pub fn generate_vanilla_cactus(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, x: i32, y: i32, z: i32) -> usize {
    let mut placed=0;
    for _ in 0..10 {
        let px=x+rng.next_int(8).unwrap_or(0) as i32-rng.next_int(8).unwrap_or(0) as i32;
        let py=y+rng.next_int(4).unwrap_or(0) as i32-rng.next_int(4).unwrap_or(0) as i32;
        let pz=z+rng.next_int(8).unwrap_or(0) as i32-rng.next_int(8).unwrap_or(0) as i32;
        if region.get_world(px,py,pz)!=Some(TerrainBlock::Air) || region.get_world(px,py-1,pz)!=Some(TerrainBlock::Sand) { continue; }
        let sides=[(-1,0),(1,0),(0,-1),(0,1)];
        if sides.iter().any(|(dx,dz)| region.get_world(px+dx,py,pz+dz)!=Some(TerrainBlock::Air)) { continue; }
        let inner=rng.next_int(3).unwrap_or(0)+1;
        let height=1+rng.next_int(inner).unwrap_or(0) as i32;
        for dy in 0..height {
            if region.set_world(px,py+dy,pz,TerrainBlock::Cactus) { placed+=1; }
        }
    }
    placed
}

/// MCP WorldGenWaterlily: ten candidates, with a full independent x/y/z draw.
pub fn generate_vanilla_waterlily(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, x: i32, y: i32, z: i32) -> usize {
    let mut placed=0;
    for _ in 0..10 {
        let px=x+rng.next_int(8).unwrap_or(0) as i32-rng.next_int(8).unwrap_or(0) as i32;
        let py=y+rng.next_int(4).unwrap_or(0) as i32-rng.next_int(4).unwrap_or(0) as i32;
        let pz=z+rng.next_int(8).unwrap_or(0) as i32-rng.next_int(8).unwrap_or(0) as i32;
        if region.get_world(px,py,pz)==Some(TerrainBlock::Air) && region.get_world(px,py-1,pz)==Some(TerrainBlock::Water)
            && region.set_world(px,py,pz,TerrainBlock::Waterlily) { placed+=1; }
    }
    placed
}

/// MCP WorldGenPumpkin / WorldGenMelon placement patches (64 attempts).
pub fn generate_vanilla_gourd_patch(region: &mut TerrainPopulationRegion, rng: &mut JavaRandom, x: i32, y: i32, z: i32, pumpkin: bool) -> usize {
    let mut placed=0;
    for _ in 0..64 {
        let px=x+rng.next_int(8).unwrap_or(0) as i32-rng.next_int(8).unwrap_or(0) as i32;
        let py=y+rng.next_int(4).unwrap_or(0) as i32-rng.next_int(4).unwrap_or(0) as i32;
        let pz=z+rng.next_int(8).unwrap_or(0) as i32-rng.next_int(8).unwrap_or(0) as i32;
        if region.get_world(px,py,pz)==Some(TerrainBlock::Air) && region.get_world(px,py-1,pz)==Some(TerrainBlock::Grass) {
            if pumpkin { let _facing=rng.next_int(4); }
            if region.set_world(px,py,pz,if pumpkin {TerrainBlock::Pumpkin} else {TerrainBlock::Melon}) { placed+=1; }
        }
    }
    placed
}

#[derive(Debug,Default,Clone,Copy,PartialEq,Eq)]
pub struct PlantGeneratorStats { pub flowers:usize, pub dead_bushes:usize, pub reeds:usize, pub cactus:usize, pub waterlilies:usize, pub pumpkins:usize, pub melons:usize }

/// Shared helpers for biome decoration. The caller selects flower species and
/// per-biome attempt counts from BiomeGenBase/BiomeDecorator; this function
/// deliberately does not guess biome defaults or noise-derived flower types.
pub fn decorate_vanilla_plant_generators(rng:&mut JavaRandom, x:i32, z:i32, y:i32,
    flower_attempts:usize, flower:TerrainBlock, dead_bush_attempts:usize,
    reed_attempts:usize, cactus_attempts:usize, waterlily_attempts:usize,
    pumpkin_attempts:usize, melon_attempts:usize, region:&mut TerrainPopulationRegion) -> PlantGeneratorStats {
    let mut stats=PlantGeneratorStats::default();
    for _ in 0..flower_attempts { stats.flowers+=generate_vanilla_flower_patch(region,rng,x,y,z,flower); }
    for _ in 0..dead_bush_attempts { stats.dead_bushes+=generate_vanilla_dead_bush(region,rng,x,y,z); }
    for _ in 0..reed_attempts { stats.reeds+=generate_vanilla_reed(region,rng,x,y,z); }
    for _ in 0..cactus_attempts { stats.cactus+=generate_vanilla_cactus(region,rng,x,y,z); }
    for _ in 0..waterlily_attempts { stats.waterlilies+=generate_vanilla_waterlily(region,rng,x,y,z); }
    for _ in 0..pumpkin_attempts { stats.pumpkins+=generate_vanilla_gourd_patch(region,rng,x,y,z,true); }
    for _ in 0..melon_attempts { stats.melons+=generate_vanilla_gourd_patch(region,rng,x,y,z,false); }
    stats
}

#[cfg(test)]
mod big_mushroom_vanilla_tests {
    use super::*;

    fn flat_region() -> TerrainPopulationRegion {
        let mut r=TerrainPopulationRegion::new(0,0);
        for cx in -1..=1 { for cz in -1..=1 {
            let c=r.chunk_mut(cx,cz).unwrap();
            for x in 0..16 { for z in 0..16 { c.set(x,63,z,TerrainBlock::Grass); }}
        }}
        r
    }

    #[test]
    fn giant_mushroom_block_ids_and_metadata_match_legacy_registry() {
        assert_eq!(TerrainBlock::MushroomBrown0.legacy_id_metadata(),(99,0));
        assert_eq!(TerrainBlock::MushroomBrown10.legacy_id_metadata(),(99,10));
        assert_eq!(TerrainBlock::MushroomRed0.legacy_id_metadata(),(100,0));
        assert_eq!(TerrainBlock::MushroomRed10.legacy_id_metadata(),(100,10));
    }

    #[test]
    fn big_mushroom_generation_is_deterministic_and_keeps_generator_type() {
        let mut a=flat_region(); let mut b=flat_region();
        let mut ra=JavaRandom::new(0x189); let mut rb=JavaRandom::new(0x189);
        let sa=decorate_overworld_big_mushrooms(&mut ra,0,0,3,&mut a);
        let sb=decorate_overworld_big_mushrooms(&mut rb,0,0,3,&mut b);
        assert_eq!(sa,sb); assert_eq!(a,b);
        assert_eq!(sa.attempts,3);
        // Vanilla's WorldGenBigMushroom instance chooses its type once and
        // retains it for subsequent attempts in this decoration pass.
        assert!(sa.red==0 || sa.brown==0);
    }
}
