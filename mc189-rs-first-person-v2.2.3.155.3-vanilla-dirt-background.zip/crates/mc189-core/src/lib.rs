//! Shared primitives for the mc189-rs project.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum Mc189Error {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),

    #[error("invalid data: {0}")]
    InvalidData(String),

    #[error("usage error: {0}")]
    Usage(String),
}

pub type Result<T> = std::result::Result<T, Mc189Error>;

pub mod worldgen;
