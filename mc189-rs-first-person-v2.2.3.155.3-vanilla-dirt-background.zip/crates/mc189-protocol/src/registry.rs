//! Minecraft Java Edition 1.8.9 (protocol 47) network protocol primitives.
//! Packet IDs and ordering are transcribed from the supplied deobfuscated 1.8.9
//! `EnumConnectionState` source.

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ConnectionState { Handshaking, Play, Status, Login }
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Direction { Clientbound, Serverbound }
#[derive(Debug, Clone, Copy)]
pub struct PacketDefinition { pub state: ConnectionState, pub direction: Direction, pub id: i32, pub mcp_name: &'static str }

pub const PROTOCOL_VERSION: i32 = 47;

pub const PACKETS: &[PacketDefinition] = &[
    PacketDefinition { state: ConnectionState::Handshaking, direction: Direction::Serverbound, id: 0, mcp_name: "C00Handshake" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 0, mcp_name: "S00PacketKeepAlive" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 1, mcp_name: "S01PacketJoinGame" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 2, mcp_name: "S02PacketChat" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 3, mcp_name: "S03PacketTimeUpdate" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 4, mcp_name: "S04PacketEntityEquipment" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 5, mcp_name: "S05PacketSpawnPosition" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 6, mcp_name: "S06PacketUpdateHealth" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 7, mcp_name: "S07PacketRespawn" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 8, mcp_name: "S08PacketPlayerPosLook" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 9, mcp_name: "S09PacketHeldItemChange" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 10, mcp_name: "S0APacketUseBed" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 11, mcp_name: "S0BPacketAnimation" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 12, mcp_name: "S0CPacketSpawnPlayer" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 13, mcp_name: "S0DPacketCollectItem" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 14, mcp_name: "S0EPacketSpawnObject" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 15, mcp_name: "S0FPacketSpawnMob" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 16, mcp_name: "S10PacketSpawnPainting" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 17, mcp_name: "S11PacketSpawnExperienceOrb" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 18, mcp_name: "S12PacketEntityVelocity" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 19, mcp_name: "S13PacketDestroyEntities" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 20, mcp_name: "S14PacketEntity" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 21, mcp_name: "S14PacketEntity.S15PacketEntityRelMove" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 22, mcp_name: "S14PacketEntity.S16PacketEntityLook" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 23, mcp_name: "S14PacketEntity.S17PacketEntityLookMove" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 24, mcp_name: "S18PacketEntityTeleport" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 25, mcp_name: "S19PacketEntityHeadLook" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 26, mcp_name: "S19PacketEntityStatus" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 27, mcp_name: "S1BPacketEntityAttach" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 28, mcp_name: "S1CPacketEntityMetadata" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 29, mcp_name: "S1DPacketEntityEffect" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 30, mcp_name: "S1EPacketRemoveEntityEffect" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 31, mcp_name: "S1FPacketSetExperience" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 32, mcp_name: "S20PacketEntityProperties" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 33, mcp_name: "S21PacketChunkData" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 34, mcp_name: "S22PacketMultiBlockChange" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 35, mcp_name: "S23PacketBlockChange" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 36, mcp_name: "S24PacketBlockAction" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 37, mcp_name: "S25PacketBlockBreakAnim" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 38, mcp_name: "S26PacketMapChunkBulk" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 39, mcp_name: "S27PacketExplosion" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 40, mcp_name: "S28PacketEffect" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 41, mcp_name: "S29PacketSoundEffect" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 42, mcp_name: "S2APacketParticles" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 43, mcp_name: "S2BPacketChangeGameState" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 44, mcp_name: "S2CPacketSpawnGlobalEntity" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 45, mcp_name: "S2DPacketOpenWindow" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 46, mcp_name: "S2EPacketCloseWindow" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 47, mcp_name: "S2FPacketSetSlot" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 48, mcp_name: "S30PacketWindowItems" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 49, mcp_name: "S31PacketWindowProperty" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 50, mcp_name: "S32PacketConfirmTransaction" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 51, mcp_name: "S33PacketUpdateSign" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 52, mcp_name: "S34PacketMaps" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 53, mcp_name: "S35PacketUpdateTileEntity" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 54, mcp_name: "S36PacketSignEditorOpen" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 55, mcp_name: "S37PacketStatistics" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 56, mcp_name: "S38PacketPlayerListItem" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 57, mcp_name: "S39PacketPlayerAbilities" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 58, mcp_name: "S3APacketTabComplete" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 59, mcp_name: "S3BPacketScoreboardObjective" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 60, mcp_name: "S3CPacketUpdateScore" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 61, mcp_name: "S3DPacketDisplayScoreboard" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 62, mcp_name: "S3EPacketTeams" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 63, mcp_name: "S3FPacketCustomPayload" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 64, mcp_name: "S40PacketDisconnect" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 65, mcp_name: "S41PacketServerDifficulty" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 66, mcp_name: "S42PacketCombatEvent" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 67, mcp_name: "S43PacketCamera" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 68, mcp_name: "S44PacketWorldBorder" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 69, mcp_name: "S45PacketTitle" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 70, mcp_name: "S46PacketSetCompressionLevel" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 71, mcp_name: "S47PacketPlayerListHeaderFooter" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 72, mcp_name: "S48PacketResourcePackSend" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Clientbound, id: 73, mcp_name: "S49PacketUpdateEntityNBT" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 0, mcp_name: "C00PacketKeepAlive" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 1, mcp_name: "C01PacketChatMessage" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 2, mcp_name: "C02PacketUseEntity" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 3, mcp_name: "C03PacketPlayer" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 4, mcp_name: "C03PacketPlayer.C04PacketPlayerPosition" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 5, mcp_name: "C03PacketPlayer.C05PacketPlayerLook" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 6, mcp_name: "C03PacketPlayer.C06PacketPlayerPosLook" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 7, mcp_name: "C07PacketPlayerDigging" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 8, mcp_name: "C08PacketPlayerBlockPlacement" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 9, mcp_name: "C09PacketHeldItemChange" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 10, mcp_name: "C0APacketAnimation" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 11, mcp_name: "C0BPacketEntityAction" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 12, mcp_name: "C0CPacketInput" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 13, mcp_name: "C0DPacketCloseWindow" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 14, mcp_name: "C0EPacketClickWindow" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 15, mcp_name: "C0FPacketConfirmTransaction" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 16, mcp_name: "C10PacketCreativeInventoryAction" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 17, mcp_name: "C11PacketEnchantItem" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 18, mcp_name: "C12PacketUpdateSign" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 19, mcp_name: "C13PacketPlayerAbilities" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 20, mcp_name: "C14PacketTabComplete" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 21, mcp_name: "C15PacketClientSettings" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 22, mcp_name: "C16PacketClientStatus" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 23, mcp_name: "C17PacketCustomPayload" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 24, mcp_name: "C18PacketSpectate" },
    PacketDefinition { state: ConnectionState::Play, direction: Direction::Serverbound, id: 25, mcp_name: "C19PacketResourcePackStatus" },
    PacketDefinition { state: ConnectionState::Status, direction: Direction::Serverbound, id: 0, mcp_name: "C00PacketServerQuery" },
    PacketDefinition { state: ConnectionState::Status, direction: Direction::Clientbound, id: 0, mcp_name: "S00PacketServerInfo" },
    PacketDefinition { state: ConnectionState::Status, direction: Direction::Serverbound, id: 1, mcp_name: "C01PacketPing" },
    PacketDefinition { state: ConnectionState::Status, direction: Direction::Clientbound, id: 1, mcp_name: "S01PacketPong" },
    PacketDefinition { state: ConnectionState::Login, direction: Direction::Clientbound, id: 0, mcp_name: "S00PacketDisconnect" },
    PacketDefinition { state: ConnectionState::Login, direction: Direction::Clientbound, id: 1, mcp_name: "S01PacketEncryptionRequest" },
    PacketDefinition { state: ConnectionState::Login, direction: Direction::Clientbound, id: 2, mcp_name: "S02PacketLoginSuccess" },
    PacketDefinition { state: ConnectionState::Login, direction: Direction::Clientbound, id: 3, mcp_name: "S03PacketEnableCompression" },
    PacketDefinition { state: ConnectionState::Login, direction: Direction::Serverbound, id: 0, mcp_name: "C00PacketLoginStart" },
    PacketDefinition { state: ConnectionState::Login, direction: Direction::Serverbound, id: 1, mcp_name: "C01PacketEncryptionResponse" },
 ];

pub fn packet_name(state: ConnectionState, direction: Direction, id: i32) -> Option<&'static str> {
    PACKETS.iter().find(|p| p.state == state && p.direction == direction && p.id == id).map(|p| p.mcp_name)
}

pub fn packet_id(state: ConnectionState, direction: Direction, mcp_name: &str) -> Option<i32> {
    PACKETS.iter().find(|p| p.state == state && p.direction == direction && p.mcp_name == mcp_name).map(|p| p.id)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn protocol_registry_has_vanilla_packet_counts() {
        let count = |s,d| PACKETS.iter().filter(|p| p.state == s && p.direction == d).count();
        assert_eq!(count(ConnectionState::Handshaking, Direction::Serverbound), 1);
        assert_eq!(count(ConnectionState::Status, Direction::Serverbound), 2);
        assert_eq!(count(ConnectionState::Status, Direction::Clientbound), 2);
        assert_eq!(count(ConnectionState::Login, Direction::Serverbound), 2);
        assert_eq!(count(ConnectionState::Login, Direction::Clientbound), 4);
        assert_eq!(count(ConnectionState::Play, Direction::Serverbound), 26);
        assert_eq!(count(ConnectionState::Play, Direction::Clientbound), 74);
        assert_eq!(PACKETS.len(), 111);
    }
}
