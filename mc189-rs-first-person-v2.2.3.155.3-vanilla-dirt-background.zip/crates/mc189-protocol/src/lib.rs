//! Traducción inicial del transporte de red de Minecraft Java 1.8.9 a Rust.
//! La fuente de referencia es el código MCP/desofuscado 1.8.9 suministrado.

mod registry;
pub use registry::{packet_id, packet_name, ConnectionState, Direction, PacketDefinition, PACKETS, PROTOCOL_VERSION};

use flate2::{read::ZlibDecoder, write::ZlibEncoder, Compression};
use std::io::{self, Read, Write};
use std::net::{TcpStream, ToSocketAddrs};
use std::time::Duration;
use std::sync::mpsc::{self, Receiver};
use std::thread;
use thiserror::Error;

const MAX_PACKET_SIZE: usize = 2 * 1024 * 1024;

#[derive(Debug, Error)]
pub enum ProtocolError {
    #[error("error de E/S de red: {0}")]
    Io(#[from] io::Error),
    #[error("paquete inválido: {0}")]
    InvalidPacket(String),
    #[error("el servidor rechazó el inicio de sesión: {0}")]
    LoginRejected(String),
    #[error("el servidor exige autenticación premium (online-mode=true); esta compilación usa modo no premium")]
    PremiumAuthenticationRequired,
    #[error("respuesta inesperada durante el inicio de sesión: paquete 0x{0:02X}")]
    UnexpectedLoginPacket(i32),
    #[error("no se pudo resolver la dirección del servidor: {0}")]
    Resolve(String),
}

pub type ProtocolResult<T> = std::result::Result<T, ProtocolError>;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Packet {
    pub id: i32,
    pub payload: Vec<u8>,
}

#[derive(Debug)]
pub struct OfflineConnection {
    stream: TcpStream,
    compression_threshold: Option<usize>,
    pub username: String,
    pub uuid: String,
}

impl OfflineConnection {
    /// Lee el siguiente paquete servidor→cliente en estado PLAY.
    pub fn read_play_packet(&mut self) -> ProtocolResult<Packet> {
        read_packet(&mut self.stream, self.compression_threshold)
    }

    /// Envía un paquete cliente→servidor en estado PLAY. `id` es el ID de protocolo 47.
    pub fn write_play_packet(&mut self, id: i32, payload: &[u8]) -> ProtocolResult<()> {
        write_packet(&mut self.stream, id, payload, self.compression_threshold)
    }

    pub fn set_read_timeout(&self, timeout: Option<Duration>) -> ProtocolResult<()> {
        self.stream.set_read_timeout(timeout)?;
        Ok(())
    }
}

/// Eventos observables de una sesión PLAY remota.
#[derive(Debug, Clone)]
pub enum PlayEvent {
    Connected { username: String, uuid: String },
    Packet { id: i32, name: Option<&'static str>, payload_len: usize },
    KeepAliveAnswered,
    ClientSettingsSent,
    PlayerPositionConfirmed { x: f64, y: f64, z: f64, yaw: f32, pitch: f32 },
    Disconnected(String),
    NetworkError(String),
}

/// Mantiene viva la conexión después de Login Success y procesa el flujo PLAY.
/// El hilo propietario conserva el socket hasta que el servidor cierre la sesión.
pub fn start_play_session(mut connection: OfflineConnection) -> Receiver<PlayEvent> {
    let (tx, rx) = mpsc::channel();
    // connect_offline uses a finite LOGIN timeout. PLAY is a long-lived session,
    // so clear it before entering the blocking receive loop or an idle server
    // would be mistaken for a network failure after ten seconds.
    if let Err(error) = connection.set_read_timeout(None) {
        let _ = tx.send(PlayEvent::NetworkError(error.to_string()));
        return rx;
    }
    thread::spawn(move || {
        let _ = tx.send(PlayEvent::Connected {
            username: connection.username.clone(),
            uuid: connection.uuid.clone(),
        });
        let mut sent_client_settings = false;
        let mut player_pose: Option<(f64, f64, f64, f32, f32)> = None;
        loop {
            let packet = match connection.read_play_packet() {
                Ok(packet) => packet,
                Err(error) => {
                    let _ = tx.send(PlayEvent::NetworkError(error.to_string()));
                    break;
                }
            };
            let name = packet_name(ConnectionState::Play, Direction::Clientbound, packet.id);
            let _ = tx.send(PlayEvent::Packet { id: packet.id, name, payload_len: packet.payload.len() });
            match packet.id {
                // S00PacketKeepAlive -> C00PacketKeepAlive. In protocol 47 its
                // payload is the same VarInt, so echo the exact payload bytes.
                0x00 => {
                    if let Err(error) = connection.write_play_packet(0x00, &packet.payload) {
                        let _ = tx.send(PlayEvent::NetworkError(format!("no se pudo responder Keep Alive: {error}")));
                        break;
                    }
                    let _ = tx.send(PlayEvent::KeepAliveAnswered);
                }
                // The vanilla 1.8.9 client sends C15PacketClientSettings after Join Game.
                0x01 if !sent_client_settings => {
                    let payload = match client_settings_payload() { Ok(payload) => payload, Err(error) => {
                        let _ = tx.send(PlayEvent::NetworkError(error.to_string()));
                        break;
                    }};
                    if let Err(error) = connection.write_play_packet(0x15, &payload) {
                        let _ = tx.send(PlayEvent::NetworkError(format!("no se pudo enviar Client Settings: {error}")));
                        break;
                    }
                    sent_client_settings = true;
                    let _ = tx.send(PlayEvent::ClientSettingsSent);
                }
                // S08PacketPlayerPosLook must be acknowledged with C06PacketPlayerPosLook.
                0x08 => {
                    match confirm_player_position_look(&packet.payload, player_pose) {
                        Ok((response, pose)) => {
                            if let Err(error) = connection.write_play_packet(0x06, &response) {
                                let _ = tx.send(PlayEvent::NetworkError(format!("no se pudo confirmar Player Position/Look: {error}")));
                                break;
                            }
                            player_pose = Some(pose);
                            let _ = tx.send(PlayEvent::PlayerPositionConfirmed { x: pose.0, y: pose.1, z: pose.2, yaw: pose.3, pitch: pose.4 });
                        }
                        Err(error) => {
                            let _ = tx.send(PlayEvent::NetworkError(format!("S08 Player Position/Look inválido: {error}")));
                            break;
                        }
                    }
                }
                // S40PacketDisconnect carries a JSON chat component string.
                0x40 => {
                    let reason = read_string(&packet.payload, 0)
                        .map(|(text, _)| text)
                        .unwrap_or_else(|_| "el servidor envió un motivo de desconexión ilegible".to_owned());
                    let _ = tx.send(PlayEvent::Disconnected(reason));
                    break;
                }
                _ => { /* The framed packet is consumed; unimplemented PLAY IDs are logged, not fatal. */ }
            }
        }
    });
    rx
}

/// Conecta a un servidor Java 1.8.9 con `online-mode=false`.
/// Envía Handshake (estado LOGIN) y Login Start; procesa compresión y Login Success.
pub fn connect_offline<A: ToSocketAddrs>(address: A, server_host: &str, server_port: u16, username: &str) -> ProtocolResult<OfflineConnection> {
    if username.is_empty() || username.len() > 16 || !username.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_') {
        return Err(ProtocolError::InvalidPacket("el nombre offline debe tener entre 1 y 16 caracteres ASCII alfanuméricos o '_'".into()));
    }
    if server_host.len() > 255 {
        return Err(ProtocolError::InvalidPacket("el host del handshake supera 255 bytes".into()));
    }
    let socket = address.to_socket_addrs().map_err(|e| ProtocolError::Resolve(e.to_string()))?.next()
        .ok_or_else(|| ProtocolError::Resolve("la dirección no produjo ninguna IP".into()))?;
    let mut stream = TcpStream::connect_timeout(&socket, Duration::from_secs(8))?;
    stream.set_nodelay(true)?;
    stream.set_read_timeout(Some(Duration::from_secs(10)))?;
    stream.set_write_timeout(Some(Duration::from_secs(10)))?;

    // C00Handshake: protocolVersion VarInt, serverAddress String, serverPort u16, nextState VarInt=2 (LOGIN).
    let mut handshake = Vec::with_capacity(server_host.len() + 16);
    write_varint(&mut handshake, PROTOCOL_VERSION);
    write_string(&mut handshake, server_host)?;
    handshake.extend_from_slice(&server_port.to_be_bytes());
    write_varint(&mut handshake, 2);
    write_packet(&mut stream, 0x00, &handshake, None)?;

    // C00PacketLoginStart: GameProfile UUID nulo; solo serializa el nombre.
    let mut login_start = Vec::with_capacity(username.len() + 5);
    write_string(&mut login_start, username)?;
    write_packet(&mut stream, 0x00, &login_start, None)?;

    let mut compression_threshold = None;
    loop {
        let packet = read_packet(&mut stream, compression_threshold)?;
        match packet.id {
            0x00 => {
                let reason = read_string(&packet.payload, 0)
                    .map(|(reason, _)| reason)
                    .unwrap_or_else(|_| "motivo de desconexión no legible".to_owned());
                return Err(ProtocolError::LoginRejected(reason));
            }
            0x01 => {
                // S01PacketEncryptionRequest: offline mode no negocia cifrado AES/Mojang.
                return Err(ProtocolError::PremiumAuthenticationRequired);
            }
            0x02 => {
                let (uuid, offset) = read_string(&packet.payload, 0)?;
                let (returned_name, used) = read_string(&packet.payload, offset)?;
                if uuid.len() != 36 || returned_name.is_empty() || returned_name.len() > 16 {
                    return Err(ProtocolError::InvalidPacket("campos de S02 Login Success fuera de los límites MCP".into()));
                }
                if offset + used != packet.payload.len() {
                    return Err(ProtocolError::InvalidPacket("S02 Login Success contiene bytes sobrantes".into()));
                }
                return Ok(OfflineConnection { stream, compression_threshold, username: returned_name, uuid });
            }
            0x03 => {
                let (threshold, used) = read_varint(&packet.payload, 0)?;
                if used != packet.payload.len() || threshold < 0 {
                    return Err(ProtocolError::InvalidPacket("S03 Enable Compression contiene un umbral inválido".into()));
                }
                compression_threshold = Some(threshold as usize);
            }
            other => return Err(ProtocolError::UnexpectedLoginPacket(other)),
        }
    }
}



/// Decodes S08PacketPlayerPosLook and builds the vanilla C06 acknowledgement.
/// Protocol 47 uses absolute values unless the corresponding relative flag is set.
fn confirm_player_position_look(
    payload: &[u8],
    current: Option<(f64, f64, f64, f32, f32)>,
) -> ProtocolResult<(Vec<u8>, (f64, f64, f64, f32, f32))> {
    if payload.len() != 33 {
        return Err(ProtocolError::InvalidPacket(format!("S08 Player Position/Look debe medir 33 bytes, recibió {}", payload.len())));
    }
    let base = current.unwrap_or((0.0, 0.0, 0.0, 0.0, 0.0));
    let x = f64::from_be_bytes(payload[0..8].try_into().unwrap());
    let y = f64::from_be_bytes(payload[8..16].try_into().unwrap());
    let z = f64::from_be_bytes(payload[16..24].try_into().unwrap());
    let yaw = f32::from_be_bytes(payload[24..28].try_into().unwrap());
    let pitch = f32::from_be_bytes(payload[28..32].try_into().unwrap());
    let flags = payload[32];
    let pose = (
        if flags & 0x01 != 0 { base.0 + x } else { x },
        if flags & 0x02 != 0 { base.1 + y } else { y },
        if flags & 0x04 != 0 { base.2 + z } else { z },
        if flags & 0x08 != 0 { base.3 + yaw } else { yaw },
        if flags & 0x10 != 0 { base.4 + pitch } else { pitch },
    );
    let mut response = Vec::with_capacity(33);
    response.extend_from_slice(&pose.0.to_be_bytes());
    response.extend_from_slice(&pose.1.to_be_bytes());
    response.extend_from_slice(&pose.2.to_be_bytes());
    response.extend_from_slice(&pose.3.to_be_bytes());
    response.extend_from_slice(&pose.4.to_be_bytes());
    response.push(0); // onGround=false, matching the initial vanilla teleport acknowledgement.
    Ok((response, pose))
}

/// Serialización de C15PacketClientSettings según MCP 1.8.9.
fn client_settings_payload() -> ProtocolResult<Vec<u8>> {
    let mut payload = Vec::with_capacity(16);
    write_string(&mut payload, "en_US")?;
    payload.push(8); // render distance
    write_varint(&mut payload, 0); // chat visibility: enabled
    payload.push(1); // chat colors
    payload.push(0x7f); // all skin parts enabled
    Ok(payload)
}

fn write_packet(stream: &mut TcpStream, packet_id: i32, payload: &[u8], threshold: Option<usize>) -> ProtocolResult<()> {
    if packet_id < 0 { return Err(ProtocolError::InvalidPacket("ID de paquete negativo".into())); }
    let mut packet_data = Vec::with_capacity(payload.len() + 5);
    write_varint(&mut packet_data, packet_id);
    packet_data.extend_from_slice(payload);
    if packet_data.len() > MAX_PACKET_SIZE { return Err(ProtocolError::InvalidPacket("paquete saliente demasiado grande".into())); }

    let mut framed_data = Vec::new();
    if let Some(limit) = threshold {
        if packet_data.len() >= limit {
            write_varint(&mut framed_data, packet_data.len() as i32);
            let mut encoder = ZlibEncoder::new(Vec::new(), Compression::default());
            encoder.write_all(&packet_data)?;
            framed_data.extend_from_slice(&encoder.finish()?);
        } else {
            write_varint(&mut framed_data, 0);
            framed_data.extend_from_slice(&packet_data);
        }
    } else {
        framed_data = packet_data;
    }
    let mut frame = Vec::with_capacity(framed_data.len() + 5);
    write_varint(&mut frame, framed_data.len() as i32);
    frame.extend_from_slice(&framed_data);
    stream.write_all(&frame)?;
    stream.flush()?;
    Ok(())
}

fn read_packet(stream: &mut TcpStream, threshold: Option<usize>) -> ProtocolResult<Packet> {
    let frame_len = read_varint_stream(stream)?;
    if frame_len < 0 || frame_len as usize > MAX_PACKET_SIZE {
        return Err(ProtocolError::InvalidPacket(format!("longitud de frame fuera de rango: {frame_len}")));
    }
    let mut frame = vec![0u8; frame_len as usize];
    stream.read_exact(&mut frame)?;
    let packet_data = if threshold.is_some() {
        let (uncompressed_len, consumed) = read_varint(&frame, 0)?;
        if uncompressed_len < 0 || uncompressed_len as usize > MAX_PACKET_SIZE {
            return Err(ProtocolError::InvalidPacket("longitud descomprimida fuera de rango".into()));
        }
        if uncompressed_len == 0 {
            frame[consumed..].to_vec()
        } else {
            if (uncompressed_len as usize) < threshold.unwrap_or(0) {
                return Err(ProtocolError::InvalidPacket("paquete comprimido menor que el umbral negociado".into()));
            }
            let mut decoder = ZlibDecoder::new(&frame[consumed..]);
            let mut decoded = Vec::with_capacity(uncompressed_len as usize);
            decoder.take((MAX_PACKET_SIZE + 1) as u64).read_to_end(&mut decoded)?;
            if decoded.len() != uncompressed_len as usize {
                return Err(ProtocolError::InvalidPacket("longitud Zlib no coincide con el prefijo".into()));
            }
            decoded
        }
    } else { frame };
    let (id, consumed) = read_varint(&packet_data, 0)?;
    if id < 0 { return Err(ProtocolError::InvalidPacket("ID de paquete negativo".into())); }
    Ok(Packet { id, payload: packet_data[consumed..].to_vec() })
}

fn read_varint_stream<R: Read>(reader: &mut R) -> ProtocolResult<i32> {
    let mut value = 0u32;
    for index in 0..5 {
        let mut byte = [0u8; 1];
        reader.read_exact(&mut byte)?;
        value |= ((byte[0] & 0x7f) as u32) << (7 * index);
        if byte[0] & 0x80 == 0 { return Ok(value as i32); }
    }
    Err(ProtocolError::InvalidPacket("VarInt excede cinco bytes".into()))
}

pub fn write_varint(out: &mut Vec<u8>, value: i32) {
    let mut value = value as u32;
    loop {
        if value & !0x7f == 0 { out.push(value as u8); return; }
        out.push(((value & 0x7f) | 0x80) as u8);
        value >>= 7;
    }
}

pub fn read_varint(data: &[u8], start: usize) -> ProtocolResult<(i32, usize)> {
    let mut value = 0u32;
    for index in 0..5 {
        let byte = *data.get(start + index).ok_or_else(|| ProtocolError::InvalidPacket("VarInt truncado".into()))?;
        value |= ((byte & 0x7f) as u32) << (7 * index);
        if byte & 0x80 == 0 { return Ok((value as i32, index + 1)); }
    }
    Err(ProtocolError::InvalidPacket("VarInt excede cinco bytes".into()))
}

pub fn write_string(out: &mut Vec<u8>, value: &str) -> ProtocolResult<()> {
    if value.len() > 32767 { return Err(ProtocolError::InvalidPacket("String supera el máximo del protocolo".into())); }
    write_varint(out, value.len() as i32);
    out.extend_from_slice(value.as_bytes());
    Ok(())
}

pub fn read_string(data: &[u8], start: usize) -> ProtocolResult<(String, usize)> {
    let (len, used) = read_varint(data, start)?;
    if len < 0 || len as usize > 32767 { return Err(ProtocolError::InvalidPacket("longitud de String inválida".into())); }
    let begin = start + used;
    let end = begin.checked_add(len as usize).ok_or_else(|| ProtocolError::InvalidPacket("overflow en String".into()))?;
    let bytes = data.get(begin..end).ok_or_else(|| ProtocolError::InvalidPacket("String truncado".into()))?;
    let value = std::str::from_utf8(bytes).map_err(|_| ProtocolError::InvalidPacket("String no es UTF-8 válido".into()))?.to_owned();
    Ok((value, used + len as usize))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test] fn varint_round_trips_protocol_values() {
        for value in [0, 1, 127, 128, 255, 25565, 2_097_151, i32::MAX, -1] {
            let mut bytes = Vec::new(); write_varint(&mut bytes, value);
            assert_eq!(read_varint(&bytes, 0).unwrap(), (value, bytes.len()));
        }
    }
    #[test] fn string_round_trip_preserves_utf8() {
        let mut bytes = Vec::new(); write_string(&mut bytes, "Jugador_ñ").unwrap();
        assert_eq!(read_string(&bytes, 0).unwrap().0, "Jugador_ñ");
    }
    #[test] fn player_position_look_applies_relative_flags_and_builds_c06() {
        let mut payload = Vec::new();
        payload.extend_from_slice(&1.5_f64.to_be_bytes());
        payload.extend_from_slice(&2.0_f64.to_be_bytes());
        payload.extend_from_slice(&(-3.0_f64).to_be_bytes());
        payload.extend_from_slice(&10.0_f32.to_be_bytes());
        payload.extend_from_slice(&(-5.0_f32).to_be_bytes());
        payload.push(0x1f); // all coordinates and both angles are relative
        let (response, pose) = confirm_player_position_look(&payload, Some((100.0, 64.0, 200.0, 30.0, 15.0))).unwrap();
        assert_eq!(pose, (101.5, 66.0, 197.0, 40.0, 10.0));
        assert_eq!(response.len(), 33);
        assert_eq!(response[32], 0);
    }

    #[test] fn client_settings_payload_matches_protocol_47_field_order() {
        let payload = client_settings_payload().unwrap();
        let (locale, used) = read_string(&payload, 0).unwrap();
        assert_eq!(locale, "en_US");
        assert_eq!(payload[used], 8);
        let (chat_mode, chat_used) = read_varint(&payload, used + 1).unwrap();
        assert_eq!(chat_mode, 0);
        assert_eq!(payload[used + 1 + chat_used], 1);
        assert_eq!(payload[used + 2 + chat_used], 0x7f);
        assert_eq!(used + 3 + chat_used, payload.len());
    }

    #[test] fn packet_registry_contains_login_and_play_ids_from_mcp() {
        assert_eq!(packet_id(ConnectionState::Handshaking, Direction::Serverbound, "C00Handshake"), Some(0));
        assert_eq!(packet_id(ConnectionState::Login, Direction::Serverbound, "C00PacketLoginStart"), Some(0));
        assert_eq!(packet_id(ConnectionState::Login, Direction::Clientbound, "S02PacketLoginSuccess"), Some(2));
        assert_eq!(packet_name(ConnectionState::Play, Direction::Clientbound, 0x21), Some("S21PacketChunkData"));
        assert_eq!(packet_name(ConnectionState::Play, Direction::Serverbound, 0x03), Some("C03PacketPlayer"));
    }
}
