//! Small defensive NBT reader for Minecraft Java Edition world data.
use mc189_core::{Mc189Error, Result};
use std::io::{Cursor, Read};

const MAX_COLLECTION_LEN: usize = 16 * 1024 * 1024;
const MAX_DEPTH: usize = 64;

#[derive(Debug, Clone)]
pub enum Tag {
    Byte(i8), Short(i16), Int(i32), Long(i64), Float(f32), Double(f64),
    ByteArray(Vec<i8>), String(String), List(u8, Vec<Tag>), Compound(Vec<(String, Tag)>),
    IntArray(Vec<i32>), LongArray(Vec<i64>),
}

impl Tag {
    pub fn as_compound(&self) -> Option<&[(String, Tag)]> {
        if let Self::Compound(entries) = self { Some(entries) } else { None }
    }
    pub fn get(&self, name: &str) -> Option<&Tag> {
        self.as_compound()?.iter().find(|(key, _)| key == name).map(|(_, value)| value)
    }
    pub fn as_byte(&self) -> Option<i8> { if let Self::Byte(v) = self { Some(*v) } else { None } }
    pub fn as_short(&self) -> Option<i16> { if let Self::Short(v) = self { Some(*v) } else { None } }
    pub fn as_int(&self) -> Option<i32> { if let Self::Int(v) = self { Some(*v) } else { None } }
    pub fn as_long(&self) -> Option<i64> { if let Self::Long(v) = self { Some(*v) } else { None } }
    pub fn as_byte_array(&self) -> Option<&[i8]> { if let Self::ByteArray(v) = self { Some(v) } else { None } }
    pub fn as_int_array(&self) -> Option<&[i32]> { if let Self::IntArray(v) = self { Some(v) } else { None } }
    pub fn as_long_array(&self) -> Option<&[i64]> { if let Self::LongArray(v) = self { Some(v) } else { None } }
    pub fn as_string(&self) -> Option<&str> { if let Self::String(v) = self { Some(v) } else { None } }
    pub fn as_list(&self) -> Option<(u8, &[Tag])> { if let Self::List(id, v) = self { Some((*id, v)) } else { None } }
    pub fn as_list_mut(&mut self) -> Option<&mut Vec<Tag>> { if let Self::List(_, v) = self { Some(v) } else { None } }
}


impl PartialEq for Tag {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (Self::Byte(a), Self::Byte(b)) => a == b,
            (Self::Short(a), Self::Short(b)) => a == b,
            (Self::Int(a), Self::Int(b)) => a == b,
            (Self::Long(a), Self::Long(b)) => a == b,
            (Self::Float(a), Self::Float(b)) => a.to_bits() == b.to_bits(),
            (Self::Double(a), Self::Double(b)) => a.to_bits() == b.to_bits(),
            (Self::ByteArray(a), Self::ByteArray(b)) => a == b,
            (Self::String(a), Self::String(b)) => a == b,
            (Self::List(at, a), Self::List(bt, b)) => at == bt && a == b,
            (Self::Compound(a), Self::Compound(b)) => {
                if a.len() != b.len() { return false; }
                let mut matched = vec![false; b.len()];
                for (name, value) in a {
                    let Some(index) = b.iter().enumerate().position(|(index, (other_name, other_value))|
                        !matched[index] && name == other_name && value == other_value) else { return false; };
                    matched[index] = true;
                }
                true
            }
            (Self::IntArray(a), Self::IntArray(b)) => a == b,
            (Self::LongArray(a), Self::LongArray(b)) => a == b,
            _ => false,
        }
    }
}
impl Eq for Tag {}

fn read_exact<const N: usize>(r: &mut Cursor<&[u8]>) -> Result<[u8; N]> {
    let mut b = [0; N];
    r.read_exact(&mut b)?;
    Ok(b)
}
fn read_string(r: &mut Cursor<&[u8]>) -> Result<String> {
    let len = u16::from_be_bytes(read_exact::<2>(r)?) as usize;
    let mut b = vec![0; len]; r.read_exact(&mut b)?;
    String::from_utf8(b).map_err(|_| Mc189Error::InvalidData("NBT string is not valid UTF-8".into()))
}
fn read_len(r: &mut Cursor<&[u8]>) -> Result<usize> {
    let len = i32::from_be_bytes(read_exact::<4>(r)?);
    if len < 0 || len as usize > MAX_COLLECTION_LEN {
        return Err(Mc189Error::InvalidData(format!("invalid NBT collection length: {len}")));
    }
    Ok(len as usize)
}
fn parse_payload(id: u8, r: &mut Cursor<&[u8]>, depth: usize) -> Result<Tag> {
    if depth > MAX_DEPTH { return Err(Mc189Error::InvalidData("NBT nesting limit exceeded".into())); }
    Ok(match id {
        1 => Tag::Byte(i8::from_be_bytes(read_exact::<1>(r)?)),
        2 => Tag::Short(i16::from_be_bytes(read_exact::<2>(r)?)),
        3 => Tag::Int(i32::from_be_bytes(read_exact::<4>(r)?)),
        4 => Tag::Long(i64::from_be_bytes(read_exact::<8>(r)?)),
        5 => Tag::Float(f32::from_bits(u32::from_be_bytes(read_exact::<4>(r)?))),
        6 => Tag::Double(f64::from_bits(u64::from_be_bytes(read_exact::<8>(r)?))),
        7 => { let n = read_len(r)?; let mut bytes = vec![0_u8; n]; r.read_exact(&mut bytes)?; Tag::ByteArray(bytes.into_iter().map(|b| b as i8).collect()) },
        8 => Tag::String(read_string(r)?),
        9 => { let child = read_exact::<1>(r)?[0]; let n = read_len(r)?; if child == 0 && n > 0 { return Err(Mc189Error::InvalidData("non-empty NBT list has TAG_End element type".into())); } let mut v = Vec::with_capacity(n); for _ in 0..n { v.push(parse_payload(child, r, depth + 1)?); } Tag::List(child, v) },
        10 => { let mut v = Vec::new(); loop { let child = read_exact::<1>(r)?[0]; if child == 0 { break; } if child > 12 { return Err(Mc189Error::InvalidData(format!("unknown NBT tag type {child}"))); } let name = read_string(r)?; let value = parse_payload(child, r, depth + 1)?; v.push((name, value)); } Tag::Compound(v) },
        11 => { let n = read_len(r)?; let mut v = Vec::with_capacity(n); for _ in 0..n { v.push(i32::from_be_bytes(read_exact::<4>(r)?)); } Tag::IntArray(v) },
        12 => { let n = read_len(r)?; let mut v = Vec::with_capacity(n); for _ in 0..n { v.push(i64::from_be_bytes(read_exact::<8>(r)?)); } Tag::LongArray(v) },
        _ => return Err(Mc189Error::InvalidData(format!("invalid NBT tag type {id}"))),
    })
}

pub fn parse_root(bytes: &[u8]) -> Result<(String, Tag)> {
    let mut r = Cursor::new(bytes);
    let id = read_exact::<1>(&mut r)?[0];
    if id != 10 { return Err(Mc189Error::InvalidData(format!("NBT root must be a compound, got tag {id}"))); }
    let name = read_string(&mut r)?;
    let root = parse_payload(id, &mut r, 0)?;
    if r.position() != bytes.len() as u64 {
        return Err(Mc189Error::InvalidData(format!("{} trailing bytes after NBT root", bytes.len() as u64 - r.position())));
    }
    Ok((name, root))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn parses_empty_root_compound() {
        let bytes = [10, 0, 0, 0];
        let (name, root) = parse_root(&bytes).unwrap();
        assert_eq!(name, "");
        assert_eq!(root.as_compound().unwrap().len(), 0);
    }
    #[test]
    fn rejects_non_compound_root() { assert!(parse_root(&[3, 0, 0, 0, 0, 0]).is_err()); }
}

impl Tag {
    pub fn as_compound_mut(&mut self) -> Option<&mut Vec<(String, Tag)>> { if let Self::Compound(v) = self { Some(v) } else { None } }
    pub fn get_mut(&mut self, name: &str) -> Option<&mut Tag> { let entries=self.as_compound_mut()?; let index=entries.iter().position(|(key,_)| key==name)?; Some(&mut entries[index].1) }
    pub fn insert(&mut self, name: impl Into<String>, value: Tag) -> Result<()> {
        let entries = self.as_compound_mut().ok_or_else(|| Mc189Error::InvalidData("NBT insert target is not a compound".into()))?;
        let name = name.into();
        if let Some(index) = entries.iter().position(|(key, _)| key == &name) { entries[index].1 = value; } else { entries.push((name, value)); }
        Ok(())
    }
}

fn write_string(out: &mut Vec<u8>, value: &str) -> Result<()> {
    let len = u16::try_from(value.len()).map_err(|_| Mc189Error::InvalidData("NBT string exceeds 65535 bytes".into()))?;
    out.extend_from_slice(&len.to_be_bytes()); out.extend_from_slice(value.as_bytes()); Ok(())
}
fn tag_id(tag: &Tag) -> u8 { match tag { Tag::Byte(_)=>1,Tag::Short(_)=>2,Tag::Int(_)=>3,Tag::Long(_)=>4,Tag::Float(_)=>5,Tag::Double(_)=>6,Tag::ByteArray(_)=>7,Tag::String(_)=>8,Tag::List(_,_)=>9,Tag::Compound(_)=>10,Tag::IntArray(_)=>11,Tag::LongArray(_)=>12 } }
fn write_payload(out: &mut Vec<u8>, tag: &Tag, depth: usize) -> Result<()> {
    if depth > MAX_DEPTH { return Err(Mc189Error::InvalidData("NBT nesting limit exceeded while writing".into())); }
    match tag {
        Tag::Byte(v)=>out.push(*v as u8), Tag::Short(v)=>out.extend_from_slice(&v.to_be_bytes()), Tag::Int(v)=>out.extend_from_slice(&v.to_be_bytes()), Tag::Long(v)=>out.extend_from_slice(&v.to_be_bytes()),
        Tag::Float(v)=>out.extend_from_slice(&v.to_bits().to_be_bytes()), Tag::Double(v)=>out.extend_from_slice(&v.to_bits().to_be_bytes()),
        Tag::ByteArray(v)=>{out.extend_from_slice(&(i32::try_from(v.len()).map_err(|_| Mc189Error::InvalidData("NBT byte array too large".into()))?).to_be_bytes()); out.extend(v.iter().map(|x| *x as u8));},
        Tag::String(v)=>write_string(out,v)?,
        Tag::List(id, values)=>{ if values.iter().any(|v| tag_id(v)!=*id) { return Err(Mc189Error::InvalidData("heterogeneous NBT list".into())); } out.push(*id); out.extend_from_slice(&(i32::try_from(values.len()).map_err(|_| Mc189Error::InvalidData("NBT list too large".into()))?).to_be_bytes()); for v in values { write_payload(out,v,depth+1)?; } },
        Tag::Compound(entries)=>{ for (name,value) in entries { out.push(tag_id(value)); write_string(out,name)?; write_payload(out,value,depth+1)?; } out.push(0); },
        Tag::IntArray(v)=>{out.extend_from_slice(&(i32::try_from(v.len()).map_err(|_| Mc189Error::InvalidData("NBT int array too large".into()))?).to_be_bytes()); for x in v {out.extend_from_slice(&x.to_be_bytes());}},
        Tag::LongArray(v)=>{out.extend_from_slice(&(i32::try_from(v.len()).map_err(|_| Mc189Error::InvalidData("NBT long array too large".into()))?).to_be_bytes()); for x in v {out.extend_from_slice(&x.to_be_bytes());}},
    } Ok(())
}
pub fn write_root(name: &str, root: &Tag) -> Result<Vec<u8>> {
    if !matches!(root, Tag::Compound(_)) { return Err(Mc189Error::InvalidData("NBT root must be a compound".into())); }
    let mut out=vec![10]; write_string(&mut out,name)?; write_payload(&mut out,root,0)?; Ok(out)
}
