//! Defensive readers and transactional legacy Anvil/NBT editing for Minecraft Java Edition 1.8.9.
//!
//! This crate validates Anvil region records, decompresses chunk payloads, parses
//! NBT, decodes legacy pre-palette block arrays, and safely rewrites modified chunks.

use mc189_core::{Mc189Error, Result};
mod nbt;
pub use nbt::{parse_root as parse_nbt_root, write_root as write_nbt_root, Tag as NbtTag};

use flate2::read::{GzDecoder, ZlibDecoder};
use flate2::write::GzEncoder;
use flate2::Compression;
use std::collections::{BTreeMap, HashSet};
use std::fs::{self, File};
use std::io::{Read, Seek, SeekFrom, Write};
use std::path::Path;

pub const SECTOR_BYTES: usize = 4096;
pub const HEADER_SECTORS: usize = 2;
pub const HEADER_BYTES: usize = SECTOR_BYTES * HEADER_SECTORS;
pub const LOCATION_ENTRIES: usize = 1024;
pub const BLOCKS_PER_SECTION: usize = 4096;
pub const NIBBLE_BYTES_PER_SECTION: usize = 2048;
const MAX_DECOMPRESSED_CHUNK_BYTES: u64 = 64 * 1024 * 1024;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ChunkLocation {
    /// Sector offset from the beginning of the region file.
    pub sector_offset: u32,
    /// Number of sectors occupied by the chunk record.
    pub sector_count: u8,
}

impl ChunkLocation {
    pub fn is_present(self) -> bool {
        self.sector_offset != 0 && self.sector_count != 0
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RegionHeader {
    locations: [ChunkLocation; LOCATION_ENTRIES],
    timestamps: [u32; LOCATION_ENTRIES],
    file_len: u64,
}

impl RegionHeader {
    pub fn parse(bytes: &[u8], file_len: u64) -> Result<Self> {
        if bytes.len() < HEADER_BYTES {
            return Err(Mc189Error::InvalidData(format!(
                "region header is {} bytes; expected at least {}",
                bytes.len(), HEADER_BYTES
            )));
        }

        let mut locations = [ChunkLocation { sector_offset: 0, sector_count: 0 }; LOCATION_ENTRIES];
        let mut timestamps = [0_u32; LOCATION_ENTRIES];

        for index in 0..LOCATION_ENTRIES {
            let start = index * 4;
            let raw = &bytes[start..start + 4];
            let sector_offset =
                (u32::from(raw[0]) << 16) | (u32::from(raw[1]) << 8) | u32::from(raw[2]);
            let sector_count = raw[3];
            let location = ChunkLocation { sector_offset, sector_count };

            if location.is_present() {
                if sector_offset < HEADER_SECTORS as u32 {
                    return Err(Mc189Error::InvalidData(format!(
                        "chunk slot {index} points into the region header (sector {sector_offset})"
                    )));
                }
                let end = (u64::from(sector_offset) + u64::from(sector_count)) * SECTOR_BYTES as u64;
                if end > file_len {
                    return Err(Mc189Error::InvalidData(format!(
                        "chunk slot {index} extends past end of file ({end} > {file_len} bytes)"
                    )));
                }
            } else if sector_offset != 0 || sector_count != 0 {
                return Err(Mc189Error::InvalidData(format!(
                    "chunk slot {index} has an incomplete location entry"
                )));
            }

            locations[index] = location;
            let ts_start = SECTOR_BYTES + index * 4;
            timestamps[index] = u32::from_be_bytes([
                bytes[ts_start], bytes[ts_start + 1], bytes[ts_start + 2], bytes[ts_start + 3],
            ]);
        }
        Ok(Self { locations, timestamps, file_len })
    }

    pub fn from_file(path: impl AsRef<Path>) -> Result<Self> {
        let path = path.as_ref();
        let mut file = File::open(path)?;
        let file_len = file.metadata()?.len();
        if file_len < HEADER_BYTES as u64 {
            return Err(Mc189Error::InvalidData(format!(
                "{} is too small to be a region file ({} bytes)", path.display(), file_len
            )));
        }
        let mut header = vec![0_u8; HEADER_BYTES];
        file.read_exact(&mut header)?;
        Self::parse(&header, file_len)
    }

    pub fn location(&self, local_x: u8, local_z: u8) -> Option<ChunkLocation> {
        if local_x > 31 || local_z > 31 { return None; }
        Some(self.locations[usize::from(local_x) + usize::from(local_z) * 32])
    }

    pub fn timestamp(&self, local_x: u8, local_z: u8) -> Option<u32> {
        if local_x > 31 || local_z > 31 { return None; }
        Some(self.timestamps[usize::from(local_x) + usize::from(local_z) * 32])
    }

    pub fn present_chunks(&self) -> usize {
        self.locations.iter().filter(|entry| entry.is_present()).count()
    }

    pub fn file_len(&self) -> u64 { self.file_len }
}

/// A decoded legacy (1.8.9) section. Arrays use Minecraft's index order:
/// `index = (y << 8) | (z << 4) | x`, where each local coordinate is 0..15.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChunkSection {
    /// Section Y coordinate (0..15 in the vanilla 1.8 world height).
    pub y: u8,
    /// Decoded 12-bit block IDs. Vanilla 1.8 uses far fewer than 4096 IDs;
    /// retaining all 12 bits preserves modded block IDs too.
    pub block_ids: Vec<u16>,
    /// Decoded 4-bit block metadata, one value per block.
    pub metadata: Vec<u8>,
    /// Decoded block light (0..15), absent only if the NBT field is absent.
    pub block_light: Option<Vec<u8>>,
    /// Decoded sky light (0..15), absent only if the NBT field is absent.
    pub sky_light: Option<Vec<u8>>,
}

impl ChunkSection {
    /// Fetch a block ID using section-local x, y and z coordinates.
    pub fn block_id_at(&self, x: u8, y: u8, z: u8) -> Option<u16> {
        let index = section_index(x, y, z)?;
        self.block_ids.get(index).copied()
    }

    /// Fetch block metadata using section-local coordinates.
    pub fn metadata_at(&self, x: u8, y: u8, z: u8) -> Option<u8> {
        let index = section_index(x, y, z)?;
        self.metadata.get(index).copied()
    }

    /// Read decoded block/sky light at a block position. Values remain in the
    /// vanilla 0..15 nibble range; a missing light array is represented as None
    /// so the chunk-level sampler can apply its heightmap-aware fallback.
    pub fn block_light_at(&self, x: u8, y: u8, z: u8) -> Option<u8> {
        let index = section_index(x, y, z)?;
        self.block_light.as_ref()?.get(index).copied().map(|v| v & 15)
    }

    pub fn sky_light_at(&self, x: u8, y: u8, z: u8) -> Option<u8> {
        let index = section_index(x, y, z)?;
        self.sky_light.as_ref()?.get(index).copied().map(|v| v & 15)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChunkData {
    pub x_pos: i32,
    pub z_pos: i32,
    pub sections: Vec<ChunkSection>,
    /// Biome ID for each column, indexed as z * 16 + x.
    pub biomes: Option<Vec<u8>>,
    /// Heightmap (256 values), indexed as z * 16 + x.
    pub height_map: Option<Vec<i32>>,
}

impl ChunkData {
    /// Number of block positions physically stored in section arrays.
    /// Missing sections are implicitly all air in the legacy Anvil format.
    pub fn stored_block_slots(&self) -> usize {
        self.sections.len() * BLOCKS_PER_SECTION
    }

    pub fn non_air_blocks(&self) -> usize {
        self.sections.iter().map(|section| section.block_ids.iter().filter(|&&id| id != 0).count()).sum()
    }

    pub fn block_id_at(&self, x: u8, y: u8, z: u8) -> Option<u16> {
        if x > 15 || z > 15 { return None; }
        let section_y = y / 16;
        let local_y = y % 16;
        match self.sections.iter().find(|section| section.y == section_y) {
            Some(section) => section.block_id_at(x, local_y, z),
            None => Some(0), // An absent section represents air.
        }
    }

    /// Fetch legacy metadata. An absent section has the default metadata value 0.
    pub fn block_metadata_at(&self, x: u8, y: u8, z: u8) -> Option<u8> {
        if x > 15 || z > 15 { return None; }
        let section_y = y / 16;
        let local_y = y % 16;
        match self.sections.iter().find(|section| section.y == section_y) {
            Some(section) => section.metadata_at(x, local_y, z),
            None => Some(0),
        }
    }

    /// Sample vanilla nibble light as (sky, block). Missing sections are treated
    /// as air; the heightmap is used to avoid illuminating cave air as sky.
    pub fn light_at(&self, x: u8, y: u8, z: u8) -> Option<(u8, u8)> {
        if x > 15 || z > 15 { return None; }
        let section_y = y / 16;
        let local_y = y % 16;
        let height = self.height_map.as_ref()
            .and_then(|map| map.get(usize::from(z) * 16 + usize::from(x))).copied();
        let sky_fallback = if height.is_some_and(|h| i32::from(y) >= h) { 15 } else { 0 };
        let section = self.sections.iter().find(|section| section.y == section_y);
        let block = section.and_then(|section| section.block_light_at(x, local_y, z)).unwrap_or(0);
        let sky = section.and_then(|section| section.sky_light_at(x, local_y, z)).unwrap_or(sky_fallback);
        Some((sky.min(15), block.min(15)))
    }

    /// Mutate a decoded chunk in memory using the same legacy section layout as Anvil.
    /// Missing sections are materialized only when a non-air block is written.
    /// Returns the previous (block ID, metadata) pair.
    pub fn set_block(&mut self, x: u8, y: u8, z: u8, id: u16, metadata: u8) -> Result<(u16, u8)> {
        if x > 15 || z > 15 || id > 4095 || metadata > 15 {
            return Err(Mc189Error::Usage("block coordinates/ID/metadata out of range".into()));
        }
        let old = (self.block_id_at(x, y, z).unwrap_or(0), self.block_metadata_at(x, y, z).unwrap_or(0));
        if old == (id, metadata) { return Ok(old); }
        let section_y = y / 16;
        let local_y = y % 16;
        let index = section_index(x, local_y, z).ok_or_else(|| Mc189Error::InvalidData("invalid legacy section index".into()))?;
        let section_index_in_vec = self.sections.iter().position(|section| section.y == section_y);
        if section_index_in_vec.is_none() && id == 0 { return Ok(old); }
        if section_index_in_vec.is_none() {
            self.sections.push(ChunkSection {
                y: section_y, block_ids: vec![0; BLOCKS_PER_SECTION],
                metadata: vec![0; BLOCKS_PER_SECTION],
                block_light: Some(vec![0; BLOCKS_PER_SECTION]),
                sky_light: Some(vec![0; BLOCKS_PER_SECTION]),
            });
            self.sections.sort_by_key(|section| section.y);
        }
        let section = self.sections.iter_mut().find(|section| section.y == section_y)
            .ok_or_else(|| Mc189Error::InvalidData("failed to materialize target section".into()))?;
        if section.block_ids.len() != BLOCKS_PER_SECTION || section.metadata.len() != BLOCKS_PER_SECTION {
            return Err(Mc189Error::InvalidData(format!("malformed decoded section Y={section_y}")));
        }
        section.block_ids[index] = id;
        section.metadata[index] = metadata;
        Ok(old)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ChunkSummary {
    pub local_x: u8,
    pub local_z: u8,
    pub x_pos: Option<i32>,
    pub z_pos: Option<i32>,
    pub section_count: usize,
    pub block_arrays: usize,
    pub root_name: String,
}

/// Selected world-level properties stored in the gzip-compressed `level.dat`.
/// Fields remain optional because different saves may omit properties or use
/// defaults; the storage `version` is not the exact Minecraft game version.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WorldMetadata {
    pub root_name: String,
    pub level_name: Option<String>,
    pub storage_version: Option<i32>,
    pub game_type: Option<i32>,
    pub random_seed: Option<i64>,
    pub spawn_x: Option<i32>,
    pub spawn_y: Option<i32>,
    pub spawn_z: Option<i32>,
    pub time: Option<i64>,
    pub day_time: Option<i64>,
    pub generator_name: Option<String>,
    pub generator_options: Option<String>,
    pub hardcore: Option<i8>,
    pub allow_commands: Option<i8>,
    pub map_features: Option<i8>,
    pub raining: Option<i8>,
    pub thundering: Option<i8>,
    pub rain_time: Option<i32>,
    pub thunder_time: Option<i32>,
}

/// Read the global properties from a world's gzip-compressed `level.dat`.
/// This function never writes to the world and bounds decompressed input size.
pub fn read_world_metadata(world_path: impl AsRef<Path>) -> Result<WorldMetadata> {
    let world_path = world_path.as_ref();
    let path = world_path.join("level.dat");
    let file = File::open(&path)?;
    let compressed_len = file.metadata()?.len();
    if compressed_len > MAX_DECOMPRESSED_CHUNK_BYTES {
        return Err(Mc189Error::InvalidData(format!(
            "compressed level.dat exceeds 64 MiB limit ({compressed_len} bytes)"
        )));
    }

    let mut decoded = Vec::new();
    GzDecoder::new(file)
        .take(MAX_DECOMPRESSED_CHUNK_BYTES + 1)
        .read_to_end(&mut decoded)?;
    if decoded.len() as u64 > MAX_DECOMPRESSED_CHUNK_BYTES {
        return Err(Mc189Error::InvalidData(
            "decompressed level.dat exceeds 64 MiB limit".into(),
        ));
    }
    let (root_name, root) = nbt::parse_root(&decoded)?;
    let data = root.get("Data").ok_or_else(|| {
        Mc189Error::InvalidData("level.dat is missing the Data compound".into())
    })?;
    if data.as_compound().is_none() {
        return Err(Mc189Error::InvalidData(
            "level.dat Data tag is not a compound".into(),
        ));
    }

    Ok(WorldMetadata {
        root_name,
        level_name: optional_string_field(data, "LevelName")?,
        storage_version: optional_int_field(data, "version")?,
        game_type: optional_int_field(data, "GameType")?,
        random_seed: optional_long_field(data, "RandomSeed")?,
        spawn_x: optional_int_field(data, "SpawnX")?,
        spawn_y: optional_int_field(data, "SpawnY")?,
        spawn_z: optional_int_field(data, "SpawnZ")?,
        time: optional_long_field(data, "Time")?,
        day_time: optional_long_field(data, "DayTime")?,
        generator_name: optional_string_field(data, "generatorName")?,
        generator_options: optional_string_field(data, "generatorOptions")?,
        hardcore: optional_byte_field(data, "hardcore")?,
        allow_commands: optional_byte_field(data, "allowCommands")?,
        map_features: optional_byte_field(data, "MapFeatures")?,
        raining: optional_byte_field(data, "raining")?,
        thundering: optional_byte_field(data, "thundering")?,
        rain_time: optional_int_field(data, "rainTime")?,
        thunder_time: optional_int_field(data, "thunderTime")?,
    })
}

/// Read the single-player Player compound stored at level.dat Data.Player.
/// Unknown player tags are retained so callers can update only the fields they own.
pub fn read_world_player_data(world_path: impl AsRef<Path>) -> Result<Option<NbtTag>> {
    let path = world_path.as_ref().join("level.dat");
    let file = File::open(&path)?;
    let compressed_len = file.metadata()?.len();
    if compressed_len > MAX_DECOMPRESSED_CHUNK_BYTES {
        return Err(Mc189Error::InvalidData(format!(
            "compressed level.dat exceeds 64 MiB limit ({compressed_len} bytes)"
        )));
    }
    let mut decoded = Vec::new();
    GzDecoder::new(file)
        .take(MAX_DECOMPRESSED_CHUNK_BYTES + 1)
        .read_to_end(&mut decoded)?;
    if decoded.len() as u64 > MAX_DECOMPRESSED_CHUNK_BYTES {
        return Err(Mc189Error::InvalidData("decompressed level.dat exceeds 64 MiB limit".into()));
    }
    let (_, root) = nbt::parse_root(&decoded)?;
    let data = root.get("Data").ok_or_else(|| Mc189Error::InvalidData("level.dat is missing the Data compound".into()))?;
    let Some(player) = data.get("Player") else { return Ok(None); };
    if player.as_compound().is_none() {
        return Err(Mc189Error::InvalidData("level.dat Data.Player is not a compound".into()));
    }
    Ok(Some(player.clone()))
}

/// Merge a partial Player compound into level.dat Data.Player and replace level.dat
/// using Minecraft's level.dat_new/level.dat_old transaction pattern. Other world
/// metadata and unowned player fields survive unchanged.
pub fn write_world_player_data(world_path: impl AsRef<Path>, player_patch: &NbtTag) -> Result<()> {
    if player_patch.as_compound().is_none() {
        return Err(Mc189Error::InvalidData("player data patch must be an NBT compound".into()));
    }
    let world = world_path.as_ref();
    let current_path = world.join("level.dat");
    let file = File::open(&current_path)?;
    let compressed_len = file.metadata()?.len();
    if compressed_len > MAX_DECOMPRESSED_CHUNK_BYTES {
        return Err(Mc189Error::InvalidData(format!(
            "compressed level.dat exceeds 64 MiB limit ({compressed_len} bytes)"
        )));
    }
    let mut decoded = Vec::new();
    GzDecoder::new(file)
        .take(MAX_DECOMPRESSED_CHUNK_BYTES + 1)
        .read_to_end(&mut decoded)?;
    if decoded.len() as u64 > MAX_DECOMPRESSED_CHUNK_BYTES {
        return Err(Mc189Error::InvalidData("decompressed level.dat exceeds 64 MiB limit".into()));
    }
    let (root_name, mut root) = nbt::parse_root(&decoded)?;
    let data = root.get_mut("Data").ok_or_else(|| Mc189Error::InvalidData("level.dat is missing the Data compound".into()))?;
    if data.as_compound().is_none() {
        return Err(Mc189Error::InvalidData("level.dat Data tag is not a compound".into()));
    }
    if let Some(existing) = data.get_mut("Player") {
        if existing.as_compound().is_none() {
            return Err(Mc189Error::InvalidData("level.dat Data.Player is not a compound".into()));
        }
        for (name, value) in player_patch.as_compound().unwrap_or_default() {
            existing.insert(name.clone(), value.clone())?;
        }
    } else {
        data.insert("Player", player_patch.clone())?;
    }

    let raw = nbt::write_root(&root_name, &root)?;
    let mut encoder = GzEncoder::new(Vec::new(), Compression::default());
    encoder.write_all(&raw)?;
    let compressed = encoder.finish()?;

    let new_path = world.join("level.dat_new");
    let old_path = world.join("level.dat_old");
    {
        let mut file = File::create(&new_path)?;
        file.write_all(&compressed)?;
        file.sync_all()?;
    }
    if old_path.exists() { fs::remove_file(&old_path)?; }
    let had_current = current_path.exists();
    if had_current { fs::rename(&current_path, &old_path)?; }
    if let Err(error) = fs::rename(&new_path, &current_path) {
        if had_current && old_path.exists() && !current_path.exists() {
            let _ = fs::rename(&old_path, &current_path);
        }
        let _ = fs::remove_file(&new_path);
        return Err(Mc189Error::InvalidData(format!("could not commit level.dat player data: {error}")));
    }
    if let Ok(directory) = File::open(world) { let _ = directory.sync_all(); }
    Ok(())
}

fn optional_int_field(compound: &NbtTag, name: &str) -> Result<Option<i32>> {
    match compound.get(name) {
        None => Ok(None),
        Some(tag) => tag.as_int().map(Some).ok_or_else(|| {
            Mc189Error::InvalidData(format!("level.dat Data.{name} is not an integer"))
        }),
    }
}

fn optional_long_field(compound: &NbtTag, name: &str) -> Result<Option<i64>> {
    match compound.get(name) {
        None => Ok(None),
        Some(tag) => tag.as_long().map(Some).ok_or_else(|| {
            Mc189Error::InvalidData(format!("level.dat Data.{name} is not a long integer"))
        }),
    }
}

fn optional_string_field(compound: &NbtTag, name: &str) -> Result<Option<String>> {
    match compound.get(name) {
        None => Ok(None),
        Some(tag) => tag.as_string().map(|value| Some(value.to_owned())).ok_or_else(|| {
            Mc189Error::InvalidData(format!("level.dat Data.{name} is not a string"))
        }),
    }
}

fn optional_byte_field(compound: &NbtTag, name: &str) -> Result<Option<i8>> {
    match compound.get(name) {
        None => Ok(None),
        Some(tag) => tag.as_byte().map(Some).ok_or_else(|| {
            Mc189Error::InvalidData(format!("level.dat Data.{name} is not a byte"))
        }),
    }
}

/// Read and parse the compressed NBT payload for one local chunk in a region.
fn load_chunk_nbt(path: &Path, local_x: u8, local_z: u8) -> Result<(String, NbtTag)> {
    let header = RegionHeader::from_file(path)?;
    let location = header.location(local_x, local_z).ok_or_else(|| {
        Mc189Error::Usage("local chunk coordinates must be between 0 and 31".into())
    })?;
    if !location.is_present() {
        return Err(Mc189Error::InvalidData(format!(
            "no chunk stored at local coordinates ({local_x}, {local_z})"
        )));
    }

    let mut file = File::open(path)?;
    file.seek(SeekFrom::Start(u64::from(location.sector_offset) * SECTOR_BYTES as u64))?;
    let mut length_bytes = [0_u8; 4];
    file.read_exact(&mut length_bytes)?;
    let length = u32::from_be_bytes(length_bytes) as usize;
    let max_record_len = usize::from(location.sector_count) * SECTOR_BYTES - 4;
    if length < 1 || length > max_record_len {
        return Err(Mc189Error::InvalidData(format!("invalid chunk record length {length}")));
    }

    let mut record = vec![0_u8; length];
    file.read_exact(&mut record)?;
    let compression = record[0];
    let compressed = &record[1..];
    let mut decoded = Vec::new();
    match compression {
        1 => {
            GzDecoder::new(compressed).take(MAX_DECOMPRESSED_CHUNK_BYTES + 1).read_to_end(&mut decoded)?;
        }
        2 => {
            ZlibDecoder::new(compressed).take(MAX_DECOMPRESSED_CHUNK_BYTES + 1).read_to_end(&mut decoded)?;
        }
        3 => {
            if compressed.len() as u64 > MAX_DECOMPRESSED_CHUNK_BYTES {
                return Err(Mc189Error::InvalidData("uncompressed chunk exceeds 64 MiB limit".into()));
            }
            decoded.extend_from_slice(compressed);
        }
        other => return Err(Mc189Error::InvalidData(format!("unsupported chunk compression type {other}"))),
    }
    if decoded.len() as u64 > MAX_DECOMPRESSED_CHUNK_BYTES {
        return Err(Mc189Error::InvalidData("decompressed chunk exceeds 64 MiB limit".into()));
    }
    nbt::parse_root(&decoded)
}

/// Inspect chunk-level metadata without decoding block arrays.
pub fn inspect_chunk(path: impl AsRef<Path>, local_x: u8, local_z: u8) -> Result<ChunkSummary> {
    let (root_name, root) = load_chunk_nbt(path.as_ref(), local_x, local_z)?;
    let level = root.get("Level").unwrap_or(&root);
    let x_pos = level.get("xPos").and_then(NbtTag::as_int);
    let z_pos = level.get("zPos").and_then(NbtTag::as_int);
    let sections = level.get("Sections").and_then(NbtTag::as_list).map(|(_, v)| v).unwrap_or(&[]);
    let block_arrays = sections.iter().filter(|section| section.get("Blocks").is_some()).count();
    Ok(ChunkSummary { local_x, local_z, x_pos, z_pos, section_count: sections.len(), block_arrays, root_name })
}

/// Decode all legacy block arrays in one chunk, including 12-bit IDs and packed nibbles.
pub fn decode_chunk(path: impl AsRef<Path>, local_x: u8, local_z: u8) -> Result<ChunkData> {
    let (_root_name, root) = load_chunk_nbt(path.as_ref(), local_x, local_z)?;
    let level = root.get("Level").ok_or_else(|| Mc189Error::InvalidData("chunk NBT is missing Level compound (not a legacy 1.8 chunk?)".into()))?;
    if level.as_compound().is_none() {
        return Err(Mc189Error::InvalidData("chunk Level tag is not a compound".into()));
    }
    let x_pos = level.get("xPos").and_then(NbtTag::as_int)
        .ok_or_else(|| Mc189Error::InvalidData("chunk Level is missing integer xPos".into()))?;
    let z_pos = level.get("zPos").and_then(NbtTag::as_int)
        .ok_or_else(|| Mc189Error::InvalidData("chunk Level is missing integer zPos".into()))?;

    let mut sections = Vec::new();
    if let Some(section_tag) = level.get("Sections") {
        let (element_id, entries) = section_tag.as_list()
            .ok_or_else(|| Mc189Error::InvalidData("chunk Sections tag is not a list".into()))?;
        if element_id != 10 && !entries.is_empty() {
            return Err(Mc189Error::InvalidData("chunk Sections list does not contain compounds".into()));
        }
        let mut seen_y = HashSet::new();
        for entry in entries {
            let section = decode_section(entry)?;
            if !seen_y.insert(section.y) {
                return Err(Mc189Error::InvalidData(format!("duplicate chunk section Y={}", section.y)));
            }
            sections.push(section);
        }
    }
    sections.sort_by_key(|section| section.y);

    let biomes = match level.get("Biomes") {
        None => None,
        Some(tag) => {
            let bytes = tag.as_byte_array().ok_or_else(|| Mc189Error::InvalidData("chunk Biomes tag is not a byte array".into()))?;
            if bytes.len() != 256 {
                return Err(Mc189Error::InvalidData(format!("chunk Biomes array has {} entries; expected 256", bytes.len())));
            }
            Some(bytes.iter().map(|&value| value as u8).collect())
        }
    };
    let height_map = match level.get("HeightMap") {
        None => None,
        Some(tag) => {
            let values = tag.as_int_array().ok_or_else(|| Mc189Error::InvalidData("chunk HeightMap tag is not an int array".into()))?;
            if values.len() != 256 {
                return Err(Mc189Error::InvalidData(format!("chunk HeightMap array has {} entries; expected 256", values.len())));
            }
            Some(values.to_vec())
        }
    };

    Ok(ChunkData { x_pos, z_pos, sections, biomes, height_map })
}

fn decode_section(tag: &NbtTag) -> Result<ChunkSection> {
    if tag.as_compound().is_none() {
        return Err(Mc189Error::InvalidData("entry in Sections list is not a compound".into()));
    }
    let y_raw = tag.get("Y").and_then(NbtTag::as_byte)
        .ok_or_else(|| Mc189Error::InvalidData("chunk section is missing byte Y".into()))?;
    let y = y_raw as u8;
    if y > 15 {
        return Err(Mc189Error::InvalidData(format!("section Y={y} is outside the 1.8 range 0..15")));
    }

    let blocks = required_byte_array(tag, "Blocks", BLOCKS_PER_SECTION)?;
    let packed_metadata = required_byte_array(tag, "Data", NIBBLE_BYTES_PER_SECTION)?;
    let packed_add = optional_byte_array(tag, "Add", NIBBLE_BYTES_PER_SECTION)?;

    let mut block_ids = Vec::with_capacity(BLOCKS_PER_SECTION);
    for (index, &low) in blocks.iter().enumerate() {
        let mut id = u16::from(low as u8);
        if let Some(add) = packed_add {
            id |= u16::from(read_nibble(add, index)) << 8;
        }
        block_ids.push(id);
    }
    let metadata = unpack_nibbles(packed_metadata);
    let block_light = optional_byte_array(tag, "BlockLight", NIBBLE_BYTES_PER_SECTION)?.map(unpack_nibbles);
    let sky_light = optional_byte_array(tag, "SkyLight", NIBBLE_BYTES_PER_SECTION)?.map(unpack_nibbles);
    Ok(ChunkSection { y, block_ids, metadata, block_light, sky_light })
}

fn required_byte_array<'a>(tag: &'a NbtTag, name: &str, expected_len: usize) -> Result<&'a [i8]> {
    let values = tag.get(name).and_then(NbtTag::as_byte_array)
        .ok_or_else(|| Mc189Error::InvalidData(format!("chunk section is missing byte array {name}")))?;
    if values.len() != expected_len {
        return Err(Mc189Error::InvalidData(format!("section {name} array has {} bytes; expected {expected_len}", values.len())));
    }
    Ok(values)
}

fn optional_byte_array<'a>(tag: &'a NbtTag, name: &str, expected_len: usize) -> Result<Option<&'a [i8]>> {
    match tag.get(name) {
        None => Ok(None),
        Some(_) => required_byte_array(tag, name, expected_len).map(Some),
    }
}

fn read_nibble(packed: &[i8], index: usize) -> u8 {
    let byte = packed[index / 2] as u8;
    if index & 1 == 0 { byte & 0x0F } else { (byte >> 4) & 0x0F }
}

fn unpack_nibbles(packed: &[i8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(packed.len() * 2);
    for byte in packed {
        let byte = *byte as u8;
        out.push(byte & 0x0F);
        out.push((byte >> 4) & 0x0F);
    }
    out
}

fn section_index(x: u8, y: u8, z: u8) -> Option<usize> {
    if x > 15 || y > 15 || z > 15 { return None; }
    Some((usize::from(y) << 8) | (usize::from(z) << 4) | usize::from(x))
}

/// Convert a world chunk coordinate into a region coordinate and local coordinate.
/// Uses Euclidean division so negative chunk coordinates map correctly.
pub fn split_chunk_coordinate(chunk_coord: i32) -> (i32, u8) {
    (chunk_coord.div_euclid(32), chunk_coord.rem_euclid(32) as u8)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn empty_header() -> Vec<u8> { vec![0; HEADER_BYTES] }

    #[test]
    fn parses_empty_header() {
        let parsed = RegionHeader::parse(&empty_header(), HEADER_BYTES as u64).unwrap();
        assert_eq!(parsed.present_chunks(), 0);
        assert_eq!(parsed.location(0, 0).unwrap().sector_offset, 0);
    }

    #[test]
    fn parses_location_entry_and_timestamp() {
        let mut header = empty_header();
        let index = 2 + 3 * 32;
        header[index * 4..index * 4 + 4].copy_from_slice(&[0, 0, 2, 1]);
        let ts_start = SECTOR_BYTES + index * 4;
        header[ts_start..ts_start + 4].copy_from_slice(&1234_u32.to_be_bytes());
        let parsed = RegionHeader::parse(&header, (3 * SECTOR_BYTES) as u64).unwrap();
        assert_eq!(parsed.present_chunks(), 1);
        assert_eq!(parsed.location(2, 3).unwrap(), ChunkLocation { sector_offset: 2, sector_count: 1 });
        assert_eq!(parsed.timestamp(2, 3), Some(1234));
    }

    #[test]
    fn rejects_header_that_is_too_short() {
        let err = RegionHeader::parse(&[0; 100], 100).unwrap_err();
        assert!(err.to_string().contains("expected at least"));
    }

    #[test]
    fn rejects_chunk_that_extends_past_file() {
        let mut header = empty_header();
        header[0..4].copy_from_slice(&[0, 0, 2, 2]);
        let err = RegionHeader::parse(&header, (3 * SECTOR_BYTES) as u64).unwrap_err();
        assert!(err.to_string().contains("extends past end"));
    }

    #[test]
    fn negative_chunk_coordinates_use_euclidean_division() {
        assert_eq!(split_chunk_coordinate(0), (0, 0));
        assert_eq!(split_chunk_coordinate(31), (0, 31));
        assert_eq!(split_chunk_coordinate(32), (1, 0));
        assert_eq!(split_chunk_coordinate(-1), (-1, 31));
        assert_eq!(split_chunk_coordinate(-32), (-1, 0));
        assert_eq!(split_chunk_coordinate(-33), (-2, 31));
    }

    fn synthetic_section() -> NbtTag {
        let mut blocks = vec![0_i8; BLOCKS_PER_SECTION];
        let mut data = vec![0_i8; NIBBLE_BYTES_PER_SECTION];
        let mut add = vec![0_i8; NIBBLE_BYTES_PER_SECTION];
        let target = (4 << 8) | (5 << 4) | 3;
        blocks[target] = 0x34;
        // Odd index: metadata and Add are stored in the high nibble.
        data[target / 2] = 0xC7_u8 as i8;
        add[target / 2] = 0xA2_u8 as i8;
        NbtTag::Compound(vec![
            ("Y".into(), NbtTag::Byte(2)),
            ("Blocks".into(), NbtTag::ByteArray(blocks)),
            ("Data".into(), NbtTag::ByteArray(data)),
            ("Add".into(), NbtTag::ByteArray(add)),
        ])
    }

    #[test]
    fn decodes_legacy_block_id_metadata_and_index_order() {
        let section = decode_section(&synthetic_section()).unwrap();
        assert_eq!(section.y, 2);
        assert_eq!(section.block_id_at(3, 4, 5), Some(0xA34));
        assert_eq!(section.metadata_at(3, 4, 5), Some(0x0C));
        assert_eq!(section.block_id_at(16, 0, 0), None);
    }

    #[test]
    fn rejects_wrong_length_legacy_block_array() {
        let mut tag = synthetic_section();
        if let NbtTag::Compound(entries) = &mut tag {
            let mut replaced = false;
            for (name, value) in entries.iter_mut() {
                if name.as_str() == "Blocks" {
                    *value = NbtTag::ByteArray(vec![0; 12]);
                    replaced = true;
                    break;
                }
            }
            assert!(replaced);
        }
        let err = decode_section(&tag).unwrap_err();
        assert!(err.to_string().contains("Blocks array"));
    }

    #[test]
    fn section_without_add_keeps_eight_bit_id_and_optional_light_absent() {
        let mut tag = synthetic_section();
        if let NbtTag::Compound(entries) = &mut tag {
            entries.retain(|entry| entry.0.as_str() != "Add");
        }
        let section = decode_section(&tag).unwrap();
        assert_eq!(section.block_id_at(3, 4, 5), Some(0x34));
        assert_eq!(section.block_light, None);
        assert_eq!(section.sky_light, None);
    }

    #[test]
    fn nibble_unpacking_uses_low_then_high_nibble() {
        assert_eq!(unpack_nibbles(&[0xA3_u8 as i8, 0xF0_u8 as i8]), vec![3, 10, 0, 15]);
    }

    #[test]
    fn world_metadata_reads_typed_level_fields() {
        let data = NbtTag::Compound(vec![
            ("LevelName".into(), NbtTag::String("Test World".into())),
            ("version".into(), NbtTag::Int(19133)),
            ("GameType".into(), NbtTag::Int(1)),
            ("RandomSeed".into(), NbtTag::Long(-123456789)),
            ("SpawnX".into(), NbtTag::Int(-17)),
            ("SpawnY".into(), NbtTag::Int(64)),
            ("SpawnZ".into(), NbtTag::Int(33)),
            ("generatorName".into(), NbtTag::String("default".into())),
        ]);
        assert_eq!(optional_string_field(&data, "LevelName").unwrap().as_deref(), Some("Test World"));
        assert_eq!(optional_int_field(&data, "version").unwrap(), Some(19133));
        assert_eq!(optional_int_field(&data, "GameType").unwrap(), Some(1));
        assert_eq!(optional_long_field(&data, "RandomSeed").unwrap(), Some(-123456789));
        assert_eq!(optional_int_field(&data, "SpawnX").unwrap(), Some(-17));
        assert_eq!(optional_int_field(&data, "Missing").unwrap(), None);
        assert!(optional_int_field(&data, "LevelName").is_err());
    }

    #[test]
    fn world_player_patch_round_trips_and_preserves_other_level_tags() {
        use flate2::write::GzEncoder;
        use flate2::Compression;
        use std::io::Write;
        use std::sync::atomic::{AtomicUsize, Ordering};
        static NEXT_ID: AtomicUsize = AtomicUsize::new(0);
        let dir = std::env::temp_dir().join(format!(
            "mc189-world-player-save-test-{}-{}",
            std::process::id(), NEXT_ID.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir_all(&dir).unwrap();
        let data = NbtTag::Compound(vec![
            ("LevelName".into(), NbtTag::String("Preserved World".into())),
            ("SpawnX".into(), NbtTag::Int(-12)),
            ("Player".into(), NbtTag::Compound(vec![
                ("Pos".into(), NbtTag::List(6, vec![NbtTag::Double(1.0), NbtTag::Double(64.0), NbtTag::Double(2.0)])),
                ("Health".into(), NbtTag::Float(20.0)),
            ])),
        ]);
        let root = NbtTag::Compound(vec![("Data".into(), data.clone())]);
        let raw = nbt::write_root("", &root).unwrap();
        let mut encoder = GzEncoder::new(Vec::new(), Compression::default());
        encoder.write_all(&raw).unwrap();
        std::fs::write(dir.join("level.dat"), encoder.finish().unwrap()).unwrap();

        let patch = NbtTag::Compound(vec![
            ("SelectedItemSlot".into(), NbtTag::Int(4)),
            ("Inventory".into(), NbtTag::List(10, vec![NbtTag::Compound(vec![
                ("Slot".into(), NbtTag::Byte(0)),
                ("id".into(), NbtTag::String("minecraft:stone".into())),
                ("Count".into(), NbtTag::Byte(32)),
                ("Damage".into(), NbtTag::Short(0)),
            ])])),
        ]);
        write_world_player_data(&dir, &patch).unwrap();
        let player = read_world_player_data(&dir).unwrap().unwrap();
        assert_eq!(player.get("SelectedItemSlot").and_then(NbtTag::as_int), Some(4));
        assert_eq!(player.get("Health").and_then(|tag| if let NbtTag::Float(v)=tag {Some(*v)} else {None}), Some(20.0));
        assert_eq!(read_world_metadata(&dir).unwrap().level_name.as_deref(), Some("Preserved World"));
        assert_eq!(read_world_metadata(&dir).unwrap().spawn_x, Some(-12));
        assert!(dir.join("level.dat_old").is_file());
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn player_patch_creates_player_compound_when_missing() {
        use flate2::write::GzEncoder;
        use flate2::Compression;
        use std::io::Write;
        use std::sync::atomic::{AtomicUsize, Ordering};
        static NEXT_ID: AtomicUsize = AtomicUsize::new(0);
        let dir = std::env::temp_dir().join(format!(
            "mc189-world-player-create-test-{}-{}",
            std::process::id(), NEXT_ID.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir_all(&dir).unwrap();
        let root = NbtTag::Compound(vec![("Data".into(), NbtTag::Compound(vec![
            ("LevelName".into(), NbtTag::String("No Player Yet".into())),
        ]))]);
        let raw = nbt::write_root("", &root).unwrap();
        let mut encoder = GzEncoder::new(Vec::new(), Compression::default());
        encoder.write_all(&raw).unwrap();
        std::fs::write(dir.join("level.dat"), encoder.finish().unwrap()).unwrap();

        let patch = NbtTag::Compound(vec![
            ("Inventory".into(), NbtTag::List(0, Vec::new())),
            ("SelectedItemSlot".into(), NbtTag::Int(2)),
        ]);
        write_world_player_data(&dir, &patch).unwrap();
        let player = read_world_player_data(&dir).unwrap().unwrap();
        assert_eq!(player.get("SelectedItemSlot").and_then(NbtTag::as_int), Some(2));
        assert_eq!(player.get("Inventory").and_then(NbtTag::as_list).map(|(kind, tags)| (kind, tags.len())), Some((0, 0)));
        assert_eq!(read_world_metadata(&dir).unwrap().level_name.as_deref(), Some("No Player Yet"));
        std::fs::remove_dir_all(&dir).unwrap();
    }

    #[test]
    fn reads_gzip_level_dat_from_a_world_folder() {
        use flate2::write::GzEncoder;
        use flate2::Compression;
        use std::io::Write;
        use std::sync::atomic::{AtomicUsize, Ordering};
        static NEXT_ID: AtomicUsize = AtomicUsize::new(0);

        fn put_string(out: &mut Vec<u8>, value: &str) {
            out.extend_from_slice(&(value.len() as u16).to_be_bytes());
            out.extend_from_slice(value.as_bytes());
        }
        let mut nbt = vec![10];
        put_string(&mut nbt, ""); // root name
        nbt.push(10); // Data compound
        put_string(&mut nbt, "Data");
        nbt.push(8); // LevelName string
        put_string(&mut nbt, "LevelName");
        put_string(&mut nbt, "Fixture World");
        nbt.push(3); // version int
        put_string(&mut nbt, "version");
        nbt.extend_from_slice(&19133_i32.to_be_bytes());
        nbt.push(4); // RandomSeed long
        put_string(&mut nbt, "RandomSeed");
        nbt.extend_from_slice(&(-123_i64).to_be_bytes());
        nbt.push(0); // end Data
        nbt.push(0); // end root

        let mut encoder = GzEncoder::new(Vec::new(), Compression::default());
        encoder.write_all(&nbt).unwrap();
        let compressed = encoder.finish().unwrap();
        let dir = std::env::temp_dir().join(format!(
            "mc189-rs-worldmeta-test-{}-{}",
            std::process::id(),
            NEXT_ID.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(dir.join("level.dat"), compressed).unwrap();

        let metadata = read_world_metadata(&dir).unwrap();
        assert_eq!(metadata.level_name.as_deref(), Some("Fixture World"));
        assert_eq!(metadata.storage_version, Some(19133));
        assert_eq!(metadata.random_seed, Some(-123));
        assert_eq!(metadata.spawn_x, None);
        std::fs::remove_dir_all(&dir).unwrap();
    }
}

/// Mutable legacy chunk backed by its original NBT tree. Unknown tags are preserved.
#[derive(Debug, Clone)]
pub struct MutableChunk { pub x_pos: i32, pub z_pos: i32, root_name: String, root: NbtTag, dirty: bool }
impl MutableChunk {
    pub fn is_dirty(&self) -> bool { self.dirty }
    /// Returns the vanilla Level.Entities list without interpreting unrelated entity types.
    pub fn entity_nbt_list(&self) -> Vec<NbtTag> {
        self.root.get("Level").and_then(|level| level.get("Entities"))
            .and_then(NbtTag::as_list).filter(|(kind, _)| *kind == 10)
            .map(|(_, entries)| entries.to_vec()).unwrap_or_default()
    }
    /// Replaces only this chunk's entity list; all other chunk NBT remains untouched.
    pub fn replace_entity_nbt_list(&mut self, entities: Vec<NbtTag>) -> Result<()> {
        if entities.iter().any(|entity| !matches!(entity, NbtTag::Compound(_))) {
            return Err(Mc189Error::InvalidData("chunk entity list contains a non-compound tag".into()));
        }
        let level = self.root.get_mut("Level").ok_or_else(|| Mc189Error::InvalidData("missing Level".into()))?;
        level.insert("Entities", NbtTag::List(10, entities))?;
        self.dirty = true;
        Ok(())
    }
    pub fn get_block(&self, x:u8, y:u8, z:u8) -> Result<(u16,u8)> {
        if x>15 || z>15 { return Err(Mc189Error::Usage("chunk-local X/Z must be 0..15".into())); }
        let level=self.root.get("Level").ok_or_else(|| Mc189Error::InvalidData("missing Level".into()))?;
        let sections=level.get("Sections").and_then(NbtTag::as_list).map(|(_,v)|v).ok_or_else(|| Mc189Error::InvalidData("missing Sections list".into()))?;
        let sy=y/16; let ly=y%16;
        let Some(sec)=sections.iter().find(|s| s.get("Y").and_then(NbtTag::as_byte)==Some(sy as i8)) else { return Ok((0,0)); };
        let index=section_index(x,ly,z).unwrap();
        let blocks=required_byte_array(sec,"Blocks",BLOCKS_PER_SECTION)?;
        let add=optional_byte_array(sec,"Add",NIBBLE_BYTES_PER_SECTION)?;
        let id=u16::from(blocks[index] as u8) | add.map(|a|u16::from(read_nibble(a,index))<<8).unwrap_or(0);
        let data=required_byte_array(sec,"Data",NIBBLE_BYTES_PER_SECTION)?;
        Ok((id,read_nibble(data,index)))
    }
    /// Changes one block in memory. ID is the legacy 12-bit block ID; metadata is 0..15.
    pub fn set_block(&mut self,x:u8,y:u8,z:u8,id:u16,metadata:u8)->Result<(u16,u8)> {
        if x>15 || z>15 || id>4095 || metadata>15 { return Err(Mc189Error::Usage("block coordinates/ID/metadata out of range".into())); }
        let old=self.get_block(x,y,z)?; if old==(id,metadata) { return Ok(old); }
        if old.0 != id {
            let level=self.root.get_mut("Level").ok_or_else(||Mc189Error::InvalidData("missing Level".into()))?;
            if let Some(NbtTag::List(10, entries))=level.get_mut("TileEntities") {
                let wx=self.x_pos.saturating_mul(16)+i32::from(x); let wz=self.z_pos.saturating_mul(16)+i32::from(z); let wy=i32::from(y);
                entries.retain(|tile| !(tile.get("x").and_then(NbtTag::as_int)==Some(wx) && tile.get("y").and_then(NbtTag::as_int)==Some(wy) && tile.get("z").and_then(NbtTag::as_int)==Some(wz)));
            }
        }
        let level=self.root.get_mut("Level").ok_or_else(||Mc189Error::InvalidData("missing Level".into()))?;
        let sections=level.get_mut("Sections").and_then(NbtTag::as_list_mut).ok_or_else(||Mc189Error::InvalidData("missing mutable Sections list".into()))?;
        let sy=y/16; let ly=y%16;
        let pos=sections.iter().position(|s|s.get("Y").and_then(NbtTag::as_byte)==Some(sy as i8));
        if pos.is_none() && id==0 { return Ok(old); }
        if pos.is_none() {
            let mut sec=vec![("Y".into(),NbtTag::Byte(sy as i8)),("Blocks".into(),NbtTag::ByteArray(vec![0;4096])),("Data".into(),NbtTag::ByteArray(vec![0;2048])),("BlockLight".into(),NbtTag::ByteArray(vec![0;2048])),("SkyLight".into(),NbtTag::ByteArray(vec![0;2048]))];
            sections.push(NbtTag::Compound(std::mem::take(&mut sec)));
        }
        let sec=sections.iter_mut().find(|s|s.get("Y").and_then(NbtTag::as_byte)==Some(sy as i8)).unwrap();
        let idx=section_index(x,ly,z).unwrap();
        let block_arr=match sec.get_mut("Blocks"){Some(NbtTag::ByteArray(v))=>v,_=>return Err(Mc189Error::InvalidData("invalid Blocks array".into()))};
        block_arr[idx]=(id as u8) as i8;
        let mut add=match sec.get_mut("Add"){Some(NbtTag::ByteArray(v))=>v.clone(),None=>vec![0;2048],_=>return Err(Mc189Error::InvalidData("invalid Add array".into()))};
        let hi=(id>>8) as u8; let bi=idx/2; if idx&1==0 {add[bi]=((add[bi] as u8&0xF0)|hi) as i8;} else {add[bi]=((add[bi] as u8&0x0F)|(hi<<4)) as i8;}
        sec.insert("Add",NbtTag::ByteArray(add))?;
        let data=match sec.get_mut("Data"){Some(NbtTag::ByteArray(v))=>v,_=>return Err(Mc189Error::InvalidData("invalid Data array".into()))};
        let b=idx/2; if idx&1==0 {data[b]=((data[b] as u8&0xF0)|metadata) as i8;} else {data[b]=((data[b] as u8&0x0F)|(metadata<<4)) as i8;}
        self.dirty=true; Ok(old)
    }
    /// Applies a complete decoded in-memory chunk snapshot to this NBT-backed chunk.
    /// Only block states that differ are written; unknown NBT tags and block entities
    /// unrelated to changed block IDs remain intact. Derived HeightMap/light data is
    /// applied after block arrays so the saved record is a consistent snapshot.
    pub fn apply_chunk_snapshot(&mut self, data: &ChunkData) -> Result<()> {
        if self.x_pos != data.x_pos || self.z_pos != data.z_pos {
            return Err(Mc189Error::InvalidData("chunk snapshot coordinate mismatch".into()));
        }
        for section in &data.sections {
            if section.block_ids.len() != BLOCKS_PER_SECTION || section.metadata.len() != BLOCKS_PER_SECTION {
                return Err(Mc189Error::InvalidData(format!("chunk ({},{}) section Y={} has invalid block arrays", self.x_pos, self.z_pos, section.y)));
            }
            for index in 0..BLOCKS_PER_SECTION {
                let x = (index & 15) as u8;
                let z = ((index >> 4) & 15) as u8;
                let y = section.y.saturating_mul(16).saturating_add((index >> 8) as u8);
                let id = section.block_ids[index];
                let metadata = section.metadata[index];
                if self.get_block(x, y, z)? != (id, metadata) {
                    self.set_block(x, y, z, id, metadata)?;
                }
            }
        }
        self.apply_derived_data(data)
    }

    /// Applies derived HeightMap and decoded light channels from a ChunkData snapshot
    /// back into the original NBT tree. This preserves every unrelated vanilla tag.
    /// Light arrays in ChunkData are expanded to 4096 nibbles; Anvil stores 2048 bytes.
    pub fn apply_derived_data(&mut self, data: &ChunkData) -> Result<()> {
        if self.x_pos != data.x_pos || self.z_pos != data.z_pos {
            return Err(Mc189Error::InvalidData("derived chunk data coordinate mismatch".into()));
        }
        let level = self.root.get_mut("Level")
            .ok_or_else(|| Mc189Error::InvalidData("missing Level".into()))?;
        if let Some(height) = data.height_map.as_ref() {
            if height.len() != 256 {
                return Err(Mc189Error::InvalidData("HeightMap must contain 256 values".into()));
            }
            level.insert("HeightMap", NbtTag::IntArray(height.clone()))?;
        }
        let nbt_sections = level.get_mut("Sections").and_then(NbtTag::as_list_mut)
            .ok_or_else(|| Mc189Error::InvalidData("missing mutable Sections list".into()))?;
        // Light propagation may create decoded sections containing only air and
        // lighting data. Persist those sections too; otherwise sky/block light in
        // an empty section would disappear after reopening the world.
        for source in &data.sections {
            let exists = nbt_sections.iter().any(|section| {
                section.get("Y").and_then(NbtTag::as_byte) == Some(source.y as i8)
            });
            let has_light = source.block_light.is_some() || source.sky_light.is_some();
            let has_blocks = source.block_ids.iter().any(|&id| id != 0);
            if !exists && (has_light || has_blocks) {
                nbt_sections.push(NbtTag::Compound(vec![
                    ("Y".into(), NbtTag::Byte(source.y as i8)),
                    ("Blocks".into(), NbtTag::ByteArray(vec![0; BLOCKS_PER_SECTION])),
                    ("Data".into(), NbtTag::ByteArray(vec![0; NIBBLE_BYTES_PER_SECTION])),
                    ("BlockLight".into(), NbtTag::ByteArray(vec![0; NIBBLE_BYTES_PER_SECTION])),
                    ("SkyLight".into(), NbtTag::ByteArray(vec![0; NIBBLE_BYTES_PER_SECTION])),
                ]));
            }
        }
        nbt_sections.sort_by_key(|section| {
            section.get("Y").and_then(NbtTag::as_byte).unwrap_or(0) as u8
        });
        for nbt_section in nbt_sections.iter_mut() {
            let Some(section_y) = nbt_section.get("Y").and_then(NbtTag::as_byte).map(|y| y as u8) else { continue; };
            let Some(source) = data.sections.iter().find(|section| section.y == section_y) else { continue; };
            for (tag_name, values) in [("BlockLight", source.block_light.as_ref()), ("SkyLight", source.sky_light.as_ref())] {
                let Some(values) = values else { continue; };
                if values.len() != BLOCKS_PER_SECTION {
                    return Err(Mc189Error::InvalidData(format!("{tag_name} section Y={section_y} must contain 4096 values")));
                }
                let mut packed = vec![0_i8; NIBBLE_BYTES_PER_SECTION];
                for index in (0..BLOCKS_PER_SECTION).step_by(2) {
                    let low = values[index] & 15;
                    let high = (values[index + 1] & 15) << 4;
                    packed[index / 2] = (low | high) as i8;
                }
                nbt_section.insert(tag_name, NbtTag::ByteArray(packed))?;
            }
        }
        self.dirty = true;
        Ok(())
    }

    fn encode(&self)->Result<Vec<u8>> { nbt::write_root(&self.root_name,&self.root) }
}

/// Load a chunk by world chunk coordinates from `<world>/region/r.<rx>.<rz>.mca`.
pub fn load_mutable_chunk(world:impl AsRef<Path>,chunk_x:i32,chunk_z:i32)->Result<MutableChunk>{
    let (rx,lx)=split_chunk_coordinate(chunk_x); let (rz,lz)=split_chunk_coordinate(chunk_z);
    let path=world.as_ref().join("region").join(format!("r.{rx}.{rz}.mca"));
    let (root_name,root)=load_chunk_nbt(&path,lx,lz)?;
    let level=root.get("Level").ok_or_else(||Mc189Error::InvalidData("chunk missing Level".into()))?;
    let x=level.get("xPos").and_then(NbtTag::as_int).ok_or_else(||Mc189Error::InvalidData("missing xPos".into()))?;
    let z=level.get("zPos").and_then(NbtTag::as_int).ok_or_else(||Mc189Error::InvalidData("missing zPos".into()))?;
    if x!=chunk_x || z!=chunk_z { return Err(Mc189Error::InvalidData(format!("chunk coordinate mismatch: expected ({chunk_x},{chunk_z}), got ({x},{z})"))); }
    Ok(MutableChunk{x_pos:x,z_pos:z,root_name,root,dirty:false})
}

/// Persist one dirty chunk with a full-region rewrite. All sibling chunk records are
/// preserved. This is a convenience wrapper over the batched region writer.
pub fn save_mutable_chunk(world: impl AsRef<Path>, chunk: &mut MutableChunk) -> Result<()> {
    save_mutable_chunks(world, std::slice::from_mut(chunk))
}

/// Persist multiple mutable chunks, rewriting each affected region only once.
/// This is intended for deferred world saves/checkpoints, not per-block writes.
pub fn save_mutable_chunks(world: impl AsRef<Path>, chunks: &mut [MutableChunk]) -> Result<()> {
    let world = world.as_ref();
    let mut regions: BTreeMap<(i32, i32), Vec<usize>> = BTreeMap::new();
    let mut seen = HashSet::new();
    for (index, chunk) in chunks.iter().enumerate() {
        if !chunk.dirty { continue; }
        let (rx, _) = split_chunk_coordinate(chunk.x_pos);
        let (rz, _) = split_chunk_coordinate(chunk.z_pos);
        if !seen.insert((chunk.x_pos, chunk.z_pos)) {
            return Err(Mc189Error::InvalidData(format!("duplicate chunk ({},{}) in deferred save batch", chunk.x_pos, chunk.z_pos)));
        }
        regions.entry((rx, rz)).or_default().push(index);
    }

    for ((rx, rz), indices) in regions {
        let path = world.join("region").join(format!("r.{rx}.{rz}.mca"));
        let parent = path.parent().ok_or_else(|| Mc189Error::Usage("region path has no parent".into()))?;
        std::fs::create_dir_all(parent)?;
        let mut slots: Vec<Option<(Vec<u8>, u32)>> = vec![None; LOCATION_ENTRIES];
        if path.exists() {
            let mut file = File::open(&path)?;
            let len = file.metadata()?.len();
            if len < HEADER_BYTES as u64 { return Err(Mc189Error::InvalidData("region shorter than header".into())); }
            let mut header = vec![0; HEADER_BYTES];
            file.read_exact(&mut header)?;
            let parsed = RegionHeader::parse(&header, len)?;
            let mut occupied = HashSet::new();
            for i in 0..LOCATION_ENTRIES {
                let loc = parsed.locations[i];
                if !loc.is_present() { continue; }
                for sector in loc.sector_offset..loc.sector_offset + u32::from(loc.sector_count) {
                    if !occupied.insert(sector) {
                        return Err(Mc189Error::InvalidData("overlapping Anvil chunk sectors; refusing write".into()));
                    }
                }
                let mut source = File::open(&path)?;
                source.seek(SeekFrom::Start(u64::from(loc.sector_offset) * SECTOR_BYTES as u64))?;
                let mut length_bytes = [0; 4];
                source.read_exact(&mut length_bytes)?;
                let record_len = u32::from_be_bytes(length_bytes) as usize;
                if record_len < 1 || record_len > usize::from(loc.sector_count) * SECTOR_BYTES - 4 {
                    return Err(Mc189Error::InvalidData("invalid sibling chunk record length".into()));
                }
                let mut record = vec![0; record_len];
                source.read_exact(&mut record)?;
                slots[i] = Some((record, parsed.timestamps[i]));
            }
        }

        let mut replaced_slots = HashSet::new();
        for &index in &indices {
            let chunk = &chunks[index];
            let (chunk_rx, local_x) = split_chunk_coordinate(chunk.x_pos);
            let (chunk_rz, local_z) = split_chunk_coordinate(chunk.z_pos);
            if (chunk_rx, chunk_rz) != (rx, rz) {
                return Err(Mc189Error::InvalidData("chunk grouped into the wrong region".into()));
            }
            let slot = usize::from(local_x) + usize::from(local_z) * 32;
            if !replaced_slots.insert(slot) {
                return Err(Mc189Error::InvalidData("two chunks map to the same Anvil region slot".into()));
            }
            let raw = chunk.encode()?;
            let mut encoder = flate2::write::ZlibEncoder::new(Vec::new(), flate2::Compression::default());
            use std::io::Write;
            encoder.write_all(&raw)?;
            let compressed = encoder.finish()?;
            let mut record = Vec::with_capacity(compressed.len() + 1);
            record.push(2);
            record.extend_from_slice(&compressed);
            let timestamp = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default().as_secs().min(u32::MAX as u64) as u32;
            slots[slot] = Some((record, timestamp));
        }

        let mut output = vec![0_u8; HEADER_BYTES];
        let mut sector = HEADER_SECTORS as u32;
        for (slot, entry) in slots.iter().enumerate() {
            if let Some((record, timestamp)) = entry {
                let needed = (record.len() + 4 + SECTOR_BYTES - 1) / SECTOR_BYTES;
                if needed == 0 || needed > 255 || sector > 0x00FF_FFFF || sector as u64 + needed as u64 > 0x00FF_FFFF {
                    return Err(Mc189Error::InvalidData("region exceeds Anvil sector address limits".into()));
                }
                let header_offset = slot * 4;
                output[header_offset] = (sector >> 16) as u8;
                output[header_offset + 1] = (sector >> 8) as u8;
                output[header_offset + 2] = sector as u8;
                output[header_offset + 3] = needed as u8;
                let timestamp_offset = SECTOR_BYTES + slot * 4;
                output[timestamp_offset..timestamp_offset + 4].copy_from_slice(&timestamp.to_be_bytes());
                let record_offset = output.len();
                output.resize(record_offset + needed * SECTOR_BYTES, 0);
                output[record_offset..record_offset + 4].copy_from_slice(&(record.len() as u32).to_be_bytes());
                output[record_offset + 4..record_offset + 4 + record.len()].copy_from_slice(record);
                sector += needed as u32;
            }
        }

        let nonce = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_nanos();
        let temp = path.with_extension(format!("mca.tmp-{}-{nonce}", std::process::id()));
        let backup = path.with_extension(format!("mca.bak-{}-{nonce}", std::process::id()));
        {
            use std::io::Write;
            let mut file = File::create(&temp)?;
            file.write_all(&output)?;
            file.sync_all()?;
        }
        if path.exists() {
            std::fs::rename(&path, &backup)?;
            if let Err(error) = std::fs::rename(&temp, &path) {
                let _ = std::fs::rename(&backup, &path);
                let _ = std::fs::remove_file(&temp);
                return Err(error.into());
            }
        } else {
            std::fs::rename(&temp, &path)?;
        }
        for index in indices { chunks[index].dirty = false; }
    }
    Ok(())
}

#[cfg(test)]
mod mutable_storage_tests {
    use super::*;
    fn sample_chunk()->MutableChunk {
        let section=NbtTag::Compound(vec![
            ("Y".into(),NbtTag::Byte(0)),("Blocks".into(),NbtTag::ByteArray(vec![0;4096])),
            ("Data".into(),NbtTag::ByteArray(vec![0;2048])),("BlockLight".into(),NbtTag::ByteArray(vec![0;2048])),
            ("SkyLight".into(),NbtTag::ByteArray(vec![0;2048])),
        ]);
        let level=NbtTag::Compound(vec![("xPos".into(),NbtTag::Int(-1)),("zPos".into(),NbtTag::Int(2)),("Sections".into(),NbtTag::List(10,vec![section])),("Biomes".into(),NbtTag::ByteArray(vec![1;256]))]);
        MutableChunk{x_pos:-1,z_pos:2,root_name:String::new(),root:NbtTag::Compound(vec![("Level".into(),level),("CustomPreserved".into(),NbtTag::String("keep".into()))]),dirty:false}
    }
    #[test]
    fn mutable_chunk_updates_legacy_id_metadata_and_add_nibble(){
        let mut c=sample_chunk(); assert_eq!(c.get_block(3,4,5).unwrap(),(0,0));
        c.set_block(3,4,5,0x2AB,13).unwrap(); assert_eq!(c.get_block(3,4,5).unwrap(),(0x2AB,13));
        assert!(c.is_dirty());
        c.set_block(3,4,5,0,0).unwrap(); assert_eq!(c.get_block(3,4,5).unwrap(),(0,0));
    }
    #[test]
    fn mutable_chunk_persists_recomputed_heightmap_and_packed_lights() {
        let mut chunk = sample_chunk();
        let mut block_light = vec![0_u8; 4096];
        let mut sky_light = vec![0_u8; 4096];
        block_light[0] = 3; block_light[1] = 12;
        sky_light[0] = 15; sky_light[1] = 7;
        let data = ChunkData {
            x_pos: -1, z_pos: 2,
            sections: vec![ChunkSection {
                y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
                block_light: Some(block_light), sky_light: Some(sky_light),
            }],
            biomes: None, height_map: Some(vec![42; 256]),
        };
        chunk.apply_derived_data(&data).unwrap();
        let level = chunk.root.get("Level").unwrap();
        assert_eq!(level.get("HeightMap").and_then(NbtTag::as_int_array).unwrap()[0], 42);
        let section = &level.get("Sections").and_then(NbtTag::as_list).unwrap().1[0];
        assert_eq!(section.get("BlockLight").and_then(NbtTag::as_byte_array).unwrap()[0] as u8, 0xC3);
        assert_eq!(section.get("SkyLight").and_then(NbtTag::as_byte_array).unwrap()[0] as u8, 0x7F);
        assert!(chunk.is_dirty());
    }

    #[test]
    fn mutable_chunk_applies_complete_snapshot_block_and_light_state() {
        let mut chunk = sample_chunk();
        let mut block_ids = vec![0_u16; BLOCKS_PER_SECTION];
        let mut metadata = vec![0_u8; BLOCKS_PER_SECTION];
        let mut block_light = vec![0_u8; BLOCKS_PER_SECTION];
        let mut sky_light = vec![0_u8; BLOCKS_PER_SECTION];
        let index = (4usize << 8) | (5usize << 4) | 3usize;
        block_ids[index] = 0x1AB;
        metadata[index] = 7;
        block_light[index] = 9;
        sky_light[index] = 15;
        let snapshot = ChunkData {
            x_pos: -1,
            z_pos: 2,
            sections: vec![ChunkSection {
                y: 0,
                block_ids,
                metadata,
                block_light: Some(block_light),
                sky_light: Some(sky_light),
            }],
            biomes: None,
            height_map: Some(vec![64; 256]),
        };
        chunk.apply_chunk_snapshot(&snapshot).unwrap();
        assert_eq!(chunk.get_block(3, 4, 5).unwrap(), (0x1AB, 7));
        assert_eq!(chunk.root.get("Level").unwrap().get("HeightMap").and_then(NbtTag::as_int_array).unwrap()[0], 64);
        let section = &chunk.root.get("Level").unwrap().get("Sections").and_then(NbtTag::as_list).unwrap().1[0];
        assert_eq!(read_nibble(section.get("BlockLight").and_then(NbtTag::as_byte_array).unwrap(), index), 9);
        assert_eq!(read_nibble(section.get("SkyLight").and_then(NbtTag::as_byte_array).unwrap(), index), 15);
        assert!(chunk.is_dirty());
    }

    #[test]
    fn deferred_batch_rewrites_a_region_once_and_preserves_both_chunks() {
        let nonce = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_nanos();
        let base = std::env::temp_dir().join(format!("mc189-anvil-batch-test-{}-{nonce}", std::process::id()));
        let _ = std::fs::remove_dir_all(&base);
        std::fs::create_dir_all(base.join("region")).unwrap();
        let mut first = sample_chunk();
        let mut second = sample_chunk();
        second.x_pos = -2; // same r.-1.0.mca region, different local X slot
        second.root.get_mut("Level").unwrap().insert("xPos", NbtTag::Int(-2)).unwrap();
        first.set_block(1, 10, 1, 1, 0).unwrap();
        second.set_block(2, 11, 2, 4, 0).unwrap();
        let mut batch = vec![first, second];
        save_mutable_chunks(&base, &mut batch).unwrap();
        assert!(batch.iter().all(|chunk| !chunk.is_dirty()));
        let loaded_first = load_mutable_chunk(&base, -1, 2).unwrap();
        let loaded_second = load_mutable_chunk(&base, -2, 2).unwrap();
        assert_eq!(loaded_first.get_block(1, 10, 1).unwrap(), (1, 0));
        assert_eq!(loaded_second.get_block(2, 11, 2).unwrap(), (4, 0));
        let _ = std::fs::remove_dir_all(&base);
    }

    #[test]
    fn snapshot_persists_light_in_an_air_only_section_missing_from_original_nbt() {
        let mut chunk = sample_chunk();
        let mut sky_light = vec![0_u8; BLOCKS_PER_SECTION];
        let light_index = (2usize << 8) | (3usize << 4) | 4usize;
        sky_light[light_index] = 14;
        let snapshot = ChunkData {
            x_pos: -1,
            z_pos: 2,
            sections: vec![ChunkSection {
                y: 1,
                block_ids: vec![0; BLOCKS_PER_SECTION],
                metadata: vec![0; BLOCKS_PER_SECTION],
                block_light: Some(vec![0; BLOCKS_PER_SECTION]),
                sky_light: Some(sky_light),
            }],
            biomes: None,
            height_map: None,
        };
        chunk.apply_chunk_snapshot(&snapshot).unwrap();
        let sections = chunk.root.get("Level").unwrap().get("Sections").and_then(NbtTag::as_list).unwrap().1;
        let empty_light_section = sections.iter().find(|section| {
            section.get("Y").and_then(NbtTag::as_byte) == Some(1)
        }).expect("air-only light section must be materialized in NBT");
        let packed_sky = empty_light_section.get("SkyLight").and_then(NbtTag::as_byte_array).unwrap();
        assert_eq!(read_nibble(packed_sky, light_index), 14);
    }

    #[test]
    fn nbt_writer_roundtrips_and_keeps_unknown_compound_tags(){
        let c=sample_chunk(); let bytes=c.encode().unwrap(); let (name,root)=nbt::parse_root(&bytes).unwrap();
        assert_eq!(name,""); assert_eq!(root.get("CustomPreserved").and_then(NbtTag::as_string),Some("keep"));
    }
    #[test]
    fn region_save_and_reload_preserves_block_edit(){
        let nonce=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_nanos();
        let base=std::env::temp_dir().join(format!("mc189-anvil-write-test-{}-{nonce}",std::process::id()));
        let _=std::fs::remove_dir_all(&base); std::fs::create_dir_all(base.join("region")).unwrap();
        let mut c=sample_chunk(); c.set_block(3,4,5,0x1AB,7).unwrap(); save_mutable_chunk(&base,&mut c).unwrap();
        assert!(!c.is_dirty()); let loaded=load_mutable_chunk(&base,-1,2).unwrap();
        assert_eq!(loaded.get_block(3,4,5).unwrap(),(0x1AB,7));
        let _=std::fs::remove_dir_all(&base);
    }
    #[test]
    fn decoded_chunk_mutation_updates_memory_and_materializes_section() {
        let mut chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![], biomes: None, height_map: None };
        assert_eq!(chunk.block_id_at(2, 35, 4), Some(0));
        assert_eq!(chunk.set_block(2, 35, 4, 0x123, 9).unwrap(), (0, 0));
        assert_eq!(chunk.block_id_at(2, 35, 4), Some(0x123));
        assert_eq!(chunk.block_metadata_at(2, 35, 4), Some(9));
        assert_eq!(chunk.sections.len(), 1);
        assert_eq!(chunk.sections[0].y, 2);
        assert_eq!(chunk.set_block(2, 35, 4, 0, 0).unwrap(), (0x123, 9));
        assert_eq!(chunk.block_id_at(2, 35, 4), Some(0));
    }

    #[test]
    fn decoded_chunk_mutation_rejects_invalid_values_without_changes() {
        let mut chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![], biomes: None, height_map: None };
        assert!(chunk.set_block(16, 0, 0, 1, 0).is_err());
        assert!(chunk.set_block(0, 0, 0, 4096, 0).is_err());
        assert!(chunk.set_block(0, 0, 0, 1, 16).is_err());
        assert!(chunk.sections.is_empty());
    }

    #[test]
    fn decoded_chunk_light_sampler_reads_nibbles_and_uses_heightmap_fallback() {
        let mut block = vec![0; BLOCKS_PER_SECTION];
        let mut sky = vec![0; BLOCKS_PER_SECTION];
        let index = (4usize << 8) | (5usize << 4) | 3usize;
        block[index] = 6;
        sky[index] = 11;
        let section = ChunkSection { y: 0, block_ids: vec![0; BLOCKS_PER_SECTION],
            metadata: vec![0; BLOCKS_PER_SECTION], block_light: Some(block), sky_light: Some(sky) };
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None,
            height_map: Some(vec![20; 256]) };
        assert_eq!(chunk.light_at(3, 4, 5), Some((11, 6)));
        assert_eq!(chunk.light_at(3, 30, 5), Some((15, 0)));
        assert_eq!(chunk.light_at(16, 4, 5), None);
    }

}
