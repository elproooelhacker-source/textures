//! Minecraft 1.8.9 sounds.
//!
//! Item/block sounds are read from the vanilla 1.8.9 sound event table and OGG
//! resources. Since client.jar has no bundled OGG payloads, the launcher asset
//! index is materialized once into runtime/audio/assets for project-local use.
use glam::Vec3;
use rodio::{buffer::SamplesBuffer, Decoder, OutputStream, OutputStreamHandle, Sink, Source};
use serde_json::Value;
use std::{
    collections::HashMap,
    fs::{self, File},
    io::Cursor,
    path::{Component, Path, PathBuf},
    sync::Arc,
};
use zip::ZipArchive;

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BlockSoundProfile {
    pub step: &'static str,
    pub broken: &'static str,
    pub volume: f32,
    pub frequency: f32,
}
impl BlockSoundProfile {
    const fn new(step: &'static str, broken: &'static str, volume: f32, frequency: f32) -> Self {
        Self { step, broken, volume, frequency }
    }
}
const STONE: BlockSoundProfile = BlockSoundProfile::new("step.stone", "dig.stone", 1.0, 1.0);
const WOOD: BlockSoundProfile = BlockSoundProfile::new("step.wood", "dig.wood", 1.0, 1.0);
const GRASS: BlockSoundProfile = BlockSoundProfile::new("step.grass", "dig.grass", 1.0, 1.0);
const GRAVEL: BlockSoundProfile = BlockSoundProfile::new("step.gravel", "dig.gravel", 1.0, 1.0);
const SAND: BlockSoundProfile = BlockSoundProfile::new("step.sand", "dig.sand", 1.0, 1.0);
const CLOTH: BlockSoundProfile = BlockSoundProfile::new("step.cloth", "dig.cloth", 1.0, 1.0);
const SNOW: BlockSoundProfile = BlockSoundProfile::new("step.snow", "dig.snow", 1.0, 1.0);
const GLASS: BlockSoundProfile = BlockSoundProfile::new("step.stone", "dig.glass", 1.0, 1.0);
const METAL: BlockSoundProfile = BlockSoundProfile::new("step.stone", "dig.stone", 1.0, 1.5);
const LADDER: BlockSoundProfile = BlockSoundProfile::new("step.ladder", "dig.wood", 1.0, 1.0);
const ANVIL: BlockSoundProfile = BlockSoundProfile::new("step.anvil", "dig.stone", 0.3, 1.0);
const SLIME: BlockSoundProfile = BlockSoundProfile::new("mob.slime.small", "mob.slime.big", 1.0, 1.0);

const EVENTS_NEEDED: [&str; 20] = [
    "step.stone", "dig.stone", "step.wood", "dig.wood", "step.grass", "dig.grass",
    "step.gravel", "dig.gravel", "step.sand", "dig.sand", "step.cloth", "dig.cloth",
    "step.snow", "dig.snow", "dig.glass", "step.ladder",
    "mob.slime.small", "mob.slime.big", "random.pop", "random.break",
];

/// Block.stepSound assignments from MCP Block.java and relevant superclass constructors.
pub fn block_sound_profile(id: u16) -> BlockSoundProfile {
    if matches!(id, 2|6|18|19|31|32|37|38|39|40|46|59|83|106|110|111|141|142|161|170|175) { return GRASS; }
    if matches!(id, 3|13|60|82) { return GRAVEL; }
    if matches!(id, 12|88) { return SAND; }
    if matches!(id, 35|51|81|92|171) { return CLOTH; }
    if matches!(id, 78|80) { return SNOW; }
    if matches!(id, 20|79|89|90|95|102|120|123|124|160|169|174) { return GLASS; }
    if matches!(id, 27|28|41|42|52|57|66|71|101|133|152|154|157|167) { return METAL; }
    if id == 65 { return LADDER; }
    if id == 145 { return ANVIL; }
    if id == 165 { return SLIME; }
    if matches!(id, 5|17|26|47|50|53|54|58|63|64|68|69|72|75|76|85|91|93|94|96|99|100|103|104|105|107|125|126|127|134|135|136|143|146|147|148|149|150|151|162|163|164|176|177|178|183..=197) { return WOOD; }
    STONE
}

#[derive(Clone)]
struct Clip {
    channels: u16,
    rate: u32,
    samples: Arc<Vec<f32>>,
    weight: u32,
    volume: f32,
    pitch: f32,
}
pub struct BlockAudio {
    _stream: OutputStream,
    handle: OutputStreamHandle,
    events: HashMap<String, Vec<Clip>>,
    // Keep active sinks owned by the audio manager until their samples finish.
    // This makes the lifetime explicit instead of relying on detached-sink
    // behavior while the world session is rapidly creating pickup sounds.
    active_sinks: Vec<Sink>,
    rng: u64,
    play_log_budget: u8,
}

impl BlockAudio {
    /// Loads event definitions from the exact client JAR selected by the launcher.
    /// In vanilla 1.8.9 the OGG files are downloaded separately, so only their
    /// payloads come from the launcher's hashed asset store when absent in the JAR.
    pub fn load_for_world(world: &Path, client_jar: &Path, seed: u64) -> Option<Self> {
        let file = match File::open(client_jar) {
            Ok(file) => file,
            Err(error) => { eprintln!("[audio] cannot open client JAR {}: {error}", client_jar.display()); return None; }
        };
        let mut jar = match ZipArchive::new(file) {
            Ok(archive) => archive,
            Err(error) => { eprintln!("[audio] invalid client JAR {}: {error}", client_jar.display()); return None; }
        };

        let assets = find_launcher_assets_root(world, client_jar);
        let asset_index = assets.as_deref().and_then(load_sound_asset_index);
        let project_audio_assets = if let Some((root, objects, index_path)) = asset_index.as_ref() {
            if let Some(project) = project_root() {
                // Extract only the selected 1.8 index, not merged mappings from
                // newer launcher indexes; otherwise the local pack could contain
                // sounds introduced after Minecraft 1.8.9.
                let exact_objects = read_asset_index_objects(index_path).unwrap_or_else(|| objects.clone());
                let (local_root, copied, reused, total_bytes, missing) =
                    extract_indexed_sound_assets(root, &exact_objects, &project);
                eprintln!("[audio] project-local Minecraft 1.8.9 sound pack: copied {copied}, reused {reused}, missing {missing}, total {total_bytes} bytes; index {}", index_path.file_name().and_then(|n| n.to_str()).unwrap_or("unknown"));
                Some(local_root)
            } else {
                eprintln!("[audio] could not locate project root; using launcher assets directly");
                project_audio_assets_root()
            }
        } else if let (Some(root), Some(project)) = (assets.as_deref(), project_root()) {
            let local_root = extract_virtual_sounds_to_project(root, &project);
            Some(local_root)
        } else {
            project_audio_assets_root()
        };
        if assets.is_none() {
            eprintln!("[audio] no launcher assets root found; checked MC189_GAME_DIR/MC189_INSTANCE_ROOT, world ancestors, client JAR directory, APPDATA/.minecraft, and virtual legacy sounds");
        }
        if let Some(root) = assets.as_deref() {
            if asset_index.is_none() {
                eprintln!("[audio] assets root found at {}, but no usable 1.8 sound index was found under indexes/", root.display());
            }
        }
        let mut definitions_bytes = read_jar_entry(&mut jar, "assets/minecraft/sounds.json");
        let mut definitions_source = if definitions_bytes.is_some() {
            format!("{}!assets/minecraft/sounds.json", client_jar.display())
        } else { String::new() };
        if definitions_bytes.is_none() {
            if let Some(local_root) = project_audio_assets.as_ref() {
                let path = local_root.join("minecraft").join("sounds.json");
                if let Ok(bytes) = fs::read(&path) {
                    definitions_bytes = Some(bytes);
                    definitions_source = format!("{} (project-local extracted assets)", path.display());
                }
            }
        }
        if definitions_bytes.is_none() {
            if let Some((root, objects, _index_path)) = asset_index.as_ref() {
                if let Some(path) = object_path(root, objects, "minecraft/sounds.json") {
                    definitions_bytes = fs::read(&path).ok();
                    if definitions_bytes.is_some() { definitions_source = format!("{} hashed asset", root.display()); }
                }
            }
        }
        let definitions: Value = if let Some(definition_bytes) = definitions_bytes {
            match serde_json::from_slice(&definition_bytes) {
                Ok(value) => {
                    eprintln!("[audio] sound events defined by {definitions_source}");
                    value
                }
                Err(error) => {
                    eprintln!("[audio] invalid sounds.json from {definitions_source}: {error}; using verified 1.8 legacy mappings");
                    Value::Object(serde_json::Map::new())
                }
            }
        } else {
            eprintln!("[audio] sounds.json not found in JAR/index; using verified 1.8 legacy event-to-file mappings");
            Value::Object(serde_json::Map::new())
        };
        eprintln!("[audio] attempting 1.8.9 legacy event IDs: {}", EVENTS_NEEDED.join(", "));
        if let Some(root) = assets.as_ref() { eprintln!("[audio] game assets root: {}", root.display()); }
        if let Some((_, _, index_path)) = asset_index.as_ref() {
            eprintln!("[audio] OGG lookup uses launcher index {}", index_path.display());
        } else {
            eprintln!("[audio] launcher asset index not found; checking client.jar and assets/virtual/legacy/sounds fallback");
        }

        let (stream, handle) = match OutputStream::try_default() {
            Ok(value) => {
                eprintln!("[audio] default output device opened successfully");
                value
            }
            Err(error) => { eprintln!("[audio] no audio output device ({error}); continuing silently"); return None; }
        };

        let mut events = HashMap::new();
        let mut loaded_variants = 0usize;
        let mut missing_variants = 0usize;
        let mut events_without_clips = Vec::new();
        for event in EVENTS_NEEDED {
            let variants = definitions.get(event).and_then(|v| v.get("sounds")).and_then(Value::as_array).cloned()
                .unwrap_or_else(|| legacy_sound_names(event).iter().map(|name| Value::String((*name).to_owned())).collect());
            if variants.is_empty() {
                events_without_clips.push(event.to_owned());
                continue;
            }
            let mut clips = Vec::new();
            for variant in &variants {
                let (name, weight, volume, pitch, is_file) = parse_variant(variant);
                if !is_file { continue; }
                let Some(logical) = logical_path(&name) else { missing_variants += 1; continue; };
                let bytes = project_audio_assets.as_ref().and_then(|root| read_project_sound(root, &logical))
                    .or_else(|| read_jar_entry(&mut jar, &format!("assets/{logical}")))
                    .or_else(|| asset_index.as_ref().and_then(|(root, objects, _)| {
                        object_path(root, objects, &logical).and_then(|path| fs::read(path).ok())
                    }))
                    .or_else(|| assets.as_deref().and_then(|root| read_legacy_virtual_sound(root, &logical)));
                let Some(bytes) = bytes else { missing_variants += 1; continue; };
                let Ok(decoder) = Decoder::new(Cursor::new(bytes)) else { missing_variants += 1; continue; };
                let channels = decoder.channels();
                let rate = decoder.sample_rate();
                // OGG/Vorbis is decoded by rodio 0.20 as signed 16-bit PCM.
                let samples: Vec<f32> = decoder.map(|sample| f32::from(sample) / 32768.0).collect();
                if channels == 0 || rate == 0 || samples.is_empty() { missing_variants += 1; continue; }
                clips.push(Clip { channels, rate, samples: Arc::new(samples), weight, volume, pitch });
                loaded_variants += 1;
            }
            // A stale/custom index can contain an event definition while omitting
            // its legacy OGG objects. Retry the canonical 1.8 filenames instead
            // of treating that partial definition as authoritative silence.
            if clips.is_empty() {
                for name in legacy_sound_names(event) {
                    let Some(logical) = logical_path(name) else { continue; };
                    let bytes = project_audio_assets.as_ref().and_then(|root| read_project_sound(root, &logical))
                        .or_else(|| read_jar_entry(&mut jar, &format!("assets/{logical}")))
                        .or_else(|| asset_index.as_ref().and_then(|(root, objects, _)| {
                            object_path(root, objects, &logical).and_then(|path| fs::read(path).ok())
                        }))
                        .or_else(|| assets.as_deref().and_then(|root| read_legacy_virtual_sound(root, &logical)));
                    let Some(bytes) = bytes else { continue; };
                    let Ok(decoder) = Decoder::new(Cursor::new(bytes)) else { continue; };
                    let channels = decoder.channels();
                    let rate = decoder.sample_rate();
                    let samples: Vec<f32> = decoder.map(|sample| f32::from(sample) / 32768.0).collect();
                    if channels == 0 || rate == 0 || samples.is_empty() { continue; }
                    clips.push(Clip { channels, rate, samples: Arc::new(samples), weight: 1, volume: 1.0, pitch: 1.0 });
                    loaded_variants += 1;
                }
            }
            if clips.is_empty() { events_without_clips.push(event.to_owned()); }
            else { events.insert(event.to_owned(), clips); }
        }

        if events.is_empty() {
            eprintln!("[audio] 0 usable clips loaded ({} missing variants); required events without audio: {}", missing_variants, events_without_clips.join(", "));
            if asset_index.is_none() {
                eprintln!(r"[audio] expected launcher files: <game_dir>\assets\indexes\1.8.json and <game_dir>\assets\objects\<hash-prefix>\<hash>");
            }
            return None;
        }
        let mut loaded_event_names: Vec<_> = events.keys().cloned().collect();
        loaded_event_names.sort();
        eprintln!("[audio] loaded {loaded_variants} OGG variants across {} sound events; {missing_variants} variants missing", events.len());
        if let Some(local_root) = project_audio_assets.as_ref() {
            eprintln!("[audio] project-local extracted audio root: {}", local_root.display());
        }
        eprintln!("[audio] playable events: {}", loaded_event_names.join(", "));
        if !events_without_clips.is_empty() {
            eprintln!("[audio] no playable variants for: {}", events_without_clips.join(", "));
        }
        Some(Self { _stream: stream, handle, events, active_sinks: Vec::new(), rng: seed ^ 0x9E37_79B9_7F4A_7C15, play_log_budget: 12 })
    }

    pub fn play_mining_hit(&mut self, id: u16, block: Vec3, listener: Vec3, yaw: f32) {
        let profile = block_sound_profile(id);
        // Vanilla's periodic block-hit sound is quieter than the final break sound.
        self.play(profile.step, block, listener, yaw, (profile.volume + 1.0) / 8.0, profile.frequency * 0.5);
    }
    pub fn play_break(&mut self, id: u16, block: Vec3, listener: Vec3, yaw: f32) {
        let profile = block_sound_profile(id);
        self.play(profile.broken, block, listener, yaw, (profile.volume + 1.0) / 2.0, profile.frequency * 0.8);
    }
    /// EntityLivingBase.renderBrokenItemStack / random.break in vanilla 1.8.9.
    /// Vanilla uses volume 0.8 and pitch 0.8 + rand.nextFloat() * 0.4.
    pub fn play_item_break(&mut self, player_position: Vec3, listener: Vec3, yaw: f32) -> bool {
        let pitch = 0.8 + self.rand_f32() * 0.4;
        self.play("random.break", player_position, listener, yaw, 0.8, pitch)
    }
    /// Mirrors EntityItem.onCollideWithPlayer: play random.pop at the player
    /// position after a positive inventory transfer, using the original
    /// two-nextFloat pitch formula. The standalone output gain is compensated
    /// because this client does not yet implement vanilla sound-category mixing.
    /// The listener is retained for diagnostics/future positional attenuation;
    /// current Windows output deliberately uses a regular non-spatial Sink.
    pub fn play_pickup(&mut self, player_position: Vec3, listener: Vec3, yaw: f32) -> bool {
        let first_random = self.rand_f32();
        let second_random = self.rand_f32();
        let pitch = vanilla_pickup_pitch(first_random, second_random);
        // Vanilla passes 0.2F to its sound-category mixer. This standalone client
        // does not yet implement SoundCategory/player-volume mixing, so the same
        // raw 0.2 gain was disproportionately quiet next to our unattenuated
        // block sounds. Apply a modest local-output compensation while preserving
        // the original two-nextFloat pitch distribution and selected OGG variant.
        const STANDALONE_PICKUP_GAIN: f32 = 0.45;
        let queued = self.play("random.pop", player_position, listener, yaw, STANDALONE_PICKUP_GAIN, pitch);
        eprintln!("[audio] EntityItem.onCollideWithPlayer random.pop: queued={queued}, gain={STANDALONE_PICKUP_GAIN:.2}, pitch={pitch:.3}, player=({:.2},{:.2},{:.2})", player_position.x, player_position.y, player_position.z);
        queued
    }

    fn play(&mut self, event: &str, source: Vec3, listener: Vec3, yaw: f32, volume: f32, pitch: f32) -> bool {
        let random = self.rand_u64();
        let log_playback = self.play_log_budget > 0;
        if log_playback {
            eprintln!("[audio] play request event='{event}' volume={volume:.3} pitch={pitch:.3} yaw={yaw:.3} source=({:.2},{:.2},{:.2}) listener=({:.2},{:.2},{:.2})",
                source.x, source.y, source.z, listener.x, listener.y, listener.z);
            self.play_log_budget -= 1;
        }
        let selected = {
            let Some(clips) = self.events.get(event) else {
                eprintln!("[audio] event '{event}' was requested but has no decoded clip");
                return false;
            };
            if clips.is_empty() { return false; }
            let total: u64 = clips.iter().map(|clip| u64::from(clip.weight.max(1))).sum();
            let mut roll = random % total.max(1);
            let mut selected = &clips[0];
            for clip in clips {
                let weight = u64::from(clip.weight.max(1));
                if roll < weight { selected = clip; break; }
                roll -= weight;
            }
            selected.clone()
        };
        // These sounds are generated only for the local player's current mining
        // target or a pickup at the player. Their coordinates can be in the
        // session-local chunk frame, while the camera may be translated by the
        // world origin. Applying world-distance attenuation here can therefore
        // mute a valid nearby sound completely. Until a shared absolute listener
        // transform is wired into the audio system, preserve the vanilla event
        // gain and let the caller's local-action range gate control playback.
        let gain = (volume * selected.volume).clamp(0.0, 1.0);
        if gain < 0.0001 { return false; }
        // The client currently renders one local player and a single world audio
        // listener. Use a regular output sink rather than SpatialSink here: the
        // latter's backend-dependent HRTF/panning path made valid OGG clips silent
        // on some Windows default-device configurations. Distance attenuation
        // is intentionally disabled until audio and camera use the same absolute
        // coordinate frame; positional panning can be reintroduced afterwards.
        let buffer = SamplesBuffer::new(selected.channels, selected.rate, selected.samples.as_ref().clone())
            .speed((pitch * selected.pitch).clamp(0.25, 4.0));
        // Reap finished one-shot channels, but keep every active Sink owned by
        // BlockAudio until rodio reports it empty. This avoids making item pickup
        // sounds depend on detached-sink lifetime while preserving overlapping
        // sounds (each event gets its own channel).
        self.active_sinks.retain(|sink| !sink.empty());
        match Sink::try_new(&self.handle) {
            Ok(sink) => {
                sink.set_volume(gain);
                sink.append(buffer);
                self.active_sinks.push(sink);
                if log_playback { eprintln!("[audio] playback queued and retained for '{event}' (active channels={})", self.active_sinks.len()); }
                true
            }
            Err(error) => {
                eprintln!("[audio] could not create playback sink for '{event}': {error}");
                false
            }
        }
    }
    fn rand_u64(&mut self) -> u64 {
        let mut value = self.rng;
        value ^= value << 13;
        value ^= value >> 7;
        value ^= value << 17;
        self.rng = value;
        value
    }
    fn rand_f32(&mut self) -> f32 { (self.rand_u64() >> 40) as f32 / (1u32 << 24) as f32 }
}

/// 1.8.x sound event table. It is a fallback for installations where an
/// asset index was pruned or sounds.json was not installed, while still loading
/// the actual original Mojang OGG payloads from assets/objects.
fn legacy_sound_names(event: &str) -> &'static [&'static str] {
    match event {
        "step.stone" => &["step/stone1", "step/stone2", "step/stone3", "step/stone4", "step/stone5", "step/stone6"],
        "dig.stone" => &["dig/stone1", "dig/stone2", "dig/stone3", "dig/stone4"],
        "step.wood" => &["step/wood1", "step/wood2", "step/wood3", "step/wood4", "step/wood5", "step/wood6"],
        "dig.wood" => &["dig/wood1", "dig/wood2", "dig/wood3", "dig/wood4"],
        "step.grass" => &["step/grass1", "step/grass2", "step/grass3", "step/grass4", "step/grass5", "step/grass6"],
        "dig.grass" => &["dig/grass1", "dig/grass2", "dig/grass3", "dig/grass4"],
        "step.gravel" => &["step/gravel1", "step/gravel2", "step/gravel3", "step/gravel4"],
        "dig.gravel" => &["dig/gravel1", "dig/gravel2", "dig/gravel3", "dig/gravel4"],
        "step.sand" => &["step/sand1", "step/sand2", "step/sand3", "step/sand4", "step/sand5"],
        "dig.sand" => &["dig/sand1", "dig/sand2", "dig/sand3", "dig/sand4"],
        "step.cloth" => &["step/cloth1", "step/cloth2", "step/cloth3", "step/cloth4"],
        "dig.cloth" => &["dig/cloth1", "dig/cloth2", "dig/cloth3", "dig/cloth4"],
        "step.snow" => &["step/snow1", "step/snow2", "step/snow3", "step/snow4"],
        "dig.snow" => &["dig/snow1", "dig/snow2", "dig/snow3", "dig/snow4"],
        "dig.glass" => &["random/glass1", "random/glass2", "random/glass3"],
        "step.ladder" => &["step/ladder1", "step/ladder2", "step/ladder3", "step/ladder4", "step/ladder5"],
        "random.anvil_land" => &["random/anvil_land"],
        "random.anvil_break" => &["random/anvil_break"],
        "mob.slime.small" => &["mob/slime/small1", "mob/slime/small2", "mob/slime/small3", "mob/slime/small4", "mob/slime/small5"],
        "mob.slime.big" => &["mob/slime/big1", "mob/slime/big2", "mob/slime/big3", "mob/slime/big4"],
        "random.pop" => &["random/pop"],
        "random.break" => &["random/break"],
        _ => &[],
    }
}

fn read_legacy_virtual_sound(assets_root: &Path, logical: &str) -> Option<Vec<u8>> {
    let relative = logical.strip_prefix("minecraft/sounds/")?;
    let candidates = [
        assets_root.join("virtual/legacy/sounds").join(relative),
        assets_root.join("sounds").join(relative),
        assets_root.parent()?.join("resources/sounds").join(relative),
    ];
    candidates.into_iter().find_map(|path| fs::read(path).ok())
}

fn find_launcher_assets_root(world: &Path, client_jar: &Path) -> Option<PathBuf> {
    let mut candidates = Vec::new();
    if let Some(path) = std::env::var_os("MC189_ASSETS_ROOT").map(PathBuf::from) {
        candidates.push(path);
    }
    for variable in ["MC189_GAME_DIR", "MC189_INSTANCE_ROOT"] {
        if let Some(path) = std::env::var_os(variable).map(PathBuf::from) {
            candidates.push(path.join("assets"));
        }
    }
    // Walk the selected world's parents instead of assuming one exact folder
    // layout. UltimMC commonly nests saves under <instance>/.minecraft/saves.
    for ancestor in world.ancestors() {
        candidates.push(ancestor.join("assets"));
    }
    // Some launchers keep the game directory next to the selected client JAR.
    if let Some(parent) = client_jar.parent() {
        candidates.push(parent.join("assets"));
        candidates.push(parent.join(".minecraft").join("assets"));
    }
    if let Some(appdata) = std::env::var_os("APPDATA").map(PathBuf::from) {
        candidates.push(appdata.join(".minecraft").join("assets"));
    }
    let mut seen = std::collections::HashSet::new();
    let candidates: Vec<PathBuf> = candidates.into_iter().filter(|root| seen.insert(root.clone())).collect();

    // Some instances create empty local assets/indexes and assets/objects folders
    // which shadow the actual shared UltimMC store. Prefer a root whose index
    // really maps 1.8 sound events, and only then fall back to virtual legacy audio.
    for root in &candidates {
        if root_has_sound_asset_index(root) { return Some(root.clone()); }
    }
    candidates.into_iter().find(|root| root_has_virtual_sounds(root))
}

fn root_has_virtual_sounds(root: &Path) -> bool {
    ["dig/stone1.ogg", "step/stone1.ogg", "random/pop.ogg"]
        .iter()
        .any(|relative| root.join("virtual/legacy/sounds").join(relative).is_file())
}

fn root_has_sound_asset_index(root: &Path) -> bool {
    let Ok(entries) = fs::read_dir(root.join("indexes")) else { return false; };
    entries.filter_map(|entry| entry.ok().map(|entry| entry.path()))
        .filter(|path| path.extension().and_then(|ext| ext.to_str()) == Some("json"))
        .any(|path| {
            let Ok(bytes) = fs::read(path) else { return false; };
            let Ok(value) = serde_json::from_slice::<Value>(&bytes) else { return false; };
            let Some(objects) = value.get("objects").and_then(Value::as_object) else { return false; };
            // A JSON mapping is not enough: require at least one referenced sound
            // object to exist on disk, otherwise an incomplete local cache can
            // still shadow the shared launcher store.
            objects.keys().any(|key| {
                (key.starts_with("minecraft/sounds/") || key.starts_with("sounds/"))
                    && object_path(root, objects, key).is_some()
            })
        })
}

fn load_sound_asset_index(root: &Path) -> Option<(PathBuf, serde_json::Map<String, Value>, PathBuf)> {
    let directory = root.join("indexes");
    let mut paths: Vec<PathBuf> = fs::read_dir(&directory).ok()?.filter_map(|entry| entry.ok().map(|e| e.path()))
        .filter(|path| path.extension().and_then(|ext| ext.to_str()) == Some("json")).collect();
    paths.sort_by_key(|path| {
        let name = path.file_name().and_then(|n| n.to_str()).unwrap_or_default();
        match name { "1.8.json" => (0, String::new()), "1.8.9.json" => (1, String::new()), _ => (2, name.to_ascii_lowercase()) }
    });

    // UltimMC installations can contain several asset-index snapshots. Prefer
    // the 1.8 index, but merge absent sound keys from the remaining indexes too:
    // the object payloads are content-addressed and safely shared by SHA-1.
    let mut merged = serde_json::Map::new();
    let mut selected_path: Option<PathBuf> = None;
    let mut loaded_indexes = Vec::new();
    for index_path in paths {
        let Ok(bytes) = fs::read(&index_path) else { continue; };
        let Ok(value) = serde_json::from_slice::<Value>(&bytes) else { continue; };
        let Some(objects) = value.get("objects").and_then(Value::as_object) else { continue; };
        let has_legacy_audio = objects.keys().any(|key| {
            key.starts_with("minecraft/sounds/dig/") || key.starts_with("minecraft/sounds/step/")
                || key.starts_with("minecraft/sounds/random/") || key.starts_with("sounds/dig/")
                || key.starts_with("sounds/step/") || key.starts_with("sounds/random/")
        });
        let has_sound_definitions = objects.contains_key("minecraft/sounds.json") || objects.contains_key("sounds.json");
        if !has_legacy_audio && !has_sound_definitions { continue; }
        if selected_path.is_none() { selected_path = Some(index_path.clone()); }
        loaded_indexes.push(index_path.file_name().and_then(|n| n.to_str()).unwrap_or("unknown").to_owned());
        for (key, value) in objects {
            merged.entry(key.clone()).or_insert_with(|| value.clone());
        }
    }
    let selected_path = selected_path?;
    if merged.is_empty() { return None; }
    eprintln!("[audio] merged sound mappings from asset indexes: {}", loaded_indexes.join(", "));
    Some((root.to_path_buf(), merged, selected_path))
}

fn read_asset_index_objects(index_path: &Path) -> Option<serde_json::Map<String, Value>> {
    let bytes = fs::read(index_path).ok()?;
    let value: Value = serde_json::from_slice(&bytes).ok()?;
    value.get("objects").and_then(Value::as_object).cloned()
}

/// Project-local copy of the full 1.8.9 sound tree. `client.jar` contains the
/// sound event/model metadata but the original OGG payloads live in the launcher's
/// content-addressed asset store. The first launch materializes every sound listed
/// in the selected 1.8 asset index under runtime/audio/assets/minecraft/sounds.
fn project_root() -> Option<PathBuf> {
    if let Some(path) = std::env::var_os("MC189_PROJECT_ROOT").map(PathBuf::from) {
        if path.join("Cargo.toml").is_file() { return Some(path); }
    }
    if let Ok(executable) = std::env::current_exe() {
        for ancestor in executable.ancestors() {
            if ancestor.join("Cargo.toml").is_file() { return Some(ancestor.to_path_buf()); }
        }
    }
    std::env::current_dir().ok().filter(|path| path.join("Cargo.toml").is_file())
}

fn project_audio_assets_root() -> Option<PathBuf> {
    project_root().map(|root| root.join("runtime").join("audio").join("assets"))
}

fn indexed_sound_relative_path(key: &str) -> Option<PathBuf> {
    let relative = key.strip_prefix("minecraft/sounds/")
        .or_else(|| key.strip_prefix("sounds/"))?;
    let path = Path::new(relative);
    if path.extension().and_then(|ext| ext.to_str()) != Some("ogg")
        || path.as_os_str().is_empty()
        || path.components().any(|part| !matches!(part, Component::Normal(_)))
    {
        return None;
    }
    Some(path.to_path_buf())
}

fn extract_indexed_sound_assets(
    assets_root: &Path,
    objects: &serde_json::Map<String, Value>,
    project_root: &Path,
) -> (PathBuf, usize, usize, u64, usize) {
    let destination_root = project_root.join("runtime").join("audio").join("assets");
    let sounds_root = destination_root.join("minecraft").join("sounds");
    let mut copied = 0_usize;
    let mut reused = 0_usize;
    let mut missing = 0_usize;
    let mut total_bytes = 0_u64;

    for (logical, descriptor) in objects {
        let Some(relative) = indexed_sound_relative_path(logical) else { continue; };
        let Some(source) = object_path(assets_root, objects, logical) else {
            missing += 1;
            continue;
        };
        let expected_size = descriptor.get("size").and_then(Value::as_u64);
        let destination = sounds_root.join(&relative);
        if let Some(parent) = destination.parent() {
            if fs::create_dir_all(parent).is_err() { missing += 1; continue; }
        }
        let is_current = destination.metadata().ok().is_some_and(|metadata| {
            expected_size.map_or(true, |size| metadata.len() == size)
        });
        if is_current {
            reused += 1;
            total_bytes = total_bytes.saturating_add(destination.metadata().map(|m| m.len()).unwrap_or(0));
            continue;
        }
        if let Err(error) = fs::copy(&source, &destination) {
            eprintln!("[audio] could not extract {} into project: {error}", relative.display());
            missing += 1;
            continue;
        }
        copied += 1;
        total_bytes = total_bytes.saturating_add(destination.metadata().map(|m| m.len()).unwrap_or(0));
    }

    // Preserve the event table beside the extracted OGG tree. If this particular
    // index does not expose sounds.json, the caller can continue using the JAR or
    // the verified 1.8 legacy sound-event table.
    if let Some(source) = object_path(assets_root, objects, "minecraft/sounds.json")
        .or_else(|| object_path(assets_root, objects, "sounds.json"))
    {
        let destination = destination_root.join("minecraft").join("sounds.json");
        if let Some(parent) = destination.parent() { let _ = fs::create_dir_all(parent); }
        let should_copy = !destination.is_file()
            || source.metadata().ok().map(|m| m.len()) != destination.metadata().ok().map(|m| m.len());
        if should_copy {
            if let Err(error) = fs::copy(&source, &destination) {
                eprintln!("[audio] could not copy sounds.json into project: {error}");
            }
        }
    }

    (destination_root, copied, reused, total_bytes, missing)
}

fn copy_virtual_sound_tree(source: &Path, destination: &Path) -> (usize, u64) {
    let mut copied = 0_usize;
    let mut bytes = 0_u64;
    let Ok(entries) = fs::read_dir(source) else { return (0, 0); };
    for entry in entries.flatten() {
        let path = entry.path();
        let target = destination.join(entry.file_name());
        if path.is_dir() {
            let (nested_count, nested_bytes) = copy_virtual_sound_tree(&path, &target);
            copied += nested_count;
            bytes = bytes.saturating_add(nested_bytes);
        } else if path.extension().and_then(|ext| ext.to_str()) == Some("ogg") {
            if let Some(parent) = target.parent() { let _ = fs::create_dir_all(parent); }
            let current = target.metadata().ok().map(|m| m.len()) == path.metadata().ok().map(|m| m.len());
            if current { continue; }
            if fs::copy(&path, &target).is_ok() {
                copied += 1;
                bytes = bytes.saturating_add(target.metadata().map(|m| m.len()).unwrap_or(0));
            }
        }
    }
    (copied, bytes)
}

fn extract_virtual_sounds_to_project(assets_root: &Path, project_root: &Path) -> PathBuf {
    let destination_root = project_root.join("runtime").join("audio").join("assets");
    let source = assets_root.join("virtual").join("legacy").join("sounds");
    let destination = destination_root.join("minecraft").join("sounds");
    let (copied, bytes) = copy_virtual_sound_tree(&source, &destination);
    eprintln!("[audio] copied {copied} legacy OGG files ({bytes} bytes) into project-local runtime/audio/assets/minecraft/sounds");
    destination_root
}

fn read_project_sound(project_assets_root: &Path, logical: &str) -> Option<Vec<u8>> {
    let relative = logical.strip_prefix("minecraft/").unwrap_or(logical);
    let path = project_assets_root.join("minecraft").join(relative.strip_prefix("minecraft/").unwrap_or(relative));
    fs::read(path).ok()
}

fn read_jar_entry(jar: &mut ZipArchive<File>, path: &str) -> Option<Vec<u8>> {
    let mut entry = jar.by_name(path).ok()?;
    if entry.size() > 32 * 1024 * 1024 { return None; }
    let mut bytes = Vec::with_capacity(entry.size() as usize);
    std::io::Read::read_to_end(&mut entry, &mut bytes).ok()?;
    Some(bytes)
}

fn object_path(root: &Path, objects: &serde_json::Map<String, Value>, logical: &str) -> Option<PathBuf> {
    let without_namespace = logical.strip_prefix("minecraft/").unwrap_or(logical);
    let sound_relative = logical.strip_prefix("minecraft/sounds/").unwrap_or(logical);
    let keys = [logical, without_namespace, sound_relative];
    for key in keys {
        let Some(hash) = objects.get(key).and_then(|value| value.get("hash")).and_then(Value::as_str) else { continue; };
        if hash.len() != 40 || !hash.bytes().all(|byte| byte.is_ascii_hexdigit()) { continue; }
        let path = root.join("objects").join(&hash[..2]).join(hash);
        if path.is_file() { return Some(path); }
    }
    None
}


/// Mirrors the local EntityItem pickup rule: a pop is emitted for any positive
/// inventory transfer. Item age and how long it has been resting on the ground
/// are deliberately not inputs to this decision.
pub fn pickup_sound_for_transfer(inserted_count: u16) -> bool { inserted_count > 0 }

/// Vanilla EntityItem / NetHandlerPlayClient random.pop pitch distribution.
fn vanilla_pickup_pitch(first: f32, second: f32) -> f32 {
    ((first.clamp(0.0, 1.0) - second.clamp(0.0, 1.0)) * 0.7 + 1.0) * 2.0
}

fn parse_variant(value: &Value) -> (String, u32, f32, f32, bool) {
    if let Some(name) = value.as_str() { return (name.to_owned(), 1, 1.0, 1.0, true); }
    let Some(object) = value.as_object() else { return (String::new(), 1, 1.0, 1.0, false); };
    let name = object.get("name").and_then(Value::as_str).unwrap_or("").to_owned();
    let kind = object.get("type").and_then(Value::as_str).unwrap_or("file");
    let weight = object.get("weight").and_then(Value::as_u64).unwrap_or(1).clamp(1, 1_000_000) as u32;
    let volume = object.get("volume").and_then(Value::as_f64).unwrap_or(1.0).clamp(0.0, 4.0) as f32;
    let pitch = object.get("pitch").and_then(Value::as_f64).unwrap_or(1.0).clamp(0.25, 4.0) as f32;
    (name, weight, volume, pitch, kind == "file")
}

fn logical_path(name: &str) -> Option<String> {
    let name = name.strip_prefix("minecraft:").unwrap_or(name);
    let name = name.strip_suffix(".ogg").unwrap_or(name);
    if name.is_empty() || Path::new(name).components().any(|part| !matches!(part, Component::Normal(_))) { return None; }
    Some(format!("minecraft/sounds/{name}.ogg"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn indexed_sound_pack_extraction_materializes_all_ogg_paths_for_project_use() {
        let root = std::env::temp_dir().join(format!("mc189-audio-extract-test-{}", std::process::id()));
        let _ = fs::remove_dir_all(&root);
        let assets = root.join("launcher-assets");
        let project = root.join("project");
        let hash = "ab0123456789abcdef0123456789abcdef012345";
        let object_path = assets.join("objects").join("ab").join(hash);
        fs::create_dir_all(object_path.parent().unwrap()).unwrap();
        fs::write(&object_path, b"fake-ogg-test-payload").unwrap();
        let mut objects = serde_json::Map::new();
        objects.insert("minecraft/sounds/dig/stone1.ogg".to_owned(), serde_json::json!({"hash": hash, "size": 21}));
        let (_destination_root, copied, reused, _bytes, missing) = extract_indexed_sound_assets(&assets, &objects, &project);
        assert_eq!(copied, 1);
        assert_eq!(reused, 0);
        assert_eq!(missing, 0);
        let local = project.join("runtime/audio/assets/minecraft/sounds/dig/stone1.ogg");
        assert_eq!(fs::read(&local).unwrap(), b"fake-ogg-test-payload");
        let (_destination_root, copied_again, reused_again, _bytes_again, missing_again) =
            extract_indexed_sound_assets(&assets, &objects, &project);
        assert_eq!(copied_again, 0, "a second launch should reuse the project-local OGG");
        assert_eq!(reused_again, 1);
        assert_eq!(missing_again, 0);
        let _ = fs::remove_dir_all(&root);
    }
    #[test]
    fn profiles_match_vanilla_block_sound_types() {
        assert_eq!(block_sound_profile(1), STONE);
        assert_eq!(block_sound_profile(5), WOOD);
        assert_eq!(block_sound_profile(3), GRAVEL);
        assert_eq!(block_sound_profile(12), SAND);
        assert_eq!(block_sound_profile(35), CLOTH);
        assert_eq!(block_sound_profile(20).broken, "dig.glass");
    }
    #[test]
    fn glass_ladder_and_anvil_keep_vanilla_break_overrides() {
        assert_eq!(block_sound_profile(20).broken, "dig.glass");
        assert!(EVENTS_NEEDED.contains(&"dig.glass"));
        assert_eq!(block_sound_profile(65).broken, "dig.wood");
        // Block.SoundTypeAnvil overrides its break/place sounds, but leaves
        // getStepSound() as step.anvil (an undefined 1.8 event).
        assert_eq!(block_sound_profile(145).step, "step.anvil");
        assert_eq!(block_sound_profile(145).broken, "dig.stone");
        assert!(!EVENTS_NEEDED.contains(&"step.anvil"));
    }
    #[test]
    fn sound_variant_parser_reads_weights_volume_pitch_and_type() {
        let value = serde_json::json!({"name":"dig/stone1","weight":3,"volume":0.75,"pitch":1.2,"type":"file"});
        let parsed = parse_variant(&value);
        assert_eq!(parsed.0, "dig/stone1");
        assert_eq!(parsed.1, 3);
        assert!((parsed.2 - 0.75).abs() < 0.0001);
        assert!((parsed.3 - 1.2).abs() < 0.0001);
        assert!(parsed.4);
        assert!(!parse_variant(&serde_json::json!({"name":"x","type":"event"})).4);
    }

    #[test]
    fn legacy_fallback_maps_real_18_sound_files() {
        assert_eq!(legacy_sound_names("dig.stone"), &["dig/stone1", "dig/stone2", "dig/stone3", "dig/stone4"]);
        assert_eq!(legacy_sound_names("random.pop"), &["random/pop"]);
        assert!(!legacy_sound_names("step.wood").is_empty());
    }

    #[test]
    fn asset_index_object_path_resolves_mojang_sha1_layout() {
        let base = std::env::temp_dir().join(format!("mc189-audio-index-test-{}", std::process::id()));
        let hash = "0123456789abcdef0123456789abcdef01234567";
        let object = base.join("objects").join("01").join(hash);
        fs::create_dir_all(object.parent().unwrap()).unwrap();
        fs::write(&object, b"ogg-placeholder").unwrap();
        let mut objects = serde_json::Map::new();
        objects.insert("minecraft/sounds/dig/stone1.ogg".into(), serde_json::json!({"hash":hash,"size":14}));
        assert_eq!(object_path(&base, &objects, "minecraft/sounds/dig/stone1.ogg"), Some(object));
        let _ = fs::remove_dir_all(base);
    }

    #[test]
    fn asset_root_search_reaches_shared_ultimc_assets_ancestor() {
        let base = std::env::temp_dir().join(format!("mc189-audio-root-test-{}", std::process::id()));
        let game = base.join("UltimMC").join("instances").join("1.8.9").join(".minecraft");
        let world = game.join("saves").join("Audio Test");
        let shared_assets = base.join("UltimMC").join("assets");
        fs::create_dir_all(&world).unwrap();
        fs::create_dir_all(shared_assets.join("indexes")).unwrap();
        fs::create_dir_all(shared_assets.join("objects")).unwrap();
        let hash = "0123456789abcdef0123456789abcdef01234567";
        let object = shared_assets.join("objects").join("01").join(hash);
        fs::create_dir_all(object.parent().unwrap()).unwrap();
        fs::write(&object, b"ogg-placeholder").unwrap();
        let index = serde_json::json!({"objects": {
            "minecraft/sounds/dig/stone1.ogg": {"hash":hash, "size":14}
        }});
        fs::write(shared_assets.join("indexes").join("1.8.json"), serde_json::to_vec(&index).unwrap()).unwrap();
        let found = find_launcher_assets_root(&world, &base.join("client.jar"));
        assert_eq!(found, Some(shared_assets.clone()));
        let _ = fs::remove_dir_all(base);
    }



    #[test]
    fn asset_root_search_skips_empty_instance_cache_and_uses_shared_ultimc_store() {
        let base = std::env::temp_dir().join(format!("mc189-audio-root-shadow-test-{}", std::process::id()));
        let game = base.join("UltimMC").join("instances").join("1.8.9").join(".minecraft");
        let world = game.join("saves").join("Audio Test");
        let empty_instance_assets = game.join("assets");
        let shared_assets = base.join("UltimMC").join("assets");
        fs::create_dir_all(&world).unwrap();
        fs::create_dir_all(empty_instance_assets.join("indexes")).unwrap();
        fs::create_dir_all(empty_instance_assets.join("objects")).unwrap();
        fs::create_dir_all(shared_assets.join("indexes")).unwrap();
        fs::create_dir_all(shared_assets.join("objects")).unwrap();
        // An instance may have a local index containing only the manifest, but
        // the shared store is where the actual OGG variants were downloaded.
        let partial_index = serde_json::json!({"objects": {
            "minecraft/sounds.json": {"hash":"abcdefabcdefabcdefabcdefabcdefabcdefabcd", "size":1}
        }});
        fs::write(empty_instance_assets.join("indexes").join("1.8.json"), serde_json::to_vec(&partial_index).unwrap()).unwrap();
        let shared_hash = "0123456789abcdef0123456789abcdef01234567";
        let shared_object = shared_assets.join("objects").join("01").join(shared_hash);
        fs::create_dir_all(shared_object.parent().unwrap()).unwrap();
        fs::write(&shared_object, b"ogg-placeholder").unwrap();
        let index = serde_json::json!({"objects": {
            "minecraft/sounds/dig/stone1.ogg": {"hash":shared_hash, "size":14}
        }});
        fs::write(shared_assets.join("indexes").join("1.8.json"), serde_json::to_vec(&index).unwrap()).unwrap();
        let found = find_launcher_assets_root(&world, &base.join("client.jar"));
        assert_eq!(found, Some(shared_assets.clone()));
        let _ = fs::remove_dir_all(base);
    }

    #[test]
    fn asset_indexes_merge_missing_sound_entries_without_overwriting_18_priority() {
        let base = std::env::temp_dir().join(format!("mc189-audio-index-merge-{}", std::process::id()));
        let indexes = base.join("indexes");
        fs::create_dir_all(&indexes).unwrap();
        let hash_a = "0123456789abcdef0123456789abcdef01234567";
        let hash_b = "1123456789abcdef0123456789abcdef01234567";
        let first = serde_json::json!({"objects": {
            "minecraft/sounds/step/stone1.ogg": {"hash": hash_a, "size": 1}
        }});
        let second = serde_json::json!({"objects": {
            "minecraft/sounds/step/stone1.ogg": {"hash": hash_b, "size": 1},
            "minecraft/sounds/random/pop.ogg": {"hash": hash_b, "size": 1}
        }});
        fs::write(indexes.join("1.8.json"), serde_json::to_vec(&first).unwrap()).unwrap();
        fs::write(indexes.join("1.20.json"), serde_json::to_vec(&second).unwrap()).unwrap();
        let (_, merged, selected) = load_sound_asset_index(&base).unwrap();
        assert_eq!(selected.file_name().unwrap(), "1.8.json");
        assert_eq!(merged.get("minecraft/sounds/step/stone1.ogg").unwrap()["hash"].as_str(), Some(hash_a));
        assert_eq!(merged.get("minecraft/sounds/random/pop.ogg").unwrap()["hash"].as_str(), Some(hash_b));
        let _ = fs::remove_dir_all(base);
    }

    #[test]
    fn pickup_sound_is_based_on_successful_transfer_not_drop_age() {
        // There is intentionally no age/pickup-delay argument: vanilla plays the
        // sound whenever an eligible entity is transferred, however old it is.
        assert!(!pickup_sound_for_transfer(0));
        assert!(pickup_sound_for_transfer(1));
        assert!(pickup_sound_for_transfer(64));
    }

    #[test]
    fn pickup_pitch_uses_vanilla_randomized_range_and_varies_between_events() {
        assert!((vanilla_pickup_pitch(0.5, 0.5) - 2.0).abs() < 1.0e-6);
        assert!((vanilla_pickup_pitch(1.0, 0.0) - 3.4).abs() < 1.0e-6);
        assert!((vanilla_pickup_pitch(0.0, 1.0) - 0.6).abs() < 1.0e-6);
        assert_ne!(vanilla_pickup_pitch(0.9, 0.1), vanilla_pickup_pitch(0.1, 0.9));
    }

    #[test]
    fn sound_paths_are_namespaced_and_cannot_escape() {
        assert_eq!(logical_path("dig/stone1"), Some("minecraft/sounds/dig/stone1.ogg".into()));
        assert_eq!(logical_path("minecraft:dig/glass1.ogg"), Some("minecraft/sounds/dig/glass1.ogg".into()));
        assert_eq!(logical_path("../escape"), None);
    }
}
