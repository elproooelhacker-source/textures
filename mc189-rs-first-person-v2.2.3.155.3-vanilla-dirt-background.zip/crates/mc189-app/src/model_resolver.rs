//! Read-only second-stage model analysis for Minecraft 1.8.9 resources.
//!
//! This resolves model-parent inheritance, inherited texture variables, and the
//! effective element/face lists. `ModelCatalog` indexes model resources once and
//! caches compiled quads for the integrated textured chunk path.

use mc189_core::{Mc189Error, Result};
use serde_json::Value;
use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet};
use std::fs::File;
use std::io::Read;
use std::path::Path;
use std::sync::Arc;
use zip::ZipArchive;

const MAX_JSON_BYTES: u64 = 4 * 1024 * 1024;
const MAX_DIAGNOSTICS: usize = 30;
const MODEL_PREFIX: &str = "assets/minecraft/models/";
const ASSET_PREFIX: &str = "assets/minecraft/";

/// Effective item display transform for ItemCameraTransforms.TransformType.FIRST_PERSON.
/// Translation is already converted from JSON's sixteenth-block units, and rotation
/// remains in degrees just like ItemTransformVec3f in Minecraft 1.8.9.
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ItemCameraTransform {
    pub rotation: [f32; 3],
    pub translation: [f32; 3],
    pub scale: [f32; 3],
}

impl Default for ItemCameraTransform {
    fn default() -> Self {
        Self { rotation: [0.0; 3], translation: [0.0; 3], scale: [1.0; 3] }
    }
}

#[derive(Clone, Debug, Default)]
struct EffectiveModel {
    textures: BTreeMap<String, String>,
    elements: Option<Vec<Value>>,
    /// ModelBlock.isAmbientOcclusion; an explicit child value overrides its parent.
    ambient_occlusion: Option<bool>,
}

/// Resolve model inheritance and texture aliases across all model JSON files in a client JAR.
pub fn resolve_client_models(jar_path: &Path) -> Result<()> {
    if !jar_path.is_file() {
        return Err(Mc189Error::Usage(format!(
            "client JAR is not a file: {}",
            jar_path.display()
        )));
    }

    let file = File::open(jar_path)?;
    let mut archive = ZipArchive::new(file).map_err(|error| {
        Mc189Error::InvalidData(format!(
            "could not open {} as a ZIP/JAR archive: {error}",
            jar_path.display()
        ))
    })?;

    let mut names = HashSet::<String>::with_capacity(archive.len());
    for index in 0..archive.len() {
        let entry = archive.by_index(index).map_err(|error| {
            Mc189Error::InvalidData(format!("could not read JAR entry {index}: {error}"))
        })?;
        if !entry.is_dir() {
            names.insert(entry.name().to_owned());
        }
    }

    // Models referenced directly by blockstates are treated as concrete render roots.
    // Parent/base models may intentionally contain unbound texture variables such as #all;
    // those are valid templates and are checked after inheritance into their concrete child.
    let mut blockstate_paths: Vec<String> = names
        .iter()
        .filter(|name| {
            name.starts_with("assets/minecraft/blockstates/") && name.ends_with(".json")
        })
        .cloned()
        .collect();
    blockstate_paths.sort();
    let mut concrete_model_paths = BTreeSet::<String>::new();
    let mut blockstate_reference_errors = Vec::new();
    let mut invalid_blockstate_references = 0_usize;
    for blockstate_path in &blockstate_paths {
        let value = match read_json_entry(&mut archive, blockstate_path) {
            Ok(value) if value.is_object() => value,
            Ok(_) => {
                invalid_blockstate_references += 1;
                push_diagnostic(&mut blockstate_reference_errors, format!("{blockstate_path}: root must be an object"));
                continue;
            }
            Err(error) => {
                invalid_blockstate_references += 1;
                push_diagnostic(&mut blockstate_reference_errors, format!("{blockstate_path}: {error}"));
                continue;
            }
        };
        let mut model_ids = Vec::new();
        collect_string_values_for_key(&value, "model", &mut model_ids);
        for model_id in model_ids {
            if has_external_namespace(&model_id) {
                continue;
            }
            match resolve_resource_id(&model_id, "block", "models", ".json") {
                Some(model_path) => {
                    concrete_model_paths.insert(model_path);
                }
                None => {
                    invalid_blockstate_references += 1;
                    push_diagnostic(
                        &mut blockstate_reference_errors,
                        format!("{blockstate_path}: invalid model resource ID {model_id:?}"),
                    );
                }
            }
        }
    }

    let mut model_paths: Vec<String> = names
        .iter()
        .filter(|name| name.starts_with(MODEL_PREFIX) && name.ends_with(".json"))
        .cloned()
        .collect();
    model_paths.sort();

    let mut models: HashMap<String, Value> = HashMap::with_capacity(model_paths.len());
    let mut parse_failures = Vec::new();
    let mut invalid_json_count = 0_usize;
    for path in &model_paths {
        match read_json_entry(&mut archive, path) {
            Ok(value) if value.is_object() => {
                models.insert(path.clone(), value);
            }
            Ok(_) => {
                invalid_json_count += 1;
                push_diagnostic(&mut parse_failures, format!("{path}: root must be an object"));
            }
            Err(error) => {
                invalid_json_count += 1;
                push_diagnostic(&mut parse_failures, format!("{path}: {error}"));
            }
        }
    }

    let mut cache: HashMap<String, EffectiveModel> = HashMap::new();
    let mut inheritance_failures = Vec::new();
    let mut inheritance_failure_count = 0_usize;
    let mut resolved_models = 0_usize;
    let mut effective_models_with_elements = 0_usize;
    let mut total_effective_elements = 0_usize;
    let mut total_effective_faces = 0_usize;
    let mut invalid_geometry_count = 0_usize;
    let mut geometry_diagnostics = Vec::new();
    let mut texture_aliases_examined = 0_usize;
    let mut texture_alias_failures = 0_usize;
    let mut missing_texture_count = 0_usize;
    let mut external_textures_skipped = 0_usize;
    let mut texture_diagnostics = Vec::new();
    let mut used_textures = BTreeSet::new();

    for path in &model_paths {
        if !models.contains_key(path) {
            continue;
        }
        let mut stack = Vec::new();
        let effective = match build_effective_model(path, &models, &mut cache, &mut stack) {
            Ok(model) => {
                resolved_models += 1;
                model
            }
            Err(error) => {
                inheritance_failure_count += 1;
                push_diagnostic(&mut inheritance_failures, format!("{path}: {error}"));
                continue;
            }
        };

        let is_concrete_root = concrete_model_paths.contains(path);
        let mut direct_face_textures = Vec::new();
        if let Some(elements) = &effective.elements {
            effective_models_with_elements += 1;
            total_effective_elements += elements.len();
            match inspect_elements(elements, &effective.textures, is_concrete_root) {
                Ok((faces, referenced_aliases, direct_textures)) => {
                    total_effective_faces += faces;
                    texture_aliases_examined += referenced_aliases;
                    direct_face_textures = direct_textures;
                }
                Err(error) => {
                    invalid_geometry_count += 1;
                    push_diagnostic(&mut geometry_diagnostics, format!("{path}: {error}"));
                }
            }
        }

        // Base templates commonly contain deliberately unbound names like #all. Validate
        // effective bindings only for models instantiated by blockstates, where inheritance
        // has supplied their final values. Every child is resolved against the complete map.
        if is_concrete_root {
            for (key, raw_value) in &effective.textures {
                if raw_value.starts_with('#') {
                    texture_aliases_examined += 1;
                }
                let mut alias_stack = vec![key.clone()];
                match resolve_texture_value(raw_value, &effective.textures, &mut alias_stack) {
                    Ok(value) => {
                        if value.starts_with('#') {
                            texture_alias_failures += 1;
                            push_diagnostic(
                                &mut texture_diagnostics,
                                format!("{path}: texture '{key}' did not resolve completely"),
                            );
                            continue;
                        }
                        if has_external_namespace(&value) {
                            external_textures_skipped += 1;
                            continue;
                        }
                        match texture_resource_path(&value) {
                            Some(texture_path) => {
                                used_textures.insert(texture_path.clone());
                                if !names.contains(&texture_path) {
                                    missing_texture_count += 1;
                                    push_diagnostic(
                                        &mut texture_diagnostics,
                                        format!("{path}: texture '{key}' -> missing {texture_path}"),
                                    );
                                }
                            }
                            None => {
                                texture_alias_failures += 1;
                                push_diagnostic(
                                    &mut texture_diagnostics,
                                    format!("{path}: invalid texture ID {value:?} (binding '{key}')"),
                                );
                            }
                        }
                    }
                    Err(error) => {
                        texture_alias_failures += 1;
                        push_diagnostic(
                            &mut texture_diagnostics,
                            format!("{path}: texture '{key}': {error}"),
                        );
                    }
                }
            }
            for value in direct_face_textures {
                if has_external_namespace(&value) {
                    external_textures_skipped += 1;
                    continue;
                }
                match texture_resource_path(&value) {
                    Some(texture_path) => {
                        used_textures.insert(texture_path.clone());
                        if !names.contains(&texture_path) {
                            missing_texture_count += 1;
                            push_diagnostic(
                                &mut texture_diagnostics,
                                format!("{path}: face references missing texture {texture_path}"),
                            );
                        }
                    }
                    None => {
                        texture_alias_failures += 1;
                        push_diagnostic(
                            &mut texture_diagnostics,
                            format!("{path}: invalid face texture ID {value:?}"),
                        );
                    }
                }
            }
        }
    }

    println!("Minecraft 1.8.9 effective-model analysis (read-only)");
    println!("File: {}", jar_path.display());
    println!("Archive entries: {}", names.len());
    println!();
    println!("Blockstate roots:");
    println!("  Blockstate JSON files examined: {}", blockstate_paths.len());
    println!("  Unique concrete model paths referenced: {}", concrete_model_paths.len());
    println!("  Invalid blockstate/model references: {invalid_blockstate_references}");
    print_diagnostics("Blockstate reference diagnostics", &blockstate_reference_errors);
    let missing_concrete_models = concrete_model_paths.iter().filter(|path| !models.contains_key(*path)).count();
    println!("  Concrete model paths missing/invalid: {missing_concrete_models}");
    println!();
    println!("Model loading and inheritance:");
    println!("  Model JSON files found: {}", model_paths.len());
    println!("  Parsed object models: {}", models.len());
    println!("  Invalid model JSON/root objects: {invalid_json_count}");
    println!("  Models successfully resolved: {resolved_models}");
    println!("  Models with inheritance failures/cycles: {inheritance_failure_count}");
    print_diagnostics("Model inheritance diagnostics", &inheritance_failures);
    print_diagnostics("Model parse diagnostics", &parse_failures);
    println!();
    println!("Effective geometry:");
    println!("  Models with effective elements: {effective_models_with_elements}");
    println!("  Effective element definitions counted: {total_effective_elements}");
    println!("  Effective faces counted: {total_effective_faces}");
    println!("  Models with invalid element/face structure: {invalid_geometry_count}");
    print_diagnostics("Geometry diagnostics", &geometry_diagnostics);
    println!();
    println!("Inherited texture bindings:");
    println!("  Texture aliases examined (may include repeated uses): {texture_aliases_examined}");
    println!("  Alias/texture ID resolution failures: {texture_alias_failures}");
    println!("  Missing resolved texture files: {missing_texture_count}");
    println!("  Unique vanilla texture files referenced: {}", used_textures.len());
    println!("  External-namespace textures skipped: {external_textures_skipped}");
    print_diagnostics("Texture resolution diagnostics", &texture_diagnostics);

    let passed = invalid_blockstate_references == 0
        && missing_concrete_models == 0
        && invalid_json_count == 0
        && inheritance_failure_count == 0
        && invalid_geometry_count == 0
        && texture_alias_failures == 0
        && missing_texture_count == 0;
    println!();
    println!(
        "Effective model/texture resolution: {}",
        if passed { "PASS" } else { "REVIEW REQUIRED" }
    );
    println!("Scope note: this resolves direct blockstate model roots, parent inheritance and texture aliases. Legacy numeric ID/metadata selection, model rotations/UV transforms, item-generated geometry, and GPU mesh creation remain separate steps.");
    println!("The JAR was not extracted or modified.");
    Ok(())
}

fn read_json_entry<R: Read + std::io::Seek>(
    archive: &mut ZipArchive<R>,
    path: &str,
) -> Result<Value> {
    let mut entry = archive.by_name(path).map_err(|error| {
        Mc189Error::InvalidData(format!("could not open resource entry {path}: {error}"))
    })?;
    if entry.size() > MAX_JSON_BYTES {
        return Err(Mc189Error::InvalidData(format!(
            "JSON entry {path} exceeds {MAX_JSON_BYTES} bytes"
        )));
    }
    let expected_size = entry.size() as usize;
    let mut bytes = Vec::with_capacity(expected_size);
    entry.read_to_end(&mut bytes)?;
    serde_json::from_slice(&bytes)
        .map_err(|error| Mc189Error::InvalidData(format!("JSON parse error: {error}")))
}

fn build_effective_model(
    path: &str,
    models: &HashMap<String, Value>,
    cache: &mut HashMap<String, EffectiveModel>,
    stack: &mut Vec<String>,
) -> std::result::Result<EffectiveModel, String> {
    if let Some(cached) = cache.get(path) {
        return Ok(cached.clone());
    }
    if stack.iter().any(|ancestor| ancestor == path) {
        let mut cycle = stack.clone();
        cycle.push(path.to_owned());
        return Err(format!("parent cycle: {}", cycle.join(" -> ")));
    }
    let raw = models
        .get(path)
        .ok_or_else(|| format!("model file missing or invalid: {path}"))?;
    stack.push(path.to_owned());

    let result = (|| {
        let object = raw
            .as_object()
            .ok_or_else(|| "model root is not an object".to_owned())?;
        let mut effective = EffectiveModel::default();

        if let Some(parent_value) = object.get("parent") {
            let parent_id = parent_value
                .as_str()
                .ok_or_else(|| "parent field is not a string".to_owned())?;
            if !is_builtin_model(parent_id) && !has_external_namespace(parent_id) {
                let default_dir = model_parent_directory(path).unwrap_or("block");
                let parent_path = resolve_resource_id(parent_id, default_dir, "models", ".json")
                    .ok_or_else(|| format!("invalid parent resource ID {parent_id:?}"))?;
                effective = build_effective_model(&parent_path, models, cache, stack)
                    .map_err(|error| format!("parent {parent_id:?}: {error}"))?;
            }
        }

        if let Some(ambient_occlusion) = object.get("ambientocclusion").and_then(Value::as_bool) {
            effective.ambient_occlusion = Some(ambient_occlusion);
        }

        if let Some(textures_value) = object.get("textures") {
            let textures = textures_value
                .as_object()
                .ok_or_else(|| "textures field is not an object".to_owned())?;
            for (key, value) in textures {
                let text = value
                    .as_str()
                    .ok_or_else(|| format!("texture binding '{key}' is not a string"))?;
                effective.textures.insert(key.clone(), text.to_owned());
            }
        }

        if let Some(elements_value) = object.get("elements") {
            let elements = elements_value
                .as_array()
                .ok_or_else(|| "elements field is not an array".to_owned())?;
            effective.elements = Some(elements.clone());
        }
        Ok(effective)
    })();

    stack.pop();
    if let Ok(model) = &result {
        cache.insert(path.to_owned(), model.clone());
    }
    result
}

fn inspect_elements(
    elements: &[Value],
    textures: &BTreeMap<String, String>,
    validate_texture_aliases: bool,
) -> std::result::Result<(usize, usize, Vec<String>), String> {
    let mut face_count = 0_usize;
    let mut aliases = 0_usize;
    let mut direct_textures = Vec::new();
    for (element_index, element) in elements.iter().enumerate() {
        let object = element
            .as_object()
            .ok_or_else(|| format!("element {element_index} must be an object"))?;
        validate_vec3(object.get("from"), "from", element_index)?;
        validate_vec3(object.get("to"), "to", element_index)?;

        if let Some(rotation_value) = object.get("rotation") {
            let rotation = rotation_value
                .as_object()
                .ok_or_else(|| format!("element {element_index} rotation must be an object"))?;
            validate_vec3(rotation.get("origin"), "rotation.origin", element_index)?;
            match rotation.get("axis").and_then(Value::as_str) {
                Some("x" | "y" | "z") => {}
                _ => return Err(format!("element {element_index} has invalid rotation axis")),
            }
            if !rotation.get("angle").and_then(Value::as_f64).is_some_and(f64::is_finite) {
                return Err(format!("element {element_index} has invalid rotation angle"));
            }
        }

        let faces = object
            .get("faces")
            .and_then(Value::as_object)
            .ok_or_else(|| format!("element {element_index} faces must be an object"))?;
        for (direction, face_value) in faces {
            if !matches!(direction.as_str(), "down" | "up" | "north" | "south" | "west" | "east") {
                return Err(format!("element {element_index} has unknown face direction {direction:?}"));
            }
            let face = face_value
                .as_object()
                .ok_or_else(|| format!("element {element_index} face {direction} must be an object"))?;
            let texture = face
                .get("texture")
                .and_then(Value::as_str)
                .ok_or_else(|| format!("element {element_index} face {direction} lacks a texture string"))?;
            if texture.starts_with('#') {
                aliases += 1;
                if validate_texture_aliases {
                    let mut stack = Vec::new();
                    resolve_texture_value(texture, textures, &mut stack)
                        .map_err(|error| format!("element {element_index} face {direction}: {error}"))?;
                }
            } else {
                direct_textures.push(texture.to_owned());
            }
            if let Some(uv_value) = face.get("uv") {
                let uv = uv_value
                    .as_array()
                    .ok_or_else(|| format!("element {element_index} face {direction} UV must be an array"))?;
                if uv.len() != 4 || uv.iter().any(|v| !v.as_f64().is_some_and(f64::is_finite)) {
                    return Err(format!("element {element_index} face {direction} UV must contain four finite numbers"));
                }
            }
            if let Some(rotation_value) = face.get("rotation") {
                match rotation_value.as_u64() {
                    Some(0 | 90 | 180 | 270) => {}
                    _ => return Err(format!("element {element_index} face {direction} has invalid UV rotation")),
                }
            }
            face_count += 1;
        }
    }
    Ok((face_count, aliases, direct_textures))
}

fn validate_vec3(
    value: Option<&Value>,
    label: &str,
    element_index: usize,
) -> std::result::Result<(), String> {
    let vector = value
        .and_then(Value::as_array)
        .ok_or_else(|| format!("element {element_index} {label} must be an array"))?;
    if vector.len() != 3 || vector.iter().any(|v| !v.as_f64().is_some_and(f64::is_finite)) {
        return Err(format!("element {element_index} {label} must contain three finite numbers"));
    }
    Ok(())
}

fn resolve_texture_value(
    value: &str,
    textures: &BTreeMap<String, String>,
    stack: &mut Vec<String>,
) -> std::result::Result<String, String> {
    if let Some(alias) = value.strip_prefix('#') {
        if alias.is_empty() {
            return Err("empty texture alias".to_owned());
        }
        if stack.iter().any(|key| key == alias) {
            let mut cycle = stack.clone();
            cycle.push(alias.to_owned());
            return Err(format!("texture alias cycle: {}", cycle.join(" -> ")));
        }
        let target = textures
            .get(alias)
            .ok_or_else(|| format!("unbound texture alias #{alias}"))?;
        stack.push(alias.to_owned());
        let result = resolve_texture_value(target, textures, stack);
        stack.pop();
        result
    } else if value.is_empty() || value.starts_with('/') || value.contains('\\') {
        Err(format!("invalid texture resource ID {value:?}"))
    } else {
        Ok(value.to_owned())
    }
}

fn texture_resource_path(resource_id: &str) -> Option<String> {
    let location = match resource_id.split_once(':') {
        Some(("minecraft", location)) => location,
        Some((_other_namespace, _location)) => return None,
        None => resource_id,
    };
    if location.is_empty() || location.starts_with('/') || location.contains('\\') {
        return None;
    }
    let clean = location.strip_suffix(".png").unwrap_or(location);
    if clean
        .split('/')
        .any(|part| part.is_empty() || part == "." || part == "..")
    {
        return None;
    }
    Some(format!("{ASSET_PREFIX}textures/{clean}.png"))
}


fn collect_string_values_for_key(value: &Value, wanted_key: &str, out: &mut Vec<String>) {
    match value {
        Value::Object(object) => {
            for (key, child) in object {
                if key == wanted_key {
                    if let Some(text) = child.as_str() {
                        out.push(text.to_owned());
                    }
                }
                collect_string_values_for_key(child, wanted_key, out);
            }
        }
        Value::Array(items) => {
            for child in items {
                collect_string_values_for_key(child, wanted_key, out);
            }
        }
        _ => {}
    }
}

fn resolve_resource_id(
    resource_id: &str,
    default_dir: &str,
    resource_group: &str,
    extension: &str,
) -> Option<String> {
    let location = match resource_id.split_once(':') {
        Some(("minecraft", location)) => location,
        Some((_other_namespace, _location)) => return None,
        None => resource_id,
    };
    if location.is_empty() || location.starts_with('/') || location.contains('\\') {
        return None;
    }
    let clean = location.strip_suffix(extension).unwrap_or(location);
    if clean
        .split('/')
        .any(|part| part.is_empty() || part == "." || part == "..")
    {
        return None;
    }
    let relative = if clean.contains('/') || default_dir.is_empty() {
        clean.to_owned()
    } else {
        format!("{default_dir}/{clean}")
    };
    Some(format!("{ASSET_PREFIX}{resource_group}/{relative}{extension}"))
}

fn model_parent_directory(model_path: &str) -> Option<&str> {
    let relative = model_path.strip_prefix(MODEL_PREFIX)?;
    relative.rsplit_once('/').map(|(directory, _)| directory)
}

fn has_external_namespace(resource_id: &str) -> bool {
    resource_id
        .split_once(':')
        .is_some_and(|(namespace, _)| namespace != "minecraft")
}

fn is_builtin_model(parent_id: &str) -> bool {
    matches!(parent_id.split_once(':'), Some(("minecraft", rest)) if rest.starts_with("builtin/"))
        || parent_id.starts_with("builtin/")
}

fn push_diagnostic(items: &mut Vec<String>, diagnostic: String) {
    if items.len() < MAX_DIAGNOSTICS {
        items.push(diagnostic);
    }
}

fn print_diagnostics(title: &str, diagnostics: &[String]) {
    if diagnostics.is_empty() {
        return;
    }
    println!("  {title} (first {} shown):", diagnostics.len());
    for diagnostic in diagnostics {
        println!("    - {diagnostic}");
    }
}


// --- CPU-side model geometry compilation ----------------------------------------------------
// This is intentionally a geometry preparation step, not a renderer. It creates quads for the
// unique models referenced by blockstates, preserving texture paths, raw UV rectangles, UV
// quarter-turns, tint and cull-face metadata. Blockstate X/Y transforms and uvlock are applied
// by a later blockstate-instance stage, after the legacy ID/metadata mapping has selected a model.

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ModelFaceDirection {
    Down,
    Up,
    North,
    South,
    West,
    East,
}

impl ModelFaceDirection {
    fn parse(value: &str) -> Option<Self> {
        match value {
            "down" => Some(Self::Down),
            "up" => Some(Self::Up),
            "north" => Some(Self::North),
            "south" => Some(Self::South),
            "west" => Some(Self::West),
            "east" => Some(Self::East),
            _ => None,
        }
    }

    pub fn name(self) -> &'static str {
        match self {
            Self::Down => "down",
            Self::Up => "up",
            Self::North => "north",
            Self::South => "south",
            Self::West => "west",
            Self::East => "east",
        }
    }
}

#[derive(Clone, Debug)]
pub struct CpuMeshQuad {
    // Coordinates are normalized to one block (model JSON coordinate / 16).
    pub positions: [[f32; 3]; 4],
    /// Owning world block cell for chunk geometry; None for standalone item/model previews.
    /// This lets a just-mined block be removed from the current GPU mesh immediately,
    /// without waiting for a full neighbor-aware chunk rebuild.
    pub source_block: Option<[i32; 3]>,
    // Keep UV coordinates in model-pixel units (0..16 by convention); the texture atlas stage
    // will normalize them against the selected sprite rectangle and apply the quarter-turn.
    pub uv_rect: [f32; 4],
    pub uv_rotation: u16,
    /// Optional per-corner UVs in sprite pixel coordinates (used by vanilla fluid flow mapping).
    pub uv_corners: Option<[[f32; 2]; 4]>,
    pub texture_path: String,
    pub face: ModelFaceDirection,
    pub cull_face: Option<ModelFaceDirection>,
    pub tint_index: i32,
    /// Per-instance biome tint in linear RGB; white means no tint.
    pub tint_color: [f32; 3],
    pub shade: bool,
    /// Model-level ambientocclusion flag, inherited through model parents.
    pub ambient_occlusion: bool,
    pub normal: [f32; 3],
    /// Per-corner values produced by the 1.8.9 BlockModelRenderer AO kernel.
    /// AO, skylight and block light remain independent until fragment shading.
    pub vertex_ao: [f32; 4],
    pub vertex_sky_light: [f32; 4],
    pub vertex_block_light: [f32; 4],
    pub vertex_face_shade: [f32; 4],
}

fn json_vec3(value: Option<&Value>, label: &str) -> std::result::Result<[f64; 3], String> {
    let array = value
        .and_then(Value::as_array)
        .ok_or_else(|| format!("{label} must be an array of three finite numbers"))?;
    if array.len() != 3 {
        return Err(format!("{label} must have exactly three components"));
    }
    let mut result = [0.0; 3];
    for (index, value) in array.iter().enumerate() {
        let number = value
            .as_f64()
            .filter(|number| number.is_finite())
            .ok_or_else(|| format!("{label}[{index}] must be a finite number"))?;
        result[index] = number;
    }
    Ok(result)
}

fn default_face_uv(
    face: ModelFaceDirection,
    from: [f64; 3],
    to: [f64; 3],
) -> [f64; 4] {
    match face {
        ModelFaceDirection::Down => [from[0], 16.0 - to[2], to[0], 16.0 - from[2]],
        ModelFaceDirection::Up => [from[0], from[2], to[0], to[2]],
        ModelFaceDirection::North => [16.0 - to[0], 16.0 - to[1], 16.0 - from[0], 16.0 - from[1]],
        ModelFaceDirection::South => [from[0], 16.0 - to[1], to[0], 16.0 - from[1]],
        ModelFaceDirection::West => [from[2], 16.0 - to[1], to[2], 16.0 - from[1]],
        ModelFaceDirection::East => [16.0 - to[2], 16.0 - to[1], 16.0 - from[2], 16.0 - from[1]],
    }
}

fn read_uv_rect(
    face_obj: &serde_json::Map<String, Value>,
    direction: ModelFaceDirection,
    from: [f64; 3],
    to: [f64; 3],
    element_index: usize,
) -> std::result::Result<[f32; 4], String> {
    let values: [f64; 4] = if let Some(value) = face_obj.get("uv") {
        let array = value
            .as_array()
            .ok_or_else(|| format!("element {element_index} face {} UV must be an array", direction.name()))?;
        if array.len() != 4 {
            return Err(format!("element {element_index} face {} UV must have four values", direction.name()));
        }
        let mut out = [0.0; 4];
        for (index, item) in array.iter().enumerate() {
            out[index] = item.as_f64().filter(|number| number.is_finite())
                .ok_or_else(|| format!("element {element_index} face {} UV[{index}] must be finite", direction.name()))?;
        }
        out
    } else {
        default_face_uv(direction, from, to)
    };
    Ok(values.map(|value| value as f32))
}

fn apply_element_rotation(
    point: [f64; 3],
    rotation_value: Option<&Value>,
    element_index: usize,
) -> std::result::Result<[f64; 3], String> {
    let Some(value) = rotation_value else { return Ok(point); };
    let object = value.as_object().ok_or_else(|| format!("element {element_index} rotation must be an object"))?;
    let origin = json_vec3(object.get("origin"), "element rotation origin")?;
    let axis = object.get("axis").and_then(Value::as_str)
        .ok_or_else(|| format!("element {element_index} rotation axis must be x, y or z"))?;
    if !matches!(axis, "x" | "y" | "z") {
        return Err(format!("element {element_index} has unsupported rotation axis {axis:?}"));
    }
    let angle = object.get("angle").and_then(Value::as_f64)
        .filter(|number| number.is_finite())
        .ok_or_else(|| format!("element {element_index} rotation angle must be finite"))?;
    let allowed = [-45.0, -22.5, 0.0, 22.5, 45.0];
    if !allowed.iter().any(|allowed| (angle - *allowed).abs() < 1e-6) {
        return Err(format!("element {element_index} rotation angle {angle} is not supported by the classic model format"));
    }
    let rescale = object.get("rescale").and_then(Value::as_bool).unwrap_or(false);
    let radians = angle.to_radians();
    let sin = radians.sin();
    let cos = radians.cos();
    let mut relative = [point[0] - origin[0], point[1] - origin[1], point[2] - origin[2]];
    if rescale && angle != 0.0 {
        let factor = 1.0 / cos;
        match axis {
            "x" => { relative[1] *= factor; relative[2] *= factor; }
            "y" => { relative[0] *= factor; relative[2] *= factor; }
            "z" => { relative[0] *= factor; relative[1] *= factor; }
            _ => unreachable!(),
        }
    }
    let rotated = match axis {
        "x" => [relative[0], relative[1] * cos - relative[2] * sin, relative[1] * sin + relative[2] * cos],
        "y" => [relative[0] * cos + relative[2] * sin, relative[1], -relative[0] * sin + relative[2] * cos],
        "z" => [relative[0] * cos - relative[1] * sin, relative[0] * sin + relative[1] * cos, relative[2]],
        _ => unreachable!(),
    };
    Ok([rotated[0] + origin[0], rotated[1] + origin[1], rotated[2] + origin[2]])
}

fn face_corners(
    face: ModelFaceDirection,
    from: [f64; 3],
    to: [f64; 3],
) -> [[f64; 3]; 4] {
    let [x0, y0, z0] = from;
    let [x1, y1, z1] = to;
    // Counter-clockwise when viewed from outside, using the classic model axes X east, Y up,
    // Z south. The renderer stage may change winding when it chooses its front-face convention.
    match face {
        ModelFaceDirection::Down => [[x0,y0,z1],[x0,y0,z0],[x1,y0,z0],[x1,y0,z1]],
        ModelFaceDirection::Up => [[x0,y1,z0],[x0,y1,z1],[x1,y1,z1],[x1,y1,z0]],
        ModelFaceDirection::North => [[x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0]],
        ModelFaceDirection::South => [[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]],
        ModelFaceDirection::West => [[x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0]],
        ModelFaceDirection::East => [[x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1]],
    }
}

fn quad_normal(positions: [[f32; 3]; 4]) -> [f32; 3] {
    let a = [positions[1][0] - positions[0][0], positions[1][1] - positions[0][1], positions[1][2] - positions[0][2]];
    let b = [positions[2][0] - positions[0][0], positions[2][1] - positions[0][1], positions[2][2] - positions[0][2]];
    let cross = [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
    let length = (cross[0] * cross[0] + cross[1] * cross[1] + cross[2] * cross[2]).sqrt();
    if length <= f32::EPSILON { [0.0, 0.0, 0.0] } else { [cross[0] / length, cross[1] / length, cross[2] / length] }
}

fn compile_element_quads(
    element: &Value,
    element_index: usize,
    textures: &BTreeMap<String, String>,
    archive_names: &HashSet<String>,
) -> std::result::Result<Vec<CpuMeshQuad>, String> {
    let object = element.as_object().ok_or_else(|| format!("element {element_index} must be an object"))?;
    let from = json_vec3(object.get("from"), "element from")?;
    let to = json_vec3(object.get("to"), "element to")?;
    // Preserve directed endpoint order. Vanilla 1.8.x assets intentionally reverse one
    // coordinate in some crossed-plane models (for example fire_nsew); rejecting or sorting
    // these endpoints changes the meaning of their specified face and its winding/UV mapping.
    let rotation = object.get("rotation");
    // Validate rotation once even if the element has no visible faces.
    if let Some(rotation) = rotation {
        let _ = apply_element_rotation([0.0, 0.0, 0.0], Some(rotation), element_index)?;
    }
    let shade = object.get("shade").and_then(Value::as_bool).unwrap_or(true);
    let faces = object.get("faces").and_then(Value::as_object)
        .ok_or_else(|| format!("element {element_index} faces must be an object"))?;
    let mut quads = Vec::with_capacity(faces.len());
    for (direction_name, face_value) in faces {
        let direction = ModelFaceDirection::parse(direction_name)
            .ok_or_else(|| format!("element {element_index} has unknown face direction {direction_name:?}"))?;
        let face = face_value.as_object().ok_or_else(|| format!("element {element_index} face {direction_name} must be an object"))?;
        let raw_texture = face.get("texture").and_then(Value::as_str)
            .ok_or_else(|| format!("element {element_index} face {direction_name} lacks a texture"))?;
        let mut alias_stack = Vec::new();
        let resolved_texture = resolve_texture_value(raw_texture, textures, &mut alias_stack)
            .map_err(|error| format!("element {element_index} face {direction_name}: {error}"))?;
        let texture_path = texture_resource_path(&resolved_texture)
            .ok_or_else(|| format!("element {element_index} face {direction_name}: invalid texture resource {resolved_texture:?}"))?;
        if !archive_names.contains(&texture_path) {
            return Err(format!("element {element_index} face {direction_name}: missing texture {texture_path}"));
        }
        let uv_rect = read_uv_rect(face, direction, from, to, element_index)?;
        let uv_rotation_degrees = match face.get("rotation") {
            None => 0,
            Some(value) => value.as_u64().ok_or_else(|| {
                format!("element {element_index} face {direction_name}: UV rotation must be an integer")
            })?,
        };
        if !matches!(uv_rotation_degrees, 0 | 90 | 180 | 270) {
            return Err(format!(
                "element {element_index} face {direction_name}: invalid UV rotation {uv_rotation_degrees}"
            ));
        }
        // Convert only after validating against the four legal quarter-turns; u16 represents 270.
        let uv_rotation = uv_rotation_degrees as u16;
        let cull_face = match face.get("cullface").and_then(Value::as_str) {
            None => None,
            Some(text) => Some(ModelFaceDirection::parse(text).ok_or_else(|| format!("element {element_index} face {direction_name}: invalid cullface {text:?}"))?),
        };
        let tint_index = face.get("tintindex").and_then(Value::as_i64).unwrap_or(-1);
        let model_positions = face_corners(direction, from, to);
        let mut positions = [[0.0_f32; 3]; 4];
        for (vertex_index, point) in model_positions.iter().enumerate() {
            let transformed = apply_element_rotation(*point, rotation, element_index)?;
            positions[vertex_index] = [(transformed[0] / 16.0) as f32, (transformed[1] / 16.0) as f32, (transformed[2] / 16.0) as f32];
        }
        let normal = quad_normal(positions);
        quads.push(CpuMeshQuad { positions, source_block: None, uv_rect, uv_rotation, uv_corners: None, texture_path, face: direction, cull_face, tint_index: tint_index as i32, tint_color: [1.0, 1.0, 1.0], shade, ambient_occlusion: true, normal, vertex_ao: [1.0; 4], vertex_sky_light: [1.0; 4], vertex_block_light: [1.0; 4], vertex_face_shade: [1.0; 4] });
    }
    Ok(quads)
}

/// A JAR-backed model catalog. Model JSON and archive paths are indexed once per
/// chunk build; inherited models and compiled quads are cached by canonical resource path.
pub struct ModelCatalog {
    models: HashMap<String, Value>,
    archive_names: HashSet<String>,
    effective_cache: HashMap<String, EffectiveModel>,
    quad_cache: HashMap<String, Arc<Vec<CpuMeshQuad>>>,
}

impl ModelCatalog {
    pub fn load(jar_path: &Path) -> Result<Self> {
        if !jar_path.is_file() {
            return Err(Mc189Error::Usage(format!("client JAR is not a file: {}", jar_path.display())));
        }
        let file = File::open(jar_path)?;
        let mut archive = ZipArchive::new(file).map_err(|error| Mc189Error::InvalidData(
            format!("could not open {} as a ZIP/JAR archive: {error}", jar_path.display())
        ))?;
        let mut archive_names = HashSet::<String>::with_capacity(archive.len());
        for index in 0..archive.len() {
            let entry = archive.by_index(index).map_err(|error| Mc189Error::InvalidData(
                format!("could not read JAR entry {index}: {error}")
            ))?;
            if !entry.is_dir() { archive_names.insert(entry.name().to_owned()); }
        }
        let mut model_paths: Vec<String> = archive_names.iter()
            .filter(|name| name.starts_with(MODEL_PREFIX) && name.ends_with(".json"))
            .cloned().collect();
        model_paths.sort();
        let mut models = HashMap::<String, Value>::with_capacity(model_paths.len());
        for path in model_paths {
            if let Ok(value) = read_json_entry(&mut archive, &path) {
                if value.is_object() { models.insert(path, value); }
            }
        }
        Ok(Self { models, archive_names, effective_cache: HashMap::new(), quad_cache: HashMap::new() })
    }

    /// Resolve an item display transform using the same model-parent inheritance
    /// as ItemCameraTransforms in 1.8.9. The transform name is one of the JSON
    /// display keys (for example `firstperson` or `ground`). Missing transforms
    /// inherit from the parent and ultimately use ItemTransformVec3f.DEFAULT.
    pub fn display_transform(&self, model_id: &str, transform_type: &str) -> ItemCameraTransform {
        let model_path = if model_id.starts_with(MODEL_PREFIX) && model_id.ends_with(".json") {
            model_id.to_owned()
        } else {
            let id = model_id.strip_prefix("minecraft:").unwrap_or(model_id);
            format!("{MODEL_PREFIX}{}.json", id.trim_start_matches("/"))
        };
        resolve_display_transform(&model_path, transform_type, &self.models, &mut HashSet::new())
            .unwrap_or_default()
    }

    /// ItemCameraTransforms.TransformType.FIRST_PERSON.
    pub fn first_person_transform(&self, model_id: &str) -> ItemCameraTransform {
        self.display_transform(model_id, "firstperson")
    }

    /// ItemCameraTransforms.TransformType.GROUND, used by RenderEntityItem.
    pub fn ground_transform(&self, model_id: &str) -> ItemCameraTransform {
        self.display_transform(model_id, "ground")
    }

    pub fn load_model_quads(&mut self, model_id: &str) -> Result<(String, Arc<Vec<CpuMeshQuad>>)> {
        let model_path = resolve_resource_id(model_id, "block", "models", ".json")
            .ok_or_else(|| Mc189Error::Usage(format!("invalid vanilla model resource ID: {model_id:?}")))?;
        if let Some(cached) = self.quad_cache.get(&model_path) {
            return Ok((model_path, Arc::clone(cached)));
        }
        let effective = build_effective_model(&model_path, &self.models, &mut self.effective_cache, &mut Vec::new())
            .map_err(|error| Mc189Error::InvalidData(format!("cannot resolve model {model_id}: {error}")))?;
        let elements = effective.elements.as_ref().ok_or_else(|| Mc189Error::InvalidData(
            format!("model {model_id} has no cuboid elements; generated/builtin models are outside this preview")
        ))?;
        let mut quads = Vec::new();
        for (index, element) in elements.iter().enumerate() {
            let mut compiled = compile_element_quads(element, index, &effective.textures, &self.archive_names)
                .map_err(|error| Mc189Error::InvalidData(format!("model {model_id}: {error}")))?;
            for quad in &mut compiled {
                quad.ambient_occlusion = effective.ambient_occlusion.unwrap_or(true);
            }
            quads.append(&mut compiled);
        }
        if quads.is_empty() {
            return Err(Mc189Error::InvalidData(format!("model {model_id} produced no renderable faces")));
        }
        let quads = Arc::new(quads);
        self.quad_cache.insert(model_path.clone(), Arc::clone(&quads));
        Ok((model_path, quads))
    }
}

fn resolve_display_transform(
    model_path: &str,
    transform_type: &str,
    models: &HashMap<String, Value>,
    visiting: &mut HashSet<String>,
) -> Option<ItemCameraTransform> {
    if !visiting.insert(model_path.to_owned()) { return None; }
    let model = models.get(model_path)?;
    if let Some(transform) = model.get("display").and_then(|value| value.get(transform_type)) {
        let parse_vec3 = |key: &str, default: [f32; 3]| -> [f32; 3] {
            let Some(values) = transform.get(key).and_then(Value::as_array) else { return default; };
            if values.len() != 3 { return default; }
            let mut result = default;
            for i in 0..3 {
                let Some(value) = values[i].as_f64() else { return default; };
                result[i] = value as f32;
            }
            result
        };
        let rotation = parse_vec3("rotation", [0.0; 3]);
        let raw_translation = parse_vec3("translation", [0.0; 3]);
        // ItemTransformVec3f.Deserializer multiplies translation by 1/16 and
        // constrains each resulting component to [-1.5, 1.5].
        let translation = raw_translation.map(|value| (value / 16.0).clamp(-1.5, 1.5));
        let scale = parse_vec3("scale", [1.0; 3]);
        visiting.remove(model_path);
        return Some(ItemCameraTransform { rotation, translation, scale });
    }
    let result = model.get("parent").and_then(Value::as_str).and_then(|raw_parent| {
        let parent = raw_parent.strip_prefix("minecraft:").unwrap_or(raw_parent);
        if parent.starts_with("builtin/") { return None; }
        resolve_display_transform(&format!("{MODEL_PREFIX}{parent}.json"), transform_type, models, visiting)
    });
    visiting.remove(model_path);
    result
}

/// Convenience single-model API retained for the existing preview command.
pub fn load_model_quads(jar_path: &Path, model_id: &str) -> Result<(String, Vec<CpuMeshQuad>)> {
    let mut catalog = ModelCatalog::load(jar_path)?;
    let (path, quads) = catalog.load_model_quads(model_id)?;
    Ok((path, quads.as_ref().clone()))
}

/// Convert effective vanilla block models into CPU-side quads without writing files or GPU data.
/// Legacy numeric block ID/metadata selection and blockstate X/Y/uvlock transforms remain separate.
pub fn compile_client_geometry(jar_path: &Path) -> Result<()> {
    if !jar_path.is_file() {
        return Err(Mc189Error::Usage(format!("client JAR is not a file: {}", jar_path.display())));
    }
    let file = File::open(jar_path)?;
    let mut archive = ZipArchive::new(file).map_err(|error| Mc189Error::InvalidData(format!("could not open {} as a ZIP/JAR archive: {error}", jar_path.display())))?;
    let mut names = HashSet::<String>::with_capacity(archive.len());
    for index in 0..archive.len() {
        let entry = archive.by_index(index).map_err(|error| Mc189Error::InvalidData(format!("could not read JAR entry {index}: {error}")))?;
        if !entry.is_dir() { names.insert(entry.name().to_owned()); }
    }

    let mut blockstate_paths: Vec<String> = names.iter()
        .filter(|name| name.starts_with("assets/minecraft/blockstates/") && name.ends_with(".json"))
        .cloned().collect();
    blockstate_paths.sort();
    let mut concrete_paths = BTreeSet::<String>::new();
    let mut blockstate_errors = 0_usize;
    for blockstate_path in &blockstate_paths {
        match read_json_entry(&mut archive, blockstate_path) {
            Ok(value) if value.is_object() => {
                let mut refs = Vec::new();
                collect_string_values_for_key(&value, "model", &mut refs);
                for id in refs {
                    if has_external_namespace(&id) { continue; }
                    if let Some(path) = resolve_resource_id(&id, "block", "models", ".json") {
                        concrete_paths.insert(path);
                    } else { blockstate_errors += 1; }
                }
            }
            _ => blockstate_errors += 1,
        }
    }

    let mut model_paths: Vec<String> = names.iter()
        .filter(|name| name.starts_with(MODEL_PREFIX) && name.ends_with(".json"))
        .cloned().collect();
    model_paths.sort();
    let mut models: HashMap<String, Value> = HashMap::with_capacity(model_paths.len());
    let mut invalid_models = 0_usize;
    for path in &model_paths {
        match read_json_entry(&mut archive, path) {
            Ok(value) if value.is_object() => { models.insert(path.clone(), value); }
            _ => invalid_models += 1,
        }
    }

    let mut cache: HashMap<String, EffectiveModel> = HashMap::new();
    let mut model_failures = 0_usize;
    let mut compiled_roots = 0_usize;
    let mut roots_without_elements = 0_usize;
    let mut element_total = 0_u64;
    let mut quad_total = 0_u64;
    let mut texture_set = BTreeSet::new();
    let mut tint_face_total = 0_u64;
    let mut cull_face_total = 0_u64;
    let mut rotated_element_total = 0_u64;
    let mut rescaled_element_total = 0_u64;
    let mut diagnostics = Vec::new();

    for path in &concrete_paths {
        let effective = match build_effective_model(path, &models, &mut cache, &mut Vec::new()) {
            Ok(model) => model,
            Err(error) => {
                model_failures += 1;
                push_diagnostic(&mut diagnostics, format!("{path}: {error}"));
                continue;
            }
        };
        let Some(elements) = effective.elements.as_ref() else {
            roots_without_elements += 1;
            compiled_roots += 1;
            continue;
        };
        let mut root_quads = Vec::new();
        let mut root_failed = None;
        for (element_index, element) in elements.iter().enumerate() {
            if element.get("rotation").is_some() {
                rotated_element_total += 1;
                if element.get("rotation").and_then(Value::as_object).and_then(|obj| obj.get("rescale")).and_then(Value::as_bool) == Some(true) {
                    rescaled_element_total += 1;
                }
            }
            match compile_element_quads(element, element_index, &effective.textures, &names) {
                Ok(mut quads) => root_quads.append(&mut quads),
                Err(error) => { root_failed = Some(error); break; }
            }
        }
        if let Some(error) = root_failed {
            model_failures += 1;
            push_diagnostic(&mut diagnostics, format!("{path}: {error}"));
            continue;
        }
        element_total += elements.len() as u64;
        quad_total += root_quads.len() as u64;
        for quad in &root_quads {
            texture_set.insert(quad.texture_path.clone());
            if quad.tint_index >= 0 { tint_face_total += 1; }
            if quad.cull_face.is_some() { cull_face_total += 1; }
            // Read these fields explicitly to keep this stage's compiled data fully checked and
            // make sure geometry generation doesn't silently drop attributes needed downstream.
            let _preserved = (quad.positions, quad.uv_rect, quad.uv_rotation, quad.face, quad.shade, quad.normal);
        }
        compiled_roots += 1;
    }

    println!("Minecraft 1.8.9 CPU model-geometry compilation (read-only)");
    println!("File: {}", jar_path.display());
    println!("Blockstate JSON files examined: {}", blockstate_paths.len());
    println!("Unique model roots referenced: {}", concrete_paths.len());
    println!("Malformed blockstates / invalid model IDs: {blockstate_errors}");
    println!("Model JSON files parsed: {} / {}", models.len(), model_paths.len());
    println!("Invalid model JSON/root objects: {invalid_models}");
    println!("Effective model roots compiled: {compiled_roots} / {}", concrete_paths.len());
    println!("Roots without element geometry (allowed templates/empty models): {roots_without_elements}");
    println!("Element definitions compiled: {element_total}");
    println!("CPU quads compiled: {quad_total}");
    println!("Triangle count if each quad is split consistently: {}", quad_total * 2);
    println!("Vertex count before deduplication: {}", quad_total * 4);
    println!("Unique resolved texture files referenced: {}", texture_set.len());
    println!("Faces preserving cullface metadata: {cull_face_total}");
    println!("Faces preserving tintindex metadata: {tint_face_total}");
    println!("Elements with local rotation: {rotated_element_total}");
    println!("Elements with rescale enabled: {rescaled_element_total}");
    print_diagnostics("Geometry compilation diagnostics", &diagnostics);
    let passed = blockstate_errors == 0 && invalid_models == 0 && model_failures == 0 && compiled_roots == concrete_paths.len();
    println!();
    println!("CPU model geometry compilation: {}", if passed { "PASS" } else { "REVIEW REQUIRED" });
    println!("Scope note: the compiled quads preserve raw UV rectangles and face attributes, and apply local element rotations. Legacy block ID/metadata selection, blockstate X/Y rotations, uvlock, atlas stitching, neighbour-face culling, lighting, GPU buffers and window rendering are not implemented yet.");
    println!("The JAR was not extracted or modified.");
    Ok(())
}

#[cfg(test)]

mod tests {
    use super::*;

    #[test]
    fn ground_display_transform_inherits_parent_and_uses_vanilla_units() {
        let mut models = HashMap::new();
        models.insert("assets/minecraft/models/item/base_generated.json".to_owned(), serde_json::json!({
            "display": { "ground": { "rotation": [0, 90, 0], "translation": [0, 2, 0], "scale": [0.5, 0.75, 0.5] } }
        }));
        models.insert("assets/minecraft/models/item/diamond_test.json".to_owned(), serde_json::json!({
            "parent": "item/base_generated"
        }));
        let transform = resolve_display_transform(
            "assets/minecraft/models/item/diamond_test.json", "ground", &models, &mut HashSet::new()
        ).unwrap();
        assert_eq!(transform.rotation, [0.0, 90.0, 0.0]);
        assert_eq!(transform.translation, [0.0, 0.125, 0.0]);
        assert_eq!(transform.scale, [0.5, 0.75, 0.5]);
    }

    #[test]
    fn absent_ground_display_transform_uses_vanilla_default() {
        let mut models = HashMap::new();
        models.insert("assets/minecraft/models/item/generated_test.json".to_owned(), serde_json::json!({
            "parent": "builtin/generated"
        }));
        assert_eq!(resolve_display_transform(
            "assets/minecraft/models/item/generated_test.json", "ground", &models, &mut HashSet::new()
        ).unwrap_or_default(), ItemCameraTransform::default());
    }

    #[test]
    fn default_uv_rectangles_follow_classic_face_direction_rules() {
        let from = [0.0, 0.0, 0.0];
        let to = [16.0, 16.0, 16.0];
        assert_eq!(default_face_uv(ModelFaceDirection::Up, from, to), [0.0, 0.0, 16.0, 16.0]);
        assert_eq!(default_face_uv(ModelFaceDirection::Down, from, to), [0.0, 0.0, 16.0, 16.0]);
        assert_eq!(default_face_uv(ModelFaceDirection::North, from, to), [0.0, 0.0, 16.0, 16.0]);
    }

    #[test]
    fn vanilla_crossed_plant_opposite_faces_share_a_plane_with_opposite_diagonals() {
        let element = serde_json::json!({
            "from": [0.8, 0, 8],
            "to": [15.2, 16, 8],
            "rotation": { "origin": [8, 8, 8], "axis": "y", "angle": 45, "rescale": true },
            "shade": false,
            "faces": {
                "north": { "uv": [0, 0, 16, 16], "texture": "#cross", "tintindex": 0 },
                "south": { "uv": [0, 0, 16, 16], "texture": "#cross", "tintindex": 0 }
            }
        });
        let mut textures = BTreeMap::new();
        textures.insert("cross".to_owned(), "blocks/tallgrass".to_owned());
        let names = HashSet::from([
            "assets/minecraft/textures/blocks/tallgrass.png".to_owned()
        ]);
        let quads = compile_element_quads(&element, 0, &textures, &names).unwrap();
        assert_eq!(quads.len(), 2);
        let north = quads.iter().find(|quad| quad.face == ModelFaceDirection::North).unwrap();
        let south = quads.iter().find(|quad| quad.face == ModelFaceDirection::South).unwrap();
        for point in north.positions {
            assert!(south.positions.iter().any(|other| {
                (point[0] - other[0]).abs() < 1e-6
                    && (point[1] - other[1]).abs() < 1e-6
                    && (point[2] - other[2]).abs() < 1e-6
            }));
        }
        for axis in 0..3 {
            assert!((north.normal[axis] + south.normal[axis]).abs() < 1e-5);
        }
        // The opposing face definitions use different first-to-third diagonals.
        assert_ne!(north.positions[0], south.positions[0]);
        assert_ne!(north.positions[2], south.positions[2]);
    }

    #[test]
    fn a_full_cube_model_compiles_to_six_outward_quads() {
        let element = serde_json::json!({
            "from": [0, 0, 0], "to": [16, 16, 16],
            "faces": {
                "down": {"texture": "#all"}, "up": {"texture": "#all"},
                "north": {"texture": "#all"}, "south": {"texture": "#all"},
                "west": {"texture": "#all"}, "east": {"texture": "#all"}
            }
        });
        let mut textures = BTreeMap::new();
        textures.insert("all".to_owned(), "blocks/stone".to_owned());
        let names = HashSet::from(["assets/minecraft/textures/blocks/stone.png".to_owned()]);
        let quads = compile_element_quads(&element, 0, &textures, &names).unwrap();
        assert_eq!(quads.len(), 6);
        assert!(quads.iter().all(|quad| quad.positions.iter().all(|p| p.iter().all(|v| v.is_finite()))));
        assert!(quads.iter().all(|quad| quad.texture_path == "assets/minecraft/textures/blocks/stone.png"));
        let mut normals: Vec<[f32; 3]> = quads.iter().map(|quad| quad.normal).collect();
        normals.sort_by(|a, b| a[0].total_cmp(&b[0]).then(a[1].total_cmp(&b[1])).then(a[2].total_cmp(&b[2])));
        assert_eq!(normals, vec![[-1.0,0.0,0.0], [0.0,-1.0,0.0], [0.0,0.0,-1.0], [0.0,0.0,1.0], [0.0,1.0,0.0], [1.0,0.0,0.0]]);
    }

    #[test]
    fn vanilla_fire_style_reversed_extent_is_compiled_without_normalizing_endpoints() {
        // The vanilla 1.8.x fire_nsew model includes this kind of directed X extent.
        // The only specified face is west, so preserve its authored position and winding.
        let element = serde_json::json!({
            "from": [15.99, 1, 0], "to": [0.01, 23.4, 16],
            "faces": {"west": {"texture": "#fire", "uv": [0, 0, 16, 16]}}
        });
        let mut textures = BTreeMap::new();
        textures.insert("fire".to_owned(), "blocks/fire_layer_0".to_owned());
        let names = HashSet::from([
            "assets/minecraft/textures/blocks/fire_layer_0.png".to_owned()
        ]);
        let quads = compile_element_quads(&element, 7, &textures, &names).unwrap();
        assert_eq!(quads.len(), 1);
        assert_eq!(quads[0].face, ModelFaceDirection::West);
        // Compiled positions are normalized from the 0..16 model-unit space to 0..1 block units.
        assert!((quads[0].positions[0][0] - (15.99_f32 / 16.0)).abs() < 1e-5);
        assert_eq!(quads[0].normal, [-1.0, 0.0, 0.0]);
    }

    #[test]
    fn face_uv_rotation_is_preserved_as_a_quarter_turn() {
        let element = serde_json::json!({
            "from": [0, 0, 0], "to": [16, 16, 16],
            "faces": {"north": {"texture": "#all", "uv": [1, 2, 9, 10], "rotation": 270}}
        });
        let mut textures = BTreeMap::new();
        textures.insert("all".to_owned(), "blocks/stone".to_owned());
        let names = HashSet::from(["assets/minecraft/textures/blocks/stone.png".to_owned()]);
        let quads = compile_element_quads(&element, 0, &textures, &names).unwrap();
        assert_eq!(quads[0].uv_rect, [1.0, 2.0, 9.0, 10.0]);
        assert_eq!(quads[0].uv_rotation, 270);
    }

    #[test]
    fn invalid_face_uv_rotation_is_rejected_instead_of_defaulted() {
        for invalid_rotation in [
            serde_json::json!(45),
            serde_json::json!(-90),
            serde_json::json!(90.5),
            serde_json::json!("90"),
        ] {
            let element = serde_json::json!({
                "from": [0, 0, 0], "to": [16, 16, 16],
                "faces": {"north": {"texture": "#all", "rotation": invalid_rotation}}
            });
            let mut textures = BTreeMap::new();
            textures.insert("all".to_owned(), "blocks/stone".to_owned());
            let names = HashSet::from(["assets/minecraft/textures/blocks/stone.png".to_owned()]);
            assert!(compile_element_quads(&element, 0, &textures, &names).is_err());
        }
    }

    #[test]
    fn element_rotation_keeps_its_origin_fixed() {
        let rotation = serde_json::json!({"origin": [8,8,8], "axis": "y", "angle": 22.5, "rescale": false});
        let point = apply_element_rotation([8.0, 8.0, 8.0], Some(&rotation), 0).unwrap();
        assert!((point[0] - 8.0).abs() < 1e-9);
        assert!((point[1] - 8.0).abs() < 1e-9);
        assert!((point[2] - 8.0).abs() < 1e-9);
    }

    #[test]
    fn model_geometry_rejects_missing_texture_files() {
        let element = serde_json::json!({
            "from": [0, 0, 0], "to": [16, 16, 16],
            "faces": {"north": {"texture": "#all"}}
        });
        let mut textures = BTreeMap::new();
        textures.insert("all".to_owned(), "blocks/not_real".to_owned());
        assert!(compile_element_quads(&element, 0, &textures, &HashSet::new()).unwrap_err().contains("missing texture"));
    }

    #[test]
    fn texture_aliases_resolve_through_inherited_bindings() {
        let mut textures = BTreeMap::new();
        textures.insert("all".to_owned(), "blocks/stone".to_owned());
        textures.insert("side".to_owned(), "#all".to_owned());
        textures.insert("particle".to_owned(), "#side".to_owned());
        let mut stack = Vec::new();
        assert_eq!(
            resolve_texture_value("#particle", &textures, &mut stack).unwrap(),
            "blocks/stone"
        );
    }

    #[test]
    fn texture_alias_cycles_are_reported() {
        let mut textures = BTreeMap::new();
        textures.insert("a".to_owned(), "#b".to_owned());
        textures.insert("b".to_owned(), "#a".to_owned());
        let mut stack = Vec::new();
        assert!(resolve_texture_value("#a", &textures, &mut stack)
            .unwrap_err()
            .contains("cycle"));
    }

    #[test]
    fn unbound_texture_alias_is_rejected() {
        let textures = BTreeMap::new();
        let mut stack = Vec::new();
        assert!(resolve_texture_value("#missing", &textures, &mut stack)
            .unwrap_err()
            .contains("unbound"));
    }

    #[test]
    fn texture_paths_stay_inside_the_minecraft_asset_namespace() {
        assert_eq!(
            texture_resource_path("blocks/stone").as_deref(),
            Some("assets/minecraft/textures/blocks/stone.png")
        );
        assert!(texture_resource_path("../secret").is_none());
        assert!(texture_resource_path("other:blocks/stone").is_none());
    }

    #[test]
    fn vec3_requires_three_finite_numbers() {
        assert!(validate_vec3(
            Some(&serde_json::json!([0, 8, 16])),
            "from",
            0
        )
        .is_ok());
        assert!(validate_vec3(
            Some(&serde_json::json!([0, 8])),
            "from",
            0
        )
        .is_err());
    }

    #[test]
    fn inherited_model_textures_and_elements_are_merged_with_child_overrides() {
        let parent_path = "assets/minecraft/models/block/parent.json".to_owned();
        let child_path = "assets/minecraft/models/block/child.json".to_owned();
        let mut models = HashMap::new();
        models.insert(
            parent_path.clone(),
            serde_json::json!({
                "textures": { "all": "blocks/stone", "particle": "#all" },
                "ambientocclusion": false,
                "elements": [{
                    "from": [0, 0, 0], "to": [16, 16, 16],
                    "faces": { "north": { "texture": "#all" } }
                }]
            }),
        );
        models.insert(
            child_path.clone(),
            serde_json::json!({
                "parent": "parent",
                "textures": { "all": "blocks/dirt" }
            }),
        );
        let mut cache = HashMap::new();
        let effective = build_effective_model(&child_path, &models, &mut cache, &mut Vec::new()).unwrap();
        assert_eq!(effective.textures.get("all").map(String::as_str), Some("blocks/dirt"));
        assert_eq!(effective.textures.get("particle").map(String::as_str), Some("#all"));
        let mut alias_stack = Vec::new();
        assert_eq!(
            resolve_texture_value("#particle", &effective.textures, &mut alias_stack).unwrap(),
            "blocks/dirt"
        );
        assert_eq!(effective.elements.as_ref().map(Vec::len), Some(1));
        assert_eq!(effective.ambient_occlusion, Some(false));
    }

    #[test]
    fn parent_cycles_are_rejected() {
        let a = "assets/minecraft/models/block/a.json".to_owned();
        let b = "assets/minecraft/models/block/b.json".to_owned();
        let mut models = HashMap::new();
        models.insert(a.clone(), serde_json::json!({ "parent": "b" }));
        models.insert(b.clone(), serde_json::json!({ "parent": "a" }));
        assert!(build_effective_model(&a, &models, &mut HashMap::new(), &mut Vec::new())
            .unwrap_err()
            .contains("cycle"));
    }

    #[test]
    fn model_resource_ids_resolve_relative_to_model_directory() {
        assert_eq!(
            resolve_resource_id("parent", "block", "models", ".json").as_deref(),
            Some("assets/minecraft/models/block/parent.json")
        );
        assert_eq!(
            resolve_resource_id("block/cube_all", "item", "models", ".json").as_deref(),
            Some("assets/minecraft/models/block/cube_all.json")
        );
    }

    #[test]
    fn element_faces_and_aliases_are_counted() {
        let elements = vec![serde_json::json!({
            "from": [0, 0, 0], "to": [16, 16, 16],
            "faces": {
                "north": { "texture": "#all", "uv": [0, 0, 16, 16] },
                "up": { "texture": "#all", "rotation": 90 }
            }
        })];
        let mut textures = BTreeMap::new();
        textures.insert("all".to_owned(), "blocks/stone".to_owned());
        assert_eq!(inspect_elements(&elements, &textures, true).unwrap(), (2, 2, Vec::new()));
    }
    #[test]
    fn ambient_occlusion_setting_inherits_and_child_can_disable_it() {
        let parent_path = "assets/minecraft/models/block/ao_parent.json".to_owned();
        let child_path = "assets/minecraft/models/block/ao_child.json".to_owned();
        let override_path = "assets/minecraft/models/block/ao_override.json".to_owned();
        let mut models = HashMap::new();
        models.insert(parent_path, serde_json::json!({ "ambientocclusion": false }));
        models.insert(child_path.clone(), serde_json::json!({ "parent": "ao_parent" }));
        models.insert(override_path.clone(), serde_json::json!({ "parent": "ao_parent", "ambientocclusion": true }));
        let inherited = build_effective_model(&child_path, &models, &mut HashMap::new(), &mut Vec::new()).unwrap();
        let overridden = build_effective_model(&override_path, &models, &mut HashMap::new(), &mut Vec::new()).unwrap();
        assert_eq!(inherited.ambient_occlusion, Some(false));
        assert_eq!(overridden.ambient_occlusion, Some(true));
    }

}
