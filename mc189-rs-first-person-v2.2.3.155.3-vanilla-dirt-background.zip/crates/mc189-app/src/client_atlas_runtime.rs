//! Runtime atlas manifest lookup, model-face UV remapping, and wgpu texture upload.
//! Animated fluid sprites are retained as frame strips and uploaded by the runtime frame scheduler.
use mc189_core::{Mc189Error, Result};
use serde::Deserialize;
use std::{collections::HashMap, fs, path::{Path, PathBuf}};

#[derive(Clone, Debug, Deserialize)]
struct Manifest {
    format: String,
    page_size: u32,
    padding: u32,
    page_count: u32,
    static_texture_count: usize,
    animated_texture_count: usize,
    entries: Vec<Entry>,
    animated: Vec<String>,
}

#[derive(Clone, Debug, Deserialize)]
struct Entry {
    path: String,
    page: u32,
    x: u32,
    y: u32,
    width: u32,
    height: u32,
    u0: f64,
    v0: f64,
    u1: f64,
    v1: f64,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct AtlasRegion {
    pub page: u32,
    pub pixel_rect: [u32; 4],
    pub uv_rect: [f32; 4],
}

#[derive(Clone, Debug)]
pub struct AtlasRuntime {
    root: PathBuf,
    page_size: u32,
    padding: u32,
    page_count: u32,
    entries: HashMap<String, AtlasRegion>,
    animated: Vec<String>,
}

impl AtlasRuntime {
    /// Loads and validates the rasterized atlas manifest. Paths are canonical atlas-relative names,
    /// such as `blocks/stone.png`; callers may also pass `minecraft:blocks/stone`.
    pub fn load(output_dir: &Path) -> Result<Self> {
        let manifest_path = output_dir.join("block-atlas-manifest.json");
        let bytes = fs::read(&manifest_path)?;
        let manifest: Manifest = serde_json::from_slice(&bytes).map_err(|error| {
            Mc189Error::InvalidData(format!("invalid atlas manifest {}: {error}", manifest_path.display()))
        })?;
        if manifest.format != "mc189-atlas-layout-v1" || manifest.page_size == 0
            || manifest.padding != 2 || manifest.static_texture_count != manifest.entries.len()
            || manifest.animated_texture_count != manifest.animated.len()
            || manifest.page_count == 0 && !manifest.entries.is_empty()
        {
            return Err(Mc189Error::InvalidData("unsupported or inconsistent atlas manifest".into()));
        }
        let mut entries = HashMap::with_capacity(manifest.entries.len());
        for entry in manifest.entries {
            if entry.path.starts_with('/') || entry.path.contains("..") || !entry.path.starts_with("blocks/")
                || entry.page >= manifest.page_count || entry.width == 0 || entry.height == 0
                || entry.x < manifest.padding || entry.y < manifest.padding
                || entry.x.checked_add(entry.width).and_then(|v| v.checked_add(manifest.padding)).map_or(true, |v| v > manifest.page_size)
                || entry.y.checked_add(entry.height).and_then(|v| v.checked_add(manifest.padding)).map_or(true, |v| v > manifest.page_size)
            {
                return Err(Mc189Error::InvalidData(format!("invalid atlas entry {}", entry.path)));
            }
            let expected = [
                entry.x as f64 / manifest.page_size as f64,
                entry.y as f64 / manifest.page_size as f64,
                (entry.x + entry.width) as f64 / manifest.page_size as f64,
                (entry.y + entry.height) as f64 / manifest.page_size as f64,
            ];
            let actual = [entry.u0, entry.v0, entry.u1, entry.v1];
            if expected.iter().zip(actual).any(|(a,b)| !b.is_finite() || (a-b).abs() > 1e-12) {
                return Err(Mc189Error::InvalidData(format!("UV/pixel mismatch for {}", entry.path)));
            }
            let region = AtlasRegion {
                page: entry.page,
                pixel_rect: [entry.x, entry.y, entry.width, entry.height],
                uv_rect: [entry.u0 as f32, entry.v0 as f32, entry.u1 as f32, entry.v1 as f32],
            };
            if entries.insert(entry.path.clone(), region).is_some() {
                return Err(Mc189Error::InvalidData(format!("duplicate atlas path {}", entry.path)));
            }
        }
        let runtime = Self { root: output_dir.to_path_buf(), page_size: manifest.page_size,
            padding: manifest.padding, page_count: manifest.page_count, entries, animated: manifest.animated };
        for page in 0..runtime.page_count {
            let path = runtime.page_path(page);
            if !path.is_file() {
                return Err(Mc189Error::InvalidData(format!("missing atlas page {}", path.display())));
            }
            let image = image::open(&path).map_err(|e| Mc189Error::InvalidData(format!("cannot decode atlas page {}: {e}", path.display())))?;
            if image.width() != runtime.page_size || image.height() != runtime.page_size {
                return Err(Mc189Error::InvalidData(format!("atlas page {} has dimensions {}x{}, expected {}x{}", path.display(), image.width(), image.height(), runtime.page_size, runtime.page_size)));
            }
        }
        Ok(runtime)
    }

    pub fn page_path(&self, page: u32) -> PathBuf { self.root.join(format!("block-atlas-{page}.png")) }
    pub fn page_size(&self) -> u32 { self.page_size }
    pub fn page_count(&self) -> u32 { self.page_count }
    pub fn padding(&self) -> u32 { self.padding }
    pub fn static_texture_count(&self) -> usize { self.entries.len() }
    pub fn animated_textures(&self) -> &[String] { &self.animated }

    pub fn lookup(&self, resource: &str) -> Option<AtlasRegion> {
        let normalized = resource.strip_prefix("minecraft:").unwrap_or(resource);
        let path = if normalized.starts_with("textures/") {
            normalized.strip_prefix("textures/").unwrap_or(normalized)
        } else { normalized };
        let path = if path.ends_with(".png") { path.to_owned() } else { format!("{path}.png") };
        if let Some(region) = self.entries.get(&path).copied() {
            return Some(region);
        }
        // The legacy dark-oak log blockstate/model name and the 1.8.9
        // texture-pack sprite name differ: the model may request log_dark_oak,
        // while the vanilla atlas stores the actual sprite as log_big_oak.
        // Keep this compatibility alias at lookup time so UVs still point at
        // the original Mojang texture and no duplicate/modified texture is made.
        // Animated sprites are stored outside the static atlas. Blocks that do not
        // yet have a live animation renderer still need a valid static preview; for
        // example, sea_lantern.png is a 16x80 five-frame strip in the 1.8.9 JAR.
        let frame_zero_alias = path.strip_suffix(".png").map(|stem| format!("{stem}_frame0.png"));
        if let Some(alias) = frame_zero_alias {
            if let Some(region) = self.entries.get(&alias).copied() {
                return Some(region);
            }
        }
        // The legacy dark-oak log blockstate/model name and the 1.8.9
        // texture-pack sprite name differ: the model may request log_dark_oak,
        // while the vanilla atlas stores the actual sprite as log_big_oak.
        let vanilla_legacy_alias = match path.as_str() {
            "blocks/log_dark_oak.png" => "blocks/log_big_oak.png",
            "blocks/log_dark_oak_top.png" => "blocks/log_big_oak_top.png",
            _ => return None,
        };
        self.entries.get(vanilla_legacy_alias).copied()
    }

    /// Remaps a Minecraft model face UV rectangle (pixel coordinates) into atlas UVs.
    /// Rotation is kept as the model's clockwise quarter-turn and is intentionally not baked
    /// into the rectangle; the mesh builder applies it to the four corner UVs.
    pub fn remap_face_uv(&self, resource: &str, uv: [f32; 4], rotation_degrees: u16) -> Result<([f32; 4], u16)> {
        if !matches!(rotation_degrees, 0 | 90 | 180 | 270) || uv.iter().any(|v| !v.is_finite()) {
            return Err(Mc189Error::InvalidData("invalid face UV rectangle or rotation".into()));
        }
        let region = self.lookup(resource).ok_or_else(|| Mc189Error::InvalidData(format!("texture not present in static atlas: {resource}")))?;
        let [u0,v0,u1,v1] = region.uv_rect;
        let [x0,y0,x1,y1] = uv;
        let width = u1-u0; let height = v1-v0;
        let mapped = [u0 + (x0/16.0)*width, v0 + (y0/16.0)*height,
                      u0 + (x1/16.0)*width, v0 + (y1/16.0)*height];
        Ok((mapped, rotation_degrees))
    }
}

/// GPU-resident atlas page. Uses nearest filtering to preserve the crisp pixel-art appearance.
pub struct GpuAtlasPage {
    pub texture: wgpu::Texture,
    pub view: wgpu::TextureView,
    pub sampler: wgpu::Sampler,
    pub bind_group_layout: wgpu::BindGroupLayout,
    pub bind_group: wgpu::BindGroup,
}

impl GpuAtlasPage {
    pub fn upload(device: &wgpu::Device, queue: &wgpu::Queue, path: &Path, expected_size: u32) -> Result<Self> {
        let rgba = image::open(path).map_err(|e| Mc189Error::InvalidData(format!("cannot decode {}: {e}", path.display())))?.to_rgba8();
        if rgba.width() != expected_size || rgba.height() != expected_size {
            return Err(Mc189Error::InvalidData(format!("atlas page dimensions are {}x{}, expected {}x{}", rgba.width(), rgba.height(), expected_size, expected_size)));
        }
        // The atlas has a two-texel extruded gutter around every sprite. One
        // mip level is therefore safe: the gutter becomes one texel at 1/2
        // resolution. We deliberately stop here; deeper global-atlas mips would
        // collapse that gutter and blend unrelated neighboring block textures.
        let mip_width = (rgba.width() / 2).max(1);
        let mip_height = (rgba.height() / 2).max(1);
        let mip_rgba = image::imageops::resize(
            &rgba, mip_width, mip_height, image::imageops::FilterType::Triangle,
        );
        let texture = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("Minecraft 1.8.9 block texture atlas with safe mip level"),
            size: wgpu::Extent3d { width: rgba.width(), height: rgba.height(), depth_or_array_layers: 1 },
            mip_level_count: 2, sample_count: 1, dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::Rgba8UnormSrgb,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        });
        queue.write_texture(wgpu::ImageCopyTexture { texture: &texture, mip_level: 0, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
            rgba.as_raw(), wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(4 * rgba.width()), rows_per_image: Some(rgba.height()) },
            wgpu::Extent3d { width: rgba.width(), height: rgba.height(), depth_or_array_layers: 1 });
        queue.write_texture(wgpu::ImageCopyTexture { texture: &texture, mip_level: 1, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
            mip_rgba.as_raw(), wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(4 * mip_width), rows_per_image: Some(mip_height) },
            wgpu::Extent3d { width: mip_width, height: mip_height, depth_or_array_layers: 1 });
        let view = texture.create_view(&wgpu::TextureViewDescriptor::default());
        let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("block atlas mipmapped sampler"), address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge, address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Nearest, min_filter: wgpu::FilterMode::Linear,
            mipmap_filter: wgpu::FilterMode::Linear, ..Default::default()
        });
        let bind_group_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("block atlas texture layout"), entries: &[
                wgpu::BindGroupLayoutEntry { binding: 0, visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: true }, view_dimension: wgpu::TextureViewDimension::D2, multisampled: false }, count: None },
                wgpu::BindGroupLayoutEntry { binding: 1, visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering), count: None },
            ]
        });
        let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor { label: Some("block atlas texture bind group"), layout: &bind_group_layout, entries: &[
            wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&view) },
            wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&sampler) },
        ]});
        Ok(Self { texture, view, sampler, bind_group_layout, bind_group })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn atlas_uv_mapping_preserves_face_rotation_and_scales_model_pixels() {
        let runtime = AtlasRuntime { root: PathBuf::new(), page_size: 2048, padding: 2, page_count: 1,
            entries: HashMap::from([("blocks/stone.png".into(), AtlasRegion { page: 0, pixel_rect: [100,200,16,16], uv_rect: [100.0/2048.0,200.0/2048.0,116.0/2048.0,216.0/2048.0] })]), animated: vec![] };
        let (uv, rotation) = runtime.remap_face_uv("minecraft:blocks/stone", [0.0,0.0,16.0,16.0], 90).unwrap();
        assert_eq!(rotation, 90);
        assert!((uv[0] - 100.0/2048.0).abs() < 1e-7);
        assert!((uv[1] - 200.0/2048.0).abs() < 1e-7);
        assert!((uv[2] - 116.0/2048.0).abs() < 1e-7);
        assert!((uv[3] - 216.0/2048.0).abs() < 1e-7);
    }
    #[test]
    fn lookup_accepts_namespaced_and_texture_prefixed_paths() {
        let runtime = AtlasRuntime { root: PathBuf::new(), page_size: 2048, padding: 2, page_count: 1,
            entries: HashMap::from([("blocks/dirt.png".into(), AtlasRegion { page: 0, pixel_rect: [4,4,16,16], uv_rect: [0.0,0.0,1.0,1.0] })]), animated: vec![] };
        assert!(runtime.lookup("minecraft:blocks/dirt").is_some());
        assert!(runtime.lookup("textures/blocks/dirt.png").is_some());
    }

    #[test]
    fn dark_oak_legacy_texture_names_resolve_to_vanilla_189_big_oak_sprites() {
        let side = AtlasRegion { page: 0, pixel_rect: [8, 8, 16, 16], uv_rect: [0.0, 0.0, 0.5, 0.5] };
        let top = AtlasRegion { page: 0, pixel_rect: [24, 8, 16, 16], uv_rect: [0.5, 0.0, 1.0, 0.5] };
        let runtime = AtlasRuntime { root: PathBuf::new(), page_size: 2048, padding: 2, page_count: 1,
            entries: HashMap::from([
                ("blocks/log_big_oak.png".into(), side),
                ("blocks/log_big_oak_top.png".into(), top),
            ]), animated: vec![] };
        assert_eq!(runtime.lookup("blocks/log_dark_oak.png"), Some(side));
        assert_eq!(runtime.lookup("blocks/log_dark_oak_top.png"), Some(top));
    }
    #[test]
    fn animated_sea_lantern_base_name_resolves_to_static_frame_zero() {
        let runtime = AtlasRuntime { root: PathBuf::new(), page_size: 2048, padding: 2, page_count: 1,
            entries: HashMap::from([("blocks/sea_lantern_frame0.png".into(), AtlasRegion { page: 0, pixel_rect: [200,300,16,16], uv_rect: [200.0/2048.0,300.0/2048.0,216.0/2048.0,316.0/2048.0] })]), animated: vec!["blocks/sea_lantern.png".into()] };
        assert_eq!(runtime.lookup("blocks/sea_lantern.png"), runtime.lookup("blocks/sea_lantern_frame0.png"));
        assert!(runtime.remap_face_uv("blocks/sea_lantern.png", [0.0,0.0,16.0,16.0], 0).is_ok());
    }

}
