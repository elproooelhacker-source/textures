//! Native wgpu preview that uploads and displays the rasterized block atlas.
use crate::client_atlas_runtime::{AtlasRuntime, GpuAtlasPage};
use mc189_core::{Mc189Error, Result};
use std::path::Path;
use std::sync::Arc;
use winit::dpi::PhysicalSize;
use winit::event::{Event, WindowEvent};
use winit::event_loop::{ControlFlow, EventLoop};
use winit::window::{Window, WindowBuilder};

struct AtlasViewer {
    surface: wgpu::Surface<'static>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,
    pipeline: wgpu::RenderPipeline,
    atlas: GpuAtlasPage,
}

impl AtlasViewer {
    async fn new(window: Arc<Window>, atlas_dir: &Path, runtime: &AtlasRuntime) -> Result<Self> {
        let instance = wgpu::Instance::default();
        let surface = instance.create_surface(window.clone()).map_err(|error| {
            Mc189Error::InvalidData(format!("cannot create atlas preview surface: {error}"))
        })?;
        let adapter = instance.request_adapter(&wgpu::RequestAdapterOptions {
            power_preference: wgpu::PowerPreference::HighPerformance,
            compatible_surface: Some(&surface),
            force_fallback_adapter: false,
        }).await.ok_or_else(|| Mc189Error::InvalidData(
            "no compatible GPU adapter found for atlas preview".to_owned()
        ))?;
        let (device, queue) = adapter.request_device(&wgpu::DeviceDescriptor {
            label: Some("mc189-rs atlas preview device"),
            required_features: wgpu::Features::empty(),
            required_limits: wgpu::Limits::downlevel_defaults(),
        }, None).await.map_err(|error| Mc189Error::InvalidData(
            format!("cannot create atlas preview GPU device: {error}")
        ))?;

        let atlas_path = atlas_dir.join("block-atlas-0.png");
        let atlas = GpuAtlasPage::upload(&device, &queue, &atlas_path, runtime.page_size())?;
        let capabilities = surface.get_capabilities(&adapter);
        let format = capabilities.formats.iter().copied().find(wgpu::TextureFormat::is_srgb)
            .or_else(|| capabilities.formats.first().copied())
            .ok_or_else(|| Mc189Error::InvalidData("GPU surface reports no formats".to_owned()))?;
        let present_mode = capabilities.present_modes.iter().copied()
            .find(|mode| *mode == wgpu::PresentMode::Fifo)
            .or_else(|| capabilities.present_modes.first().copied())
            .ok_or_else(|| Mc189Error::InvalidData("GPU surface reports no present modes".to_owned()))?;
        let alpha_mode = capabilities.alpha_modes.first().copied()
            .ok_or_else(|| Mc189Error::InvalidData("GPU surface reports no alpha modes".to_owned()))?;
        let size = window.inner_size();
        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format,
            width: size.width.max(1),
            height: size.height.max(1),
            present_mode,
            desired_maximum_frame_latency: 2,
            alpha_mode,
            view_formats: vec![],
        };
        surface.configure(&device, &config);

        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("block atlas fullscreen display shader"),
            source: wgpu::ShaderSource::Wgsl(ATLAS_SHADER.into()),
        });
        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("block atlas preview pipeline layout"),
            bind_group_layouts: &[&atlas.bind_group_layout],
            push_constant_ranges: &[],
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("block atlas display pipeline"),
            layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState { module: &shader, entry_point: "vs_main", buffers: &[] },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: "fs_main",
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::REPLACE),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw,
                cull_mode: None,
                polygon_mode: wgpu::PolygonMode::Fill,
                unclipped_depth: false,
                conservative: false,
            },
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
        });
        Ok(Self { surface, device, queue, config, pipeline, atlas })
    }

    fn resize(&mut self, width: u32, height: u32) {
        if width == 0 || height == 0 { return; }
        self.config.width = width;
        self.config.height = height;
        self.surface.configure(&self.device, &self.config);
    }

    fn render(&mut self) -> std::result::Result<(), wgpu::SurfaceError> {
        let frame = self.surface.get_current_texture()?;
        let view = frame.texture.create_view(&wgpu::TextureViewDescriptor::default());
        let mut encoder = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("block atlas preview encoder"),
        });
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("block atlas preview pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color { r: 0.08, g: 0.08, b: 0.08, a: 1.0 }),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: None,
                occlusion_query_set: None,
                timestamp_writes: None,
            });
            pass.set_pipeline(&self.pipeline);
            pass.set_bind_group(0, &self.atlas.bind_group, &[]);
            pass.draw(0..3, 0..1);
        }
        self.queue.submit(Some(encoder.finish()));
        frame.present();
        Ok(())
    }
}

/// Opens a window and displays atlas page zero after a real wgpu texture upload.
pub fn run(atlas_dir: &Path) -> Result<()> {
    let runtime = AtlasRuntime::load(atlas_dir)?;
    println!("Minecraft 1.8.9 block atlas GPU preview");
    println!("Atlas: {}", atlas_dir.display());
    println!("Page 0: {}x{} RGBA8", runtime.page_size(), runtime.page_size());
    println!("Static entries: {}", runtime.static_texture_count());
    println!("Animated textures: {} (not included in this static atlas preview)", runtime.animated_textures().len());
    println!("GPU upload: page 0 uploaded using wgpu; nearest filtering enabled");
    println!("Controls: close the window or press Esc");

    let event_loop = EventLoop::new().map_err(|error| Mc189Error::InvalidData(
        format!("cannot create atlas preview event loop: {error}")
    ))?;
    event_loop.set_control_flow(ControlFlow::Wait);
    let window = Arc::new(WindowBuilder::new()
        .with_title("mc189-rs — Minecraft 1.8.9 block atlas")
        .with_inner_size(PhysicalSize::new(1024, 1024))
        .build(&event_loop)
        .map_err(|error| Mc189Error::InvalidData(format!("cannot create atlas preview window: {error}")))?);
    let mut viewer = pollster::block_on(AtlasViewer::new(window.clone(), atlas_dir, &runtime))?;
    window.request_redraw();
    event_loop.run(move |event, event_loop| {
        match event {
            Event::WindowEvent { window_id, event } if window_id == window.id() => match event {
                WindowEvent::CloseRequested => event_loop.exit(),
                WindowEvent::Resized(size) => {
                    viewer.resize(size.width, size.height);
                    window.request_redraw();
                }
                WindowEvent::RedrawRequested => match viewer.render() {
                    Ok(()) => {}
                    Err(wgpu::SurfaceError::Lost | wgpu::SurfaceError::Outdated) => {
                        let width = viewer.config.width;
                        let height = viewer.config.height;
                        viewer.resize(width, height);
                    }
                    Err(wgpu::SurfaceError::Timeout) => eprintln!("GPU surface timed out; skipped one atlas frame"),
                    Err(wgpu::SurfaceError::OutOfMemory) => {
                        eprintln!("GPU ran out of memory; closing atlas preview");
                        event_loop.exit();
                    }
                },
                WindowEvent::KeyboardInput { event, .. }
                    if event.state == winit::event::ElementState::Pressed
                        && event.physical_key == winit::keyboard::PhysicalKey::Code(winit::keyboard::KeyCode::Escape) => event_loop.exit(),
                _ => {}
            },
            _ => {}
        }
    }).map_err(|error| Mc189Error::InvalidData(format!("atlas preview event loop failed: {error}")))?;
    Ok(())
}

const ATLAS_SHADER: &str = r#"
struct VertexOutput {
    @builtin(position) position: vec4<f32>,
    @location(0) uv: vec2<f32>,
};
@group(0) @binding(0) var atlas_texture: texture_2d<f32>;
@group(0) @binding(1) var atlas_sampler: sampler;

@vertex
fn vs_main(@builtin(vertex_index) index: u32) -> VertexOutput {
    var positions = array<vec2<f32>, 3>(
        vec2<f32>(-1.0, -1.0),
        vec2<f32>( 3.0, -1.0),
        vec2<f32>(-1.0,  3.0)
    );
    var uvs = array<vec2<f32>, 3>(
        vec2<f32>(0.0, 1.0),
        vec2<f32>(2.0, 1.0),
        vec2<f32>(0.0, -1.0)
    );
    var output: VertexOutput;
    output.position = vec4<f32>(positions[index], 0.0, 1.0);
    output.uv = uvs[index];
    return output;
}

@fragment
fn fs_main(input: VertexOutput) -> @location(0) vec4<f32> {
    return textureSample(atlas_texture, atlas_sampler, input.uv);
}
"#;
