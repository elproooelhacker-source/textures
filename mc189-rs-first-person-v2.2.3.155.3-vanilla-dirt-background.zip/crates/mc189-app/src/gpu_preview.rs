//! Native wgpu preview for the diagnostic OBJ exported by `chunk_mesh`.
//!
//! This is a validation viewer only: it displays the mesh geometry in a solid neutral
//! material. It does not yet load Minecraft textures, fluid meshes, or special block models.

use glam::{Mat4, Vec3};
use mc189_core::{Mc189Error, Result};
use std::fs;
use std::mem::size_of;
use std::path::Path;
use std::sync::Arc;
use wgpu::util::DeviceExt;
use winit::dpi::PhysicalSize;
use winit::event::{ElementState, Event, MouseButton, MouseScrollDelta, WindowEvent};
use winit::event_loop::{ControlFlow, EventLoop};
use winit::keyboard::{KeyCode, PhysicalKey};
use winit::window::{Window, WindowBuilder};

const MAX_OBJ_BYTES: u64 = 512 * 1024 * 1024;

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct Vertex {
    position: [f32; 3],
    normal: [f32; 3],
}

impl Vertex {
    const ATTRIBUTES: [wgpu::VertexAttribute; 2] =
        wgpu::vertex_attr_array![0 => Float32x3, 1 => Float32x3];

    fn layout() -> wgpu::VertexBufferLayout<'static> {
        wgpu::VertexBufferLayout {
            array_stride: size_of::<Self>() as wgpu::BufferAddress,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &Self::ATTRIBUTES,
        }
    }
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct CameraUniform {
    view_projection: [[f32; 4]; 4],
}

struct ObjMesh {
    vertices: Vec<Vertex>,
    min: Vec3,
    max: Vec3,
    triangles: usize,
}

fn parse_obj_index(raw: &str, available: usize, line_number: usize) -> Result<usize> {
    let index = raw.parse::<i64>().map_err(|_| {
        Mc189Error::InvalidData(format!("OBJ line {line_number}: invalid face index {raw:?}"))
    })?;
    if index == 0 {
        return Err(Mc189Error::InvalidData(format!(
            "OBJ line {line_number}: OBJ indices are 1-based; index zero is invalid"
        )));
    }
    let resolved = if index > 0 {
        index - 1
    } else {
        available as i64 + index
    };
    if resolved < 0 || resolved >= available as i64 {
        return Err(Mc189Error::InvalidData(format!(
            "OBJ line {line_number}: vertex index {index} is outside the {available} vertices defined so far"
        )));
    }
    Ok(resolved as usize)
}

fn read_obj_mesh(path: &Path) -> Result<ObjMesh> {
    let metadata = fs::metadata(path)?;
    if metadata.len() > MAX_OBJ_BYTES {
        return Err(Mc189Error::InvalidData(format!(
            "OBJ is {} bytes; viewer limit is {} bytes",
            metadata.len(), MAX_OBJ_BYTES
        )));
    }
    let source = fs::read_to_string(path)?;
    let mut positions: Vec<Vec3> = Vec::new();
    let mut vertices: Vec<Vertex> = Vec::new();
    let mut min = Vec3::splat(f32::INFINITY);
    let mut max = Vec3::splat(f32::NEG_INFINITY);

    for (line_index, line) in source.lines().enumerate() {
        let line_number = line_index + 1;
        let mut parts = line.split_whitespace();
        let Some(kind) = parts.next() else { continue };
        match kind {
            "v" => {
                let coordinates: Vec<&str> = parts.collect();
                if coordinates.len() < 3 {
                    return Err(Mc189Error::InvalidData(format!(
                        "OBJ line {line_number}: vertex needs at least three coordinates"
                    )));
                }
                let mut xyz = [0.0_f32; 3];
                for axis in 0..3 {
                    xyz[axis] = coordinates[axis].parse::<f32>().map_err(|_| {
                        Mc189Error::InvalidData(format!(
                            "OBJ line {line_number}: invalid vertex coordinate {:?}",
                            coordinates[axis]
                        ))
                    })?;
                    if !xyz[axis].is_finite() {
                        return Err(Mc189Error::InvalidData(format!(
                            "OBJ line {line_number}: non-finite vertex coordinate"
                        )));
                    }
                }
                let point = Vec3::from_array(xyz);
                min = min.min(point);
                max = max.max(point);
                positions.push(point);
            }
            "f" => {
                let raw_indices: Vec<&str> = parts.collect();
                if raw_indices.len() < 3 {
                    return Err(Mc189Error::InvalidData(format!(
                        "OBJ line {line_number}: face needs at least three vertices"
                    )));
                }
                let mut face_indices = Vec::with_capacity(raw_indices.len());
                for raw in raw_indices {
                    let vertex_index = raw.split('/').next().unwrap_or("");
                    face_indices.push(parse_obj_index(vertex_index, positions.len(), line_number)?);
                }
                // Fan triangulation preserves the polygon's authored winding. Exported
                // diagnostic faces are convex quads, so this is deterministic for this input.
                for index in 1..face_indices.len() - 1 {
                    let points = [
                        positions[face_indices[0]],
                        positions[face_indices[index]],
                        positions[face_indices[index + 1]],
                    ];
                    let cross = (points[1] - points[0]).cross(points[2] - points[0]);
                    if cross.length_squared() <= 1.0e-12 {
                        return Err(Mc189Error::InvalidData(format!(
                            "OBJ line {line_number}: degenerate triangle in face"
                        )));
                    }
                    let normal = cross.normalize().to_array();
                    for point in points {
                        vertices.push(Vertex {
                            position: point.to_array(),
                            normal,
                        });
                    }
                }
            }
            _ => {
                // Comments, group names, object names, materials, normals and UV lines are
                // intentionally ignored. This viewer is for geometry validation only.
            }
        }
    }

    if positions.is_empty() || vertices.is_empty() {
        return Err(Mc189Error::InvalidData(format!(
            "{} contains no renderable vertices/faces",
            path.display()
        )));
    }
    Ok(ObjMesh {
        triangles: vertices.len() / 3,
        vertices,
        min,
        max,
    })
}

struct ViewerState {
    surface: wgpu::Surface<'static>,
    device: wgpu::Device,
    queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration,
    pipeline: wgpu::RenderPipeline,
    vertex_buffer: wgpu::Buffer,
    vertex_count: u32,
    camera_buffer: wgpu::Buffer,
    camera_bind_group: wgpu::BindGroup,
    _depth_texture: wgpu::Texture,
    depth_view: wgpu::TextureView,
    target: Vec3,
    radius: f32,
    yaw: f32,
    pitch: f32,
    zoom: f32,
}

impl ViewerState {
    async fn new(window: Arc<Window>, mesh: &ObjMesh) -> Result<Self> {
        if mesh.vertices.len() > u32::MAX as usize {
            return Err(Mc189Error::InvalidData(
                "OBJ has more vertices than the preview renderer can address".to_owned(),
            ));
        }
        let instance = wgpu::Instance::default();
        let surface = instance
            .create_surface(window.clone())
            .map_err(|error| Mc189Error::InvalidData(format!("cannot create window surface: {error}")))?;
        let adapter = instance
            .request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                compatible_surface: Some(&surface),
                force_fallback_adapter: false,
            })
            .await
            .ok_or_else(|| {
                Mc189Error::InvalidData(
                    "no compatible GPU adapter found; update graphics drivers or check GPU support".to_owned(),
                )
            })?;
        let (device, queue) = adapter
            .request_device(
                &wgpu::DeviceDescriptor {
                    label: Some("mc189-rs preview device"),
                    required_features: wgpu::Features::empty(),
                    required_limits: wgpu::Limits::downlevel_defaults(),
                },
                None,
            )
            .await
            .map_err(|error| Mc189Error::InvalidData(format!("cannot create GPU device: {error}")))?;

        let size = window.inner_size();
        let capabilities = surface.get_capabilities(&adapter);
        let format = capabilities
            .formats
            .iter()
            .copied()
            .find(wgpu::TextureFormat::is_srgb)
            .or_else(|| capabilities.formats.first().copied())
            .ok_or_else(|| Mc189Error::InvalidData("GPU surface reports no formats".to_owned()))?;
        let present_mode = capabilities
            .present_modes
            .iter()
            .copied()
            .find(|mode| *mode == wgpu::PresentMode::Fifo)
            .or_else(|| capabilities.present_modes.first().copied())
            .ok_or_else(|| Mc189Error::InvalidData("GPU surface reports no presentation modes".to_owned()))?;
        let alpha_mode = capabilities
            .alpha_modes
            .first()
            .copied()
            .ok_or_else(|| Mc189Error::InvalidData("GPU surface reports no alpha modes".to_owned()))?;
        let config = wgpu::SurfaceConfiguration {
            usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
            format,
            width: size.width.max(1),
            height: size.height.max(1),
            present_mode,
            desired_maximum_frame_latency: 2,
            alpha_mode,
            view_formats: vec![],
        };
        surface.configure(&device, &config);

        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("mc189-rs diagnostic preview shader"),
            source: wgpu::ShaderSource::Wgsl(SHADER.into()),
        });
        let camera_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("camera uniform layout"),
            entries: &[wgpu::BindGroupLayoutEntry {
                binding: 0,
                visibility: wgpu::ShaderStages::VERTEX,
                ty: wgpu::BindingType::Buffer {
                    ty: wgpu::BufferBindingType::Uniform,
                    has_dynamic_offset: false,
                    min_binding_size: None,
                },
                count: None,
            }],
        });
        let camera_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("camera uniform buffer"),
            contents: bytemuck::bytes_of(&CameraUniform {
                view_projection: Mat4::IDENTITY.to_cols_array_2d(),
            }),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });
        let camera_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("camera uniform bind group"),
            layout: &camera_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: camera_buffer.as_entire_binding(),
            }],
        });
        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("preview pipeline layout"),
            bind_group_layouts: &[&camera_layout],
            push_constant_ranges: &[],
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("diagnostic mesh pipeline"),
            layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: "vs_main",
                buffers: &[Vertex::layout()],
            },
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: "fs_main",
                targets: &[Some(wgpu::ColorTargetState {
                    format,
                    blend: Some(wgpu::BlendState::REPLACE),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
            }),
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw,
                cull_mode: None,
                polygon_mode: wgpu::PolygonMode::Fill,
                unclipped_depth: false,
                conservative: false,
            },
            depth_stencil: Some(wgpu::DepthStencilState {
                format: wgpu::TextureFormat::Depth32Float,
                depth_write_enabled: true,
                depth_compare: wgpu::CompareFunction::LessEqual,
                stencil: wgpu::StencilState::default(),
                bias: wgpu::DepthBiasState::default(),
            }),
            multisample: wgpu::MultisampleState::default(),
            multiview: None,
        });
        let vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("diagnostic mesh vertices"),
            contents: bytemuck::cast_slice(&mesh.vertices),
            usage: wgpu::BufferUsages::VERTEX,
        });
        let (depth_texture, depth_view) = create_depth_resources(&device, &config);
        let extent = mesh.max - mesh.min;
        let target = (mesh.max + mesh.min) * 0.5;
        let radius = (extent.length() * 0.5).max(1.0);
        let mut state = Self {
            surface,
            device,
            queue,
            config,
            pipeline,
            vertex_buffer,
            vertex_count: mesh.vertices.len() as u32,
            camera_buffer,
            camera_bind_group,
            _depth_texture: depth_texture,
            depth_view,
            target,
            radius,
            yaw: 0.72,
            pitch: 0.48,
            zoom: 2.8,
        };
        state.update_camera();
        Ok(state)
    }

    fn resize(&mut self, width: u32, height: u32) {
        if width == 0 || height == 0 {
            return;
        }
        self.config.width = width;
        self.config.height = height;
        self.surface.configure(&self.device, &self.config);
        let (texture, view) = create_depth_resources(&self.device, &self.config);
        self._depth_texture = texture;
        self.depth_view = view;
        self.update_camera();
    }

    fn update_camera(&mut self) {
        let horizontal = self.pitch.cos();
        let direction = Vec3::new(self.yaw.cos() * horizontal, self.pitch.sin(), self.yaw.sin() * horizontal);
        let eye = self.target + direction * (self.radius * self.zoom);
        let view = Mat4::look_at_rh(eye, self.target, Vec3::Y);
        let aspect = self.config.width.max(1) as f32 / self.config.height.max(1) as f32;
        let near = (self.radius * 0.002).max(0.01);
        let far = (self.radius * 24.0).max(100.0);
        let projection = Mat4::perspective_rh(45.0_f32.to_radians(), aspect, near, far);
        let uniform = CameraUniform {
            view_projection: (projection * view).to_cols_array_2d(),
        };
        self.queue.write_buffer(&self.camera_buffer, 0, bytemuck::bytes_of(&uniform));
    }

    fn orbit(&mut self, dx: f64, dy: f64) {
        self.yaw += (dx as f32) * 0.008;
        self.pitch = (self.pitch - (dy as f32) * 0.008).clamp(-1.45, 1.45);
        self.update_camera();
    }

    fn zoom_by(&mut self, amount: f32) {
        self.zoom = (self.zoom * (1.0 - amount * 0.08)).clamp(0.7, 12.0);
        self.update_camera();
    }

    fn reset_camera(&mut self) {
        self.yaw = 0.72;
        self.pitch = 0.48;
        self.zoom = 2.8;
        self.update_camera();
    }

    fn render(&mut self) -> std::result::Result<(), wgpu::SurfaceError> {
        let frame = self.surface.get_current_texture()?;
        let view = frame.texture.create_view(&wgpu::TextureViewDescriptor::default());
        let mut encoder = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor {
            label: Some("preview render encoder"),
        });
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("diagnostic mesh render pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view,
                    resolve_target: None,
                    ops: wgpu::Operations {
                        load: wgpu::LoadOp::Clear(wgpu::Color {
                            r: 0.055,
                            g: 0.075,
                            b: 0.105,
                            a: 1.0,
                        }),
                        store: wgpu::StoreOp::Store,
                    },
                })],
                depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                    view: &self.depth_view,
                    depth_ops: Some(wgpu::Operations {
                        load: wgpu::LoadOp::Clear(1.0),
                        store: wgpu::StoreOp::Store,
                    }),
                    stencil_ops: None,
                }),
                occlusion_query_set: None,
                timestamp_writes: None,
            });
            pass.set_pipeline(&self.pipeline);
            pass.set_bind_group(0, &self.camera_bind_group, &[]);
            pass.set_vertex_buffer(0, self.vertex_buffer.slice(..));
            pass.draw(0..self.vertex_count, 0..1);
        }
        self.queue.submit(Some(encoder.finish()));
        frame.present();
        Ok(())
    }
}

fn create_depth_resources(
    device: &wgpu::Device,
    config: &wgpu::SurfaceConfiguration,
) -> (wgpu::Texture, wgpu::TextureView) {
    let texture = device.create_texture(&wgpu::TextureDescriptor {
        label: Some("preview depth texture"),
        size: wgpu::Extent3d {
            width: config.width,
            height: config.height,
            depth_or_array_layers: 1,
        },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: wgpu::TextureFormat::Depth32Float,
        usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
        view_formats: &[],
    });
    let view = texture.create_view(&wgpu::TextureViewDescriptor::default());
    (texture, view)
}

/// Open a native preview window for a previously exported diagnostic OBJ mesh.
pub fn run(obj_path: &Path) -> Result<()> {
    if !obj_path.is_file() {
        return Err(Mc189Error::Usage(format!(
            "OBJ file does not exist: {}",
            obj_path.display()
        )));
    }
    let mesh = read_obj_mesh(obj_path)?;
    println!("Native wgpu diagnostic mesh preview");
    println!("OBJ: {}", obj_path.display());
    println!("Triangles: {}", mesh.triangles);
    println!("Vertices: {}", mesh.vertices.len());
    println!("Bounds min: {:?}", mesh.min.to_array());
    println!("Bounds max: {:?}", mesh.max.to_array());
    println!("Controls: left mouse drag = orbit, mouse wheel = zoom, R = reset camera, Esc = close");
    println!("Preview scope: untextured diagnostic geometry; this is not the finished Minecraft renderer.");

    let event_loop = EventLoop::new()
        .map_err(|error| Mc189Error::InvalidData(format!("cannot create window event loop: {error}")))?;
    event_loop.set_control_flow(ControlFlow::Wait);
    let window = Arc::new(
        WindowBuilder::new()
            .with_title("mc189-rs — diagnostic chunk preview (untextured)")
            .with_inner_size(PhysicalSize::new(1280, 800))
            .build(&event_loop)
            .map_err(|error| Mc189Error::InvalidData(format!("cannot create preview window: {error}")))?,
    );
    let mut state = pollster::block_on(ViewerState::new(window.clone(), &mesh))?;
    let mut dragging = false;
    let mut previous_cursor: Option<(f64, f64)> = None;
    window.request_redraw();

    event_loop
        .run(move |event, event_loop| {
            match event {
                Event::WindowEvent { window_id, event } if window_id == window.id() => match event {
                    WindowEvent::CloseRequested => event_loop.exit(),
                    WindowEvent::Resized(size) => {
                        state.resize(size.width, size.height);
                        window.request_redraw();
                    }
                    WindowEvent::RedrawRequested => match state.render() {
                        Ok(()) => {}
                        Err(wgpu::SurfaceError::Lost | wgpu::SurfaceError::Outdated) => {
                            let width = state.config.width;
                            let height = state.config.height;
                            state.resize(width, height);
                        }
                        Err(wgpu::SurfaceError::Timeout) => {
                            eprintln!("GPU surface timed out; skipped one preview frame");
                        }
                        Err(wgpu::SurfaceError::OutOfMemory) => {
                            eprintln!("GPU ran out of memory; closing preview");
                            event_loop.exit();
                        }
                    },
                    WindowEvent::MouseInput { state: button_state, button: MouseButton::Left, .. } => {
                        dragging = button_state == ElementState::Pressed;
                        previous_cursor = None;
                    }
                    WindowEvent::CursorMoved { position, .. } => {
                        let current = (position.x, position.y);
                        if dragging {
                            if let Some(previous) = previous_cursor {
                                state.orbit(current.0 - previous.0, current.1 - previous.1);
                                window.request_redraw();
                            }
                        }
                        previous_cursor = Some(current);
                    }
                    WindowEvent::MouseWheel { delta, .. } => {
                        let amount = match delta {
                            MouseScrollDelta::LineDelta(_, y) => y,
                            MouseScrollDelta::PixelDelta(position) => position.y as f32 / 40.0,
                        };
                        state.zoom_by(amount);
                        window.request_redraw();
                    }
                    WindowEvent::KeyboardInput { event, .. } if event.state == ElementState::Pressed => {
                        match event.physical_key {
                            PhysicalKey::Code(KeyCode::Escape) => event_loop.exit(),
                            PhysicalKey::Code(KeyCode::KeyR) => {
                                state.reset_camera();
                                window.request_redraw();
                            }
                            _ => {}
                        }
                    }
                    _ => {}
                },
                _ => {}
            }
        })
        .map_err(|error| Mc189Error::InvalidData(format!("preview event loop failed: {error}")))?;
    Ok(())
}

const SHADER: &str = r#"
struct Camera {
    view_projection: mat4x4<f32>,
};
@group(0) @binding(0) var<uniform> camera: Camera;

struct VertexInput {
    @location(0) position: vec3<f32>,
    @location(1) normal: vec3<f32>,
};
struct VertexOutput {
    @builtin(position) clip_position: vec4<f32>,
    @location(0) normal: vec3<f32>,
};

@vertex
fn vs_main(input: VertexInput) -> VertexOutput {
    var output: VertexOutput;
    output.clip_position = camera.view_projection * vec4<f32>(input.position, 1.0);
    output.normal = input.normal;
    return output;
}

@fragment
fn fs_main(input: VertexOutput) -> @location(0) vec4<f32> {
    let n = normalize(input.normal);
    let light_direction = normalize(vec3<f32>(0.35, 0.82, 0.44));
    let diffuse = max(dot(n, light_direction), 0.0);
    let illumination = 0.22 + 0.78 * diffuse;
    let base_color = vec3<f32>(0.62, 0.69, 0.78);
    return vec4<f32>(base_color * illumination, 1.0);
}
"#;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn obj_reader_triangulates_a_quad_and_preserves_outward_normal() {
        let obj = "v 0 0 0\nv 1 0 0\nv 1 1 0\nv 0 1 0\nf 1 2 3 4\n";
        let path = std::env::temp_dir().join(format!("mc189-obj-test-{}.obj", std::process::id()));
        fs::write(&path, obj).expect("write temporary test OBJ");
        let mesh = read_obj_mesh(&path).expect("parse test OBJ");
        let _ = fs::remove_file(&path);
        assert_eq!(mesh.triangles, 2);
        assert_eq!(mesh.vertices.len(), 6);
        for vertex in &mesh.vertices {
            assert!((vertex.normal[2] - 1.0).abs() < 1.0e-6);
        }
        assert_eq!(mesh.min, Vec3::new(0.0, 0.0, 0.0));
        assert_eq!(mesh.max, Vec3::new(1.0, 1.0, 0.0));
    }

    #[test]
    fn obj_reader_resolves_negative_vertex_indices() {
        let obj = "v 0 0 0\nv 1 0 0\nv 0 1 0\nf -3 -2 -1\n";
        let path = std::env::temp_dir().join(format!("mc189-obj-negative-test-{}.obj", std::process::id()));
        fs::write(&path, obj).expect("write temporary test OBJ");
        let mesh = read_obj_mesh(&path).expect("parse OBJ with negative indices");
        let _ = fs::remove_file(&path);
        assert_eq!(mesh.triangles, 1);
        assert_eq!(mesh.vertices.len(), 3);
    }

    #[test]
    fn obj_reader_rejects_zero_face_index() {
        let obj = "v 0 0 0\nv 1 0 0\nv 0 1 0\nf 1 0 3\n";
        let path = std::env::temp_dir().join(format!("mc189-obj-bad-index-test-{}.obj", std::process::id()));
        fs::write(&path, obj).expect("write temporary test OBJ");
        let result = read_obj_mesh(&path);
        let _ = fs::remove_file(&path);
        assert!(result.is_err());
    }
}
