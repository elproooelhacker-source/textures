//! Safe extraction of the Minecraft 1.8.9 client resource namespace.
//! Only `assets/minecraft/**` entries are copied; classes, META-INF, manifests,
//! libraries and other executable/archive content are deliberately excluded.
use mc189_core::{Mc189Error, Result};
use std::fs::{self, File};
use std::io::Read;
use std::path::{Component, Path, PathBuf};
use zip::ZipArchive;

const PREFIX: &str = "assets/minecraft/";
const MAX_ENTRY_BYTES: u64 = 64 * 1024 * 1024;
const MAX_TOTAL_BYTES: u64 = 1024 * 1024 * 1024;

fn safe_asset_path(entry: &str) -> Option<PathBuf> {
    let relative = entry.strip_prefix(PREFIX)?;
    if relative.is_empty() { return None; }
    let path = Path::new(relative);
    if path.components().any(|part| !matches!(part, Component::Normal(_))) { return None; }
    Some(path.to_path_buf())
}

/// Extract only the resource namespace shipped inside client.jar.
/// Minecraft 1.8.9's sound/music OGG payloads are normally launcher-managed
/// objects and are not present in this client JAR; the summary reports that.
pub fn extract_client_assets(jar_path: &Path, output_dir: &Path) -> Result<()> {
    if !jar_path.is_file() {
        return Err(Mc189Error::Usage(format!("client JAR is not a file: {}", jar_path.display())));
    }
    let file = File::open(jar_path)?;
    let mut archive = ZipArchive::new(file).map_err(|e| Mc189Error::InvalidData(format!("could not open client JAR: {e}")))?;
    let mut extracted = 0usize;
    let mut total_bytes = 0u64;
    let mut categories = std::collections::BTreeMap::<String, usize>::new();
    let mut audio_files = 0usize;
    fs::create_dir_all(output_dir)?;

    for index in 0..archive.len() {
        let mut entry = archive.by_index(index).map_err(|e| Mc189Error::InvalidData(format!("could not read JAR entry {index}: {e}")))?;
        let name = entry.name().to_owned();
        let Some(relative) = safe_asset_path(&name) else { continue; };
        if entry.is_dir() { continue; }
        if entry.size() > MAX_ENTRY_BYTES || total_bytes.saturating_add(entry.size()) > MAX_TOTAL_BYTES {
            return Err(Mc189Error::InvalidData(format!("asset extraction size limit exceeded at {name}")));
        }
        let mut bytes = Vec::with_capacity(entry.size() as usize);
        entry.read_to_end(&mut bytes)?;
        if bytes.len() as u64 != entry.size() {
            return Err(Mc189Error::InvalidData(format!("truncated asset entry: {name}")));
        }
        let destination = output_dir.join(&relative);
        if let Some(parent) = destination.parent() { fs::create_dir_all(parent)?; }
        fs::write(&destination, &bytes)?;
        extracted += 1;
        total_bytes += bytes.len() as u64;
        if let Some(category) = relative.components().next().and_then(|c| c.as_os_str().to_str()) {
            *categories.entry(category.to_owned()).or_insert(0) += 1;
        }
        if matches!(relative.extension().and_then(|x| x.to_str()), Some("ogg" | "wav" | "mp3")) {
            audio_files += 1;
        }
    }

    println!("Minecraft 1.8.9 client asset extraction");
    println!("  JAR: {}", jar_path.display());
    println!("  Output namespace: {}/", output_dir.display());
    println!("  Files extracted: {extracted}");
    println!("  Bytes extracted: {total_bytes}");
    println!("  Audio files in client JAR: {audio_files}");
    for (category, count) in categories { println!("  {category}: {count} files"); }
    if audio_files == 0 {
        println!("  NOTE: no OGG/WAV/MP3 payload exists in this JAR. Vanilla 1.8.9 sound/music is downloaded separately by the launcher from the version asset index.");
    }
    println!("  Only assets/minecraft/** was copied. No .class, META-INF, manifest or other executable content was extracted.");
    Ok(())
}


/// Extract audio objects referenced by the matching Minecraft launcher asset
/// index. `assets_root` is the launcher's `.minecraft/assets` directory (the
/// directory containing `objects/`); `index_path` is its matching `indexes/1.8.json`.
/// This is separate from client.jar because 1.8.9 audio is not embedded there.
pub fn extract_launcher_audio(assets_root: &Path, index_path: &Path, output_dir: &Path) -> Result<()> {
    if !assets_root.is_dir() { return Err(Mc189Error::Usage(format!("launcher assets directory is not a directory: {}", assets_root.display()))); }
    let index_bytes = fs::read(index_path)?;
    let index: serde_json::Value = serde_json::from_slice(&index_bytes).map_err(|e| Mc189Error::InvalidData(format!("invalid launcher asset index: {e}")))?;
    let objects = index.get("objects").and_then(|v| v.as_object()).ok_or_else(|| Mc189Error::InvalidData("asset index has no objects map".into()))?;
    fs::create_dir_all(output_dir)?;
    let mut extracted=0usize; let mut missing=0usize; let mut total=0u64;
    for (logical, descriptor) in objects {
        let Some(relative)=logical.strip_prefix("minecraft/sounds/") else { continue; };
        let rel_path=Path::new(relative);
        if relative.is_empty() || rel_path.components().any(|c| !matches!(c, Component::Normal(_))) { continue; }
        let Some(hash)=descriptor.get("hash").and_then(|v|v.as_str()) else { continue; };
        if hash.len()!=40 || !hash.bytes().all(|b|b.is_ascii_hexdigit()) { continue; }
        let expected_size=descriptor.get("size").and_then(|v|v.as_u64());
        let object_path=assets_root.join("objects").join(&hash[..2]).join(hash);
        if !object_path.is_file() { missing+=1; continue; }
        let metadata=fs::metadata(&object_path)?;
        if let Some(size)=expected_size { if metadata.len()!=size { return Err(Mc189Error::InvalidData(format!("launcher asset size mismatch: {logical}"))); } }
        if metadata.len()>MAX_ENTRY_BYTES { return Err(Mc189Error::InvalidData(format!("launcher audio object too large: {logical}"))); }
        let destination=output_dir.join(rel_path);
        if let Some(parent)=destination.parent(){fs::create_dir_all(parent)?;}
        fs::copy(&object_path,&destination)?;
        extracted+=1; total+=metadata.len();
    }
    println!("Minecraft 1.8.9 launcher audio extraction");
    println!("  Index: {}",index_path.display());
    println!("  Output: {}/",output_dir.display());
    println!("  Sound/music objects copied: {extracted}");
    println!("  Missing objects: {missing}");
    println!("  Bytes copied: {total}");
    println!("  Note: copied objects are checked against index sizes; SHA-1 is not verified by this command.");
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn accepts_only_safe_minecraft_asset_paths() {
        assert!(safe_asset_path("assets/minecraft/textures/blocks/stone.png").is_some());
        assert!(safe_asset_path("assets/minecraft/../evil.class").is_none());
        assert!(safe_asset_path("META-INF/MANIFEST.MF").is_none());
        assert!(safe_asset_path("assets/other/file.ogg").is_none());
    }
}
