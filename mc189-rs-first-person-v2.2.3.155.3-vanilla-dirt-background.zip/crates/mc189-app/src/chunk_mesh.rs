//! Diagnostic chunk-mesh exporter for known full opaque legacy blocks.
//!
//! This is intentionally not the final Minecraft renderer: it emits untextured unit cubes
//! for an explicit list of opaque full-cube block IDs so that block indexing, chunk origins,
//! face culling, and OBJ output can be checked independently of model/texture rendering.

use mc189_core::{Mc189Error, Result};
use mc189_storage::{decode_chunk, split_chunk_coordinate, ChunkData, RegionHeader};
use std::collections::{BTreeMap, HashMap};
use std::fs::OpenOptions;
use std::io::{BufWriter, Write};
use std::path::Path;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Face {
    Down,
    Up,
    North,
    South,
    West,
    East,
}

const FACES: [Face; 6] = [
    Face::Down,
    Face::Up,
    Face::North,
    Face::South,
    Face::West,
    Face::East,
];

impl Face {
    fn neighbor_offset(self) -> (i32, i32, i32) {
        match self {
            Self::Down => (0, -1, 0),
            Self::Up => (0, 1, 0),
            Self::North => (0, 0, -1),
            Self::South => (0, 0, 1),
            Self::West => (-1, 0, 0),
            Self::East => (1, 0, 0),
        }
    }
}

/// Explicit set of vanilla 1.8-era IDs whose block shape is a full cube and whose
/// faces may be hidden by an adjacent member of the same set. This is a geometry
/// diagnostic allowlist, not a complete block registry or texture mapping.
fn is_opaque_full_cube(id: u16) -> bool {
    matches!(
        id,
        1 | 2 | 3 | 4 | 5 | 7 | 12 | 13 | 14 | 15 | 16 | 17 | 21 | 22 | 24 | 35
            | 41 | 42 | 43 | 45 | 46 | 47 | 48 | 49 | 56 | 57 | 58 | 61 | 62 | 73 | 74
            | 80 | 82 | 87 | 89 | 97 | 98 | 110 | 112 | 121 | 123 | 124 | 125 | 129 | 133
            | 152 | 153 | 155 | 159 | 162 | 168 | 172 | 173 | 174 | 179
    )
}

fn face_corners(face: Face, x: u8, y: i32, z: u8) -> [[i64; 3]; 4] {
    let x0 = i64::from(x);
    let x1 = x0 + 1;
    let y0 = i64::from(y);
    let y1 = y0 + 1;
    let z0 = i64::from(z);
    let z1 = z0 + 1;
    match face {
        Face::Down => [[x0, y0, z1], [x0, y0, z0], [x1, y0, z0], [x1, y0, z1]],
        Face::Up => [[x0, y1, z0], [x0, y1, z1], [x1, y1, z1], [x1, y1, z0]],
        Face::North => [[x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0]],
        Face::South => [[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]],
        Face::West => [[x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0]],
        Face::East => [[x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1]],
    }
}

pub(crate) fn load_chunk(world_path: &Path, chunk_x: i32, chunk_z: i32) -> Result<Option<ChunkData>> {
    let (region_x, local_x) = split_chunk_coordinate(chunk_x);
    let (region_z, local_z) = split_chunk_coordinate(chunk_z);
    let region_path = world_path
        .join("region")
        .join(format!("r.{region_x}.{region_z}.mca"));
    if !region_path.is_file() {
        return Ok(None);
    }
    let header = RegionHeader::from_file(&region_path)?;
    let Some(location) = header.location(local_x, local_z) else {
        return Ok(None);
    };
    if !location.is_present() {
        return Ok(None);
    }
    let chunk = decode_chunk(&region_path, local_x, local_z)?;
    if chunk.x_pos != chunk_x || chunk.z_pos != chunk_z {
        return Err(Mc189Error::InvalidData(format!(
            "chunk coordinate mismatch: requested ({chunk_x},{chunk_z}), payload says ({},{})",
            chunk.x_pos, chunk.z_pos
        )));
    }
    Ok(Some(chunk))
}

fn block_id_at_world(
    chunks: &HashMap<(i32, i32), ChunkData>,
    world_x: i64,
    world_y: i32,
    world_z: i64,
) -> u16 {
    if !(0..=255).contains(&world_y) {
        return 0;
    }
    let chunk_x_i64 = world_x.div_euclid(16);
    let chunk_z_i64 = world_z.div_euclid(16);
    let (Ok(chunk_x), Ok(chunk_z)) = (
        i32::try_from(chunk_x_i64),
        i32::try_from(chunk_z_i64),
    ) else {
        return 0;
    };
    let Some(chunk) = chunks.get(&(chunk_x, chunk_z)) else {
        // A missing neighbor chunk is treated as air for this diagnostic mesh. Any
        // present neighboring chunk is loaded and coordinate-validated before meshing.
        return 0;
    };
    let local_x = world_x.rem_euclid(16) as u8;
    let local_z = world_z.rem_euclid(16) as u8;
    chunk.block_id_at(local_x, world_y as u8, local_z).unwrap_or(0)
}

/// Export one chunk as an untextured diagnostic OBJ. Existing output files are never
/// overwritten; the source world is read only. X/Z coordinates are chunk-local, Y is
/// the classic world height, and the chunk's world origin is written in the OBJ comment.
pub fn export_debug_chunk_mesh(
    world_path: &Path,
    chunk_x: i32,
    chunk_z: i32,
    output_path: &Path,
) -> Result<()> {
    if !world_path.is_dir() {
        return Err(Mc189Error::Usage(format!(
            "world path is not a directory: {}",
            world_path.display()
        )));
    }
    if !world_path.join("region").is_dir() {
        return Err(Mc189Error::Usage(format!(
            "no region directory found at {}",
            world_path.join("region").display()
        )));
    }
    if output_path.extension().and_then(|value| value.to_str()) != Some("obj") {
        return Err(Mc189Error::Usage(
            "debug mesh output must use the .obj extension".to_owned(),
        ));
    }
    if output_path.exists() {
        return Err(Mc189Error::Usage(format!(
            "output already exists; choose a new file so it is not overwritten: {}",
            output_path.display()
        )));
    }
    if let Some(parent) = output_path.parent() {
        if !parent.as_os_str().is_empty() && !parent.is_dir() {
            return Err(Mc189Error::Usage(format!(
                "output directory does not exist: {}",
                parent.display()
            )));
        }
    }

    let Some(selected) = load_chunk(world_path, chunk_x, chunk_z)? else {
        return Err(Mc189Error::InvalidData(format!(
            "chunk ({chunk_x},{chunk_z}) is not present in this world"
        )));
    };

    // Neighbor chunks are loaded for horizontal face culling. Missing chunk entries are
    // treated as air, while a malformed present region/chunk is reported as an error.
    let mut chunks = HashMap::new();
    chunks.insert((chunk_x, chunk_z), selected.clone());
    for (nx, nz) in [
        (chunk_x.checked_sub(1), Some(chunk_z)),
        (chunk_x.checked_add(1), Some(chunk_z)),
        (Some(chunk_x), chunk_z.checked_sub(1)),
        (Some(chunk_x), chunk_z.checked_add(1)),
    ] {
        if let (Some(nx), Some(nz)) = (nx, nz) {
            if let Some(neighbor) = load_chunk(world_path, nx, nz)? {
                chunks.insert((nx, nz), neighbor);
            }
        }
    }

    let file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(output_path)?;
    let mut output = BufWriter::new(file);
    let origin_x = i64::from(chunk_x) * 16;
    let origin_z = i64::from(chunk_z) * 16;
    writeln!(output, "# mc189-rs diagnostic chunk mesh; untextured cube geometry only")?;
    writeln!(output, "# chunk: {chunk_x} {chunk_z}")?;
    writeln!(output, "# world_origin_xz: {origin_x} {origin_z}")?;
    writeln!(output, "# X/Z are chunk-local; Y is world height 0..255")?;
    writeln!(output, "# block ID and metadata are recorded in group names; not a final texture/model render")?;

    let mut cube_blocks = 0_u64;
    let mut non_air_blocks_seen = 0_u64;
    let mut omitted_non_cubes = 0_u64;
    let mut emitted_faces = 0_u64;
    let mut culled_faces = 0_u64;
    let mut omitted_by_state: BTreeMap<(u16, u8), u64> = BTreeMap::new();
    let mut vertex_index = 1_u64;
    let mut current_group: Option<(u16, u8)> = None;

    for section in &selected.sections {
        for local_y in 0_u8..16 {
            let world_y = i32::from(section.y) * 16 + i32::from(local_y);
            for local_z in 0_u8..16 {
                for local_x in 0_u8..16 {
                    let index = (usize::from(local_y) << 8)
                        | (usize::from(local_z) << 4)
                        | usize::from(local_x);
                    let Some(&id) = section.block_ids.get(index) else {
                        return Err(Mc189Error::InvalidData(format!(
                            "section Y={} has a short block ID array",
                            section.y
                        )));
                    };
                    if id == 0 {
                        continue;
                    }
                    non_air_blocks_seen += 1;
                    let metadata = section.metadata.get(index).copied().ok_or_else(|| {
                        Mc189Error::InvalidData(format!(
                            "section Y={} has a short metadata array",
                            section.y
                        ))
                    })?;
                    if !is_opaque_full_cube(id) {
                        omitted_non_cubes += 1;
                        *omitted_by_state.entry((id, metadata)).or_insert(0) += 1;
                        continue;
                    }
                    cube_blocks += 1;
                    let wx = origin_x + i64::from(local_x);
                    let wz = origin_z + i64::from(local_z);
                    for face in FACES {
                        let (dx, dy, dz) = face.neighbor_offset();
                        let neighbor = block_id_at_world(
                            &chunks,
                            wx + i64::from(dx),
                            world_y + dy,
                            wz + i64::from(dz),
                        );
                        if is_opaque_full_cube(neighbor) {
                            culled_faces += 1;
                            continue;
                        }
                        let group = (id, metadata);
                        if current_group != Some(group) {
                            writeln!(output, "g block_id_{}_meta_{}", id, metadata)?;
                            current_group = Some(group);
                        }
                        let corners = face_corners(face, local_x, world_y, local_z);
                        for point in corners {
                            writeln!(output, "v {} {} {}", point[0], point[1], point[2])?;
                        }
                        writeln!(
                            output,
                            "f {} {} {} {}",
                            vertex_index,
                            vertex_index + 1,
                            vertex_index + 2,
                            vertex_index + 3
                        )?;
                        vertex_index += 4;
                        emitted_faces += 1;
                    }
                }
            }
        }
    }
    output.flush()?;

    let mut skipped: Vec<((u16, u8), u64)> = omitted_by_state.into_iter().collect();
    skipped.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));

    println!("Minecraft 1.8.9 diagnostic chunk-mesh export (CPU, read-only source world)");
    println!("World: {}", world_path.display());
    println!("Chunk: ({chunk_x},{chunk_z})");
    println!("OBJ output: {}", output_path.display());
    println!("Neighbor chunks loaded: {}", chunks.len().saturating_sub(1));
    println!("Non-air positions visited in stored sections: {non_air_blocks_seen}");
    println!("Full opaque cube blocks meshed: {cube_blocks}");
    println!("Visible quads emitted: {emitted_faces}");
    println!("Triangles if each quad is split in two: {}", emitted_faces * 2);
    println!("Vertices written (not deduplicated): {}", emitted_faces * 4);
    println!("Faces culled against adjacent full opaque cubes: {culled_faces}");
    println!("Non-air blocks skipped by this diagnostic mesher: {omitted_non_cubes}");
    if !skipped.is_empty() {
        println!("Skipped block ID/metadata pairs (first 15 by count):");
        for ((id, metadata), count) in skipped.iter().take(15) {
            println!("  ID {id} meta {metadata}: {count}");
        }
    }
    println!("Texture UVs, model-specific geometry, blockstate rotations, fluids, transparency, lighting and GPU rendering are not included.");
    println!("The OBJ is an intermediate geometry diagnostic, not the final Minecraft renderer.");
    println!("No world files or JAR entries were modified.");
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn normal(points: [[i64; 3]; 4]) -> [i64; 3] {
        let a = [
            points[1][0] - points[0][0],
            points[1][1] - points[0][1],
            points[1][2] - points[0][2],
        ];
        let b = [
            points[2][0] - points[0][0],
            points[2][1] - points[0][1],
            points[2][2] - points[0][2],
        ];
        [
            a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0],
        ]
    }

    #[test]
    fn opaque_full_cube_classifier_excludes_air_fluids_and_special_shapes() {
        assert!(is_opaque_full_cube(1));
        assert!(is_opaque_full_cube(5));
        assert!(!is_opaque_full_cube(0));
        assert!(!is_opaque_full_cube(8));
        assert!(!is_opaque_full_cube(50));
        assert!(!is_opaque_full_cube(18));
    }

    #[test]
    fn every_unit_cube_face_has_outward_winding() {
        let expectations = [
            (Face::Down, [0, -1, 0]),
            (Face::Up, [0, 1, 0]),
            (Face::North, [0, 0, -1]),
            (Face::South, [0, 0, 1]),
            (Face::West, [-1, 0, 0]),
            (Face::East, [1, 0, 0]),
        ];
        for (face, expected) in expectations {
            let points = face_corners(face, 2, 7, 4);
            let actual = normal(points);
            assert_eq!(actual, expected, "incorrect winding for {face:?}");
        }
    }

    #[test]
    fn classic_negative_chunk_coordinates_split_to_euclidean_region_slots() {
        assert_eq!(split_chunk_coordinate(-1), (-1, 31));
        assert_eq!(split_chunk_coordinate(-16), (-1, 16));
        assert_eq!(split_chunk_coordinate(-32), (-1, 0));
        assert_eq!(split_chunk_coordinate(-33), (-2, 31));
    }
}
