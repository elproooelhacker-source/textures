//! Discovery, selection and guarded management helpers for vanilla Java world saves.
use mc189_core::{Mc189Error, Result};
use mc189_storage::{read_world_metadata, WorldMetadata};
use std::fs;
use std::path::{Path, PathBuf};
use std::io::{Read, Write};
use flate2::{read::GzDecoder, write::GzEncoder, Compression};
use mc189_storage::{parse_nbt_root, write_nbt_root, NbtTag};

#[derive(Debug, Clone)]
pub struct SavedWorld {
    pub folder_name: String,
    pub path: PathBuf,
    pub metadata: WorldMetadata,
    pub region_file_count: usize,
}

/// Finds direct child directories of `.minecraft/saves` that look like Java worlds.
/// Invalid or incomplete directories are ignored; valid worlds are sorted by display name.
pub fn discover_worlds(saves_dir: &Path) -> Result<Vec<SavedWorld>> {
    if !saves_dir.is_dir() {
        return Err(Mc189Error::Usage(format!("saves directory does not exist: {}", saves_dir.display())));
    }
    let mut worlds = Vec::new();
    for entry in fs::read_dir(saves_dir)? {
        let entry = entry?;
        let path = entry.path();
        if !path.is_dir() || !path.join("level.dat").is_file() || !path.join("region").is_dir() {
            continue;
        }
        let metadata = match read_world_metadata(&path) {
            Ok(value) => value,
            Err(_) => continue,
        };
        let region_file_count = fs::read_dir(path.join("region"))?
            .filter_map(std::result::Result::ok)
            .filter(|item| item.path().extension().is_some_and(|ext| ext == "mca"))
            .count();
        let folder_name = entry.file_name().to_string_lossy().into_owned();
        worlds.push(SavedWorld { folder_name, path, metadata, region_file_count });
    }
    worlds.sort_by(|a, b| {
        a.metadata.level_name.as_deref().unwrap_or(&a.folder_name)
            .to_lowercase().cmp(&b.metadata.level_name.as_deref().unwrap_or(&b.folder_name).to_lowercase())
            .then_with(|| a.folder_name.cmp(&b.folder_name))
    });
    Ok(worlds)
}


/// Update only Data.LevelName using the same NBT field used by vanilla's
/// GuiRenameWorld. Unknown tags are retained. The replacement follows the
/// level.dat_new / level.dat_old transaction pattern.
pub fn rename_world_display_name(world: &SavedWorld, display_name: &str) -> Result<()> {
    let name = display_name.trim();
    if name.is_empty() || name.chars().count() > 32 || name.chars().any(char::is_control) {
        return Err(Mc189Error::Usage("world name must contain 1-32 printable characters".into()));
    }
    let current = world.path.join("level.dat");
    let mut decoded = Vec::new();
    GzDecoder::new(fs::File::open(&current)?)
        .take(64 * 1024 * 1024 + 1)
        .read_to_end(&mut decoded)?;
    if decoded.len() > 64 * 1024 * 1024 {
        return Err(Mc189Error::InvalidData("level.dat exceeds the 64 MiB safety limit".into()));
    }
    let (root_name, mut root) = parse_nbt_root(&decoded)?;
    let data = root.get_mut("Data").ok_or_else(|| Mc189Error::InvalidData("level.dat has no Data compound".into()))?;
    data.insert("LevelName", NbtTag::String(name.to_owned()))?;
    let encoded = write_nbt_root(&root_name, &root)?;
    let new_path = world.path.join("level.dat_new");
    let old_path = world.path.join("level.dat_old");
    let file = fs::File::create(&new_path)?;
    let mut gzip = GzEncoder::new(file, Compression::default());
    gzip.write_all(&encoded)?;
    gzip.finish()?.sync_all()?;
    if old_path.exists() { fs::remove_file(&old_path)?; }
    fs::rename(&current, &old_path)?;
    if let Err(error) = fs::rename(&new_path, &current) {
        let _ = fs::rename(&old_path, &current);
        return Err(Mc189Error::InvalidData(format!("could not commit world rename: {error}")));
    }
    Ok(())
}

/// Quarantine a save instead of permanently deleting it. Vanilla deletes the
/// directory, but retaining it under saves/.mc189-trash makes accidental GUI
/// activation recoverable while preserving the exact world bytes.
pub fn quarantine_world(saves_dir: &Path, world: &SavedWorld) -> Result<PathBuf> {
    let canonical_saves = saves_dir.canonicalize()?;
    let canonical_world = world.path.canonicalize()?;
    if canonical_world.parent() != Some(canonical_saves.as_path()) {
        return Err(Mc189Error::InvalidData("refusing to move a world outside the saves directory".into()));
    }
    let trash = saves_dir.join(".mc189-trash");
    fs::create_dir_all(&trash)?;
    let mut destination = trash.join(&world.folder_name);
    let mut suffix = 2u32;
    while destination.exists() {
        destination = trash.join(format!("{} ({suffix})", world.folder_name));
        suffix += 1;
    }
    fs::rename(&canonical_world, &destination)?;
    Ok(destination)
}

pub fn print_worlds(saves_dir: &Path) -> Result<()> {
    let worlds = discover_worlds(saves_dir)?;
    println!("Minecraft 1.8.9 — saved worlds (read-only)");
    println!("Saves: {}", saves_dir.display());
    if worlds.is_empty() {
        println!("No valid worlds found. Expected each world to contain level.dat and region/*.mca.");
        return Ok(());
    }
    println!("Found {} world(s):", worlds.len());
    for (index, world) in worlds.iter().enumerate() {
        let name = world.metadata.level_name.as_deref().unwrap_or(&world.folder_name);
        let spawn = match (world.metadata.spawn_x, world.metadata.spawn_y, world.metadata.spawn_z) {
            (Some(x), Some(y), Some(z)) => format!("{x}, {y}, {z}"),
            _ => "missing spawn coordinates".to_owned(),
        };
        println!("  [{}] {}", index + 1, name);
        println!("      Folder: {}", world.folder_name);
        println!("      Spawn: {spawn} | Region files: {}", world.region_file_count);
        println!("      Path: {}", world.path.display());
    }
    Ok(())
}

pub fn select_world_interactively(saves_dir: &Path) -> Result<SavedWorld> {
    use std::io::{self, Write};
    let worlds = discover_worlds(saves_dir)?;
    if worlds.is_empty() {
        return Err(Mc189Error::InvalidData(format!("no valid worlds found in {}", saves_dir.display())));
    }
    println!("\n========== M C  1.8.9  R U S T ==========");
    println!("             SELECT WORLD\n");
    for (index, world) in worlds.iter().enumerate() {
        let name = world.metadata.level_name.as_deref().unwrap_or(&world.folder_name);
        println!("  {}. {}", index + 1, name);
    }
    println!("  0. Cancel\n");
    print!("Select a world: ");
    io::stdout().flush()?;
    let mut input = String::new();
    io::stdin().read_line(&mut input)?;
    let selection = input.trim().parse::<usize>()
        .map_err(|_| Mc189Error::Usage("enter the number shown beside a world".into()))?;
    if selection == 0 { return Err(Mc189Error::Usage("world selection cancelled".into())); }
    worlds.get(selection - 1).cloned()
        .ok_or_else(|| Mc189Error::Usage(format!("world selection {selection} is out of range")))
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn region_extension_match_is_case_sensitive_for_vanilla_names() {
        assert!(Path::new("r.0.0.mca").extension().is_some_and(|ext| ext == "mca"));
        assert!(!Path::new("r.0.0.txt").extension().is_some_and(|ext| ext == "mca"));
    }
}

#[cfg(test)]
mod management_tests {
    use super::*;
    use flate2::{write::GzEncoder, Compression};
    use mc189_storage::{write_nbt_root, NbtTag};
    use std::time::{SystemTime, UNIX_EPOCH};
    use std::io::{Read, Write};

    fn fixture() -> (PathBuf, SavedWorld) {
        let stamp = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_nanos();
        let saves = std::env::temp_dir().join(format!("mc189-world-menu-{}-{stamp}", std::process::id()));
        let path = saves.join("TestWorld");
        fs::create_dir_all(path.join("region")).unwrap();
        let root = NbtTag::Compound(vec![("Data".into(), NbtTag::Compound(vec![
            ("LevelName".into(), NbtTag::String("Original".into())),
            ("version".into(), NbtTag::Int(19133)),
            ("GameType".into(), NbtTag::Int(0)),
            ("UnknownPreserved".into(), NbtTag::Long(123456789)),
        ]))]);
        let bytes = write_nbt_root("", &root).unwrap();
        let mut gzip = GzEncoder::new(fs::File::create(path.join("level.dat")).unwrap(), Compression::default());
        gzip.write_all(&bytes).unwrap(); gzip.finish().unwrap();
        let metadata = read_world_metadata(&path).unwrap();
        let world = SavedWorld { folder_name:"TestWorld".into(), path, metadata, region_file_count:0 };
        (saves, world)
    }

    #[test]
    fn rename_changes_only_vanilla_level_name_and_keeps_unknown_tags() {
        let (saves, world) = fixture();
        rename_world_display_name(&world, "Renamed World").unwrap();
        let metadata = read_world_metadata(&world.path).unwrap();
        assert_eq!(metadata.level_name.as_deref(), Some("Renamed World"));
        assert!(world.path.join("level.dat_old").is_file());
        let mut decoded = Vec::new();
        GzDecoder::new(fs::File::open(world.path.join("level.dat")).unwrap()).read_to_end(&mut decoded).unwrap();
        let (_, root) = parse_nbt_root(&decoded).unwrap();
        assert_eq!(root.get("Data").unwrap().get("UnknownPreserved").unwrap().as_long(), Some(123456789));
        fs::remove_dir_all(saves).unwrap();
    }

    #[test]
    fn delete_confirmation_quarantines_instead_of_destroying_world_bytes() {
        let (saves, world) = fixture();
        let moved = quarantine_world(&saves, &world).unwrap();
        assert!(moved.join("level.dat").is_file());
        assert!(!world.path.exists());
        assert!(moved.starts_with(saves.join(".mc189-trash")));
        fs::remove_dir_all(saves).unwrap();
    }
}
