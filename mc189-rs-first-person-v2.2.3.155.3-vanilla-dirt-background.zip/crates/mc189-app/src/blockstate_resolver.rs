//! Read-only resolver for classic Minecraft 1.8.9 blockstate variants and multipart rules.
use mc189_core::{Mc189Error, Result};
use serde_json::Value;
use std::{fs::File, io::Read, path::Path};
use zip::ZipArchive;

const MAX_BLOCKSTATE_BYTES: u64 = 4 * 1024 * 1024;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct VariantModel {
    pub model: String,
    pub x: u16,
    pub y: u16,
    pub uvlock: bool,
    pub weight: u32,
}

fn canonical_blockstate_path(id: &str) -> Option<String> {
    let id = id.strip_prefix("minecraft:").unwrap_or(id);
    if id.is_empty() || id.starts_with('/') || id.contains("..") || id.contains('\\') {
        return None;
    }
    let path = if id.starts_with("blockstates/") { id.to_owned() } else { format!("blockstates/{id}") };
    let path = if path.ends_with(".json") { path } else { format!("{path}.json") };
    if path.split('/').any(|part| part.is_empty()) { return None; }
    Some(format!("assets/minecraft/{path}"))
}

fn parse_model(value: &Value) -> std::result::Result<VariantModel, String> {
    let object = value.as_object().ok_or("variant model must be a JSON object")?;
    let model = object.get("model").and_then(Value::as_str)
        .ok_or("variant model is missing string field 'model'")?;
    let model = model.strip_prefix("minecraft:").unwrap_or(model);
    if model.is_empty() || model.starts_with('/') || model.contains("..") || model.contains('\\') {
        return Err(format!("invalid model resource ID {model:?}"));
    }
    let rotation = |key: &str| -> std::result::Result<u16, String> {
        let Some(value) = object.get(key) else { return Ok(0); };
        let raw = value.as_u64().ok_or_else(|| format!("variant {key} rotation must be an unsigned integer"))?;
        if raw > 270 || raw % 90 != 0 { return Err(format!("variant {key} rotation must be 0, 90, 180 or 270")); }
        Ok(raw as u16)
    };
    let weight = match object.get("weight") {
        None => 1,
        Some(value) => value.as_u64().ok_or("variant weight must be an unsigned integer")?,
    };
    if weight == 0 || weight > u32::MAX as u64 { return Err("variant weight must be between 1 and u32::MAX".into()); }
    let uvlock = match object.get("uvlock") {
        None => false,
        Some(value) => value.as_bool().ok_or("variant uvlock must be a boolean")?,
    };
    Ok(VariantModel {
        model: model.to_owned(), x: rotation("x")?, y: rotation("y")?, uvlock, weight: weight as u32,
    })
}

pub fn resolve_variant_value(blockstate: &Value, selector: &str) -> std::result::Result<Vec<VariantModel>, String> {
    let root = blockstate.as_object().ok_or("blockstate root must be a JSON object")?;
    let variants = root.get("variants").and_then(Value::as_object)
        .ok_or_else(|| if root.contains_key("multipart") { "blockstate uses multipart rules; this resolver currently handles variants only".to_owned() } else { "blockstate has no variants object".to_owned() })?;
    let selected = variants.get(selector).ok_or_else(|| format!("selector {selector:?} does not exist in this blockstate"))?;
    let entries: Vec<&Value> = if let Some(array) = selected.as_array() {
        if array.is_empty() { return Err(format!("selector {selector:?} has an empty model list")); }
        array.iter().collect()
    } else { vec![selected] };
    entries.into_iter().map(parse_model).collect()
}

/// Selects one weighted alternative using the 48-bit java.util.Random algorithm.
/// The caller supplies the seed; a world renderer should derive it from block position.
pub fn select_weighted_variant_index(alternatives: &[VariantModel], seed: i64) -> std::result::Result<usize, String> {
    if alternatives.is_empty() { return Err("cannot select from an empty variant list".into()); }
    let total_weight: u64 = alternatives.iter().try_fold(0_u64, |sum, item| {
        sum.checked_add(item.weight as u64).ok_or_else(|| "total variant weight overflow".to_owned())
    })?;
    if total_weight == 0 || total_weight > i32::MAX as u64 {
        return Err(format!("total variant weight must be between 1 and {}", i32::MAX));
    }
    let bound = total_weight as u32;
    let mut random = JavaRandom::new(seed);
    let mut choice = random.next_int(bound) as u64;
    for (index, item) in alternatives.iter().enumerate() {
        if choice < item.weight as u64 { return Ok(index); }
        choice -= item.weight as u64;
    }
    Err("weighted variant selection exhausted its weight range".into())
}

struct JavaRandom { seed: u64 }
impl JavaRandom {
    const MULTIPLIER: u64 = 0x5DEECE66D;
    const ADDEND: u64 = 0xB;
    const MASK: u64 = (1_u64 << 48) - 1;
    fn new(seed: i64) -> Self { Self { seed: ((seed as u64) ^ Self::MULTIPLIER) & Self::MASK } }
    fn next(&mut self, bits: u32) -> u32 {
        self.seed = self.seed.wrapping_mul(Self::MULTIPLIER).wrapping_add(Self::ADDEND) & Self::MASK;
        (self.seed >> (48 - bits)) as u32
    }
    fn next_int(&mut self, bound: u32) -> u32 {
        if bound.is_power_of_two() { return ((bound as u64 * self.next(31) as u64) >> 31) as u32; }
        loop {
            let bits = self.next(31);
            let value = bits % bound;
            if (bits as i64 - value as i64 + (bound - 1) as i64) < (1_i64 << 31) { return value; }
        }
    }
}

pub fn load_blockstate_variant(jar_path: &Path, blockstate_id: &str, selector: &str) -> Result<(String, Vec<VariantModel>)> {
    if !jar_path.is_file() { return Err(Mc189Error::Usage(format!("client JAR is not a file: {}", jar_path.display()))); }
    let path = canonical_blockstate_path(blockstate_id)
        .ok_or_else(|| Mc189Error::Usage(format!("invalid blockstate resource ID: {blockstate_id:?}")))?;
    let file = File::open(jar_path)?;
    let mut archive = ZipArchive::new(file).map_err(|e| Mc189Error::InvalidData(format!("could not open client JAR: {e}")))?;
    let mut entry = archive.by_name(&path).map_err(|e| Mc189Error::InvalidData(format!("blockstate not found ({path}): {e}")))?;
    if entry.size() > MAX_BLOCKSTATE_BYTES { return Err(Mc189Error::InvalidData(format!("blockstate exceeds {MAX_BLOCKSTATE_BYTES} bytes"))); }
    let mut bytes = Vec::with_capacity(entry.size() as usize);
    entry.read_to_end(&mut bytes)?;
    let json: Value = serde_json::from_slice(&bytes).map_err(|e| Mc189Error::InvalidData(format!("invalid JSON in {path}: {e}")))?;
    let resolved = resolve_variant_value(&json, selector).map_err(Mc189Error::InvalidData)?;
    Ok((path, resolved))
}


#[derive(Clone, Debug, PartialEq, Eq)]
pub struct MultipartModel {
    pub part_index: usize,
    pub model: String,
    pub x: u16,
    pub y: u16,
    pub uvlock: bool,
    pub weight: u32,
}

fn property_matches(condition: &Value, properties: &std::collections::BTreeMap<String, String>) -> std::result::Result<bool, String> {
    let object = condition.as_object().ok_or("multipart condition must be a JSON object")?;
    for (key, expected) in object {
        match key.as_str() {
            "OR" | "AND" => {
                let clauses = expected.as_array().ok_or_else(|| format!("multipart {key} condition must be an array"))?;
                if clauses.is_empty() { return Err(format!("multipart {key} condition cannot be empty")); }
                if key == "OR" {
                    let mut matched = false;
                    for clause in clauses {
                        if property_matches(clause, properties)? { matched = true; break; }
                    }
                    if !matched { return Ok(false); }
                } else {
                    for clause in clauses {
                        if !property_matches(clause, properties)? { return Ok(false); }
                    }
                }
            }
            property => {
                let actual = properties.get(property).ok_or_else(|| format!("missing blockstate property {property:?} required by multipart condition"))?;
                let expected = expected.as_str().ok_or_else(|| format!("multipart property {property:?} condition must be a string"))?;
                if !expected.split(',').any(|candidate| candidate.trim() == actual) { return Ok(false); }
            }
        }
    }
    Ok(true)
}

pub fn resolve_multipart_value(blockstate: &Value, properties: &std::collections::BTreeMap<String, String>) -> std::result::Result<Vec<MultipartModel>, String> {
    let root = blockstate.as_object().ok_or("blockstate root must be a JSON object")?;
    if root.contains_key("variants") { return Err("blockstate contains variants; use the variant resolver".into()); }
    let parts = root.get("multipart").and_then(Value::as_array).ok_or("blockstate has no multipart array")?;
    let mut resolved = Vec::new();
    for (part_index, part) in parts.iter().enumerate() {
        let part = part.as_object().ok_or_else(|| format!("multipart part {part_index} must be an object"))?;
        if let Some(condition) = part.get("when") {
            if !property_matches(condition, properties)? { continue; }
        }
        let apply = part.get("apply").ok_or_else(|| format!("multipart part {part_index} is missing apply"))?;
        let entries: Vec<&Value> = match apply {
            Value::Array(items) if !items.is_empty() => items.iter().collect(),
            Value::Array(_) => return Err(format!("multipart part {part_index} has an empty apply array")),
            value => vec![value],
        };
        for entry in entries {
            let model = parse_model(entry).map_err(|e| format!("multipart part {part_index}: {e}"))?;
            resolved.push(MultipartModel { part_index, model: model.model, x: model.x, y: model.y, uvlock: model.uvlock, weight: model.weight });
        }
    }
    Ok(resolved)
}

pub fn load_blockstate_multipart(jar_path: &Path, blockstate_id: &str, properties: &std::collections::BTreeMap<String, String>) -> Result<(String, Vec<MultipartModel>)> {
    if !jar_path.is_file() { return Err(Mc189Error::Usage(format!("client JAR is not a file: {}", jar_path.display()))); }
    let path = canonical_blockstate_path(blockstate_id).ok_or_else(|| Mc189Error::Usage(format!("invalid blockstate resource ID: {blockstate_id:?}")))?;
    let file = File::open(jar_path)?;
    let mut archive = ZipArchive::new(file).map_err(|e| Mc189Error::InvalidData(format!("could not open client JAR: {e}")))?;
    let mut entry = archive.by_name(&path).map_err(|e| Mc189Error::InvalidData(format!("blockstate not found ({path}): {e}")))?;
    if entry.size() > MAX_BLOCKSTATE_BYTES { return Err(Mc189Error::InvalidData(format!("blockstate exceeds {MAX_BLOCKSTATE_BYTES} bytes"))); }
    let mut bytes = Vec::with_capacity(entry.size() as usize);
    entry.read_to_end(&mut bytes)?;
    let json: Value = serde_json::from_slice(&bytes).map_err(|e| Mc189Error::InvalidData(format!("invalid JSON in {path}: {e}")))?;
    let resolved = resolve_multipart_value(&json, properties).map_err(Mc189Error::InvalidData)?;
    Ok((path, resolved))
}

pub fn inspect_blockstate_multipart(jar_path: &Path, blockstate_id: &str, properties: &std::collections::BTreeMap<String, String>) -> Result<()> {
    let (path, resolved) = load_blockstate_multipart(jar_path, blockstate_id, properties)?;
    println!("Minecraft 1.8.9 blockstate multipart resolver (read-only)");
    println!("  Blockstate: {path}");
    println!("  Supplied properties: {}", if properties.is_empty() { "<none>".into() } else { properties.iter().map(|(k,v)| format!("{k}={v}")).collect::<Vec<_>>().join(",") });
    println!("  Resolved model applications: {}", resolved.len());
    for item in &resolved { println!("  [part {}] model={} | x={} | y={} | uvlock={} | weight={}", item.part_index, item.model, item.x, item.y, item.uvlock, item.weight); }
    println!("Scope: evaluates multipart AND/OR/property conditions and lists matching model applications; weighted selection, uvlock compensation and GPU composition are not applied yet.");
    println!("The JAR was not modified.");
    Ok(())
}

pub fn inspect_blockstate_variant(jar_path: &Path, blockstate_id: &str, selector: &str) -> Result<()> {
    let (path, resolved) = load_blockstate_variant(jar_path, blockstate_id, selector)?;
    println!("Minecraft 1.8.9 blockstate variant resolver (read-only)");
    println!("  Blockstate: {path}");
    println!("  Selector: {}", if selector.is_empty() { "<default>" } else { selector });
    println!("  Model alternatives: {}", resolved.len());
    for (index, item) in resolved.iter().enumerate() {
        println!("  [{}] model={} | x={} | y={} | uvlock={} | weight={}", index + 1, item.model, item.x, item.y, item.uvlock, item.weight);
    }
    println!("Scope: resolves variant selection metadata only; weighted random choice, model geometry rotation and uvlock application are not yet applied to the GPU preview.");
    println!("The JAR was not modified.");
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    #[test]
    fn resolves_default_variant_and_defaults() {
        let data = json!({"variants":{"":{"model":"block/cube","weight":2}}});
        let got = resolve_variant_value(&data, "").unwrap();
        assert_eq!(got, vec![VariantModel { model:"block/cube".into(), x:0, y:0, uvlock:false, weight:2 }]);
    }

    #[test]
    fn resolves_rotations_uvlock_and_weighted_alternatives() {
        let data = json!({"variants":{"facing=north":[
            {"model":"minecraft:block/a","x":90,"y":180,"uvlock":true,"weight":3},
            {"model":"block/b","y":270}
        ]}});
        let got = resolve_variant_value(&data, "facing=north").unwrap();
        assert_eq!(got.len(), 2);
        assert_eq!(got[0], VariantModel { model:"block/a".into(), x:90, y:180, uvlock:true, weight:3 });
        assert_eq!(got[1].y, 270);
        assert_eq!(got[1].weight, 1);
    }

    #[test]
    fn rejects_missing_selector_and_bad_rotation() {
        let data = json!({"variants":{"normal":{"model":"block/a","x":45}}});
        assert!(resolve_variant_value(&data, "missing").unwrap_err().contains("does not exist"));
        assert!(resolve_variant_value(&data, "normal").unwrap_err().contains("0, 90, 180 or 270"));
    }

    #[test]
    fn explicitly_rejects_multipart_for_now() {
        let data = json!({"multipart":[]});
        assert!(resolve_variant_value(&data, "").unwrap_err().contains("multipart"));
    }

    #[test]
    fn multipart_matches_unconditional_and_and_or_conditions() {
        let data = json!({"multipart":[
            {"apply":{"model":"block/base"}},
            {"when":{"north":"true","OR":[{"east":"true"},{"south":"true"}]},"apply":{"model":"block/side","y":90}},
            {"when":{"AND":[{"west":"true"},{"up":"true"}]},"apply":[{"model":"block/top"},{"model":"block/weighted","weight":2}]}
        ]});
        let props = std::collections::BTreeMap::from([
            ("north".into(),"true".into()),("east".into(),"false".into()),
            ("south".into(),"true".into()),("west".into(),"true".into()),("up".into(),"true".into())]);
        let got = resolve_multipart_value(&data, &props).unwrap();
        assert_eq!(got.len(), 4);
        assert_eq!(got[0].model, "block/base");
        assert_eq!(got[1].model, "block/side");
        assert_eq!(got[2].part_index, 2);
        assert_eq!(got[3].weight, 2);
    }

    #[test]
    fn multipart_skips_nonmatching_parts_and_supports_comma_values() {
        let data = json!({"multipart":[
            {"when":{"facing":"north,east"},"apply":{"model":"block/a"}},
            {"when":{"facing":"south"},"apply":{"model":"block/b"}}
        ]});
        let props = std::collections::BTreeMap::from([("facing".into(),"east".into())]);
        let got = resolve_multipart_value(&data, &props).unwrap();
        assert_eq!(got.len(), 1);
        assert_eq!(got[0].model, "block/a");
    }

    #[test]
    fn multipart_or_short_circuits_after_a_matching_clause() {
        let data = json!({"multipart":[{"when":{"OR":[{"north":"true"},{"unknown":"true"}]},"apply":{"model":"block/a"}}]});
        let props = std::collections::BTreeMap::from([("north".into(),"true".into())]);
        assert_eq!(resolve_multipart_value(&data, &props).unwrap()[0].model, "block/a");
    }

    #[test]
    fn multipart_rejects_missing_properties_and_invalid_conditions() {
        let missing = json!({"multipart":[{"when":{"north":"true"},"apply":{"model":"block/a"}}]});
        assert!(resolve_multipart_value(&missing, &Default::default()).unwrap_err().contains("missing blockstate property"));
        let invalid = json!({"multipart":[{"when":{"OR":[]},"apply":{"model":"block/a"}}]});
        assert!(resolve_multipart_value(&invalid, &Default::default()).unwrap_err().contains("cannot be empty"));
    }

    #[test]
    fn weighted_selection_matches_java_random_and_respects_weight_ranges() {
        let alternatives = vec![
            VariantModel { model:"block/a".into(), x:0, y:0, uvlock:false, weight:1 },
            VariantModel { model:"block/b".into(), x:0, y:0, uvlock:false, weight:3 },
        ];
        // java.util.Random(0).nextInt(4) == 2, so the second entry wins.
        assert_eq!(select_weighted_variant_index(&alternatives, 0).unwrap(), 1);
        assert_eq!(select_weighted_variant_index(&alternatives, 1).unwrap(), 1);
        let single = vec![alternatives[0].clone()];
        assert_eq!(select_weighted_variant_index(&single, 9876).unwrap(), 0);
    }

    #[test]
    fn weighted_selection_rejects_empty_or_excessive_total_weight() {
        assert!(select_weighted_variant_index(&[], 0).unwrap_err().contains("empty"));
        let too_large = vec![VariantModel { model:"block/a".into(), x:0, y:0, uvlock:false, weight:i32::MAX as u32 },
            VariantModel { model:"block/b".into(), x:0, y:0, uvlock:false, weight:1 }];
        assert!(select_weighted_variant_index(&too_large, 0).unwrap_err().contains("total variant weight"));
    }

    #[test]
    fn validates_resource_path() {
        assert_eq!(canonical_blockstate_path("minecraft:oak_log").as_deref(), Some("assets/minecraft/blockstates/oak_log.json"));
        assert!(canonical_blockstate_path("../evil").is_none());
    }
}
