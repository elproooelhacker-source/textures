//! Deterministic atlas planning and lossless RGBA8 PNG rasterization for 1.8.9 block textures.
//!
//! The layout manifest addresses content texels. A two-texel edge-extruded gutter is
//! written around each image. Mipmaps are deliberately not generated here: a 2px
//! gutter is not sufficient for a complete mip chain without per-level repacking.
use image::{ImageBuffer, ImageFormat, Rgba, RgbaImage};
use mc189_core::{Mc189Error, Result};
use serde::{Deserialize, Serialize};
use std::{
    collections::HashSet,
    fs,
    path::{Path, PathBuf},
};

const PNG_SIGNATURE: &[u8; 8] = b"\x89PNG\r\n\x1a\n";
const PADDING: u32 = 2;
const MAX_PAGE: u32 = 2048;
const LAYOUT_FORMAT: &str = "mc189-atlas-layout-v1";

// Animated textures whose frame zero is also needed by the static block renderer.
// Water/lava use their frame aliases in the fluid pass. Sea lantern is currently
// rendered from frame zero until its non-fluid animation scheduler is implemented.
const STATIC_FRAME_ZERO_SPRITES: [&str; 5] = [
    "blocks/water_still.png",
    "blocks/water_flow.png",
    "blocks/lava_still.png",
    "blocks/lava_flow.png",
    "blocks/sea_lantern.png",
];

fn animated_frame_alias(path: &str) -> Option<String> {
    STATIC_FRAME_ZERO_SPRITES.iter().any(|candidate| *candidate == path).then(|| {
        path.strip_suffix(".png").unwrap_or(path).to_owned() + "_frame0.png"
    })
}

#[derive(Clone, Debug)]
struct Texture {
    path: String,
    width: u32,
    height: u32,
}

#[derive(Clone, Debug)]
struct Placement {
    texture: Texture,
    page: u32,
    x: u32,
    y: u32,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
struct AtlasManifest {
    format: String,
    page_size: u32,
    padding: u32,
    page_count: u32,
    static_texture_count: usize,
    animated_texture_count: usize,
    entries: Vec<ManifestEntry>,
    animated: Vec<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
struct ManifestEntry {
    path: String,
    page: u32,
    x: u32,
    y: u32,
    width: u32,
    height: u32,
    u0: f64,
    v0: f64,
    u1: f64,
    v1: f64,
}

fn png_dimensions(path: &Path) -> Result<(u32, u32)> {
    let bytes = fs::read(path)?;
    if bytes.len() < 24 || &bytes[..8] != PNG_SIGNATURE || &bytes[12..16] != b"IHDR" {
        return Err(Mc189Error::InvalidData(format!(
            "invalid PNG header: {}",
            path.display()
        )));
    }
    let width = u32::from_be_bytes(bytes[16..20].try_into().expect("slice length"));
    let height = u32::from_be_bytes(bytes[20..24].try_into().expect("slice length"));
    if width == 0 || height == 0 || width > MAX_PAGE - 3 * PADDING || height > MAX_PAGE - 3 * PADDING {
        return Err(Mc189Error::InvalidData(format!(
            "unsupported atlas texture dimensions {width}x{height}: {}",
            path.display()
        )));
    }
    Ok((width, height))
}

fn collect_pngs(dir: &Path, out: &mut Vec<PathBuf>) -> Result<()> {
    for item in fs::read_dir(dir)? {
        let path = item?.path();
        if path.is_dir() {
            collect_pngs(&path, out)?;
        } else if path.extension().and_then(|s| s.to_str()) == Some("png") {
            out.push(path);
        }
    }
    Ok(())
}

fn has_animation_metadata(png_path: &Path) -> Result<bool> {
    let meta = PathBuf::from(format!("{}.mcmeta", png_path.display()));
    if !meta.is_file() {
        return Ok(false);
    }
    let bytes = fs::read(&meta)?;
    let value: serde_json::Value = serde_json::from_slice(&bytes).map_err(|e| {
        Mc189Error::InvalidData(format!("invalid animation metadata {}: {e}", meta.display()))
    })?;
    Ok(value.get("animation").is_some())
}

/// Plan a deterministic multi-page layout for extracted block PNGs.
pub fn build_atlas_layout(texture_root: &Path, output_json: &Path) -> Result<()> {
    let block_root = texture_root.join("blocks");
    if !block_root.is_dir() {
        return Err(Mc189Error::Usage(format!(
            "block texture directory not found: {}",
            block_root.display()
        )));
    }
    let mut paths = Vec::new();
    collect_pngs(&block_root, &mut paths)?;
    paths.sort();

    let mut static_textures = Vec::new();
    let mut animated = Vec::new();
    for path in paths {
        let relative = path.strip_prefix(texture_root).map_err(|_| {
            Mc189Error::InvalidData("texture escaped root".into())
        })?;
        let name = relative.to_string_lossy().replace('\\', "/");
        if has_animation_metadata(&path)? {
            animated.push(name.clone());
            if let Some(alias) = animated_frame_alias(&name) {
                let (width, height) = png_dimensions(&path)?;
                if height % width != 0 {
                    return Err(Mc189Error::InvalidData(format!(
                        "animated sprite {name} is not a vertical strip of square frames ({width}x{height})"
                    )));
                }
                static_textures.push(Texture { path: alias, width, height: width });
            }
            continue;
        }
        let (width, height) = png_dimensions(&path)?;
        static_textures.push(Texture { path: name, width, height });
    }

    // Stable best-fit-decreasing shelf order: large rectangles first, lexical tie-break.
    static_textures.sort_by(|a, b| {
        (b.height.max(b.width), b.height, b.width, &a.path)
            .cmp(&(a.height.max(a.width), a.height, a.width, &b.path))
    });
    let mut placements = Vec::new();
    let (mut page, mut x, mut y, mut row_h) = (0u32, PADDING, PADDING, 0u32);
    for texture in static_textures.iter().cloned() {
        let w = texture.width + 2 * PADDING;
        let h = texture.height + 2 * PADDING;
        if x + w > MAX_PAGE {
            x = PADDING;
            y += row_h;
            row_h = 0;
        }
        if y + h > MAX_PAGE {
            page += 1;
            x = PADDING;
            y = PADDING;
            row_h = 0;
        }
        placements.push(Placement { texture, page, x: x + PADDING, y: y + PADDING });
        x += w;
        row_h = row_h.max(h);
    }

    let page_count = if placements.is_empty() { 0 } else { page + 1 };
    let mut entries = Vec::with_capacity(placements.len());
    for p in placements {
        entries.push(ManifestEntry {
            path: p.texture.path,
            page: p.page,
            x: p.x,
            y: p.y,
            width: p.texture.width,
            height: p.texture.height,
            u0: p.x as f64 / MAX_PAGE as f64,
            v0: p.y as f64 / MAX_PAGE as f64,
            u1: (p.x + p.texture.width) as f64 / MAX_PAGE as f64,
            v1: (p.y + p.texture.height) as f64 / MAX_PAGE as f64,
        });
    }
    entries.sort_by(|a, b| a.path.cmp(&b.path));
    animated.sort();
    let manifest = AtlasManifest {
        format: LAYOUT_FORMAT.into(),
        page_size: MAX_PAGE,
        padding: PADDING,
        page_count,
        static_texture_count: entries.len(),
        animated_texture_count: animated.len(),
        entries,
        animated,
    };
    if let Some(parent) = output_json.parent() {
        fs::create_dir_all(parent)?;
    }
    let json = serde_json::to_vec_pretty(&manifest)
        .map_err(|e| Mc189Error::InvalidData(format!("could not serialize atlas manifest: {e}")))?;
    fs::write(output_json, json)?;
    println!("Minecraft 1.8.9 block texture atlas layout");
    println!("  Texture root: {}", texture_root.display());
    println!("  Manifest: {}", output_json.display());
    println!("  Static block textures placed: {}", manifest.static_texture_count);
    println!("  Animated block textures kept separate: {}", manifest.animated_texture_count);
    println!("  Atlas pages required: {} ({}x{} each)", manifest.page_count, MAX_PAGE, MAX_PAGE);
    println!("  Reserved gutter: {} px per side", PADDING);
    println!("  Note: layout only; use build-block-texture-atlas to rasterize PNG pages.");
    Ok(())
}


/// Ensure the atlas used by gameplay contains a static frame-zero alias for the
/// animated sea lantern sprite. Old output directories were built before that
/// alias existed, so merely updating the executable would otherwise leave the
/// lantern invisible until the user manually rebuilt the atlas.
pub fn ensure_gameplay_atlas(jar_path: &Path, output_dir: &Path) -> Result<()> {
    let manifest_path = output_dir.join("block-atlas-manifest.json");
    let current_manifest = fs::read(&manifest_path).ok()
        .and_then(|bytes| serde_json::from_slice::<AtlasManifest>(&bytes).ok());
    let atlas_is_current = current_manifest.as_ref().is_some_and(|manifest| {
        manifest.format == LAYOUT_FORMAT
            && manifest.entries.iter().any(|entry| entry.path == "blocks/sea_lantern_frame0.png")
            && (0..manifest.page_count).all(|page| output_dir.join(format!("block-atlas-{page}.png")).is_file())
    });
    if atlas_is_current {
        return Ok(());
    }

    println!("Refreshing block atlas: animated sea lantern frame zero is missing from the existing atlas.");
    fs::create_dir_all(output_dir)?;
    let texture_root = output_dir.join(".mc189-atlas-source-textures");
    let layout_path = output_dir.join(".mc189-atlas-layout.json");
    if texture_root.exists() {
        fs::remove_dir_all(&texture_root)?;
    }
    crate::client_textures::extract_client_textures(jar_path, &texture_root)?;
    build_atlas_layout(&texture_root, &layout_path)?;
    build_block_texture_atlas(&texture_root, &layout_path, output_dir)?;
    let _ = fs::remove_dir_all(&texture_root);
    let _ = fs::remove_file(&layout_path);
    println!("Block atlas refreshed with the static sea-lantern frame-zero texture.");
    Ok(())
}

fn checked_rect(entry: &ManifestEntry, manifest: &AtlasManifest) -> Result<(u32, u32, u32, u32)> {
    if entry.page >= manifest.page_count || entry.width == 0 || entry.height == 0 {
        return Err(Mc189Error::InvalidData(format!("invalid page or dimensions for {}", entry.path)));
    }
    let pad = manifest.padding;
    let left = entry.x.checked_sub(pad).ok_or_else(|| Mc189Error::InvalidData(format!("left gutter outside page for {}", entry.path)))?;
    let top = entry.y.checked_sub(pad).ok_or_else(|| Mc189Error::InvalidData(format!("top gutter outside page for {}", entry.path)))?;
    let right = entry.x.checked_add(entry.width).and_then(|v| v.checked_add(pad))
        .ok_or_else(|| Mc189Error::InvalidData(format!("rectangle overflow for {}", entry.path)))?;
    let bottom = entry.y.checked_add(entry.height).and_then(|v| v.checked_add(pad))
        .ok_or_else(|| Mc189Error::InvalidData(format!("rectangle overflow for {}", entry.path)))?;
    if right > manifest.page_size || bottom > manifest.page_size {
        return Err(Mc189Error::InvalidData(format!("content or gutter exceeds page for {}", entry.path)));
    }
    let expected = (
        entry.x as f64 / manifest.page_size as f64,
        entry.y as f64 / manifest.page_size as f64,
        (entry.x + entry.width) as f64 / manifest.page_size as f64,
        (entry.y + entry.height) as f64 / manifest.page_size as f64,
    );
    let actual = (entry.u0, entry.v0, entry.u1, entry.v1);
    if [expected.0, expected.1, expected.2, expected.3]
        .iter().zip([actual.0, actual.1, actual.2, actual.3].iter())
        .any(|(a, b)| !b.is_finite() || (a - b).abs() > 1e-12)
    {
        return Err(Mc189Error::InvalidData(format!("UV coordinates do not match pixel rectangle for {}", entry.path)));
    }
    Ok((left, top, right, bottom))
}

fn validate_manifest(manifest: &AtlasManifest) -> Result<()> {
    if manifest.format != LAYOUT_FORMAT || manifest.page_size != MAX_PAGE || manifest.padding != PADDING {
        return Err(Mc189Error::InvalidData("unsupported atlas manifest format, page size, or gutter size".into()));
    }
    if manifest.static_texture_count != manifest.entries.len()
        || manifest.animated_texture_count != manifest.animated.len()
    {
        return Err(Mc189Error::InvalidData("atlas manifest counts do not match entry arrays".into()));
    }
    if manifest.page_count == 0 && !manifest.entries.is_empty() {
        return Err(Mc189Error::InvalidData("non-empty atlas has zero pages".into()));
    }
    if manifest.page_count as usize > manifest.entries.len() {
        return Err(Mc189Error::InvalidData("atlas page count exceeds the number of static textures".into()));
    }
    let mut names = HashSet::new();
    let mut rects: Vec<(u32, u32, u32, u32, u32, String)> = Vec::new();
    for path in &manifest.animated {
        let relative = Path::new(path);
        if relative.is_absolute() || relative.components().any(|c| matches!(c, std::path::Component::ParentDir | std::path::Component::RootDir | std::path::Component::Prefix(_))) || path.contains("..\\") || !path.starts_with("blocks/") {
            return Err(Mc189Error::InvalidData(format!("unsafe animated texture path: {path}")));
        }
        if !names.insert(path.as_str()) {
            return Err(Mc189Error::InvalidData(format!("duplicate animated texture path: {path}")));
        }
    }
    for entry in &manifest.entries {
        let relative = Path::new(&entry.path);
        if relative.is_absolute() || relative.components().any(|c| matches!(c, std::path::Component::ParentDir | std::path::Component::RootDir | std::path::Component::Prefix(_))) || entry.path.contains("..\\") || !entry.path.starts_with("blocks/") {
            return Err(Mc189Error::InvalidData(format!("unsafe or non-block texture path: {}", entry.path)));
        }
        if !names.insert(entry.path.as_str()) {
            return Err(Mc189Error::InvalidData(format!("duplicate atlas path: {}", entry.path)));
        }
        let (l, t, r, b) = checked_rect(entry, manifest)?;
        for (other_page, ol, ot, or_, ob, other_name) in &rects {
            if *other_page == entry.page && l < *or_ && r > *ol && t < *ob && b > *ot {
                return Err(Mc189Error::InvalidData(format!(
                    "gutter overlap between {} and {}", entry.path, other_name
                )));
            }
        }
        rects.push((entry.page, l, t, r, b, entry.path.clone()));
    }
    Ok(())
}

fn copy_animated_assets(texture_root: &Path, output_dir: &Path, paths: &[String]) -> Result<()> {
    let animated_root = output_dir.join("animated");
    for relative in paths {
        let source = texture_root.join(relative);
        let meta_source = PathBuf::from(format!("{}.mcmeta", source.display()));
        if !source.is_file() || !meta_source.is_file() {
            return Err(Mc189Error::InvalidData(format!(
                "animated texture or its .mcmeta is missing: {}", source.display()
            )));
        }
        let meta: serde_json::Value = serde_json::from_slice(&fs::read(&meta_source)?).map_err(|e| {
            Mc189Error::InvalidData(format!("invalid animation metadata {}: {e}", meta_source.display()))
        })?;
        if meta.get("animation").is_none() {
            return Err(Mc189Error::InvalidData(format!("missing animation object in {}", meta_source.display())));
        }
        let destination = animated_root.join(relative);
        if let Some(parent) = destination.parent() { fs::create_dir_all(parent)?; }
        fs::copy(&source, &destination)?;
        fs::copy(&meta_source, PathBuf::from(format!("{}.mcmeta", destination.display())))?;
    }
    Ok(())
}

/// Rasterize an existing layout manifest into RGBA8 PNG pages with edge-extruded gutters.
pub fn build_block_texture_atlas(texture_root: &Path, layout_json: &Path, output_dir: &Path) -> Result<()> {
    let manifest: AtlasManifest = serde_json::from_slice(&fs::read(layout_json)?).map_err(|e| {
        Mc189Error::InvalidData(format!("could not parse atlas manifest {}: {e}", layout_json.display()))
    })?;
    validate_manifest(&manifest)?;
    if !texture_root.join("blocks").is_dir() {
        return Err(Mc189Error::Usage(format!("block texture directory not found: {}", texture_root.join("blocks").display())));
    }

    fs::create_dir_all(output_dir)?;
    let mut pages: Vec<RgbaImage> = (0..manifest.page_count)
        .map(|_| ImageBuffer::from_pixel(manifest.page_size, manifest.page_size, Rgba([0, 0, 0, 0])))
        .collect();

    for entry in &manifest.entries {
        let (source_path, first_frame) = if let Some(base) = entry.path.strip_suffix("_frame0.png") {
            (texture_root.join(format!("{base}.png")), true)
        } else {
            (texture_root.join(&entry.path), false)
        };
        let decoded = image::ImageReader::open(&source_path)
            .map_err(|e| Mc189Error::InvalidData(format!("cannot open {}: {e}", source_path.display())))?
            .with_guessed_format()
            .map_err(|e| Mc189Error::InvalidData(format!("cannot identify {}: {e}", source_path.display())))?
            .decode()
            .map_err(|e| Mc189Error::InvalidData(format!("cannot decode {}: {e}", source_path.display())))?;
        let decoded = decoded.to_rgba8();
        let source = if first_frame {
            if decoded.width() != entry.width || decoded.height() < entry.height {
                return Err(Mc189Error::InvalidData(format!(
                    "invalid first-frame dimensions for {}: manifest {}x{}, decoded {}x{}",
                    entry.path, entry.width, entry.height, decoded.width(), decoded.height()
                )));
            }
            image::imageops::crop_imm(&decoded, 0, 0, entry.width, entry.height).to_image()
        } else {
            if decoded.width() != entry.width || decoded.height() != entry.height {
                return Err(Mc189Error::InvalidData(format!(
                    "dimension mismatch for {}: manifest {}x{}, decoded {}x{}",
                    entry.path, entry.width, entry.height, decoded.width(), decoded.height()
                )));
            }
            decoded
        };
        let destination = &mut pages[entry.page as usize];
        let pad = manifest.padding as i64;
        for dy in -pad..(entry.height as i64 + pad) {
            for dx in -pad..(entry.width as i64 + pad) {
                let sx = dx.clamp(0, entry.width as i64 - 1) as u32;
                let sy = dy.clamp(0, entry.height as i64 - 1) as u32;
                let pixel = *source.get_pixel(sx, sy);
                let tx = (entry.x as i64 + dx) as u32;
                let ty = (entry.y as i64 + dy) as u32;
                destination.put_pixel(tx, ty, pixel);
            }
        }
    }

    for (index, page) in pages.iter().enumerate() {
        let path = output_dir.join(format!("block-atlas-{index}.png"));
        page.save_with_format(&path, ImageFormat::Png).map_err(|e| {
            Mc189Error::InvalidData(format!("cannot write atlas page {}: {e}", path.display()))
        })?;
    }
    copy_animated_assets(texture_root, output_dir, &manifest.animated)?;
    let output_manifest = output_dir.join("block-atlas-manifest.json");
    fs::copy(layout_json, &output_manifest)?;

    println!("Minecraft 1.8.9 block texture atlas rasterization");
    println!("  Static textures rasterized: {}", manifest.entries.len());
    println!("  RGBA8 pages written: {}", manifest.page_count);
    println!("  Page dimensions: {}x{}", manifest.page_size, manifest.page_size);
    println!("  Edge-extruded gutter: {} px", manifest.padding);
    println!("  Animated textures copied separately: {}", manifest.animated.len());
    println!("  Output: {}", output_dir.display());
    println!("  Mipmaps: one safe half-resolution level generated at GPU upload; deeper atlas levels are intentionally disabled to prevent sprite bleeding");
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn animated_sprites_needed_by_block_rendering_receive_frame_zero_aliases() {
        assert_eq!(animated_frame_alias("blocks/water_still.png").as_deref(), Some("blocks/water_still_frame0.png"));
        assert_eq!(animated_frame_alias("blocks/lava_flow.png").as_deref(), Some("blocks/lava_flow_frame0.png"));
        assert_eq!(animated_frame_alias("blocks/sea_lantern.png").as_deref(), Some("blocks/sea_lantern_frame0.png"));
        assert_eq!(animated_frame_alias("blocks/fire_0.png"), None);
    }

    #[test]
    fn layout_constants_leave_room_for_gutters() {
        assert_eq!(MAX_PAGE, 2048);
        assert_eq!(PADDING, 2);
    }

    #[test]
    fn png_header_dimensions_are_read_without_assuming_square_images() {
        let dir = std::env::temp_dir().join(format!("mc189-atlas-test-{}", std::process::id()));
        fs::create_dir_all(&dir).unwrap();
        let path = dir.join("wide.png");
        let mut bytes = vec![0u8; 24];
        bytes[..8].copy_from_slice(PNG_SIGNATURE);
        bytes[12..16].copy_from_slice(b"IHDR");
        bytes[16..20].copy_from_slice(&64u32.to_be_bytes());
        bytes[20..24].copy_from_slice(&32u32.to_be_bytes());
        fs::write(&path, bytes).unwrap();
        assert_eq!(png_dimensions(&path).unwrap(), (64, 32));
        let _ = fs::remove_dir_all(dir);
    }

    #[test]
    fn manifest_rejects_overlapping_gutters() {
        let entry = |path: &str, x: u32| ManifestEntry {
            path: path.into(), page: 0, x, y: 4, width: 16, height: 16,
            u0: x as f64 / 2048.0, v0: 4.0 / 2048.0,
            u1: (x + 16) as f64 / 2048.0, v1: 20.0 / 2048.0,
        };
        let manifest = AtlasManifest {
            format: LAYOUT_FORMAT.into(), page_size: MAX_PAGE, padding: PADDING,
            page_count: 1, static_texture_count: 2, animated_texture_count: 0,
            entries: vec![entry("blocks/a.png", 4), entry("blocks/b.png", 23)], animated: vec![],
        };
        assert!(validate_manifest(&manifest).is_err());
    }

    #[test]
    fn manifest_accepts_adjacent_non_overlapping_gutters() {
        let entry = |path: &str, x: u32| ManifestEntry {
            path: path.into(), page: 0, x, y: 4, width: 16, height: 16,
            u0: x as f64 / 2048.0, v0: 4.0 / 2048.0,
            u1: (x + 16) as f64 / 2048.0, v1: 20.0 / 2048.0,
        };
        let manifest = AtlasManifest {
            format: LAYOUT_FORMAT.into(), page_size: MAX_PAGE, padding: PADDING,
            page_count: 1, static_texture_count: 2, animated_texture_count: 0,
            entries: vec![entry("blocks/a.png", 4), entry("blocks/b.png", 24)], animated: vec![],
        };
        assert!(validate_manifest(&manifest).is_ok());
    }

    #[test]
    fn edge_extrusion_copies_corner_and_edge_texels() {
        let mut source = RgbaImage::new(2, 2);
        source.put_pixel(0, 0, Rgba([1, 2, 3, 4]));
        source.put_pixel(1, 0, Rgba([5, 6, 7, 8]));
        source.put_pixel(0, 1, Rgba([9, 10, 11, 12]));
        source.put_pixel(1, 1, Rgba([13, 14, 15, 16]));
        let mut target = RgbaImage::from_pixel(6, 6, Rgba([0, 0, 0, 0]));
        let padding = 2i64;
        for dy in -padding..(2 + padding) {
            for dx in -padding..(2 + padding) {
                let sx = dx.clamp(0, 1) as u32;
                let sy = dy.clamp(0, 1) as u32;
                target.put_pixel((2 + dx) as u32, (2 + dy) as u32, *source.get_pixel(sx, sy));
            }
        }
        assert_eq!(*target.get_pixel(0, 0), Rgba([1, 2, 3, 4]));
        assert_eq!(*target.get_pixel(5, 0), Rgba([5, 6, 7, 8]));
        assert_eq!(*target.get_pixel(0, 5), Rgba([9, 10, 11, 12]));
        assert_eq!(*target.get_pixel(5, 5), Rgba([13, 14, 15, 16]));
        assert_eq!(*target.get_pixel(2, 3), Rgba([9, 10, 11, 12]));
    }
}
