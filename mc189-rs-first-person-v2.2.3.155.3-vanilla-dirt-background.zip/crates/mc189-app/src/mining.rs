//! Client-side world-item presentation. Block-drop spawning and simulation live in mc189-server;
//! the remaining local player-drop path is scheduled for the inventory command migration.
use glam::Vec3;
use crate::player::BlockCollision;
pub use mc189_server::mining::{BlockPos, ToolKind, ToolTier, HeldTool, MiningContext, BlockInfo, block_info, held_tool_from_item_id, can_harvest, damage_per_tick, RayHit, raycast, MiningEvent, MiningController};
#[derive(Debug, Clone, PartialEq)]
pub struct DroppedItem {
    pub item_id: u16,
    /// Legacy variant / item damage stored by Minecraft ItemStack (short in NBT).
    pub metadata: u16,
    pub count: u8,
    /// Preserve the ItemStack tag when a player manually drops a named/enchanted item.
    pub nbt_tag: Option<mc189_storage::NbtTag>,
    /// Previous fixed-tick position, retained for render-frame interpolation.
    pub previous_position: Vec3,
    pub position: Vec3,
    pub velocity: Vec3,
    pub age: u16,
    pub pickup_delay: u16,
    pub hover_start: f32,
    /// Block-edit revision awaiting acceptance by the in-memory edit worker.
    /// `None` means the drop is part of the live session state; disk persistence
    /// is deferred to world checkpoints and the final shutdown flush.
    pub pending_edit_revision: Option<u64>,
}
impl DroppedItem {
    /// Build a short-lived client presentation copy from a confirmed server pickup.
    /// It is never inserted into the world entity list or used for gameplay.
    pub fn from_server_pickup(item_id: u16, metadata: u16, count: u16, position: Vec3, age: u16) -> Option<Self> {
        let count = u8::try_from(count).ok()?;
        if item_id == 0 || count == 0 { return None; }
        Some(Self { item_id, metadata, count, nbt_tag: None,
            previous_position: position, position, velocity: Vec3::ZERO, age,
            pickup_delay: 0, hover_start: hover_phase(position, item_id, metadata, count),
            pending_edit_revision: None })
    }

    /// Test-only fixture constructor. Production block drops are spawned by the server.
    #[cfg(test)]
    fn spawn(pos:BlockPos, info:BlockInfo, seed:u64)->Option<Self> {
        if info.drop_id==0 || info.drop_count==0 { return None; }
        let mut rng=crate::drop_registry::JavaRandom::new(seed);
        let position=Vec3::new(
            pos.x as f32+0.25+rng.next_float()*0.5,
            pos.y as f32+0.25+rng.next_float()*0.5,
            pos.z as f32+0.25+rng.next_float()*0.5,
        );
        let velocity=Vec3::new((rng.next_float()-0.5)*0.2,0.2,(rng.next_float()-0.5)*0.2);
        let metadata=u16::from(info.drop_meta);
        let hover_start=hover_phase(position,info.drop_id,metadata,info.drop_count);
        Some(Self { item_id:info.drop_id,metadata,count:info.drop_count,nbt_tag:None,
            previous_position:position,position,velocity,age:0,pickup_delay:10,hover_start,pending_edit_revision:None })
    }

    /// EntityPlayer.dropOneItem/dropItem from MCP 1.8.9. The item appears at
    /// posY - 0.3 + eyeHeight, flies along the look vector, receives the small
    /// vanilla random impulse, and is protected from pickup for 40 ticks.
    pub fn spawn_from_player_drop(
        stack: &crate::inventory::ItemStack,
        item_id: u16,
        player: crate::player::PlayerState,
        rng: &mut crate::drop_registry::JavaRandom,
    ) -> Option<Self> {
        if item_id == 0 || stack.count == 0 { return None; }
        let count = u8::try_from(stack.count).ok()?;
        let position = Vec3::new(
            player.position.x,
            player.position.y - 0.30000001192092896 + f64::from(crate::player::PLAYER_EYE_HEIGHT) as f32,
            player.position.z,
        );
        let direction = player.look_direction();
        let mut velocity = direction * 0.3 + Vec3::Y * 0.1;
        let angle = rng.next_float() * std::f32::consts::TAU;
        let spread = 0.02 * rng.next_float();
        velocity.x += angle.cos() * spread;
        velocity.y += (rng.next_float() - rng.next_float()) * 0.1;
        velocity.z += angle.sin() * spread;
        let metadata = stack.damage;
        let hover_start = hover_phase(position, item_id, metadata, count);
        Some(Self {
            item_id, metadata, count, nbt_tag: stack.nbt_tag.clone(),
            previous_position: position, position, velocity, age: 0, pickup_delay: 40,
            hover_start, pending_edit_revision: None,
        })
    }

    /// One vanilla entity update (world tick), not a frame-delta integration.
    /// Item gravity is 0.04 blocks/tick²; age 6000 is the five-minute despawn.
    pub fn tick_vanilla(&mut self){
        self.previous_position = self.position;
        self.velocity.y-=0.04;
        self.position+=self.velocity;
        self.velocity*=0.98;
        self.age=self.age.saturating_add(1);
        self.pickup_delay=self.pickup_delay.saturating_sub(1);
    }

    /// EntityItem.onUpdate + Entity.moveEntity collision order from MCP 1.8.9.
    /// EntityItem has a 0.25 x 0.25 AABB; movement is clipped against every
    /// block collision shape on Y, then X, then Z, so drops cannot pass through
    /// walls, ceilings, slabs, stairs or fences as they previously did.
    pub fn tick_with_block_collision<C: BlockCollision>(&mut self, world: &C) {
        self.previous_position = self.position;
        self.velocity.y -= 0.039_999_999_105_930_33;
        let mut bounds = ItemAabb::from_item_position(self.position);
        let requested = self.velocity;
        let obstacles = collect_item_collision_boxes(world, bounds, requested);

        let mut dy = requested.y;
        for obstacle in &obstacles { dy = obstacle.clip_y(bounds, dy); }
        bounds.offset(Vec3::new(0.0, dy, 0.0));
        let collided_y = (dy - requested.y).abs() > 1.0e-7;
        let on_ground = collided_y && requested.y < 0.0;

        let mut dx = requested.x;
        for obstacle in &obstacles { dx = obstacle.clip_x(bounds, dx); }
        bounds.offset(Vec3::new(dx, 0.0, 0.0));
        let collided_x = (dx - requested.x).abs() > 1.0e-7;

        let mut dz = requested.z;
        for obstacle in &obstacles { dz = obstacle.clip_z(bounds, dz); }
        bounds.offset(Vec3::new(0.0, 0.0, dz));
        let collided_z = (dz - requested.z).abs() > 1.0e-7;

        self.position = Vec3::new((bounds.min.x + bounds.max.x) * 0.5, bounds.min.y,
            (bounds.min.z + bounds.max.z) * 0.5);
        if collided_x { self.velocity.x = 0.0; }
        if collided_y { self.velocity.y = 0.0; }
        if collided_z { self.velocity.z = 0.0; }

        // EntityItem uses block.slipperiness * 0.98 on the ground (0.6 for
        // ordinary blocks), 0.98 in air, then a half-strength vertical bounce.
        let horizontal_drag = if on_ground { 0.6 * 0.98 } else { 0.98 };
        self.velocity.x *= horizontal_drag;
        self.velocity.y *= 0.980_000_019_073_486_3;
        self.velocity.z *= horizontal_drag;
        if on_ground { self.velocity.y *= -0.5; }

        self.age = self.age.saturating_add(1);
        self.pickup_delay = self.pickup_delay.saturating_sub(1);
    }
    pub fn is_expired(&self)->bool { self.age>=6000 }
    /// Compatibility helper for callers that still advance by elapsed time.
    pub fn tick(&mut self,dt:f32){let ticks=(dt.clamp(0.0,0.25)*20.0).round() as u32;for _ in 0..ticks{self.tick_vanilla();}}
    pub fn is_committed_to_session(&self) -> bool {
        self.pending_edit_revision.is_none()
    }
    pub fn can_merge_with(&self, other: &Self) -> bool {
        self.is_committed_to_session()
            && other.is_committed_to_session()
            && self.item_id == other.item_id
            && self.metadata == other.metadata
            && self.nbt_tag == other.nbt_tag
            && self.position.distance_squared(other.position) < 0.25
    }
    pub fn can_pickup(&self, player: Vec3) -> bool {
        self.is_committed_to_session()
            && self.pickup_delay == 0
            && self.position.distance_squared(player) < 1.0
    }
}

fn hover_phase(position: Vec3, item_id: u16, metadata: u16, count: u8) -> f32 {
    let mut phase = (position.x.floor() as u32).wrapping_mul(0x9E37_79B9)
        ^ (position.y.floor() as u32).wrapping_mul(0x85EB_CA6B)
        ^ (position.z.floor() as u32).wrapping_mul(0xC2B2_AE35)
        ^ u32::from(item_id).wrapping_mul(0x27D4_EB2D)
        ^ u32::from(metadata).wrapping_mul(0x1656_67B1)
        ^ u32::from(count);
    phase ^= phase >> 16;
    phase = phase.wrapping_mul(0x7FEB_352D);
    phase ^= phase >> 15;
    ((phase & 0x00FF_FFFF) as f32 / 16_777_216.0) * std::f32::consts::TAU
}

/// Vanilla EntityPickupFX keeps a visual copy of the collected EntityItem for
/// three world ticks while it follows the interpolated player position using t².
#[derive(Debug, Clone, PartialEq)]
pub struct PickupAnimation {
    pub item: DroppedItem,
    pub age: u8,
}
impl PickupAnimation {
    pub const MAX_AGE: u8 = 3;
    pub fn new(item: DroppedItem) -> Self { Self { item, age: 0 } }
    pub fn tick(&mut self) { self.age = self.age.saturating_add(1); }
    // EntityPickupFX increments age and dies as soon as it reaches maxAge,
    // so the last visible frame approaches age=3 but never renders age=3.
    pub fn is_finished(&self) -> bool { self.age >= Self::MAX_AGE }
    pub fn render_position(&self, previous_player: Vec3, player: Vec3, partial_ticks: f32) -> Vec3 {
        let partial = partial_ticks.clamp(0.0, 1.0);
        let target = previous_player.lerp(player, partial) + Vec3::new(0.0, 0.5, 0.0);
        let progress = ((f32::from(self.age) + partial) / f32::from(Self::MAX_AGE)).clamp(0.0, 1.0);
        self.item.position.lerp(target, progress * progress)
    }
}

#[derive(Debug, Clone, Copy)]
struct ItemAabb { min: Vec3, max: Vec3 }

impl ItemAabb {
    fn from_item_position(position: Vec3) -> Self {
        const HALF_WIDTH: f32 = 0.125;
        const HEIGHT: f32 = 0.25;
        Self {
            min: Vec3::new(position.x - HALF_WIDTH, position.y, position.z - HALF_WIDTH),
            max: Vec3::new(position.x + HALF_WIDTH, position.y + HEIGHT, position.z + HALF_WIDTH),
        }
    }
    fn offset(&mut self, delta: Vec3) { self.min += delta; self.max += delta; }
    fn intersects(&self, other: Self) -> bool {
        self.max.x > other.min.x && self.min.x < other.max.x
            && self.max.y > other.min.y && self.min.y < other.max.y
            && self.max.z > other.min.z && self.min.z < other.max.z
    }
    fn clip_y(self, moving: Self, mut offset: f32) -> f32 {
        if moving.max.x > self.min.x && moving.min.x < self.max.x
            && moving.max.z > self.min.z && moving.min.z < self.max.z {
            if offset > 0.0 && moving.max.y <= self.min.y { offset = offset.min(self.min.y - moving.max.y); }
            else if offset < 0.0 && moving.min.y >= self.max.y { offset = offset.max(self.max.y - moving.min.y); }
        }
        offset
    }
    fn clip_x(self, moving: Self, mut offset: f32) -> f32 {
        if moving.max.y > self.min.y && moving.min.y < self.max.y
            && moving.max.z > self.min.z && moving.min.z < self.max.z {
            if offset > 0.0 && moving.max.x <= self.min.x { offset = offset.min(self.min.x - moving.max.x); }
            else if offset < 0.0 && moving.min.x >= self.max.x { offset = offset.max(self.max.x - moving.min.x); }
        }
        offset
    }
    fn clip_z(self, moving: Self, mut offset: f32) -> f32 {
        if moving.max.x > self.min.x && moving.min.x < self.max.x
            && moving.max.y > self.min.y && moving.min.y < self.max.y {
            if offset > 0.0 && moving.max.z <= self.min.z { offset = offset.min(self.min.z - moving.max.z); }
            else if offset < 0.0 && moving.min.z >= self.max.z { offset = offset.max(self.max.z - moving.min.z); }
        }
        offset
    }
}

fn collect_item_collision_boxes<C: BlockCollision>(world: &C, bounds: ItemAabb, motion: Vec3) -> Vec<ItemAabb> {
    let swept_min = bounds.min.min(bounds.min + motion);
    let swept_max = bounds.max.max(bounds.max + motion);
    let min_x = swept_min.x.floor() as i32;
    // Some vanilla collision shapes extend above their owning block cell
    // (fences and closed gates reach 1.5 blocks). Include the cell below the
    // swept item bounds so those protruding shapes are not skipped.
    let min_y = (swept_min.y.floor() as i32).saturating_sub(1);
    let min_z = swept_min.z.floor() as i32;
    let max_x = (swept_max.x - 1.0e-6).floor() as i32;
    let max_y = (swept_max.y - 1.0e-6).floor() as i32;
    let max_z = (swept_max.z - 1.0e-6).floor() as i32;
    let mut result = Vec::new();
    for y in min_y..=max_y {
        for z in min_z..=max_z {
            for x in min_x..=max_x {
                for shape in world.collision_boxes(x, y, z) {
                    let obstacle = ItemAabb {
                        min: Vec3::new(x as f32 + shape.min[0], y as f32 + shape.min[1], z as f32 + shape.min[2]),
                        max: Vec3::new(x as f32 + shape.max[0], y as f32 + shape.max[1], z as f32 + shape.max[2]),
                    };
                    if bounds.intersects(obstacle) || swept_min.x < obstacle.max.x && swept_max.x > obstacle.min.x
                        && swept_min.y < obstacle.max.y && swept_max.y > obstacle.min.y
                        && swept_min.z < obstacle.max.z && swept_max.z > obstacle.min.z {
                        result.push(obstacle);
                    }
                }
            }
        }
    }
    result
}

#[cfg(test)] mod tests {
 use super::*;
 #[test] fn stone_brick_preserves_its_variant_metadata(){let b=block_info(98,3).unwrap();assert_eq!(b.drop_id,98);assert_eq!(b.drop_meta,3);}
 #[test] fn stone_diamond_pickaxe_damage_matches_vanilla(){let b=block_info(1,0).unwrap();let t=HeldTool{kind:ToolKind::Pickaxe,tier:ToolTier::Diamond,efficiency:0};assert!((damage_per_tick(b,t,MiningContext::default())-8.0/1.5/30.0).abs()<1e-6);}
 #[test] fn wrong_tool_uses_hundred_denominator(){let b=block_info(1,0).unwrap();assert!((damage_per_tick(b,HeldTool::default(),MiningContext::default())-1.0/1.5/100.0).abs()<1e-6);}
 #[test] fn selected_item_names_resolve_to_vanilla_tool_tiers(){assert_eq!(held_tool_from_item_id(Some("diamond_pickaxe")),HeldTool{kind:ToolKind::Pickaxe,tier:ToolTier::Diamond,efficiency:0});assert_eq!(held_tool_from_item_id(Some("minecraft:diamond_pickaxe")).tier,ToolTier::Diamond);assert_eq!(held_tool_from_item_id(Some("wooden_shovel")).tier,ToolTier::Wood);assert_eq!(held_tool_from_item_id(Some("iron_axe")).kind,ToolKind::Axe);assert_eq!(held_tool_from_item_id(Some("shears")).kind,ToolKind::Shears);assert_eq!(held_tool_from_item_id(Some("stick")),HeldTool::default());}
 #[test] fn target_change_and_release_reset_progress(){let mut c=MiningController::default();let b=block_info(1,0).unwrap();let h=Some((BlockPos{x:1,y:2,z:3},b));c.tick(h,true,HeldTool::default(),MiningContext::default());assert!(c.progress()>0.0);c.tick(Some((BlockPos{x:2,y:2,z:3},b)),true,HeldTool::default(),MiningContext::default());assert!(c.progress()<0.01);assert_eq!(c.tick(None,false,HeldTool::default(),MiningContext::default()),MiningEvent::Cancelled);assert_eq!(c.progress(),0.0);}
 #[test] fn raycast_hits_first_voxel_and_reports_face(){let hit=raycast(Vec3::new(0.5,0.5,0.5),Vec3::Z,4.5,|p|p==BlockPos{x:0,y:0,z:2}).unwrap();assert_eq!(hit.pos,BlockPos{x:0,y:0,z:2});assert_eq!(hit.face,[0,0,-1]);assert!((hit.distance-1.5).abs()<1e-6);}
 #[test] fn pickup_animation_uses_three_tick_quadratic_path_to_player(){
   let item = DroppedItem { item_id:264, metadata:0, count:1, nbt_tag: None, previous_position:Vec3::ZERO,
     position:Vec3::new(1.0,2.0,3.0), velocity:Vec3::ZERO, age:0, pickup_delay:0,
     hover_start:0.0, pending_edit_revision:None };
   let mut pickup = PickupAnimation::new(item.clone());
   let player = Vec3::new(1.0,1.0,1.0);
   assert_eq!(pickup.render_position(player,player,0.0),item.position);
   pickup.age=1;
   let target=player+Vec3::new(0.0,0.5,0.0);
   assert!(pickup.render_position(player,player,0.0).distance(item.position.lerp(target,1.0/9.0))<1.0e-6);
   pickup.age=2;
   assert_eq!(pickup.render_position(player,player,1.0),target);
   assert!(!pickup.is_finished());
   pickup.tick();
   assert!(pickup.is_finished());
 }
 #[test] fn player_drop_uses_vanilla_position_velocity_delay_and_preserves_nbt(){
   let mut rng=crate::drop_registry::JavaRandom::new(17);
   let stack=crate::inventory::ItemStack{id:"diamond".into(),count:3,damage:0,nbt_tag:Some(mc189_storage::NbtTag::Compound(vec![("display".into(),mc189_storage::NbtTag::Compound(vec![("Name".into(),mc189_storage::NbtTag::String("Test".into()))]))]))};
   let mut player=crate::player::PlayerState::at(Vec3::new(2.0,64.0,3.0));
   player.yaw=0.0; player.pitch=0.0;
   let item=DroppedItem::spawn_from_player_drop(&stack,264,player,&mut rng).unwrap();
   assert_eq!(item.count,3);
   assert_eq!(item.pickup_delay,40);
   assert_eq!(item.nbt_tag,stack.nbt_tag);
   assert!((item.position.y-(64.0-0.3+crate::player::PLAYER_EYE_HEIGHT)).abs()<1e-5);
   assert!(item.velocity.z>0.29 && item.velocity.z<0.32);
 }
 #[test] fn drops_have_vanilla_centered_spawn_and_delay(){let d=DroppedItem::spawn(BlockPos{x:1,y:2,z:3},block_info(1,0).unwrap(),42).unwrap();assert!(d.position.x>=1.25&&d.position.x<=1.75);assert_eq!(d.pickup_delay,10);}
 #[test] fn provisional_drop_cannot_be_picked_up_until_its_edit_is_committed(){
   let mut d = DroppedItem::spawn(BlockPos{x:0,y:0,z:0}, block_info(1,0).unwrap(), 9).unwrap();
   d.pickup_delay = 0;
   d.pending_edit_revision = Some(42);
   assert!(!d.can_pickup(Vec3::ZERO));
   d.pending_edit_revision = None;
   assert!(d.can_pickup(Vec3::ZERO));
 }
 #[test] fn provisional_drop_cannot_merge_until_its_edit_is_committed(){
   let mut a = DroppedItem::spawn(BlockPos{x:0,y:0,z:0}, block_info(1,0).unwrap(), 9).unwrap();
   let b = a.clone();
   assert!(a.can_merge_with(&b));
   a.pending_edit_revision = Some(77);
   assert!(!a.can_merge_with(&b));
 }

 #[test] fn dropped_item_collides_with_vertical_wall_on_x_axis(){
   struct World;
   impl BlockCollision for World { fn is_solid(&self,x:i32,y:i32,z:i32)->bool { (x,y,z)==(1,0,0) } }
   let mut item = DroppedItem::spawn(BlockPos{x:0,y:0,z:0}, block_info(1,0).unwrap(), 3).unwrap();
   item.position = Vec3::new(0.75, 0.2, 0.5);
   item.previous_position = item.position;
   item.velocity = Vec3::new(0.5, 0.0, 0.0);
   item.tick_with_block_collision(&World);
   assert!(item.position.x <= 0.875001, "item AABB must stop at the wall, got {}", item.position.x);
   assert_eq!(item.velocity.x, 0.0, "horizontal motion must be clipped rather than pass through the wall");
 }
 #[test] fn dropped_item_collides_with_fence_shape_that_extends_above_its_cell(){
   struct FenceWorld;
   impl BlockCollision for FenceWorld {
     fn is_solid(&self,_x:i32,_y:i32,_z:i32)->bool { false }
     fn collision_boxes(&self,x:i32,y:i32,z:i32)->Vec<crate::player::BlockCollisionBox> {
       if (x,y,z)==(1,0,0) {
         vec![crate::player::BlockCollisionBox { min:[0.0,0.0,0.375], max:[1.0,1.5,0.625] }]
       } else { Vec::new() }
     }
   }
   let mut item = DroppedItem::spawn(BlockPos{x:0,y:1,z:0}, block_info(1,0).unwrap(), 8).unwrap();
   item.position = Vec3::new(0.75, 1.3, 0.5);
   item.previous_position = item.position;
   item.velocity = Vec3::new(0.5, 0.0, 0.0);
   item.tick_with_block_collision(&FenceWorld);
   assert!(item.position.x <= 0.875001, "the protruding fence collision must stop the item, got {}", item.position.x);
   assert_eq!(item.velocity.x, 0.0);
 }
 #[test] fn dropped_item_lands_on_floor_using_its_bottom_aabb(){
   struct World;
   impl BlockCollision for World { fn is_solid(&self,x:i32,y:i32,z:i32)->bool { (x,y,z)==(0,0,0) } }
   let mut item = DroppedItem::spawn(BlockPos{x:0,y:0,z:0}, block_info(1,0).unwrap(), 4).unwrap();
   item.position = Vec3::new(0.5, 1.1, 0.5);
   item.previous_position = item.position;
   item.velocity = Vec3::new(0.0, -0.3, 0.0);
   item.tick_with_block_collision(&World);
   assert!((item.position.y - 1.0).abs() < 1.0e-5, "0.25-high item should rest on top of the block, got {}", item.position.y);
   assert!(item.velocity.y.abs() < 1.0e-6, "vertical velocity should be zero after floor contact");
 }
 #[test] fn dropped_item_keeps_previous_fixed_tick_position_for_interpolation(){
   struct Empty;
   impl BlockCollision for Empty { fn is_solid(&self,_x:i32,_y:i32,_z:i32)->bool { false } }
   let mut item = DroppedItem::spawn(BlockPos{x:0,y:4,z:0}, block_info(1,0).unwrap(), 5).unwrap();
   let before = item.position;
   item.velocity = Vec3::new(0.1, 0.0, 0.0);
   item.tick_with_block_collision(&Empty);
   assert_eq!(item.previous_position, before);
   assert!(item.position.x > before.x);
 }
 #[test] fn vanilla_item_tick_applies_per_tick_gravity_drag_and_despawn_age(){let mut d=DroppedItem{item_id:1,metadata:0,count:1,nbt_tag:None,previous_position:Vec3::ZERO,position:Vec3::ZERO,velocity:Vec3::new(0.1,0.2,-0.1),age:5999,pickup_delay:1,hover_start:0.0,pending_edit_revision:None};d.tick_vanilla();assert!((d.velocity.y-0.1568).abs()<1e-6);assert!((d.velocity.x-0.098).abs()<1e-6);assert_eq!(d.age,6000);assert_eq!(d.pickup_delay,0);assert!(d.is_expired());}
}
