//! Textured single-model preview. This is a focused validation viewer, not yet a world renderer.
use crate::blockstate_resolver::{load_blockstate_variant, select_weighted_variant_index};
use crate::client_atlas_runtime::{AtlasRuntime, GpuAtlasPage};
use crate::model_resolver::{load_model_quads, CpuMeshQuad, ItemCameraTransform, ModelCatalog, ModelFaceDirection};
use crate::player::{self, BlockCollision, LoadedWorldCollision, PlayerInput, PlayerState};
use crate::textured_chunk::{vanilla_celestial_angle, vanilla_lightmap_rgb, vanilla_sun_brightness, vanilla_sun_brightness_at, ChunkStreamer, GameplayBlockEditWorker, GameplayBlockEditRequest, WorldSaveRequest, PlayerDataSnapshot, EntityItemsSnapshot, DirtyChunkSnapshot, STREAM_RADIUS_CHUNKS, RETAIN_RADIUS_CHUNKS};
use crate::mining::{self, BlockPos, DroppedItem, MiningContext, MiningEvent};
use glam::{Mat4, Quat, Vec3};
use mc189_core::{Mc189Error, Result};
use mc189_server::runtime::IntegratedServer;
use mc189_server::entity_item::EntityItemSnapshot;
use std::mem::size_of;
use std::path::Path;
use std::fs::File;
use std::io::Read;
use zip::ZipArchive;
use std::sync::{mpsc, Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
use std::collections::{BTreeMap, HashMap, HashSet, VecDeque};
use wgpu::util::DeviceExt;
use winit::dpi::PhysicalSize;
use winit::event::{DeviceEvent, ElementState, Event, MouseButton, MouseScrollDelta, WindowEvent};
use winit::event_loop::{ControlFlow, EventLoop};
use winit::platform::run_on_demand::EventLoopExtRunOnDemand;
use winit::keyboard::{KeyCode, PhysicalKey};
use winit::window::{Window, WindowBuilder};


/// java.util.Random's 48-bit generator, preserving the random sequence
/// semantics used by Java 1.8.9 Math.random() for torch flicker.
#[derive(Clone, Debug)]
struct JavaRandom48 { seed: u64 }
impl JavaRandom48 {
    const MULTIPLIER: u64 = 0x5DEECE66D;
    const ADDEND: u64 = 0xB;
    const MASK: u64 = (1_u64 << 48) - 1;
    fn new(seed: u64) -> Self { Self { seed: (seed ^ Self::MULTIPLIER) & Self::MASK } }
    fn next_bits(&mut self, bits: u32) -> u32 {
        self.seed = self.seed.wrapping_mul(Self::MULTIPLIER).wrapping_add(Self::ADDEND) & Self::MASK;
        (self.seed >> (48 - bits)) as u32
    }
    fn next_double(&mut self) -> f64 {
        let high = u64::from(self.next_bits(26));
        let low = u64::from(self.next_bits(27));
        ((high << 27) + low) as f64 / ((1_u64 << 53) as f64)
    }
    fn next_float(&mut self) -> f32 {
        (self.next_bits(24) as f32) / ((1_u32 << 24) as f32)
    }
}

#[derive(Clone, Debug)]
struct VanillaTorchFlicker { random: JavaRandom48, dx: f32, x: f32 }
impl VanillaTorchFlicker {
    fn new(seed: u64) -> Self { Self { random: JavaRandom48::new(seed), dx: 0.0, x: 0.0 } }
    /// EntityRenderer.updateTorchFlicker(), including Java's double-to-float
    /// conversion points and the original per-render-update accumulator.
    fn update(&mut self) -> f32 {
        let delta = (self.random.next_double() - self.random.next_double())
            * self.random.next_double() * self.random.next_double();
        self.dx = (f64::from(self.dx) + delta) as f32;
        self.dx = (f64::from(self.dx) * 0.9_f64) as f32;
        self.x += (self.dx - self.x) * 1.0_f32;
        self.x
    }
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct Vertex {
    position: [f32; 3],
    normal: [f32; 3],
    uv: [f32; 2],
    tint: [f32; 3],
    ao: f32,
    sky_light: f32,
    block_light: f32,
    face_shade: f32,
}
impl Vertex {
    const ATTRIBUTES: [wgpu::VertexAttribute; 8] = wgpu::vertex_attr_array![
        0 => Float32x3, 1 => Float32x3, 2 => Float32x2, 3 => Float32x3,
        4 => Float32, 5 => Float32, 6 => Float32, 7 => Float32
    ];
    fn layout() -> wgpu::VertexBufferLayout<'static> {
        wgpu::VertexBufferLayout { array_stride: size_of::<Self>() as wgpu::BufferAddress,
            step_mode: wgpu::VertexStepMode::Vertex, attributes: &Self::ATTRIBUTES }
    }
}
#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct CameraUniform { view_projection: [[f32; 4]; 4] }
#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct OverlayVertex { position: [f32; 2], color: [f32; 4] }
impl OverlayVertex {
    const ATTRIBUTES: [wgpu::VertexAttribute; 2] = wgpu::vertex_attr_array![0 => Float32x2, 1 => Float32x4];
    fn layout() -> wgpu::VertexBufferLayout<'static> {
        wgpu::VertexBufferLayout { array_stride: size_of::<Self>() as wgpu::BufferAddress,
            step_mode: wgpu::VertexStepMode::Vertex, attributes: &Self::ATTRIBUTES }
    }
}

#[repr(C)]
#[derive(Clone, Copy, bytemuck::Pod, bytemuck::Zeroable)]
struct GuiTextureVertex { position: [f32; 2], uv: [f32; 2] }
impl GuiTextureVertex {
    const ATTRIBUTES: [wgpu::VertexAttribute; 2] = wgpu::vertex_attr_array![0 => Float32x2, 1 => Float32x2];
    fn layout() -> wgpu::VertexBufferLayout<'static> {
        wgpu::VertexBufferLayout { array_stride: size_of::<Self>() as wgpu::BufferAddress,
            step_mode: wgpu::VertexStepMode::Vertex, attributes: &Self::ATTRIBUTES }
    }
}

/// Full-frame, nearest-filtered GUI texture. Inventory and HUD pixels are composed
/// from Minecraft 1.8.9's own GUI and item PNGs, then alpha-blended over the world.
struct GuiOverlayGpu {
    _texture: wgpu::Texture,
    _view: wgpu::TextureView,
    _sampler: wgpu::Sampler,
    bind_group: wgpu::BindGroup,
    layout: wgpu::BindGroupLayout,
    pipeline: wgpu::RenderPipeline,
    vertex_buffer: wgpu::Buffer,
    width: u32,
    height: u32,
}
impl GuiOverlayGpu {
    fn new(device: &wgpu::Device, format: wgpu::TextureFormat, width: u32, height: u32) -> Self {
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("Minecraft 1.8.9 GUI texture shader"),
            source: wgpu::ShaderSource::Wgsl(r#"
                struct In { @location(0) position: vec2<f32>, @location(1) uv: vec2<f32> };
                struct Out { @builtin(position) position: vec4<f32>, @location(0) uv: vec2<f32> };
                @group(0) @binding(0) var gui_texture: texture_2d<f32>;
                @group(0) @binding(1) var gui_sampler: sampler;
                @vertex fn vs_main(input: In) -> Out {
                    var output: Out;
                    output.position = vec4<f32>(input.position, 0.0, 1.0);
                    output.uv = input.uv;
                    return output;
                }
                @fragment fn fs_main(input: Out) -> @location(0) vec4<f32> {
                    return textureSample(gui_texture, gui_sampler, input.uv);
                }
            "#.into()),
        });
        let layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("Minecraft 1.8.9 GUI texture bind layout"),
            entries: &[
                wgpu::BindGroupLayoutEntry { binding: 0, visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2, multisampled: false }, count: None },
                wgpu::BindGroupLayoutEntry { binding: 1, visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering), count: None },
            ],
        });
        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("Minecraft 1.8.9 GUI overlay pipeline layout"), bind_group_layouts: &[&layout], push_constant_ranges: &[],
        });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("Minecraft 1.8.9 GUI overlay pipeline"), layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState { module: &shader, entry_point: "vs_main", buffers: &[GuiTextureVertex::layout()] },
            fragment: Some(wgpu::FragmentState { module: &shader, entry_point: "fs_main", targets: &[Some(wgpu::ColorTargetState {
                format, blend: Some(wgpu::BlendState::ALPHA_BLENDING), write_mask: wgpu::ColorWrites::ALL,
            })] }),
            primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw, cull_mode: None, polygon_mode: wgpu::PolygonMode::Fill,
                unclipped_depth: false, conservative: false },
            depth_stencil: None, multisample: wgpu::MultisampleState::default(), multiview: None,
        });
        let vertices = [
            GuiTextureVertex { position: [-1.0, 1.0], uv: [0.0, 0.0] },
            GuiTextureVertex { position: [-1.0, -1.0], uv: [0.0, 1.0] },
            GuiTextureVertex { position: [1.0, -1.0], uv: [1.0, 1.0] },
            GuiTextureVertex { position: [-1.0, 1.0], uv: [0.0, 0.0] },
            GuiTextureVertex { position: [1.0, -1.0], uv: [1.0, 1.0] },
            GuiTextureVertex { position: [1.0, 1.0], uv: [1.0, 0.0] },
        ];
        let vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("Minecraft 1.8.9 GUI full-frame quad"), contents: bytemuck::cast_slice(&vertices), usage: wgpu::BufferUsages::VERTEX,
        });
        let (texture, view, sampler, bind_group) = Self::make_texture(device, &layout, width.max(1), height.max(1));
        Self { _texture: texture, _view: view, _sampler: sampler, bind_group, layout, pipeline, vertex_buffer,
            width: width.max(1), height: height.max(1) }
    }

    fn make_texture(device: &wgpu::Device, layout: &wgpu::BindGroupLayout, width: u32, height: u32)
        -> (wgpu::Texture, wgpu::TextureView, wgpu::Sampler, wgpu::BindGroup) {
        let texture = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("Minecraft 1.8.9 composed HUD/inventory pixels"),
            size: wgpu::Extent3d { width, height, depth_or_array_layers: 1 }, mip_level_count: 1, sample_count: 1,
            dimension: wgpu::TextureDimension::D2, format: wgpu::TextureFormat::Rgba8UnormSrgb,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST, view_formats: &[],
        });
        let view = texture.create_view(&wgpu::TextureViewDescriptor::default());
        let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: Some("Minecraft GUI nearest-neighbour sampler"), address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge, address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Nearest, min_filter: wgpu::FilterMode::Nearest,
            mipmap_filter: wgpu::FilterMode::Nearest, ..Default::default()
        });
        let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("Minecraft 1.8.9 GUI overlay texture bind group"), layout,
            entries: &[
                wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&view) },
                wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&sampler) },
            ],
        });
        (texture, view, sampler, bind_group)
    }

    fn resize(&mut self, device: &wgpu::Device, width: u32, height: u32) {
        let width = width.max(1); let height = height.max(1);
        if self.width == width && self.height == height { return; }
        let (texture, view, sampler, bind_group) = Self::make_texture(device, &self.layout, width, height);
        self._texture = texture; self._view = view; self._sampler = sampler; self.bind_group = bind_group;
        self.width = width; self.height = height;
    }

    fn upload(&self, queue: &wgpu::Queue, pixels: &image::RgbaImage) {
        if pixels.width() != self.width || pixels.height() != self.height { return; }
        queue.write_texture(wgpu::ImageCopyTexture { texture: &self._texture, mip_level: 0, origin: wgpu::Origin3d::ZERO,
            aspect: wgpu::TextureAspect::All }, pixels.as_raw(),
            wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(self.width * 4), rows_per_image: Some(self.height) },
            wgpu::Extent3d { width: self.width, height: self.height, depth_or_array_layers: 1 });
    }
}

/// Small high-resolution transparent GUI sprite. Unlike the full scaled GUI texture,
/// these sprites are rendered one framebuffer pixel per source pixel: Steve's geometry
/// therefore keeps smooth pixel-aligned edges, and the carried stack tracks the actual cursor.
struct GuiSpriteGpu {
    _texture: wgpu::Texture,
    _view: wgpu::TextureView,
    _sampler: wgpu::Sampler,
    bind_group: wgpu::BindGroup,
    vertex_buffer: wgpu::Buffer,
    width: u32,
    height: u32,
}
impl GuiSpriteGpu {
    fn new(device: &wgpu::Device, layout: &wgpu::BindGroupLayout, width: u32, height: u32) -> Self {
        let width = width.max(1);
        let height = height.max(1);
        let (texture, view, sampler, bind_group) = GuiOverlayGpu::make_texture(device, layout, width, height);
        let vertices = [GuiTextureVertex { position: [0.0, 0.0], uv: [0.0, 0.0] }; 6];
        let vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("Minecraft inventory sprite rectangle vertices"),
            contents: bytemuck::cast_slice(&vertices),
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
        });
        Self { _texture: texture, _view: view, _sampler: sampler, bind_group, vertex_buffer, width, height }
    }

    fn resize(&mut self, device: &wgpu::Device, layout: &wgpu::BindGroupLayout, width: u32, height: u32) {
        let width = width.max(1);
        let height = height.max(1);
        if self.width == width && self.height == height { return; }
        let (texture, view, sampler, bind_group) = GuiOverlayGpu::make_texture(device, layout, width, height);
        self._texture = texture;
        self._view = view;
        self._sampler = sampler;
        self.bind_group = bind_group;
        self.width = width;
        self.height = height;
    }

    fn upload(&self, queue: &wgpu::Queue, pixels: &image::RgbaImage) {
        if pixels.width() != self.width || pixels.height() != self.height { return; }
        queue.write_texture(
            wgpu::ImageCopyTexture { texture: &self._texture, mip_level: 0, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
            pixels.as_raw(),
            wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(self.width * 4), rows_per_image: Some(self.height) },
            wgpu::Extent3d { width: self.width, height: self.height, depth_or_array_layers: 1 },
        );
    }

    fn set_rect(&self, queue: &wgpu::Queue, frame_width: u32, frame_height: u32, left: f32, top: f32) {
        let fw = frame_width.max(1) as f32;
        let fh = frame_height.max(1) as f32;
        let x0 = 2.0 * left / fw - 1.0;
        let y0 = 1.0 - 2.0 * top / fh;
        let x1 = 2.0 * (left + self.width as f32) / fw - 1.0;
        let y1 = 1.0 - 2.0 * (top + self.height as f32) / fh;
        let vertices = [
            GuiTextureVertex { position: [x0, y0], uv: [0.0, 0.0] },
            GuiTextureVertex { position: [x0, y1], uv: [0.0, 1.0] },
            GuiTextureVertex { position: [x1, y1], uv: [1.0, 1.0] },
            GuiTextureVertex { position: [x0, y0], uv: [0.0, 0.0] },
            GuiTextureVertex { position: [x1, y1], uv: [1.0, 1.0] },
            GuiTextureVertex { position: [x1, y0], uv: [1.0, 0.0] },
        ];
        queue.write_buffer(&self.vertex_buffer, 0, bytemuck::cast_slice(&vertices));
    }
}

/// Pixel mask copied from Minecraft 1.8.9's textures/gui/icons.png at
/// UV (0, 0), size 16x16. GuiIngame.renderGameOverlay draws this exact sprite
/// at (scaledWidth / 2 - 7, scaledHeight / 2 - 7).
const VANILLA_189_CROSSHAIR_PIXELS: [(u8, u8); 17] = [
    (7, 3), (7, 4), (7, 5), (7, 6),
    (3, 7), (4, 7), (5, 7), (6, 7), (7, 7), (8, 7), (9, 7), (10, 7), (11, 7),
    (7, 8), (7, 9), (7, 10), (7, 11),
];

/// Minecraft 1.8.9 ScaledResolution with GUI scale set to Auto (0),
/// Unicode font disabled. The HUD's 16x16 logical-pixel crosshair is drawn
/// after this scale is applied, not as a fixed 16 physical-pixel overlay.
fn vanilla_gui_scale_factor(width: u32, height: u32) -> u32 {
    let mut scale = 1_u32;
    while width / (scale + 1) >= 320 && height / (scale + 1) >= 240 {
        scale += 1;
    }
    scale
}

fn build_crosshair_vertices(width: u32, height: u32) -> Vec<OverlayVertex> {
    let mut vertices = Vec::with_capacity(VANILLA_189_CROSSHAIR_PIXELS.len() * 6);
    let scale = vanilla_gui_scale_factor(width, height) as f32;
    // GuiIngame draws 16x16 scaled GUI pixels at (scaledWidth/2-7,
    // scaledHeight/2-7). In physical pixels this is the same scale around
    // the framebuffer centre, including the original 1px sprite texels.
    let scaled_width = ((width + scale as u32 - 1) / scale as u32) as f32;
    let scaled_height = ((height + scale as u32 - 1) / scale as u32) as f32;
    let left = (scaled_width * 0.5 - 7.0) * scale;
    let top = (scaled_height * 0.5 - 7.0) * scale;
    let color = [1.0, 1.0, 1.0, 1.0];
    for (px, py) in VANILLA_189_CROSSHAIR_PIXELS {
        let x0 = left + f32::from(px) * scale;
        let y0 = top + f32::from(py) * scale;
        let x1 = x0 + scale;
        let y1 = y0 + scale;
        let to_clip = |x: f32, y: f32| [2.0 * x / width as f32 - 1.0, 1.0 - 2.0 * y / height as f32];
        for point in [to_clip(x0,y0), to_clip(x0,y1), to_clip(x1,y1), to_clip(x0,y0), to_clip(x1,y1), to_clip(x1,y0)] {
            vertices.push(OverlayVertex { position: point, color });
        }
    }
    vertices
}

#[derive(Clone, Default)]
struct CpuMesh {
    vertices: Vec<Vertex>,
    cutout_vertices: Vec<Vertex>,
    translucent_vertices: Vec<Vertex>,
    fluid_vertices: Vec<Vertex>,
    // CPU-only owner tags, parallel to each vertex vector. They are not uploaded
    // to the GPU; they let the currently displayed block be removed immediately
    // while the full, neighbor-aware replacement mesh is still being built.
    vertex_owners: Vec<[i32; 3]>,
    cutout_owners: Vec<[i32; 3]>,
    translucent_owners: Vec<[i32; 3]>,
    fluid_owners: Vec<[i32; 3]>,
    triangles: usize,
}

impl CpuMesh {
    fn total_vertices(&self) -> usize {
        self.vertices.len() + self.cutout_vertices.len()
            + self.translucent_vertices.len() + self.fluid_vertices.len()
    }

    fn section_mesh(&self, section_y: u8) -> Self {
        fn copy_layer(
            vertices: &[Vertex], owners: &[[i32; 3]], section_y: u8,
            out_vertices: &mut Vec<Vertex>, out_owners: &mut Vec<[i32; 3]>,
        ) {
            debug_assert_eq!(vertices.len(), owners.len(), "each CPU mesh vertex must retain its source block");
            for (vertex, owner) in vertices.iter().zip(owners.iter()) {
                let owner_section = owner[1].clamp(0, 255).div_euclid(16) as u8;
                if owner_section == section_y {
                    out_vertices.push(*vertex);
                    out_owners.push(*owner);
                }
            }
        }
        let mut result = Self::default();
        copy_layer(&self.vertices, &self.vertex_owners, section_y, &mut result.vertices, &mut result.vertex_owners);
        copy_layer(&self.cutout_vertices, &self.cutout_owners, section_y, &mut result.cutout_vertices, &mut result.cutout_owners);
        copy_layer(&self.translucent_vertices, &self.translucent_owners, section_y, &mut result.translucent_vertices, &mut result.translucent_owners);
        copy_layer(&self.fluid_vertices, &self.fluid_owners, section_y, &mut result.fluid_vertices, &mut result.fluid_owners);
        result.triangles = result.total_vertices() / 3;
        result
    }

    fn replace_section(&mut self, section_y: u8, replacement: &Self) {
        fn replace_layer(
            vertices: &mut Vec<Vertex>, owners: &mut Vec<[i32; 3]>,
            replacement_vertices: &[Vertex], replacement_owners: &[[i32; 3]], section_y: u8,
        ) {
            debug_assert_eq!(vertices.len(), owners.len(), "each CPU mesh vertex must retain its source block");
            debug_assert_eq!(replacement_vertices.len(), replacement_owners.len(), "replacement vertices must retain source ownership");
            let mut index = 0usize;
            vertices.retain(|_| {
                let keep = owners.get(index).is_some_and(|owner| owner[1].clamp(0, 255).div_euclid(16) as u8 != section_y);
                index += 1;
                keep
            });
            owners.retain(|owner| owner[1].clamp(0, 255).div_euclid(16) as u8 != section_y);
            vertices.extend_from_slice(replacement_vertices);
            owners.extend_from_slice(replacement_owners);
        }
        replace_layer(&mut self.vertices, &mut self.vertex_owners, &replacement.vertices, &replacement.vertex_owners, section_y);
        replace_layer(&mut self.cutout_vertices, &mut self.cutout_owners, &replacement.cutout_vertices, &replacement.cutout_owners, section_y);
        replace_layer(&mut self.translucent_vertices, &mut self.translucent_owners, &replacement.translucent_vertices, &replacement.translucent_owners, section_y);
        replace_layer(&mut self.fluid_vertices, &mut self.fluid_owners, &replacement.fluid_vertices, &replacement.fluid_owners, section_y);
        self.triangles = self.total_vertices() / 3;
    }

    fn hide_block(&mut self, block: [i32; 3]) -> usize {
        fn filter(vertices: &mut Vec<Vertex>, owners: &mut Vec<[i32; 3]>, block: [i32; 3]) -> usize {
            debug_assert_eq!(vertices.len(), owners.len(), "each CPU mesh vertex must retain its source block");
            let old_len = vertices.len();
            let mut index = 0usize;
            // Retain in place to avoid allocating a second full copy of a chunk's
            // vertices on every mined block. Preserve original order in translucent
            // layers so alpha blending remains deterministic.
            vertices.retain(|_| {
                let keep = owners.get(index).is_some_and(|owner| *owner != block);
                index += 1;
                keep
            });
            owners.retain(|owner| *owner != block);
            old_len - vertices.len()
        }
        let removed = filter(&mut self.vertices, &mut self.vertex_owners, block)
            + filter(&mut self.cutout_vertices, &mut self.cutout_owners, block)
            + filter(&mut self.translucent_vertices, &mut self.translucent_owners, block)
            + filter(&mut self.fluid_vertices, &mut self.fluid_owners, block);
        self.triangles = (self.vertices.len() + self.cutout_vertices.len()
            + self.translucent_vertices.len() + self.fluid_vertices.len()) / 3;
        removed
    }
}

fn face_uv_corners(face: ModelFaceDirection, uv: [f32; 4], rotation: u16) -> [[f32; 2]; 4] {
    let [u0, v0, u1, v1] = uv;
    let mut corners = match face {
        ModelFaceDirection::Down | ModelFaceDirection::Up =>
            [[u0,v0],[u0,v1],[u1,v1],[u1,v0]],
        ModelFaceDirection::North | ModelFaceDirection::South |
        ModelFaceDirection::West | ModelFaceDirection::East =>
            [[u0,v1],[u1,v1],[u1,v0],[u0,v0]],
    };
    let turns = (rotation / 90) as usize;
    if turns > 0 {
        let original = corners;
        for index in 0..4 { corners[index] = original[(index + 4 - turns) % 4]; }
    }
    corners
}

/// Load the ten original 1.8.9 destroy-stage sprites from the client JAR and pack
/// them into one horizontal strip. Each source remains a byte-for-byte RGBA sprite.
fn load_destroy_stage_sheet(jar_path: &Path) -> Result<image::RgbaImage> {
    let file = File::open(jar_path)?;
    let mut archive = ZipArchive::new(file)
        .map_err(|error| Mc189Error::InvalidData(format!("cannot open client JAR for destroy-stage textures: {error}")))?;
    let mut sheet = image::RgbaImage::new(160, 16);
    for stage in 0..10_u32 {
        let path = format!("assets/minecraft/textures/blocks/destroy_stage_{stage}.png");
        let bytes = {
            let mut entry = archive.by_name(&path).map_err(|error| {
                Mc189Error::InvalidData(format!("vanilla breaking overlay {path} missing from client JAR: {error}"))
            })?;
            let mut bytes = Vec::new();
            entry.read_to_end(&mut bytes)?;
            bytes
        };
        let sprite = image::load_from_memory(&bytes)
            .map_err(|error| Mc189Error::InvalidData(format!("cannot decode {path}: {error}")))?
            .to_rgba8();
        if sprite.dimensions() != (16, 16) {
            return Err(Mc189Error::InvalidData(format!("{path} is {}x{}, expected 16x16", sprite.width(), sprite.height())));
        }
        image::imageops::replace(&mut sheet, &sprite, i64::from(stage * 16), 0);
    }
    Ok(sheet)
}

/// Build the six slightly offset faces used by RenderGlobal's block-damage overlay.
/// Stage UVs select one original destroy_stage_N sprite from the packed texture.
fn build_mining_crack_vertices(pos: BlockPos, stage: u8, sky_light: u8, block_light: u8) -> Vec<Vertex> {
    let x = pos.x as f32;
    let y = pos.y as f32;
    let z = pos.z as f32;
    let e = 0.0015_f32;
    let u0 = (f32::from(stage.min(9)) * 16.0 + 0.5) / 160.0;
    let u1 = (f32::from(stage.min(9)) * 16.0 + 15.5) / 160.0;
    let v0 = 0.5 / 16.0;
    let v1 = 15.5 / 16.0;
    let uv = [[u0, v0], [u1, v0], [u1, v1], [u0, v1]];
    let faces: [([[f32; 3]; 4], [f32; 3]); 6] = [
        // Down, Up, North, South, West, East; epsilon avoids z-fighting.
        ([[x, y-e, z+1.0], [x, y-e, z], [x+1.0, y-e, z], [x+1.0, y-e, z+1.0]], [0.0, -1.0, 0.0]),
        ([[x, y+1.0+e, z], [x, y+1.0+e, z+1.0], [x+1.0, y+1.0+e, z+1.0], [x+1.0, y+1.0+e, z]], [0.0, 1.0, 0.0]),
        ([[x+1.0, y, z-e], [x, y, z-e], [x, y+1.0, z-e], [x+1.0, y+1.0, z-e]], [0.0, 0.0, -1.0]),
        ([[x, y, z+1.0+e], [x+1.0, y, z+1.0+e], [x+1.0, y+1.0, z+1.0+e], [x, y+1.0, z+1.0+e]], [0.0, 0.0, 1.0]),
        ([[x-e, y, z], [x-e, y, z+1.0], [x-e, y+1.0, z+1.0], [x-e, y+1.0, z]], [-1.0, 0.0, 0.0]),
        ([[x+1.0+e, y, z+1.0], [x+1.0+e, y, z], [x+1.0+e, y+1.0, z], [x+1.0+e, y+1.0, z+1.0]], [1.0, 0.0, 0.0]),
    ];
    let order = [0_usize, 1, 2, 0, 2, 3];
    let mut vertices = Vec::with_capacity(36);
    for (points, normal) in faces {
        for corner in order {
            vertices.push(Vertex {
                position: points[corner], normal, uv: uv[corner], tint: [1.0; 3],
                ao: 1.0,
                sky_light: f32::from(sky_light.min(15)) / 15.0,
                block_light: f32::from(block_light.min(15)) / 15.0,
                face_shade: 1.0,
            });
        }
    }
    vertices
}

fn append_dropped_item_vertices(
    target: &mut Vec<Vertex>,
    base: &[Vertex],
    item: &DroppedItem,
    sky_light: u8,
    block_light: u8,
    is_gui3d: bool,
    ground_transform: ItemCameraTransform,
    partial_ticks: f32,
) {
    // MCP RenderEntityItem.func_177078_a uses the exact stack thresholds below.
    // The ground transform of vanilla block items applies a 0.5 baked-model scale
    // after the renderer's 0.5 copy scale, yielding the 0.25 world scale here.
    let copies: usize = if item.count > 48 { 5 } else if item.count > 32 { 4 } else if item.count > 16 { 3 } else if item.count > 1 { 2 } else { 1 };
    // RenderEntityItem.func_177077_a: sin((age + partialTicks)/10 + hoverStart)*0.1 + 0.1.
    let interpolated_age = item.age as f32 + partial_ticks.clamp(0.0, 1.0);
    let bob = (interpolated_age / 10.0 + item.hover_start).sin() * 0.1 + 0.1;
    // RenderManager supplies partialTicks to RenderEntityItem; interpolate both
    // position and age on every display frame rather than rebuilding only at 20 Hz.
    let render_position = item.previous_position.lerp(item.position, partial_ticks.clamp(0.0, 1.0));
    // MCP angle is ((age + partialTicks)/20 + hoverStart) in radians.
    let spin = interpolated_age / 20.0 + item.hover_start;
    let spin_rotation = Mat4::from_rotation_y(spin);
    let ground = item_ground_transform_matrix(ground_transform);
    // RenderEntityItem.doRender calls RenderItem.renderItem(stack, bakedModel)
    // directly. That overload applies its inner 0.5 scale, but does NOT call the
    // separate renderItemModelTransform/preTransform path (which adds 2x for
    // generated items in GUI/hand rendering). Thus flat drops are net 0.5, while
    // GUI-3D block drops also receive RenderEntityItem's outer 0.5 (net 0.25).
    let model_to_entity = if is_gui3d {
        Mat4::from_scale(Vec3::splat(0.5))
            * ground
            * Mat4::from_scale(Vec3::splat(0.5))
            * Mat4::from_translation(Vec3::splat(-0.5))
    } else {
        // Generated ItemLayerModel geometry is already centred at the origin;
        // RenderItem.renderItem(stack, bakedModel) then applies its own 0.5 scale.
        // The 2x preTransform belongs to a different overload and is not called by
        // RenderEntityItem.doRender.
        ground * Mat4::from_scale(Vec3::splat(0.5))
    };
    let normal_matrix = ground;
    // RenderEntityItem resets this java.util.Random to 187 for every rendered entity.
    let mut copy_random = JavaRandom48::new(187);
    for copy in 0..copies {
        let random_offset = if is_gui3d && copy > 0 {
            Vec3::new(
                (copy_random.next_float() * 2.0 - 1.0) * 0.15,
                (copy_random.next_float() * 2.0 - 1.0) * 0.15,
                (copy_random.next_float() * 2.0 - 1.0) * 0.15,
            )
        } else { Vec3::ZERO };
        // RenderEntityItem translates the entity before applying the model's
        // GROUND transform. Its base Y offset is 0.25 * ground.scale.y, followed
        // by the sinusoidal hover bob.
        let ground_y = if is_gui3d { 0.125 } else { 0.25 * ground_transform.scale[1] };
        let base_position = render_position + Vec3::new(0.0, ground_y + bob, 0.0);
        // RenderEntityItem.func_177077_a centres a flat stack before the loop
        // with translate(0, 0, -0.046875 * (copies - 1) * 0.5). After each
        // rendered copy it advances by 0.046875 * GROUND.scale.z. Both offsets
        // are outside the model transform but inside the entity's Y rotation.
        let flat_copy_offset = if !is_gui3d {
            let centered_start = -0.0234375 * (copies.saturating_sub(1) as f32);
            let local_z = centered_start + copy as f32 * 0.046875 * ground_transform.scale[2];
            spin_rotation.transform_vector3(Vec3::new(0.0, 0.0, local_z))
        } else { Vec3::ZERO };
        for mut vertex in base.iter().copied() {
            let model_position = model_to_entity.transform_point3(Vec3::from_array(vertex.position));
            let rotated = spin_rotation.transform_vector3(model_position);
            let world = base_position + spin_rotation.transform_vector3(random_offset) + rotated + flat_copy_offset;
            vertex.position = world.to_array();
            let normal = spin_rotation.transform_vector3(normal_matrix.transform_vector3(Vec3::from_array(vertex.normal)));
            vertex.normal = normal.normalize_or_zero().to_array();
            vertex.sky_light = f32::from(sky_light.min(15)) / 15.0;
            vertex.block_light = f32::from(block_light.min(15)) / 15.0;
            target.push(vertex);
        }
    }
}

/// ItemCameraTransforms.applyTransform(GROUND), in the same post-multiplication
/// order as MCP 1.8.9: translate, Y rotation, X rotation, Z rotation, scale.
fn item_ground_transform_matrix(transform: ItemCameraTransform) -> Mat4 {
    Mat4::from_translation(Vec3::from_array(transform.translation))
        * Mat4::from_rotation_y(transform.rotation[1].to_radians())
        * Mat4::from_rotation_x(transform.rotation[0].to_radians())
        * Mat4::from_rotation_z(transform.rotation[2].to_radians())
        * Mat4::from_scale(Vec3::from_array(transform.scale))
}

/// Compile an actual 1.8.9 block-like item model against the existing vanilla atlas.
/// If any face uses a non-block texture or a sprite absent from this atlas, the caller
/// falls back to the item's generated texture layer instead of showing a partial model.
fn build_block_item_vertices(quads: &[CpuMeshQuad], atlas: &AtlasRuntime) -> Option<Vec<Vertex>> {
    if quads.is_empty() { return None; }
    let mut vertices = Vec::with_capacity(quads.len() * 6);
    let order = [0_usize, 1, 2, 0, 2, 3];
    for quad in quads {
        let texture = quad.texture_path.strip_prefix("assets/minecraft/textures/")?;
        if !texture.starts_with("blocks/") || atlas.lookup(texture).is_none() { return None; }
        let (mapped, rotation) = atlas.remap_face_uv(texture, quad.uv_rect, quad.uv_rotation).ok()?;
        let uv = if let Some(corners) = quad.uv_corners {
            let [u0, v0, u1, v1] = mapped;
            corners.map(|[u, v]| [u0 + (u / 16.0) * (u1 - u0), v0 + (v / 16.0) * (v1 - v0)])
        } else { face_uv_corners(quad.face, mapped, rotation) };
        let directional_shade = match quad.face {
            ModelFaceDirection::Down => 0.5,
            ModelFaceDirection::Up => 1.0,
            ModelFaceDirection::North | ModelFaceDirection::South => 0.8,
            ModelFaceDirection::West | ModelFaceDirection::East => 0.6,
        };
        for corner in order {
            vertices.push(Vertex {
                position: quad.positions[corner], normal: quad.normal, uv: uv[corner],
                tint: quad.tint_color, ao: 1.0, sky_light: 1.0, block_light: 1.0,
                // The held-item pass uses the vanilla block-face brightness levels;
                // world light/lighting equations are not modified by this path.
                face_shade: if quad.shade { directional_shade } else { 1.0 },
            });
        }
    }
    Some(vertices)
}

/// ItemLayerModel in 1.8.9 uses front/back alpha-cutout planes plus extrusion along
/// the opaque silhouette's pixel boundaries. The GPU alpha test preserves holes and
/// transparency without generating a quad for every opaque pixel on both sides.
fn build_generated_item_layer_vertices(icon: &image::RgbaImage) -> Vec<Vertex> {
    let (width, height) = icon.dimensions();
    if width == 0 || height == 0 { return Vec::new(); }
    // Build one front cutout surface and extrude the alpha silhouette into thickness.
    // The hand pipeline is two-sided (cull_mode=None), so a second full back plane is
    // unnecessary for visibility. Emitting a second complete sprite surface here made
    // a thin, offset duplicate silhouette visible after the first-person transform,
    // which looked like a second flat tool crossing the correctly extruded tool.
    // Keep the existing item transform untouched; fix only the generated mesh.
    let mut vertices = Vec::with_capacity(((width + height) * 48).max(36) as usize);
    let z0 = 7.5_f32 / 16.0;
    let z1 = 8.5_f32 / 16.0;
    let transparent = |x: i32, y: i32| -> bool {
        x < 0 || y < 0 || x >= width as i32 || y >= height as i32 || icon.get_pixel(x as u32, y as u32)[3] < 16
    };
    let full_uv = [[0.0,0.0],[1.0,0.0],[1.0,1.0],[0.0,1.0]];
    push_item_quad(&mut vertices,
        [[0.0,1.0,z1],[1.0,1.0,z1],[1.0,0.0,z1],[0.0,0.0,z1]], full_uv, [0.0,0.0,1.0]);
    for y in 0..height as i32 {
        for x in 0..width as i32 {
            if transparent(x, y) { continue; }
            let x0 = x as f32 / width as f32;
            let x1 = (x + 1) as f32 / width as f32;
            // Texture row zero is the top of the icon; model Y increases upward.
            let y1 = 1.0 - y as f32 / height as f32;
            let y0 = 1.0 - (y + 1) as f32 / height as f32;
            // A side wall belongs to one source texel. Sampling exactly at a
            // texel centre prevents nearest-sampler edge ambiguity and stops
            // neighbouring rows/columns bleeding into thin tool silhouettes.
            let texel_uv = [
                (x as f32 + 0.5) / width as f32,
                (y as f32 + 0.5) / height as f32,
            ];
            let solid_pixel_uv = [texel_uv; 4];
            if transparent(x - 1, y) {
                push_item_quad(&mut vertices,
                    [[x0,y1,z0],[x0,y1,z1],[x0,y0,z1],[x0,y0,z0]],
                    solid_pixel_uv, [-1.0,0.0,0.0]);
            }
            if transparent(x + 1, y) {
                push_item_quad(&mut vertices,
                    [[x1,y1,z1],[x1,y1,z0],[x1,y0,z0],[x1,y0,z1]],
                    solid_pixel_uv, [1.0,0.0,0.0]);
            }
            if transparent(x, y - 1) {
                push_item_quad(&mut vertices,
                    [[x0,y1,z0],[x1,y1,z0],[x1,y1,z1],[x0,y1,z1]],
                    solid_pixel_uv, [0.0,1.0,0.0]);
            }
            if transparent(x, y + 1) {
                push_item_quad(&mut vertices,
                    [[x0,y0,z1],[x1,y0,z1],[x1,y0,z0],[x0,y0,z0]],
                    solid_pixel_uv, [0.0,-1.0,0.0]);
            }
        }
    }
    // ItemLayerModel in Minecraft 1.8.9 emits coordinates centered on the model
    // origin. Center the generated 0..1 silhouette on all axes before applying
    // ItemCameraTransforms.FIRST_PERSON (e.g. diamond_sword: rotation [0,-135,25],
    // translation [0,4,2], scale [1.7,1.7,1.7] from client.jar).
    for vertex in &mut vertices {
        vertex.position[0] -= 0.5;
        vertex.position[1] -= 0.5;
        vertex.position[2] -= 0.5;
    }
    vertices
}

/// Build the world-drop variant of ItemLayerModel. Vanilla ItemModelGenerator
/// creates both SOUTH and NORTH alpha-cutout planes (the NORTH face mirrors its U
/// coordinates), then extrudes the opaque pixel silhouette between them. The
/// first-person hand keeps its existing one-plane mesh to avoid reintroducing the
/// duplicate silhouette that was previously visible there.
fn build_generated_item_drop_vertices(icon: &image::RgbaImage) -> Vec<Vertex> {
    let mut vertices = build_generated_item_layer_vertices(icon);
    let (width, height) = icon.dimensions();
    if width == 0 || height == 0 { return vertices; }

    let back_z = 7.5_f32 / 16.0 - 0.5;
    let full_uv = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]];
    // Match the NORTH face generated by MCP ItemModelGenerator + FaceBakery.
    // Vanilla stores its NORTH UV rectangle with reversed U, but FaceBakery
    // also emits NORTH vertices in the order top-right, bottom-right,
    // bottom-left, top-left. Once those baked vertices are normalized into
    // this function's shared top-left -> top-right -> bottom-right -> bottom-left
    // quad order, the UVs are again [0,0] -> [1,0] -> [1,1] -> [0,1].
    // Mirroring U while keeping SOUTH-style vertex order mirrored the pickaxe
    // a second time, so the rear head pointed the opposite way and formed an X.
    // The mesh is already centered by build_generated_item_layer_vertices.
    push_item_quad(
        &mut vertices,
        [[-0.5, 0.5, back_z], [0.5, 0.5, back_z], [0.5, -0.5, back_z], [-0.5, -0.5, back_z]],
        full_uv,
        [0.0, 0.0, -1.0],
    );

    // The main item pipeline has no fixed-function directional lighting. Match
    // the vanilla block-face brightness convention for the extruded silhouette:
    // top=1.0, bottom=0.5, X sides=0.6, front/back=0.8.
    for vertex in &mut vertices {
        vertex.face_shade = if vertex.normal[1] > 0.5 {
            1.0
        } else if vertex.normal[1] < -0.5 {
            0.5
        } else if vertex.normal[0].abs() > 0.5 {
            0.6
        } else {
            0.8
        };
    }
    vertices
}

fn push_item_quad(
    out: &mut Vec<Vertex>,
    positions: [[f32; 3]; 4],
    uvs: [[f32; 2]; 4],
    normal: [f32; 3],
) {
    for corner in [0_usize, 1, 2, 0, 2, 3] {
        out.push(Vertex {
            position: positions[corner], normal, uv: uvs[corner], tint: [1.0; 3],
            ao: 1.0, sky_light: 1.0, block_light: 1.0, face_shade: 1.0,
        });
    }
}

/// MCP 1.8.9 first-person path for a block model (`shouldRenderItemIn3D`).
/// `ItemRenderer.renderItem` applies scale(2) to GUI-3D models before calling
/// RenderItem; RenderItem.renderItem then applies scale(0.5) and translates the
/// model by (-0.5, -0.5, -0.5), the latter already being baked into the mesh.
/// Block models normally inherit the DEFAULT FIRST_PERSON transform (zero
/// rotation/translation, unit scale) from ItemCameraTransforms, unlike tools
/// and swords whose item JSON explicitly defines `display.firstperson`.
fn vanilla_first_person_block_matrix(
    swing_progress: f32,
    equip_progress: f32,
    display: ItemCameraTransform,
) -> Mat4 {
    let swing = swing_progress.clamp(0.0, 1.0);
    let root = swing.sqrt() * std::f32::consts::PI;
    let f = (swing * swing * std::f32::consts::PI).sin();
    let f1 = root.sin();
    let swing_translation = Vec3::new(
        -0.4 * f1,
        0.2 * (root * 2.0).sin(),
        -0.2 * (swing * std::f32::consts::PI).sin(),
    );
    let hand_pose = Mat4::from_translation(swing_translation)
        * Mat4::from_translation(Vec3::new(0.56, -0.52, -0.71999997))
        * Mat4::from_translation(Vec3::new(0.0, equip_progress * -0.6, 0.0))
        * Mat4::from_rotation_y(45.0_f32.to_radians())
        * Mat4::from_rotation_y((-20.0 * f).to_radians())
        * Mat4::from_rotation_z((-20.0 * f1).to_radians())
        * Mat4::from_rotation_x((-80.0 * f1).to_radians())
        * Mat4::from_scale(Vec3::splat(0.4));
    let first_person_display = Mat4::from_translation(Vec3::from_array(display.translation))
        * Mat4::from_rotation_y(display.rotation[1].to_radians())
        * Mat4::from_rotation_x(display.rotation[0].to_radians())
        * Mat4::from_rotation_z(display.rotation[2].to_radians())
        * Mat4::from_scale(Vec3::from_array(display.scale));
    // Exact MCP 1.8.9 RenderItem.renderItem order for baked block models:
    // ItemRenderer.renderItem applies scale(2) to GUI-3D models, then
    // RenderItem.renderItem applies scale(0.5) AND translate(-0.5,-0.5,-0.5)
    // before drawing the model. The block mesh still uses normalized 0..1
    // model coordinates, so that final translation must remain in this matrix
    // (it is NOT baked into build_block_item_vertices). Omitting it leaves the
    // cube origin at a corner instead of centering it, making held blocks sit
    // incorrectly relative to the hand. Keep this correction block-only.
    hand_pose * Mat4::from_scale(Vec3::splat(2.0)) * first_person_display
        * Mat4::from_scale(Vec3::splat(0.5))
        * Mat4::from_translation(Vec3::splat(-0.5))
}

/// ItemRenderer.doItemUsedTransformations + transformFirstPersonItem, followed
/// by the generated-item preTransform scale, model display transform and
/// RenderItem's inner scale(0.5), in MCP 1.8.9 OpenGL post-multiplication order.
fn vanilla_first_person_item_matrix(
    swing_progress: f32,
    equip_progress: f32,
    display: ItemCameraTransform,
    _gui_3d_model: bool,
) -> Mat4 {
    let swing = swing_progress.clamp(0.0, 1.0);
    let root = swing.sqrt() * std::f32::consts::PI;
    let f = (swing * swing * std::f32::consts::PI).sin();
    let f1 = root.sin();
    let swing_translation = Vec3::new(
        -0.4 * f1,
        0.2 * (root * 2.0).sin(),
        -0.2 * (swing * std::f32::consts::PI).sin(),
    );
    let vanilla = Mat4::from_translation(swing_translation)
        * Mat4::from_translation(Vec3::new(0.56, -0.52, -0.71999997))
        * Mat4::from_translation(Vec3::new(0.0, equip_progress * -0.6, 0.0))
        * Mat4::from_rotation_y(45.0_f32.to_radians())
        * Mat4::from_rotation_y((-20.0 * f).to_radians())
        * Mat4::from_rotation_z((-20.0 * f1).to_radians())
        * Mat4::from_rotation_x((-80.0 * f1).to_radians())
        // MCP 1.8.9 ItemRenderer.transformFirstPersonItem ends with
        // GlStateManager.scale(0.4F, 0.4F, 0.4F). Omitting this makes
        // generated swords/tools 2.5x too large despite correct display JSON.
        * Mat4::from_scale(Vec3::splat(0.4));
    // MCP 1.8.9 RenderItem.renderItemModelTransform calls preTransform before
    // applying the display transform: GUI-3D models get ItemRenderer's outer
    // scale(2), while flat/generated models get preTransform's scale(2).
    // Both paths then enter renderItem(), which applies scale(0.5). Therefore
    // the effective model scale is 2 * 0.5 for BOTH model classes. The previous
    // code only applied the 2x factor to GUI-3D models, making every generated
    // tool (pickaxe, sword, apple, etc.) half-size and distorting its apparent
    // relationship to its extruded silhouette.
    let model_path_scale = 2.0;
    let display_transform = Mat4::from_translation(Vec3::from_array(display.translation))
        // Verified against MCP 1.8.9 ItemCameraTransforms.applyTransform:
        // GlStateManager.rotate(Y), then rotate(X), then rotate(Z), then scale.
        // In the composed matrix this is T * Ry * Rx * Rz * S. The old Rust
        // order (Z * Y * X) rotated generated sprites around the wrong axes,
        // making the front/back sprite silhouette appear crossed against its
        // own extrusion when the first-person model rotation was applied.
        * Mat4::from_rotation_y(display.rotation[1].to_radians())
        * Mat4::from_rotation_x(display.rotation[0].to_radians())
        * Mat4::from_rotation_z(display.rotation[2].to_radians())
        * Mat4::from_scale(Vec3::from_array(display.scale));
    vanilla * Mat4::from_scale(Vec3::splat(model_path_scale)) * display_transform
        * Mat4::from_scale(Vec3::splat(0.5))
}

/// Upload a small generated item texture with nearest sampling. The item atlas uses
/// alpha cutout like RenderItem; keeping a private texture also avoids atlas UV bleed.
fn upload_rgba_texture(
    device: &wgpu::Device,
    queue: &wgpu::Queue,
    layout: &wgpu::BindGroupLayout,
    label: &str,
    pixels: &image::RgbaImage,
) -> GpuHandTexture {
    let width = pixels.width().max(1);
    let height = pixels.height().max(1);
    let texture = device.create_texture(&wgpu::TextureDescriptor {
        label: Some(label), size: wgpu::Extent3d { width, height, depth_or_array_layers: 1 },
        mip_level_count: 1, sample_count: 1, dimension: wgpu::TextureDimension::D2,
        format: wgpu::TextureFormat::Rgba8UnormSrgb,
        usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
        view_formats: &[],
    });
    queue.write_texture(
        wgpu::ImageCopyTexture { texture: &texture, mip_level: 0, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
        pixels.as_raw(),
        wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(width * 4), rows_per_image: Some(height) },
        wgpu::Extent3d { width, height, depth_or_array_layers: 1 },
    );
    let view = texture.create_view(&wgpu::TextureViewDescriptor::default());
    let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
        label: Some("Minecraft generated item nearest sampler"),
        address_mode_u: wgpu::AddressMode::ClampToEdge,
        address_mode_v: wgpu::AddressMode::ClampToEdge,
        address_mode_w: wgpu::AddressMode::ClampToEdge,
        mag_filter: wgpu::FilterMode::Nearest,
        min_filter: wgpu::FilterMode::Nearest,
        mipmap_filter: wgpu::FilterMode::Nearest,
        ..Default::default()
    });
    let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some("Minecraft generated item texture bind group"), layout,
        entries: &[
            wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&view) },
            wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&sampler) },
        ],
    });
    GpuHandTexture { _texture: texture, bind_group }
}

/// Vanilla foliage and flowers use binary-alpha textures. Crossed plant models
/// additionally expose opposite-winding faces on the same zero-thickness planes.
/// Route these resources through a cutout pipeline: replacement blending prevents
/// alpha accumulation, while back-face culling selects one side of crossed planes.
fn is_cutout_vegetation_texture(path: &str) -> bool {
    matches!(path,
        // Grass and fern, including double-height variants.
        "assets/minecraft/textures/blocks/tallgrass.png"
        | "assets/minecraft/textures/blocks/fern.png"
        | "assets/minecraft/textures/blocks/double_plant_grass_bottom.png"
        | "assets/minecraft/textures/blocks/double_plant_grass_top.png"
        | "assets/minecraft/textures/blocks/double_plant_fern_bottom.png"
        | "assets/minecraft/textures/blocks/double_plant_fern_top.png"
        // Single-block flowers.
        | "assets/minecraft/textures/blocks/flower_allium.png"
        | "assets/minecraft/textures/blocks/flower_blue_orchid.png"
        | "assets/minecraft/textures/blocks/flower_dandelion.png"
        | "assets/minecraft/textures/blocks/flower_houstonia.png"
        | "assets/minecraft/textures/blocks/flower_oxeye_daisy.png"
        | "assets/minecraft/textures/blocks/flower_rose.png"
        | "assets/minecraft/textures/blocks/flower_tulip_orange.png"
        | "assets/minecraft/textures/blocks/flower_tulip_pink.png"
        | "assets/minecraft/textures/blocks/flower_tulip_red.png"
        | "assets/minecraft/textures/blocks/flower_tulip_white.png"
        // Double-height flowers and their front/back sunflower planes.
        | "assets/minecraft/textures/blocks/double_plant_paeonia_bottom.png"
        | "assets/minecraft/textures/blocks/double_plant_paeonia_top.png"
        | "assets/minecraft/textures/blocks/double_plant_rose_bottom.png"
        | "assets/minecraft/textures/blocks/double_plant_rose_top.png"
        | "assets/minecraft/textures/blocks/double_plant_syringa_bottom.png"
        | "assets/minecraft/textures/blocks/double_plant_syringa_top.png"
        | "assets/minecraft/textures/blocks/double_plant_sunflower_back.png"
        | "assets/minecraft/textures/blocks/double_plant_sunflower_bottom.png"
        | "assets/minecraft/textures/blocks/double_plant_sunflower_front.png"
        | "assets/minecraft/textures/blocks/double_plant_sunflower_top.png"
        // Mushrooms are also crossed, zero-thickness plant models. Use the same
        // binary-alpha/culling path as grass and flowers to avoid coincident-face
        // depth fighting between their opposite-winding sides.
        | "assets/minecraft/textures/blocks/mushroom_brown.png"
        | "assets/minecraft/textures/blocks/mushroom_red.png"
        // Saplings share the same crossed-plane model construction.
        | "assets/minecraft/textures/blocks/sapling_acacia.png"
        | "assets/minecraft/textures/blocks/sapling_birch.png"
        | "assets/minecraft/textures/blocks/sapling_jungle.png"
        | "assets/minecraft/textures/blocks/sapling_oak.png"
        | "assets/minecraft/textures/blocks/sapling_roofed_oak.png"
        | "assets/minecraft/textures/blocks/sapling_spruce.png"
        // All six vanilla leaf species use alpha cutout in fancy foliage rendering.
        | "assets/minecraft/textures/blocks/leaves_acacia.png"
        | "assets/minecraft/textures/blocks/leaves_big_oak.png"
        | "assets/minecraft/textures/blocks/leaves_birch.png"
        | "assets/minecraft/textures/blocks/leaves_jungle.png"
        | "assets/minecraft/textures/blocks/leaves_oak.png"
        | "assets/minecraft/textures/blocks/leaves_spruce.png"
        // Sugar cane (the vanilla reeds crossed-plane model) uses binary alpha.
        // Render it through the same cutout pass to avoid coplanar opposite faces
        // fighting while keeping transparent texels fully discarded.
        | "assets/minecraft/textures/blocks/reeds.png"
        // Cobweb inherits block/cross: its two crossed, zero-thickness planes
        // have opposite-facing copies just like the vanilla plant models above.
        | "assets/minecraft/textures/blocks/web.png"
        // Every vanilla rail model (flat, curved and ascending) is a zero-thickness
        // plane with coincident up/down faces. Powered and detector variants use
        // the same geometry with distinct binary-alpha textures, so route all rail
        // textures through the identical single-sided cutout pipeline.
        | "assets/minecraft/textures/blocks/rail_activator.png"
        | "assets/minecraft/textures/blocks/rail_activator_powered.png"
        | "assets/minecraft/textures/blocks/rail_detector.png"
        | "assets/minecraft/textures/blocks/rail_detector_powered.png"
        | "assets/minecraft/textures/blocks/rail_golden.png"
        | "assets/minecraft/textures/blocks/rail_golden_powered.png"
        | "assets/minecraft/textures/blocks/rail_normal.png"
        | "assets/minecraft/textures/blocks/rail_normal_turned.png"
    )
}

/// Glass blocks and stained glass belong to the vanilla translucent layer.
/// They must not write opaque depth while alpha-blending, otherwise the first
/// face of a glass cuboid hides its opposite face and creates order-dependent
/// speckling/z-fighting when several panes touch.
fn is_translucent_glass_texture(path: &str) -> bool {
    path.starts_with("assets/minecraft/textures/blocks/glass")
}

fn is_translucent_water_texture(path: &str) -> bool {
    matches!(path,
        "assets/minecraft/textures/blocks/water_still_frame0.png"
        | "assets/minecraft/textures/blocks/water_flow_frame0.png")
}

fn compile_textured_mesh(quads: &[CpuMeshQuad], atlas: &AtlasRuntime) -> Result<CpuMesh> {
    let mut vertices = Vec::with_capacity(quads.len() * 6);
    let mut cutout_vertices = Vec::new();
    let mut translucent_vertices = Vec::new();
    let mut fluid_vertices = Vec::new();
    let mut vertex_owners = Vec::new();
    let mut cutout_owners = Vec::new();
    let mut translucent_owners = Vec::new();
    let mut fluid_owners = Vec::new();
    let mut reported_missing_textures = HashSet::<String>::new();
    let mut reported_invalid_paths = HashSet::<String>::new();
    for quad in quads {
        // The current atlas builder produces one page for the verified vanilla 1.8.9 set.
        // A single bad face descriptor must not discard every other face in the chunk.
        let Some(texture) = quad.texture_path.strip_prefix("assets/minecraft/textures/") else {
            if reported_invalid_paths.insert(quad.texture_path.clone()) {
                eprintln!("[atlas] non-vanilla or invalid texture path {:?}; skipping only faces using this path", quad.texture_path);
            }
            continue;
        };
        let (mapped, rotation) = match atlas.remap_face_uv(texture, quad.uv_rect, quad.uv_rotation) {
            Ok(mapped) => mapped,
            Err(error) => {
                if reported_missing_textures.insert(texture.to_owned()) {
                    eprintln!("[atlas] missing or invalid sprite {:?}: {}; skipping only faces using this sprite, not the whole chunk", texture, error);
                }
                continue;
            }
        };
        let uv = if let Some(corners) = quad.uv_corners {
            let [u0, v0, u1, v1] = mapped;
            corners.map(|[u, v]| [u0 + (u / 16.0) * (u1 - u0), v0 + (v / 16.0) * (v1 - v0)])
        } else {
            face_uv_corners(quad.face, mapped, rotation)
        };
        let order = [0_usize, 1, 2, 0, 2, 3];
        let (target, owner_target) = if is_translucent_water_texture(&quad.texture_path) {
            (&mut fluid_vertices, &mut fluid_owners)
        } else if is_cutout_vegetation_texture(&quad.texture_path) {
            (&mut cutout_vertices, &mut cutout_owners)
        } else if is_translucent_glass_texture(&quad.texture_path) {
            (&mut translucent_vertices, &mut translucent_owners)
        } else {
            (&mut vertices, &mut vertex_owners)
        };
        let owner = quad.source_block.unwrap_or([i32::MIN; 3]);
        for corner in order {
            let shaded = quad.shade;
            target.push(Vertex {
                position: quad.positions[corner], normal: quad.normal, uv: uv[corner], tint: quad.tint_color,
                ao: if quad.ambient_occlusion { quad.vertex_ao[corner] } else { 1.0 },
                sky_light: quad.vertex_sky_light[corner],
                block_light: quad.vertex_block_light[corner],
                face_shade: if shaded { quad.vertex_face_shade[corner] } else { 1.0 },
            });
            owner_target.push(owner);
        }
    }
    let triangles = (vertices.len() + cutout_vertices.len() + translucent_vertices.len() + fluid_vertices.len()) / 3;
    Ok(CpuMesh { vertices, cutout_vertices, translucent_vertices, fluid_vertices,
        vertex_owners, cutout_owners, translucent_owners, fluid_owners, triangles })
}

struct GpuChunkSectionMesh {
    vertex_buffer: Option<wgpu::Buffer>,
    vertex_buffer_capacity: u64,
    vertex_count: u32,
    vegetation_vertex_buffer: Option<wgpu::Buffer>,
    vegetation_vertex_buffer_capacity: u64,
    vegetation_vertex_count: u32,
    translucent_vertex_buffer: Option<wgpu::Buffer>,
    translucent_vertex_buffer_capacity: u64,
    translucent_vertex_count: u32,
    fluid_vertex_buffer: Option<wgpu::Buffer>,
    fluid_vertex_buffer_capacity: u64,
    fluid_vertex_count: u32,
}

impl GpuChunkSectionMesh {
    fn empty() -> Self {
        Self {
            vertex_buffer: None, vertex_buffer_capacity: 0, vertex_count: 0,
            vegetation_vertex_buffer: None, vegetation_vertex_buffer_capacity: 0, vegetation_vertex_count: 0,
            translucent_vertex_buffer: None, translucent_vertex_buffer_capacity: 0, translucent_vertex_count: 0,
            fluid_vertex_buffer: None, fluid_vertex_buffer_capacity: 0, fluid_vertex_count: 0,
        }
    }

    fn update(&mut self, device: &wgpu::Device, queue: &wgpu::Queue, mesh: &CpuMesh) -> Result<()> {
        if mesh.vertices.len() > u32::MAX as usize || mesh.cutout_vertices.len() > u32::MAX as usize
            || mesh.translucent_vertices.len() > u32::MAX as usize || mesh.fluid_vertices.len() > u32::MAX as usize {
            return Err(Mc189Error::InvalidData("chunk has too many vertices".into()));
        }
        // Reuse per-layer GPU allocations whenever the recompiled chunk still
        // fits. Empty layers set count=0 but retain capacity for the next edit.
        fn write_layer(
            device: &wgpu::Device, queue: &wgpu::Queue, label: &'static str,
            vertices: &[Vertex], buffer: &mut Option<wgpu::Buffer>, capacity: &mut u64,
        ) -> Result<()> {
            if vertices.is_empty() { return Ok(()); }
            let bytes = bytemuck::cast_slice(vertices);
            let required = bytes.len() as u64;
            if required > *capacity {
                let next_capacity = required.checked_next_power_of_two().unwrap_or(required);
                *buffer = Some(device.create_buffer(&wgpu::BufferDescriptor {
                    label: Some(label), size: next_capacity,
                    usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                    mapped_at_creation: false,
                }));
                *capacity = next_capacity;
            }
            if let Some(target) = buffer.as_ref() { queue.write_buffer(target, 0, bytes); }
            Ok(())
        }
        write_layer(device, queue, "streamed chunk opaque vertices", &mesh.vertices, &mut self.vertex_buffer, &mut self.vertex_buffer_capacity)?;
        write_layer(device, queue, "streamed chunk cutout vertices", &mesh.cutout_vertices, &mut self.vegetation_vertex_buffer, &mut self.vegetation_vertex_buffer_capacity)?;
        write_layer(device, queue, "streamed chunk translucent glass vertices", &mesh.translucent_vertices, &mut self.translucent_vertex_buffer, &mut self.translucent_vertex_buffer_capacity)?;
        write_layer(device, queue, "streamed chunk translucent water vertices", &mesh.fluid_vertices, &mut self.fluid_vertex_buffer, &mut self.fluid_vertex_buffer_capacity)?;
        self.vertex_count = mesh.vertices.len() as u32;
        self.vegetation_vertex_count = mesh.cutout_vertices.len() as u32;
        self.translucent_vertex_count = mesh.translucent_vertices.len() as u32;
        self.fluid_vertex_count = mesh.fluid_vertices.len() as u32;
        Ok(())
    }
}


struct GpuChunkMesh {
    sections: BTreeMap<u8, GpuChunkSectionMesh>,
}

impl GpuChunkMesh {
    fn empty() -> Self { Self { sections: BTreeMap::new() } }

    fn upload(device: &wgpu::Device, queue: &wgpu::Queue, mesh: &CpuMesh) -> Result<Self> {
        let mut result = Self::empty();
        result.update_full(device, queue, mesh)?;
        Ok(result)
    }

    fn update_full(&mut self, device: &wgpu::Device, queue: &wgpu::Queue, mesh: &CpuMesh) -> Result<()> {
        let mut section_ids = BTreeMap::<u8, ()>::new();
        for owner in mesh.vertex_owners.iter().chain(mesh.cutout_owners.iter())
            .chain(mesh.translucent_owners.iter()).chain(mesh.fluid_owners.iter())
        {
            section_ids.insert(owner[1].clamp(0, 255).div_euclid(16) as u8, ());
        }
        self.sections.retain(|section_y, _| section_ids.contains_key(section_y));
        for section_y in section_ids.keys().copied() {
            let part = mesh.section_mesh(section_y);
            self.update_section(device, queue, section_y, &part)?;
        }
        Ok(())
    }

    fn update_section(&mut self, device: &wgpu::Device, queue: &wgpu::Queue, section_y: u8, mesh: &CpuMesh) -> Result<()> {
        if mesh.total_vertices() == 0 {
            self.sections.remove(&section_y);
            return Ok(());
        }
        let section = self.sections.entry(section_y).or_insert_with(GpuChunkSectionMesh::empty);
        section.update(device, queue, mesh)
    }
}
struct GpuHandTexture {
    _texture: wgpu::Texture,
    bind_group: wgpu::BindGroup,
}

struct DroppedGeneratedItemCacheEntry {
    base_vertices: Vec<Vertex>,
    texture: GpuHandTexture,
}

struct DroppedGeneratedItemBatch {
    vertex_buffer: wgpu::Buffer,
    vertex_buffer_capacity: u64,
    vertex_count: u32,
}

struct GpuVanillaLightmap {
    _texture: wgpu::Texture,
    _view: wgpu::TextureView,
    _sampler: wgpu::Sampler,
    bind_group: wgpu::BindGroup,
}

/// Build the same 16x16 lightmap lookup table as EntityRenderer.updateLightmap
/// for clear daytime. X is block light and Y is sky light, matching the packed
/// light-coordinate convention used by the original renderer.
fn vanilla_lightmap_pixels() -> Vec<u8> {
    vanilla_lightmap_pixels_for_conditions(1.0, 0.0, false)
}

fn vanilla_lightmap_pixels_for_conditions(
    sun_brightness: f32,
    torch_flicker: f32,
    lightning_flash: bool,
) -> Vec<u8> {
    const SIZE: u32 = 16;
    let mut pixels = vec![0_u8; (SIZE * SIZE * 4) as usize];
    for sky in 0..SIZE {
        for block in 0..SIZE {
            let rgb = vanilla_lightmap_rgb(
                sky as f32 / 15.0,
                block as f32 / 15.0,
                sun_brightness,
                torch_flicker,
                lightning_flash,
            );
            let offset = ((sky * SIZE + block) * 4) as usize;
            pixels[offset] = (rgb[0] * 255.0).clamp(0.0, 255.0) as u8;
            pixels[offset + 1] = (rgb[1] * 255.0).clamp(0.0, 255.0) as u8;
            pixels[offset + 2] = (rgb[2] * 255.0).clamp(0.0, 255.0) as u8;
            pixels[offset + 3] = 255;
        }
    }
    pixels
}

/// Build the 16x16 texture and a linear sampler. Vertex light levels are
/// interpolated first, then the lookup texture performs the same bilinear
/// filtering role as the legacy OpenGL lightmap texture.
fn upload_vanilla_lightmap(
    device: &wgpu::Device,
    queue: &wgpu::Queue,
    layout: &wgpu::BindGroupLayout,
) -> GpuVanillaLightmap {
    const SIZE: u32 = 16;
    let pixels = vanilla_lightmap_pixels();
    let texture = device.create_texture(&wgpu::TextureDescriptor {
        label: Some("Minecraft 1.8.9 clear-day 16x16 lightmap"),
        size: wgpu::Extent3d { width: SIZE, height: SIZE, depth_or_array_layers: 1 },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: wgpu::TextureFormat::Rgba8Unorm,
        usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
        view_formats: &[],
    });
    queue.write_texture(
        wgpu::ImageCopyTexture {
            texture: &texture,
            mip_level: 0,
            origin: wgpu::Origin3d::ZERO,
            aspect: wgpu::TextureAspect::All,
        },
        &pixels,
        wgpu::ImageDataLayout {
            offset: 0,
            bytes_per_row: Some(SIZE * 4),
            rows_per_image: Some(SIZE),
        },
        wgpu::Extent3d { width: SIZE, height: SIZE, depth_or_array_layers: 1 },
    );
    let view = texture.create_view(&wgpu::TextureViewDescriptor::default());
    let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
        label: Some("Minecraft 1.8.9 lightmap linear sampler"),
        address_mode_u: wgpu::AddressMode::ClampToEdge,
        address_mode_v: wgpu::AddressMode::ClampToEdge,
        address_mode_w: wgpu::AddressMode::ClampToEdge,
        mag_filter: wgpu::FilterMode::Linear,
        min_filter: wgpu::FilterMode::Linear,
        mipmap_filter: wgpu::FilterMode::Nearest,
        ..Default::default()
    });
    let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some("Minecraft 1.8.9 lightmap bind group"),
        layout,
        entries: &[
            wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&view) },
            wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&sampler) },
        ],
    });
    GpuVanillaLightmap { _texture: texture, _view: view, _sampler: sampler, bind_group }
}

fn update_vanilla_lightmap(
    queue: &wgpu::Queue,
    lightmap: &GpuVanillaLightmap,
    sun_brightness: f32,
    torch_flicker: f32,
    lightning_flash: bool,
) {
    const SIZE: u32 = 16;
    let pixels = vanilla_lightmap_pixels_for_conditions(sun_brightness, torch_flicker, lightning_flash);
    queue.write_texture(
        wgpu::ImageCopyTexture { texture: &lightmap._texture, mip_level: 0, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
        &pixels,
        wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(SIZE * 4), rows_per_image: Some(SIZE) },
        wgpu::Extent3d { width: SIZE, height: SIZE, depth_or_array_layers: 1 },
    );
}

struct FluidAnimationFrame {
    pixels: image::RgbaImage,
    duration_ticks: u32,
}

struct FluidAnimation {
    pixel_rect: [u32; 4],
    frames: Vec<FluidAnimationFrame>,
    current_frame: usize,
    elapsed: Duration,
}

fn load_fluid_animations(atlas_dir: &Path, atlas_runtime: &AtlasRuntime) -> Result<Vec<FluidAnimation>> {
    let definitions = [
        ("blocks/water_still.png", "blocks/water_still_frame0.png"),
        ("blocks/water_flow.png", "blocks/water_flow_frame0.png"),
        ("blocks/lava_still.png", "blocks/lava_still_frame0.png"),
        ("blocks/lava_flow.png", "blocks/lava_flow_frame0.png"),
    ];
    let mut animations = Vec::new();
    for (source_name, alias_name) in definitions {
        if !atlas_runtime.animated_textures().iter().any(|path| path.as_str() == source_name) {
            continue;
        }
        let Some(region) = atlas_runtime.lookup(alias_name) else { continue; };
        if region.page != 0 {
            return Err(Mc189Error::InvalidData(format!("animated fluid sprite {source_name} is not on atlas page 0")));
        }
        let image_path = atlas_dir.join("animated").join(source_name);
        let metadata_path = std::path::PathBuf::from(format!("{}.mcmeta", image_path.display()));
        if !image_path.is_file() || !metadata_path.is_file() {
            // Keep older hand-built atlases usable; they simply retain frame zero.
            eprintln!("[fluid animation] missing animation data for {source_name}; using frame zero");
            continue;
        }
        let strip = image::open(&image_path).map_err(|error| Mc189Error::InvalidData(format!("cannot decode fluid animation {}: {error}", image_path.display())))?.to_rgba8();
        let frame_size = strip.width();
        if frame_size == 0 || strip.height() % frame_size != 0
            || region.pixel_rect[2] != frame_size || region.pixel_rect[3] != frame_size {
            return Err(Mc189Error::InvalidData(format!("invalid frame dimensions for fluid animation {source_name}")));
        }
        let frame_count = strip.height() / frame_size;
        let metadata: serde_json::Value = serde_json::from_slice(&std::fs::read(&metadata_path)?).map_err(|error| {
            Mc189Error::InvalidData(format!("invalid fluid animation metadata {}: {error}", metadata_path.display()))
        })?;
        let animation = metadata.get("animation").and_then(serde_json::Value::as_object)
            .ok_or_else(|| Mc189Error::InvalidData(format!("missing animation object in {}", metadata_path.display())))?;
        let default_time = animation.get("frametime").and_then(serde_json::Value::as_u64).unwrap_or(1).clamp(1, u64::from(u32::MAX)) as u32;
        let mut frame_specs = Vec::<(u32, u32)>::new();
        if let Some(specs) = animation.get("frames").and_then(serde_json::Value::as_array) {
            for spec in specs {
                let (index, duration) = if let Some(index) = spec.as_u64() {
                    (index, default_time)
                } else if let Some(object) = spec.as_object() {
                    let index = object.get("index").and_then(serde_json::Value::as_u64)
                        .ok_or_else(|| Mc189Error::InvalidData(format!("fluid frame entry in {source_name} has no index")))?;
                    let duration = object.get("time").and_then(serde_json::Value::as_u64).unwrap_or(u64::from(default_time))
                        .clamp(1, u64::from(u32::MAX)) as u32;
                    (index, duration)
                } else {
                    return Err(Mc189Error::InvalidData(format!("invalid fluid frame entry in {source_name}")));
                };
                if index >= u64::from(frame_count) {
                    return Err(Mc189Error::InvalidData(format!("fluid frame {index} is outside {source_name} ({frame_count} frames)")));
                }
                frame_specs.push((index as u32, duration));
            }
        } else {
            frame_specs.extend((0..frame_count).map(|index| (index, default_time)));
        }
        if frame_specs.is_empty() {
            return Err(Mc189Error::InvalidData(format!("fluid animation {source_name} has no frames")));
        }
        let frames = frame_specs.into_iter().map(|(index, duration_ticks)| {
            let pixels = image::imageops::crop_imm(&strip, 0, index * frame_size, frame_size, frame_size).to_image();
            FluidAnimationFrame { pixels, duration_ticks }
        }).collect();
        animations.push(FluidAnimation { pixel_rect: region.pixel_rect, frames, current_frame: 0, elapsed: Duration::ZERO });
    }
    Ok(animations)
}

fn extrude_fluid_frame(frame: &image::RgbaImage, padding: u32) -> image::RgbaImage {
    let (width, height) = frame.dimensions();
    let mut padded = image::RgbaImage::new(width + padding * 2, height + padding * 2);
    for y in 0..padded.height() {
        for x in 0..padded.width() {
            let source_x = x.saturating_sub(padding).min(width - 1);
            let source_y = y.saturating_sub(padding).min(height - 1);
            padded.put_pixel(x, y, *frame.get_pixel(source_x, source_y));
        }
    }
    padded
}

struct Viewer {
    surface: wgpu::Surface<'static>, device: wgpu::Device, queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration, pipeline: wgpu::RenderPipeline,
    vegetation_pipeline: wgpu::RenderPipeline,
    fluid_pipeline: wgpu::RenderPipeline,
    hand_pipeline: wgpu::RenderPipeline,
    crosshair_pipeline: wgpu::RenderPipeline,
    crosshair_vertex_buffer: wgpu::Buffer,
    crosshair_vertex_count: u32,
    crosshair_visible: bool,
    hand_vertex_buffer: wgpu::Buffer,
    hand_vertex_count: u32,
    hand_texture_height: f32,
    hand_swing_progress_int: i32,
    hand_swing_in_progress: bool,
    hand_prev_swing_progress: f32,
    hand_swing_progress: f32,
    hand_render_swing_progress: f32,
    hand_camera_buffer: wgpu::Buffer,
    hand_camera_bind_group: wgpu::BindGroup,
    hand_texture: Option<GpuHandTexture>,
    /// Active first-person item mesh. Block-like items sample the vanilla block atlas;
    /// generated item layers use their own small, nearest-filtered item texture.
    held_item_vertex_buffer: wgpu::Buffer,
    held_item_vertex_count: u32,
    held_item_buffer_capacity_vertices: usize,
    held_item_base_vertices: Vec<Vertex>,
    held_item_render_vertices: Vec<Vertex>,
    held_item_texture: Option<GpuHandTexture>,
    held_item_uses_atlas: bool,
    /// Key currently represented by the active mesh (ItemRenderer.itemToRender).
    held_item_key: Option<String>,
    /// Currently selected hotbar item, which may be waiting for equip lowering.
    held_item_requested_key: Option<String>,
    held_item_swap_pending: bool,
    held_item_equip_progress: f32,
    held_item_prev_equip_progress: f32,
    held_item_render_equip_progress: f32,
    held_item_display_transform: ItemCameraTransform,
    /// True when the selected model resolves to cuboid/block geometry; its camera transform is independent from generated items.
    held_item_is_block_model: bool,
    /// World-space dropped item entities, rendered with the vanilla block atlas.
    dropped_item_vertex_buffer: wgpu::Buffer,
    dropped_item_vertex_count: u32,
    dropped_item_buffer_capacity_vertices: usize,
    dropped_item_generated_cache: HashMap<(u16, u16), DroppedGeneratedItemCacheEntry>,
    dropped_item_texture_failures: HashSet<(u16, u16)>,
    /// Persistent dynamic vertex buffers keyed by item+metadata. The previous
    /// path allocated fresh GPU buffers for every dropped-item update (20 Hz),
    /// which caused severe driver stalls whenever item entities were present.
    dropped_item_generated_batches: HashMap<(u16, u16), DroppedGeneratedItemBatch>,
    /// CPU-side block-model geometry cache; model JSON and baked vertices are
    /// resolved once per legacy item state, not reloaded/rebuilt each world tick.
    dropped_item_block_model_cache: HashMap<(u16, u16), Option<Vec<Vertex>>> ,
    /// Vanilla 1.8.9 destroy_stage_0..9 sprites packed into one 160x16 texture.
    mining_crack_texture: Option<GpuHandTexture>,
    mining_crack_vertex_buffer: wgpu::Buffer,
    mining_crack_vertex_count: u32,
    mining_crack_buffer_capacity_vertices: usize,
    mining_crack_pipeline: wgpu::RenderPipeline,
    held_model_catalog: Option<ModelCatalog>,
    atlas_runtime: AtlasRuntime,
    gui_overlay: GuiOverlayGpu,
    chat_overlay: GuiOverlayGpu,
    player_preview_sprite: GuiSpriteGpu,
    cursor_stack_sprite: GuiSpriteGpu,
    slot_highlight_sprite: GuiSpriteGpu,
    hotbar_selection_sprite: GuiSpriteGpu,
    player_preview_visible: bool,
    cursor_stack_visible: bool,
    slot_highlight_visible: bool,
    hotbar_selection_visible: bool,
    player_preview_dirty: bool,
    cursor_stack_dirty: bool,
    cursor_stack_image_dirty: bool,
    inventory_ui: Option<crate::inventory::InventoryUi>,
    chunk_meshes: BTreeMap<(i32, i32), GpuChunkMesh>,
    camera_buffer: wgpu::Buffer,
    camera_bind_group: wgpu::BindGroup, atlas: GpuAtlasPage,
    lightmap: GpuVanillaLightmap,
    _depth_texture: wgpu::Texture, depth_view: wgpu::TextureView,
    target: Vec3, home_target: Vec3, radius: f32, yaw: f32, pitch: f32, zoom: f32,
    camera_position: Vec3,
    chunk_origin: (i32, i32),
    fluid_animations: Vec<FluidAnimation>,
    fluid_animation_padding: u32,
    last_fluid_animation_update: Instant,
    sky_clear_color: [f64; 3],
}
impl Viewer {
    async fn new(window: Arc<Window>, meshes: &HashMap<(i32, i32), CpuMesh>, atlas_dir: &Path, atlas_runtime: &AtlasRuntime, hand_skin_jar: Option<&Path>, camera_target: Vec3, camera_radius: f32, chunk_origin: (i32, i32)) -> Result<Self> {
        let instance = wgpu::Instance::default();
        let surface = instance.create_surface(window.clone()).map_err(|e| Mc189Error::InvalidData(format!("cannot create preview surface: {e}")))?;
        let adapter = instance.request_adapter(&wgpu::RequestAdapterOptions { power_preference: wgpu::PowerPreference::HighPerformance,
            compatible_surface: Some(&surface), force_fallback_adapter: false }).await
            .ok_or_else(|| Mc189Error::InvalidData("no compatible GPU adapter found".into()))?;
        let (device, queue) = adapter.request_device(&wgpu::DeviceDescriptor { label: Some("mc189 textured block preview device"),
            required_features: wgpu::Features::empty(), required_limits: wgpu::Limits::downlevel_defaults() }, None).await
            .map_err(|e| Mc189Error::InvalidData(format!("cannot create GPU device: {e}")))?;
        let atlas = GpuAtlasPage::upload(&device, &queue, &atlas_runtime.page_path(0), atlas_runtime.page_size())?;
        let fluid_animations = load_fluid_animations(atlas_dir, atlas_runtime)?;
        println!("[fluid animation] scheduled {} vanilla water/lava sprites", fluid_animations.len());
        let capabilities = surface.get_capabilities(&adapter);
        let format = capabilities.formats.iter().copied().find(wgpu::TextureFormat::is_srgb)
            .or_else(|| capabilities.formats.first().copied()).ok_or_else(|| Mc189Error::InvalidData("surface has no formats".into()))?;
        let present_mode = capabilities.present_modes.iter().copied().find(|m| *m == wgpu::PresentMode::Fifo)
            .or_else(|| capabilities.present_modes.first().copied()).ok_or_else(|| Mc189Error::InvalidData("surface has no present modes".into()))?;
        let alpha_mode = *capabilities.alpha_modes.first().ok_or_else(|| Mc189Error::InvalidData("surface has no alpha modes".into()))?;
        let size = window.inner_size();
        let config = wgpu::SurfaceConfiguration { usage: wgpu::TextureUsages::RENDER_ATTACHMENT, format,
            width: size.width.max(1), height: size.height.max(1), present_mode, desired_maximum_frame_latency: 2,
            alpha_mode, view_formats: vec![] };
        surface.configure(&device, &config);
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("textured block shader"), source: wgpu::ShaderSource::Wgsl(SHADER.into()) });
        let camera_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor { label: Some("block preview camera layout"), entries: &[wgpu::BindGroupLayoutEntry {
            binding: 0, visibility: wgpu::ShaderStages::VERTEX, ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform,
                has_dynamic_offset: false, min_binding_size: None }, count: None }] });
        let lightmap_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("Minecraft 1.8.9 lightmap layout"),
            entries: &[
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Float { filterable: true },
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                    count: None,
                },
            ],
        });
        let lightmap = upload_vanilla_lightmap(&device, &queue, &lightmap_layout);
        let camera_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor { label: Some("block preview camera buffer"),
            contents: bytemuck::bytes_of(&CameraUniform { view_projection: Mat4::IDENTITY.to_cols_array_2d() }),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST });
        let camera_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor { label: Some("block preview camera bind group"), layout: &camera_layout,
            entries: &[wgpu::BindGroupEntry { binding: 0, resource: camera_buffer.as_entire_binding() }] });
        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor { label: Some("textured block pipeline layout"),
            bind_group_layouts: &[&camera_layout, &atlas.bind_group_layout, &lightmap_layout], push_constant_ranges: &[] });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor { label: Some("textured block pipeline"), layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState { module: &shader, entry_point: "vs_main", buffers: &[Vertex::layout()] },
            fragment: Some(wgpu::FragmentState { module: &shader, entry_point: "fs_main", targets: &[Some(wgpu::ColorTargetState {
                format, blend: Some(wgpu::BlendState::ALPHA_BLENDING), write_mask: wgpu::ColorWrites::ALL })] }),
            primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw, cull_mode: None, polygon_mode: wgpu::PolygonMode::Fill, unclipped_depth: false, conservative: false },
            depth_stencil: Some(wgpu::DepthStencilState { format: wgpu::TextureFormat::Depth32Float, depth_write_enabled: true,
                depth_compare: wgpu::CompareFunction::Less, stencil: wgpu::StencilState::default(), bias: wgpu::DepthBiasState::default() }),
            multisample: wgpu::MultisampleState::default(), multiview: None });
        // Crossed plants use binary alpha cutout, not blended transparency. Their
        // opposite faces share exactly the same plane, so back-face culling selects
        // only the side facing the camera and prevents coplanar double rendering.
        let vegetation_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor { label: Some("vanilla vegetation cutout pipeline"), layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState { module: &shader, entry_point: "vs_main", buffers: &[Vertex::layout()] },
            fragment: Some(wgpu::FragmentState { module: &shader, entry_point: "fs_main", targets: &[Some(wgpu::ColorTargetState {
                format, blend: None, write_mask: wgpu::ColorWrites::ALL })] }),
            primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw, cull_mode: Some(wgpu::Face::Back), polygon_mode: wgpu::PolygonMode::Fill, unclipped_depth: false, conservative: false },
            depth_stencil: Some(wgpu::DepthStencilState { format: wgpu::TextureFormat::Depth32Float, depth_write_enabled: true,
                depth_compare: wgpu::CompareFunction::Less, stencil: wgpu::StencilState::default(), bias: wgpu::DepthBiasState::default() }),
            multisample: wgpu::MultisampleState::default(), multiview: None });
        // Translucent glass and water use a separate pass: opaque terrain and cutout
        // blocks are drawn first; this pass blends without writing depth, as in the
        // classic translucent block layer. Water frame animation remains independent.
        let fluid_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("vanilla translucent block pipeline"), layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState { module: &shader, entry_point: "vs_main", buffers: &[Vertex::layout()] },
            fragment: Some(wgpu::FragmentState { module: &shader, entry_point: "fs_main", targets: &[Some(wgpu::ColorTargetState {
                format, blend: Some(wgpu::BlendState::ALPHA_BLENDING), write_mask: wgpu::ColorWrites::ALL })] }),
            primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw, cull_mode: None, polygon_mode: wgpu::PolygonMode::Fill, unclipped_depth: false, conservative: false },
            depth_stencil: Some(wgpu::DepthStencilState { format: wgpu::TextureFormat::Depth32Float, depth_write_enabled: false,
                depth_compare: wgpu::CompareFunction::LessEqual, stencil: wgpu::StencilState::default(), bias: wgpu::DepthBiasState::default() }),
            multisample: wgpu::MultisampleState::default(), multiview: None,
        });
        // Block-breaking cracks use the original destroy_stage_0..9 textures.
        // The overlay is depth-tested against terrain but does not write depth;
        // its CPU geometry is nudged slightly outward to avoid z-fighting.
        let mining_crack_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("Minecraft 1.8.9 block damage crack overlay pipeline"),
            layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState { module: &shader, entry_point: "vs_main", buffers: &[Vertex::layout()] },
            fragment: Some(wgpu::FragmentState { module: &shader, entry_point: "fs_main", targets: &[Some(wgpu::ColorTargetState {
                format, blend: Some(wgpu::BlendState::ALPHA_BLENDING), write_mask: wgpu::ColorWrites::ALL,
            })] }),
            primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw, cull_mode: None, polygon_mode: wgpu::PolygonMode::Fill,
                unclipped_depth: false, conservative: false },
            depth_stencil: Some(wgpu::DepthStencilState { format: wgpu::TextureFormat::Depth32Float,
                depth_write_enabled: false, depth_compare: wgpu::CompareFunction::LessEqual,
                stencil: wgpu::StencilState::default(), bias: wgpu::DepthBiasState::default() }),
            multisample: wgpu::MultisampleState::default(), multiview: None,
        });
        // The first-person arm is rendered in a separate view-space pass. This
        // keeps it fixed to the camera like Minecraft's held hand, without
        // changing world depth, collision, or the player's camera interpolation.
        let hand_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("first-person Steve arm pipeline"),
            layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState { module: &shader, entry_point: "vs_main", buffers: &[Vertex::layout()] },
            fragment: Some(wgpu::FragmentState { module: &shader, entry_point: "fs_main", targets: &[Some(wgpu::ColorTargetState {
                format, blend: Some(wgpu::BlendState::ALPHA_BLENDING), write_mask: wgpu::ColorWrites::ALL })] }),
            primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw, cull_mode: None, polygon_mode: wgpu::PolygonMode::Fill, unclipped_depth: false, conservative: false },
            depth_stencil: Some(wgpu::DepthStencilState { format: wgpu::TextureFormat::Depth32Float, depth_write_enabled: true,
                depth_compare: wgpu::CompareFunction::LessEqual, stencil: wgpu::StencilState::default(), bias: wgpu::DepthBiasState::default() }),
            multisample: wgpu::MultisampleState::default(), multiview: None,
        });
        // Pixel-space overlay pipeline for the classic centered crosshair. It has
        // no depth attachment, so the reticle stays visible over the world and arm.
        let crosshair_shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("first-person crosshair shader"),
            source: wgpu::ShaderSource::Wgsl(r#"
                struct In { @location(0) position: vec2<f32>, @location(1) color: vec4<f32> };
                struct Out { @builtin(position) position: vec4<f32>, @location(0) color: vec4<f32> };
                @vertex fn vs_main(input: In) -> Out {
                    var output: Out;
                    output.position = vec4<f32>(input.position, 0.0, 1.0);
                    output.color = input.color;
                    return output;
                }
                @fragment fn fs_main(input: Out) -> @location(0) vec4<f32> { return input.color; }
            "#.into()),
        });
        let crosshair_pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("first-person crosshair pipeline layout"), bind_group_layouts: &[], push_constant_ranges: &[],
        });
        let crosshair_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("classic first-person crosshair pipeline"), layout: Some(&crosshair_pipeline_layout),
            vertex: wgpu::VertexState { module: &crosshair_shader, entry_point: "vs_main", buffers: &[OverlayVertex::layout()] },
            fragment: Some(wgpu::FragmentState { module: &crosshair_shader, entry_point: "fs_main", targets: &[Some(wgpu::ColorTargetState {
                format,
                // GuiIngame uses GL_ONE_MINUS_DST_COLOR / GL_ONE_MINUS_SRC_COLOR
                // for the reticle. With an opaque white sprite this inverts the
                // destination, making the crosshair legible on both light/dark terrain.
                blend: Some(wgpu::BlendState {
                    color: wgpu::BlendComponent { src_factor: wgpu::BlendFactor::OneMinusDst, dst_factor: wgpu::BlendFactor::OneMinusSrc, operation: wgpu::BlendOperation::Add },
                    alpha: wgpu::BlendComponent { src_factor: wgpu::BlendFactor::One, dst_factor: wgpu::BlendFactor::Zero, operation: wgpu::BlendOperation::Add },
                }),
                write_mask: wgpu::ColorWrites::ALL })] }),
            primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw, cull_mode: None, polygon_mode: wgpu::PolygonMode::Fill, unclipped_depth: false, conservative: false },
            depth_stencil: None, multisample: wgpu::MultisampleState::default(), multiview: None,
        });
        let crosshair_vertices = build_crosshair_vertices(config.width, config.height);
        let crosshair_vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("classic crosshair overlay vertices"), contents: bytemuck::cast_slice(&crosshair_vertices),
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
        });
        let gui_scale = vanilla_gui_scale_factor(config.width, config.height);
        let gui_overlay = GuiOverlayGpu::new(&device, format, config.width.div_ceil(gui_scale), config.height.div_ceil(gui_scale));
        let chat_overlay = GuiOverlayGpu::new(&device, format, config.width.div_ceil(gui_scale), config.height.div_ceil(gui_scale));
        let player_preview_sprite = GuiSpriteGpu::new(&device, &gui_overlay.layout, 80 * gui_scale, 82 * gui_scale);
        let cursor_stack_sprite = GuiSpriteGpu::new(&device, &gui_overlay.layout, 20 * gui_scale, 18 * gui_scale);
        let mut slot_highlight_sprite = GuiSpriteGpu::new(&device, &gui_overlay.layout, 16 * gui_scale, 16 * gui_scale);
        let slot_highlight_pixels = image::RgbaImage::from_pixel(
            16 * gui_scale, 16 * gui_scale, image::Rgba([255, 255, 255, 128]),
        );
        slot_highlight_sprite.upload(&queue, &slot_highlight_pixels);
        // Start at 1x1 so refresh_hotbar_selection uploads the exact widgets.png frame
        // once, at the actual ScaledResolution scale.
        let hotbar_selection_sprite = GuiSpriteGpu::new(&device, &gui_overlay.layout, 1, 1);
        let inventory_ui = hand_skin_jar.map(crate::inventory::InventoryUi::load).transpose()?;
        let hand_camera_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("first-person arm camera buffer"),
            contents: bytemuck::bytes_of(&CameraUniform { view_projection: Mat4::IDENTITY.to_cols_array_2d() }),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });
        let hand_camera_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("first-person arm camera bind group"), layout: &camera_layout,
            entries: &[wgpu::BindGroupEntry { binding: 0, resource: hand_camera_buffer.as_entire_binding() }],
        });
        let hand_texture_height = hand_skin_jar.map(|path| read_steve_skin_dimensions(path)).transpose()?.map(|(_, height)| height as f32).unwrap_or(64.0);
        let hand_vertices = build_steve_arm_vertices(hand_texture_height, 0.0, 0.0);
        let hand_vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("classic Steve right arm vertices"),
            contents: bytemuck::cast_slice(&hand_vertices), usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
        });
        let hand_texture = hand_skin_jar
            .map(|path| upload_steve_skin(&device, &queue, &atlas.bind_group_layout, path))
            .transpose()?;
        // Load the vanilla model catalog once. The selected item mesh is rebuilt only
        // when id/metadata changes; swinging only transforms the cached small mesh.
        let held_model_catalog = hand_skin_jar.map(ModelCatalog::load).transpose()?;
        let mining_crack_texture = hand_skin_jar
            .map(load_destroy_stage_sheet)
            .transpose()?
            .map(|pixels| upload_rgba_texture(&device, &queue, &atlas.bind_group_layout,
                "Minecraft 1.8.9 destroy-stage crack texture strip", &pixels));
        let held_item_buffer_capacity_vertices = 16_384_usize;
        let dropped_item_buffer_capacity_vertices = 6_144_usize;
        let mining_crack_buffer_capacity_vertices = 36_usize;
        let mining_crack_vertex_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Minecraft 1.8.9 block breaking crack vertices"),
            size: (mining_crack_buffer_capacity_vertices * size_of::<Vertex>()) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let dropped_item_vertex_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Minecraft 1.8.9 dropped item entity vertices"),
            size: (dropped_item_buffer_capacity_vertices * size_of::<Vertex>()) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
        let held_item_vertex_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("Minecraft 1.8.9 first-person held item vertices"),
            size: (held_item_buffer_capacity_vertices * size_of::<Vertex>()) as u64,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });

        // Stable chunk ordering keeps blended fluid draw order deterministic.
        let mut chunk_meshes = BTreeMap::new();
        for (&coords, mesh) in meshes {
            chunk_meshes.insert(coords, GpuChunkMesh::upload(&device, &queue, mesh)?);
        }
        let (depth_texture, depth_view) = create_depth(&device, &config);
        let mut viewer = Self { surface, device, queue, config, pipeline,
            vegetation_pipeline, fluid_pipeline, hand_pipeline, crosshair_pipeline, crosshair_vertex_buffer,
            crosshair_vertex_count: crosshair_vertices.len() as u32, crosshair_visible: false,
            hand_vertex_buffer, hand_vertex_count: hand_vertices.len() as u32,
            hand_texture_height, hand_swing_progress_int: 0, hand_swing_in_progress: false,
            hand_prev_swing_progress: 0.0, hand_swing_progress: 0.0, hand_render_swing_progress: 0.0,
            hand_camera_buffer, hand_camera_bind_group, hand_texture,
            held_item_vertex_buffer, held_item_vertex_count: 0, held_item_buffer_capacity_vertices,
            held_item_base_vertices: Vec::new(), held_item_render_vertices: Vec::new(), held_item_texture: None,
            held_item_uses_atlas: true, held_item_key: None, held_item_requested_key: None,
            held_item_swap_pending: false, held_item_equip_progress: 1.0,
            held_item_prev_equip_progress: 1.0, held_item_render_equip_progress: 0.0,
            held_item_display_transform: ItemCameraTransform::default(),
            held_item_is_block_model: false,
            dropped_item_vertex_buffer, dropped_item_vertex_count: 0, dropped_item_buffer_capacity_vertices,
            dropped_item_generated_cache: HashMap::new(), dropped_item_texture_failures: HashSet::new(),
            dropped_item_generated_batches: HashMap::new(), dropped_item_block_model_cache: HashMap::new(),
            mining_crack_texture, mining_crack_vertex_buffer, mining_crack_vertex_count: 0,
            mining_crack_buffer_capacity_vertices, mining_crack_pipeline,
            held_model_catalog, atlas_runtime: atlas_runtime.clone(), gui_overlay, chat_overlay,
            player_preview_sprite, cursor_stack_sprite, slot_highlight_sprite, hotbar_selection_sprite,
            player_preview_visible: false, cursor_stack_visible: false, slot_highlight_visible: false,
            hotbar_selection_visible: false,
            player_preview_dirty: true, cursor_stack_dirty: true, cursor_stack_image_dirty: true,
            inventory_ui, chunk_meshes,
            camera_buffer, camera_bind_group, atlas, lightmap, _depth_texture: depth_texture, depth_view,
            target: camera_target, home_target: camera_target, radius: camera_radius.max(0.9), yaw: 0.72, pitch: 0.48, zoom: 2.8,
            camera_position: camera_target + Vec3::new(0.0, 0.0, camera_radius.max(0.9) * 2.8),
            chunk_origin, fluid_animations, fluid_animation_padding: atlas_runtime.padding(),
            last_fluid_animation_update: Instant::now(), sky_clear_color: [0.38, 0.62, 1.0] };
        viewer.update_camera();
        viewer.update_hand_camera();
        viewer.refresh_gui_overlay();
        viewer.refresh_held_item_if_changed();
        Ok(viewer)
    }
    /// Recompose only the scaled GUI background/slot contents. Hover indication is a
    /// separate GPU quad, so crossing a slot boundary doesn't upload the full interface.
    fn refresh_gui_surface(&mut self) {
        if let Some(ui) = self.inventory_ui.as_mut() {
            let pixels = ui.render_overlay(self.config.width, self.config.height);
            self.gui_overlay.upload(&self.queue, &pixels);
            let chat_pixels = ui.render_chat_overlay(self.config.width, self.config.height);
            self.chat_overlay.upload(&self.queue, &chat_pixels);
        }
    }

    /// Re-rasterize only while a stack-pop animation is active. GuiIngame uses
    /// partialTicks at display cadence, so the five-tick pop stays smooth at 60+ FPS.
    fn refresh_gui_animation_frame(&mut self, partial_ticks: f32) {
        if let Some(ui) = self.inventory_ui.as_mut() {
            if !ui.has_active_inventory_animations() { return; }
            let pixels = ui.render_overlay_interpolated(self.config.width, self.config.height, partial_ticks);
            self.gui_overlay.upload(&self.queue, &pixels);
        }
    }

    fn refresh_gui_overlay(&mut self) {
        self.refresh_gui_surface();
        self.player_preview_dirty = true;
        self.cursor_stack_dirty = true;
        self.cursor_stack_image_dirty = true;
        self.refresh_hover_highlight();
        self.refresh_hotbar_selection();
    }

    /// GuiContainer.drawScreen uses drawGradientRect with -2130706433 on both ends:
    /// a flat 50%-opaque white overlay. Keep the exact effect in a tiny GPU sprite.
    fn refresh_hover_highlight(&mut self) {
        let width = self.config.width;
        let height = self.config.height;
        let scale = vanilla_gui_scale_factor(width, height);
        let sprite_size = 16 * scale;
        let size_changed = self.slot_highlight_sprite.width != sprite_size
            || self.slot_highlight_sprite.height != sprite_size;
        self.slot_highlight_sprite.resize(&self.device, &self.gui_overlay.layout, sprite_size, sprite_size);
        if size_changed {
            let pixels = image::RgbaImage::from_pixel(
                sprite_size, sprite_size, image::Rgba([255, 255, 255, 128]),
            );
            self.slot_highlight_sprite.upload(&self.queue, &pixels);
        }
        let rect = self.inventory_ui.as_ref()
            .and_then(|ui| ui.hovered_slot_rect_physical(width, height));
        if let Some((left, top)) = rect {
            self.slot_highlight_sprite.set_rect(&self.queue, width, height, left as f32, top as f32);
            self.slot_highlight_visible = true;
        } else {
            self.slot_highlight_visible = false;
        }
    }

    /// GuiIngame's selection frame is the exact 24x22 texture region at widgets.png
    /// (0,22). Selecting 1-9 only changes this quad's vertices, avoiding a full HUD
    /// CPU composition and texture upload for every number-key/scroll event.
    fn refresh_hotbar_selection(&mut self) {
        let width = self.config.width;
        let height = self.config.height;
        let scale = vanilla_gui_scale_factor(width, height);
        let sprite_width = 24 * scale;
        let sprite_height = 22 * scale;
        let size_changed = self.hotbar_selection_sprite.width != sprite_width
            || self.hotbar_selection_sprite.height != sprite_height;
        self.hotbar_selection_sprite.resize(
            &self.device, &self.gui_overlay.layout, sprite_width, sprite_height,
        );
        if size_changed {
            if let Some(pixels) = self.inventory_ui.as_ref()
                .map(|ui| ui.render_hotbar_selection_sprite(scale))
            {
                self.hotbar_selection_sprite.upload(&self.queue, &pixels);
            }
        }
        let rect = self.inventory_ui.as_ref()
            .and_then(|ui| ui.hotbar_selection_rect_physical(width, height));
        if let Some((left, top)) = rect {
            self.hotbar_selection_sprite.set_rect(
                &self.queue, width, height, left as f32, top as f32,
            );
            self.hotbar_selection_visible = true;
        } else {
            self.hotbar_selection_visible = false;
        }
    }

    /// Runs at most once for the coalesced redraw, not once per raw cursor event.
    /// Only the small avatar sprite is rasterized; the large GUI texture is left untouched.
    fn refresh_player_preview(&mut self) {
        let width = self.config.width;
        let height = self.config.height;
        let scale = vanilla_gui_scale_factor(width, height);
        let sprite_width = 80 * scale;
        let sprite_height = 82 * scale;
        self.player_preview_sprite.resize(&self.device, &self.gui_overlay.layout, sprite_width, sprite_height);
        self.player_preview_visible = false;
        if let Some(ui) = self.inventory_ui.as_ref() {
            if ui.screen == crate::inventory::UiScreen::Inventory {
                let logical_width = width.div_ceil(scale);
                let logical_height = height.div_ceil(scale);
                let gui_left = (logical_width as i32 - 176) / 2;
                let gui_top = (logical_height as i32 - 166) / 2;
                let pixels = ui.render_player_preview(scale, gui_left, gui_top);
                self.player_preview_sprite.upload(&self.queue, &pixels);
                self.player_preview_sprite.set_rect(
                    &self.queue, width, height,
                    (gui_left * scale as i32) as f32,
                    (gui_top * scale as i32) as f32,
                );
                self.player_preview_visible = true;
            }
        }
        self.player_preview_dirty = false;
    }

    /// The carried icon has independent texture and geometry, so movement changes only
    /// six GPU vertices. Its image is uploaded only when inventory contents change or the
    /// screen opens/closes, while movement remains synchronized to each rendered frame.
    fn refresh_cursor_stack_sprite(&mut self) {
        let width = self.config.width;
        let height = self.config.height;
        let scale = vanilla_gui_scale_factor(width, height);
        self.cursor_stack_sprite.resize(&self.device, &self.gui_overlay.layout, 20 * scale, 18 * scale);
        self.cursor_stack_visible = false;
        let cursor_state = if let Some(ui) = self.inventory_ui.as_mut() {
            if ui.screen == crate::inventory::UiScreen::Inventory {
                let position = ui.cursor_position;
                let has_stack = ui.inventory.cursor_stack.is_some();
                let pixels = if self.cursor_stack_image_dirty { ui.render_cursor_stack_icon(scale) } else { None };
                Some((position, has_stack, pixels))
            } else { None }
        } else { None };
        if let Some((position, has_stack, pixels)) = cursor_state {
            if has_stack {
                if let Some(pixels) = pixels { self.cursor_stack_sprite.upload(&self.queue, &pixels); }
                let sf = f64::from(scale);
                let left = (position.0 / sf).floor() * sf - 8.0 * sf;
                let top = (position.1 / sf).floor() * sf - 8.0 * sf;
                self.cursor_stack_sprite.set_rect(&self.queue, width, height, left as f32, top as f32);
                self.cursor_stack_visible = true;
            }
        }
        self.cursor_stack_dirty = false;
        self.cursor_stack_image_dirty = false;
    }

    /// Track the selected stack separately from ItemRenderer's active stack. In vanilla,
    /// changing slots lowers the currently rendered item for three 20-Hz ticks, swaps the
    /// stack once equippedProgress < 0.1, then raises the new item. The mesh is rebuilt only
    /// at that swap point, never for count-only changes.
    fn refresh_held_item_if_changed(&mut self) {
        let visual = self.inventory_ui.as_mut().and_then(|ui| ui.current_held_item_visual());
        let next_key = visual.as_ref().map(|(key, _, _)| key.clone());
        if next_key == self.held_item_requested_key { return; }
        self.held_item_requested_key = next_key.clone();
        self.held_item_swap_pending = next_key != self.held_item_key;
    }

    /// ItemRenderer.updateEquippedItem(), using vanilla's 0.4-per-tick easing and
    /// the same item-swap threshold (< 0.1). Called from the 20 Hz simulation tick.
    fn tick_held_item_equip(&mut self) {
        self.held_item_prev_equip_progress = self.held_item_equip_progress;
        let target = if self.held_item_swap_pending { 0.0 } else { 1.0 };
        self.held_item_equip_progress +=
            (target - self.held_item_equip_progress).clamp(-0.4, 0.4);

        if self.held_item_swap_pending && self.held_item_equip_progress < 0.1 {
            let visual = self.inventory_ui.as_mut().and_then(|ui| ui.current_held_item_visual());
            let selected_key = visual.as_ref().map(|(key, _, _)| key.clone());
            if selected_key == self.held_item_requested_key {
                self.install_held_item_visual(visual);
                self.held_item_swap_pending = false;
            }
        }
    }

    fn install_held_item_visual(&mut self, visual: Option<(String, String, image::RgbaImage)>) {
        self.held_item_key = visual.as_ref().map(|(key, _, _)| key.clone());
        let Some((_key, model_id, icon)) = visual else {
            self.held_item_base_vertices.clear();
            self.held_item_render_vertices.clear();
            self.held_item_vertex_count = 0;
            self.held_item_texture = None;
            self.held_item_uses_atlas = true;
            self.held_item_display_transform = ItemCameraTransform::default();
            self.held_item_is_block_model = false;
            return;
        };

        let transform = self.held_model_catalog.as_ref()
            .map(|catalog| catalog.first_person_transform(&format!("item/{model_id}")))
            .unwrap_or_default();
        let quads = self.held_model_catalog.as_mut().and_then(|catalog| {
            catalog.load_model_quads(&format!("item/{model_id}")).ok().map(|(_, quads)| quads.as_ref().clone())
        });
        let block_model_vertices = quads.as_deref()
            .and_then(|model_quads| build_block_item_vertices(model_quads, &self.atlas_runtime));
        self.held_item_is_block_model = block_model_vertices.is_some();
        if let Some(vertices) = block_model_vertices {
            self.held_item_base_vertices = vertices;
            self.held_item_texture = None;
            self.held_item_uses_atlas = true;
        } else {
            self.held_item_base_vertices = build_generated_item_layer_vertices(&icon);
            self.held_item_texture = Some(upload_rgba_texture(
                &self.device, &self.queue, &self.atlas.bind_group_layout,
                "Minecraft 1.8.9 generated first-person item layer", &icon,
            ));
            self.held_item_uses_atlas = false;
        }
        self.held_item_display_transform = transform;
        self.rebuild_held_item_vertices(
            self.hand_render_swing_progress,
            self.held_item_render_equip_progress,
        );
    }

    fn rebuild_held_item_vertices(&mut self, swing_progress: f32, equip_progress: f32) {
        if self.held_item_base_vertices.is_empty() {
            self.held_item_vertex_count = 0;
            self.held_item_render_vertices.clear();
            return;
        }
        self.held_item_render_vertices.clone_from(&self.held_item_base_vertices);
        // Keep the item and block camera paths independent. Vanilla 1.8.9 gives
        // block models their own GUI-3D route (ItemRenderer.renderItem applies
        // scale(2) when shouldRenderItemIn3D is true); generated items get the
        // same effective scale from RenderItem.preTransform. The common hand
        // pose remains the MCP transformFirstPersonItem pose, while the model's
        // inherited FIRST_PERSON display transform is resolved independently.
        let model_to_view = if self.held_item_is_block_model {
            vanilla_first_person_block_matrix(
                swing_progress, equip_progress, self.held_item_display_transform,
            )
        } else {
            vanilla_first_person_item_matrix(
                swing_progress, equip_progress, self.held_item_display_transform,
                self.held_item_uses_atlas,
            )
        };
        for vertex in &mut self.held_item_render_vertices {
            vertex.position = model_to_view.transform_point3(Vec3::from_array(vertex.position)).to_array();
            vertex.normal = model_to_view.transform_vector3(Vec3::from_array(vertex.normal)).normalize_or_zero().to_array();
        }
        if self.held_item_render_vertices.len() > self.held_item_buffer_capacity_vertices {
            self.held_item_buffer_capacity_vertices = self.held_item_render_vertices.len().next_power_of_two();
            self.held_item_vertex_buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("Minecraft 1.8.9 first-person held item vertices (expanded)"),
                size: (self.held_item_buffer_capacity_vertices * size_of::<Vertex>()) as u64,
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
        }
        self.queue.write_buffer(&self.held_item_vertex_buffer, 0, bytemuck::cast_slice(&self.held_item_render_vertices));
        self.held_item_vertex_count = self.held_item_render_vertices.len() as u32;
    }

    /// Rebuild the small dynamic entity batch at display-frame cadence. The item model
    /// itself comes from the 1.8.9 JAR model catalog; only its ground transform is
    /// applied here. Items use the world camera/atlas and therefore participate in
    /// world depth testing instead of being drawn as HUD sprites.
    fn update_dropped_item_mesh(
        &mut self,
        items: &[DroppedItem],
        pickup_animations: &[mining::PickupAnimation],
        previous_player_position: Vec3,
        player_position: Vec3,
        jar_path: &Path,
        collision: &LoadedWorldCollision,
        partial_ticks: f32,
    ) {
        let mut display_items = items.to_vec();
        for animation in pickup_animations {
            let mut visual_item = animation.item.clone();
            // EntityPickupFX.renderParticle: f=((age+partialTicks)/3)^2,
            // target is the interpolated player position plus 0.5 on Y.
            let position = animation.render_position(previous_player_position, player_position, partial_ticks);
            visual_item.previous_position = position;
            visual_item.position = position;
            display_items.push(visual_item);
        }

        let mut block_vertices = Vec::<Vertex>::new();
        let mut generated_vertices = HashMap::<(u16, u16), Vec<Vertex>>::new();
        for item in &display_items {
            let light = collision.light_at_local(
                item.position.x.floor() as i32,
                item.position.y.floor().clamp(0.0, 255.0) as i32,
                item.position.z.floor() as i32,
            ).unwrap_or((15, 0));
            let Some(name) = legacy_item_registry_name(item.item_id) else { continue; };
            let key = (item.item_id, item.metadata);
            let ground_transform = self.held_model_catalog.as_ref()
                .map(|catalog| catalog.ground_transform(&format!("item/{name}")))
                .unwrap_or_default();
            if !self.dropped_item_block_model_cache.contains_key(&key) {
                let model_name = format!("item/{name}");
                let quads = self.held_model_catalog.as_mut().and_then(|catalog| {
                    catalog.load_model_quads(&model_name).ok().map(|(_, quads)| quads.as_ref().clone())
                });
                let base = quads.as_deref().and_then(|quads| build_block_item_vertices(quads, &self.atlas_runtime));
                self.dropped_item_block_model_cache.insert(key, base);
            }
            if let Some(Some(base)) = self.dropped_item_block_model_cache.get(&key) {
                append_dropped_item_vertices(&mut block_vertices, base, item, light.0, light.1, true, ground_transform, partial_ticks);
                continue;
            }

            // Generated item models resolve to textures/items rather than the block
            // atlas. Cache their exact 1.8.9 metadata-aware sprite and draw each
            // distinct sprite with its own bind group, instead of substituting a
            // missing-texture purple/black checker or silently omitting the entity.
            if self.dropped_item_texture_failures.contains(&key) { continue; }
            if !self.dropped_item_generated_cache.contains_key(&key) {
                let icon = match crate::inventory::load_item_icon(jar_path, name, item.metadata) {
                    Ok(icon) => icon,
                    Err(error) => {
                        eprintln!("[dropped item] cannot resolve vanilla sprite for {name} (metadata {}): {error}", item.metadata);
                        self.dropped_item_texture_failures.insert(key);
                        continue;
                    }
                };
                // Dropped generated items are viewed from every side while they
                // spin. Keep the first-person mesh's single cutout face unchanged,
                // but bake the mirrored back face required by ItemModelGenerator.
                let base_vertices = build_generated_item_drop_vertices(&icon);
                let texture = upload_rgba_texture(
                    &self.device, &self.queue, &self.atlas.bind_group_layout,
                    "Minecraft 1.8.9 dropped generated-item sprite", &icon,
                );
                self.dropped_item_generated_cache.insert(key, DroppedGeneratedItemCacheEntry {
                    base_vertices, texture,
                });
            }
            if let Some(cached) = self.dropped_item_generated_cache.get(&key) {
                append_dropped_item_vertices(
                    generated_vertices.entry(key).or_default(),
                    &cached.base_vertices,
                    item,
                    light.0,
                    light.1,
                    false,
                    ground_transform,
                    partial_ticks,
                );
            }
        }

        if block_vertices.len() > self.dropped_item_buffer_capacity_vertices {
            self.dropped_item_buffer_capacity_vertices = block_vertices.len().next_power_of_two();
            self.dropped_item_vertex_buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("Minecraft 1.8.9 dropped block-model item vertices (expanded)"),
                size: (self.dropped_item_buffer_capacity_vertices * size_of::<Vertex>()) as u64,
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
        }
        if !block_vertices.is_empty() {
            self.queue.write_buffer(&self.dropped_item_vertex_buffer, 0, bytemuck::cast_slice(&block_vertices));
        }
        self.dropped_item_vertex_count = block_vertices.len() as u32;

        // Reuse per-item GPU allocations. Mark every known batch empty first so
        // entities that despawn or are picked up stop rendering without dropping
        // their buffers; a later entity of the same item can reuse the allocation.
        for batch in self.dropped_item_generated_batches.values_mut() {
            batch.vertex_count = 0;
        }
        for (key, vertices) in generated_vertices {
            if vertices.is_empty() { continue; }
            let bytes = bytemuck::cast_slice(&vertices);
            let required = bytes.len() as u64;
            if !self.dropped_item_generated_batches.contains_key(&key) {
                let capacity = required.checked_next_power_of_two().unwrap_or(required);
                let vertex_buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
                    label: Some("Minecraft 1.8.9 dropped generated-item entity batch"),
                    size: capacity,
                    usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                    mapped_at_creation: false,
                });
                self.dropped_item_generated_batches.insert(key, DroppedGeneratedItemBatch {
                    vertex_buffer, vertex_buffer_capacity: capacity, vertex_count: 0,
                });
            }
            let old_capacity = self.dropped_item_generated_batches
                .get(&key).map(|batch| batch.vertex_buffer_capacity).unwrap_or(0);
            if required > old_capacity {
                let capacity = required.checked_next_power_of_two().unwrap_or(required);
                let replacement = self.device.create_buffer(&wgpu::BufferDescriptor {
                    label: Some("Minecraft 1.8.9 dropped generated-item entity batch (expanded)"),
                    size: capacity,
                    usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                    mapped_at_creation: false,
                });
                if let Some(batch) = self.dropped_item_generated_batches.get_mut(&key) {
                    batch.vertex_buffer = replacement;
                    batch.vertex_buffer_capacity = capacity;
                }
            }
            if let Some(batch) = self.dropped_item_generated_batches.get_mut(&key) {
                self.queue.write_buffer(&batch.vertex_buffer, 0, bytes);
                batch.vertex_count = vertices.len() as u32;
            }
        }
    }

    fn update_mining_crack(&mut self, target: Option<(BlockPos, u8)>, light: Option<(u8, u8)>) {
        let Some((pos, stage)) = target else {
            self.mining_crack_vertex_count = 0;
            return;
        };
        if self.mining_crack_texture.is_none() {
            self.mining_crack_vertex_count = 0;
            return;
        }
        let (sky_light, block_light) = light.unwrap_or((15, 0));
        let vertices = build_mining_crack_vertices(pos, stage, sky_light, block_light);
        if vertices.len() > self.mining_crack_buffer_capacity_vertices {
            self.mining_crack_buffer_capacity_vertices = vertices.len().next_power_of_two();
            self.mining_crack_vertex_buffer = self.device.create_buffer(&wgpu::BufferDescriptor {
                label: Some("Minecraft 1.8.9 block breaking crack vertices (expanded)"),
                size: (self.mining_crack_buffer_capacity_vertices * size_of::<Vertex>()) as u64,
                usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
                mapped_at_creation: false,
            });
        }
        self.queue.write_buffer(&self.mining_crack_vertex_buffer, 0, bytemuck::cast_slice(&vertices));
        self.mining_crack_vertex_count = vertices.len() as u32;
    }

    fn insert_chunk_mesh(&mut self, coords: (i32, i32), mesh: &CpuMesh) -> Result<()> {
        if let Some(existing) = self.chunk_meshes.get_mut(&coords) {
            existing.update_full(&self.device, &self.queue, mesh)?;
        } else {
            let gpu_mesh = GpuChunkMesh::upload(&self.device, &self.queue, mesh)?;
            self.chunk_meshes.insert(coords, gpu_mesh);
        }
        Ok(())
    }

    fn insert_chunk_section_mesh(&mut self, coords: (i32, i32), section_y: u8, mesh: &CpuMesh) -> Result<()> {
        let chunk = self.chunk_meshes.entry(coords).or_insert_with(GpuChunkMesh::empty);
        let section = mesh.section_mesh(section_y);
        chunk.update_section(&self.device, &self.queue, section_y, &section)
    }

    fn retain_chunk_meshes(&mut self, center: (i32, i32), radius: i32, protected: &HashSet<(i32, i32)>) {
        self.chunk_meshes.retain(|&(x, z), _| {
            protected.contains(&(x, z)) || (
                (i64::from(x) - i64::from(center.0)).abs() <= i64::from(radius)
                    && (i64::from(z) - i64::from(center.1)).abs() <= i64::from(radius)
            )
        });
    }

    fn resize(&mut self, width: u32, height: u32) {
        if width == 0 || height == 0 { return; }
        self.config.width = width; self.config.height = height; self.surface.configure(&self.device, &self.config);
        let (texture, view) = create_depth(&self.device, &self.config); self._depth_texture = texture; self.depth_view = view;
        let vertices = build_crosshair_vertices(width, height);
        self.queue.write_buffer(&self.crosshair_vertex_buffer, 0, bytemuck::cast_slice(&vertices));
        let gui_scale = vanilla_gui_scale_factor(width, height);
        self.gui_overlay.resize(&self.device, width.div_ceil(gui_scale), height.div_ceil(gui_scale));
        self.chat_overlay.resize(&self.device, width.div_ceil(gui_scale), height.div_ceil(gui_scale));
        self.update_camera(); self.update_hand_camera();
        self.refresh_gui_overlay();
    }
    fn set_crosshair_visible(&mut self, visible: bool) { self.crosshair_visible = visible; }
    fn update_camera(&mut self) {
        let horizontal = self.pitch.cos();
        let direction = Vec3::new(self.yaw.cos()*horizontal, self.pitch.sin(), self.yaw.sin()*horizontal);
        let eye = self.target + direction * (self.radius*self.zoom);
        self.camera_position = eye;
        let view = Mat4::look_at_rh(eye, self.target, Vec3::Y);
        let aspect = self.config.width.max(1) as f32 / self.config.height.max(1) as f32;
        let projection = Mat4::perspective_rh(45_f32.to_radians(), aspect, 0.1, (self.radius * 8.0 + 100.0).max(100.0));
        self.queue.write_buffer(&self.camera_buffer, 0, bytemuck::bytes_of(&CameraUniform { view_projection: (projection*view).to_cols_array_2d() }));
    }
    fn update_player_camera(&mut self, player: PlayerState) {
        let eye = player.eye_position();
        self.camera_position = eye;
        let direction = player.look_direction();
        let view = Mat4::look_at_rh(eye, eye + direction, Vec3::Y);
        let aspect = self.config.width.max(1) as f32 / self.config.height.max(1) as f32;
        let projection = Mat4::perspective_rh(70_f32.to_radians(), aspect, 0.05, 512.0);
        self.queue.write_buffer(&self.camera_buffer, 0, bytemuck::bytes_of(&CameraUniform {
            view_projection: (projection * view).to_cols_array_2d(),
        }));
    }
    /// EntityLivingBase.swingItem(): restart when no swing is active, at or
    /// beyond half of the six-tick duration, or while the counter is negative.
    /// The initial click that captures the mouse is intentionally consumed by
    /// the focus handler, matching Minecraft 1.8.9's focus-capture behavior.
    fn start_hand_swing(&mut self) {
        if !self.hand_swing_in_progress || self.hand_swing_progress_int >= 3 || self.hand_swing_progress_int < 0 {
            self.hand_swing_progress_int = -1;
            self.hand_swing_in_progress = true;
        }
    }

    /// EntityLivingBase.updateArmSwingProgress(), with the vanilla six-tick
    /// duration and integer counter rather than a wall-clock approximation.
    fn tick_hand_swing(&mut self) {
        self.hand_prev_swing_progress = self.hand_swing_progress;
        if self.hand_swing_in_progress {
            self.hand_swing_progress_int += 1;
            if self.hand_swing_progress_int >= 6 {
                self.hand_swing_progress_int = 0;
                self.hand_swing_in_progress = false;
            }
        } else {
            self.hand_swing_progress_int = 0;
        }
        self.hand_swing_progress = self.hand_swing_progress_int as f32 / 6.0;
    }

    /// EntityLivingBase.getSwingProgress(partialTicks) interpolates between
    /// the previous and current tick. When the counter wraps to zero, vanilla
    /// adds one to the negative delta so the last frame reaches progress 1.0.
    /// Re-bake only the small arm mesh; world geometry and lighting stay intact.
    fn update_hand_swing(&mut self, partial_ticks: f32) {
        let progress = vanilla_interpolated_swing_progress(
            self.hand_prev_swing_progress, self.hand_swing_progress, partial_ticks,
        );
        let equipped = self.held_item_prev_equip_progress
            + (self.held_item_equip_progress - self.held_item_prev_equip_progress) * partial_ticks;
        // ItemRenderer.renderItemInFirstPerson passes 1 - interpolated equippedProgress
        // to transformFirstPersonItem/renderPlayerArm.
        let equip_transform = 1.0 - equipped;
        let swing_changed = (progress - self.hand_render_swing_progress).abs() > 0.001;
        let equip_changed = (equip_transform - self.held_item_render_equip_progress).abs() > 0.001;
        if swing_changed || equip_changed {
            self.hand_render_swing_progress = progress;
            self.held_item_render_equip_progress = equip_transform;
            if self.held_item_base_vertices.is_empty() {
                let vertices = build_steve_arm_vertices(
                    self.hand_texture_height, progress, equip_transform,
                );
                self.queue.write_buffer(&self.hand_vertex_buffer, 0, bytemuck::cast_slice(&vertices));
            } else {
                self.rebuild_held_item_vertices(progress, equip_transform);
            }
        }
    }

    fn update_hand_camera(&mut self) {
        let aspect = self.config.width.max(1) as f32 / self.config.height.max(1) as f32;
        let projection = Mat4::perspective_rh(70_f32.to_radians(), aspect, 0.03, 4.0);
        self.queue.write_buffer(&self.hand_camera_buffer, 0, bytemuck::bytes_of(&CameraUniform {
            view_projection: projection.to_cols_array_2d(),
        }));
    }
    fn orbit(&mut self, dx: f64, dy: f64) { self.yaw += dx as f32*0.008; self.pitch = (self.pitch-dy as f32*0.008).clamp(-1.45,1.45); self.update_camera(); }
    fn pan(&mut self, dx: f64, dy: f64) {
        let direction = Vec3::new(self.yaw.cos()*self.pitch.cos(), self.pitch.sin(), self.yaw.sin()*self.pitch.cos()).normalize_or_zero();
        let right = direction.cross(Vec3::Y).normalize_or_zero();
        let up = right.cross(direction).normalize_or_zero();
        let scale = (self.radius * self.zoom * 0.0025).clamp(0.002, 2.0);
        self.target += right * (-(dx as f32) * scale) + up * ((dy as f32) * scale);
        self.update_camera();
    }
    fn zoom_by(&mut self, amount: f32) { self.zoom = (self.zoom*(1.0-amount*0.08)).clamp(0.8,10.0); self.update_camera(); }
    fn reset(&mut self) { self.target=self.home_target; self.yaw=0.72; self.pitch=0.48; self.zoom=2.8; self.update_camera(); }
    fn advance_fluid_animations(&mut self) {
        let now = Instant::now();
        let delta = now.duration_since(self.last_fluid_animation_update);
        self.last_fluid_animation_update = now;
        for animation in &mut self.fluid_animations {
            animation.elapsed += delta;
            let mut changed = false;
            loop {
                let duration = Duration::from_millis(u64::from(animation.frames[animation.current_frame].duration_ticks) * 50);
                if animation.elapsed < duration { break; }
                animation.elapsed -= duration;
                animation.current_frame = (animation.current_frame + 1) % animation.frames.len();
                changed = true;
            }
            if changed {
                let frame = &animation.frames[animation.current_frame].pixels;
                let padded = extrude_fluid_frame(frame, self.fluid_animation_padding);
                let origin = wgpu::Origin3d {
                    x: animation.pixel_rect[0] - self.fluid_animation_padding,
                    y: animation.pixel_rect[1] - self.fluid_animation_padding,
                    z: 0,
                };
                self.queue.write_texture(
                    wgpu::ImageCopyTexture { texture: &self.atlas.texture, mip_level: 0, origin, aspect: wgpu::TextureAspect::All },
                    padded.as_raw(),
                    wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(4 * padded.width()), rows_per_image: Some(padded.height()) },
                    wgpu::Extent3d { width: padded.width(), height: padded.height(), depth_or_array_layers: 1 },
                );
            }
        }
    }

    fn set_world_sky(&mut self, day_time: f64, rain: f32, thunder: f32) {
        self.sky_clear_color = vanilla_sky_clear_color(day_time, rain, thunder);
    }

    fn render(&mut self) -> std::result::Result<(), wgpu::SurfaceError> {
        self.advance_fluid_animations();
        let frame = self.surface.get_current_texture()?; let view = frame.texture.create_view(&wgpu::TextureViewDescriptor::default());
        let mut encoder = self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor { label: Some("textured block encoder") });
        { let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor { label: Some("textured block pass"),
            color_attachments: &[Some(wgpu::RenderPassColorAttachment { view: &view, resolve_target: None,
                ops: wgpu::Operations { load: wgpu::LoadOp::Clear(wgpu::Color { r:self.sky_clear_color[0].powf(2.2),g:self.sky_clear_color[1].powf(2.2),b:self.sky_clear_color[2].powf(2.2),a:1.0 }), store: wgpu::StoreOp::Store } })],
            depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment { view: &self.depth_view,
                depth_ops: Some(wgpu::Operations { load: wgpu::LoadOp::Clear(1.0), store: wgpu::StoreOp::Store }), stencil_ops: None }),
            occlusion_query_set: None, timestamp_writes: None });
            pass.set_bind_group(0,&self.camera_bind_group,&[]); pass.set_bind_group(1,&self.atlas.bind_group,&[]);
            pass.set_bind_group(2,&self.lightmap.bind_group,&[]);
            // Opaque terrain first.
            pass.set_pipeline(&self.pipeline);
            for mesh in self.chunk_meshes.values() {
                for section in mesh.sections.values() {
                    if let Some(buffer) = &section.vertex_buffer {
                        pass.set_vertex_buffer(0, buffer.slice(..));
                        pass.draw(0..section.vertex_count, 0..1);
                    }
                }
            }
            // Binary-alpha plants/leaves are also completed before translucent fluids.
            pass.set_pipeline(&self.vegetation_pipeline);
            for mesh in self.chunk_meshes.values() {
                for section in mesh.sections.values() {
                    if let Some(buffer) = &section.vegetation_vertex_buffer {
                        pass.set_vertex_buffer(0, buffer.slice(..));
                        pass.draw(0..section.vegetation_vertex_count, 0..1);
                    }
                }
            }
            // The active mining target receives vanilla destroy-stage texture
            // overlays on all six block faces, alpha blended and depth tested.
            if self.mining_crack_vertex_count > 0 {
                if let Some(texture) = &self.mining_crack_texture {
                    pass.set_pipeline(&self.mining_crack_pipeline);
                    pass.set_bind_group(0, &self.camera_bind_group, &[]);
                    pass.set_bind_group(1, &texture.bind_group, &[]);
                    pass.set_bind_group(2, &self.lightmap.bind_group, &[]);
                    pass.set_vertex_buffer(0, self.mining_crack_vertex_buffer.slice(..));
                    pass.draw(0..self.mining_crack_vertex_count, 0..1);
                }
            }
            // Glass and fluids use the vanilla translucent layer: blend after opaque
            // geometry, do not write depth, and order chunk groups far-to-near.
            // Shared faces between like glass blocks are removed during mesh build.
            let camera_position = self.camera_position;
            let chunk_origin = self.chunk_origin;
            let mut translucent_order: Vec<((i32, i32, u8), f32)> = self.chunk_meshes.iter()
                .flat_map(|(&coords, mesh)| mesh.sections.iter().filter_map(move |(&section_y, section)| {
                    (section.translucent_vertex_buffer.is_some() || section.fluid_vertex_buffer.is_some()).then(|| {
                        let center_x = (coords.0 - chunk_origin.0) as f32 * 16.0 + 8.0;
                        let center_y = f32::from(section_y) * 16.0 + 8.0;
                        let center_z = (coords.1 - chunk_origin.1) as f32 * 16.0 + 8.0;
                        let dx = center_x - camera_position.x;
                        let dy = center_y - camera_position.y;
                        let dz = center_z - camera_position.z;
                        ((coords.0, coords.1, section_y), dx * dx + dy * dy + dz * dz)
                    })
                }))
                .collect();
            translucent_order.sort_by(|a, b| b.1.total_cmp(&a.1));
            pass.set_pipeline(&self.fluid_pipeline);
            for ((chunk_x, chunk_z, section_y), _) in translucent_order {
                if let Some(section) = self.chunk_meshes.get(&(chunk_x, chunk_z)).and_then(|mesh| mesh.sections.get(&section_y)) {
                    if let Some(buffer) = &section.translucent_vertex_buffer {
                        pass.set_vertex_buffer(0, buffer.slice(..));
                        pass.draw(0..section.translucent_vertex_count, 0..1);
                    }
                    if let Some(buffer) = &section.fluid_vertex_buffer {
                        pass.set_vertex_buffer(0, buffer.slice(..));
                        pass.draw(0..section.fluid_vertex_count, 0..1);
                    }
                }
            }
            // Dropped entities share world projection, atlas and depth with terrain.
            if self.dropped_item_vertex_count > 0 {
                pass.set_pipeline(&self.pipeline);
                pass.set_bind_group(0, &self.camera_bind_group, &[]);
                pass.set_bind_group(1, &self.atlas.bind_group, &[]);
                pass.set_bind_group(2, &self.lightmap.bind_group, &[]);
                pass.set_vertex_buffer(0, self.dropped_item_vertex_buffer.slice(..));
                pass.draw(0..self.dropped_item_vertex_count, 0..1);
            }
            // Generated item-layer sprites (diamonds, ingots, seeds, etc.) use
            // metadata-aware textures outside textures/blocks and therefore have
            // their own cached texture bind groups but share world camera/lightmap.
            if !self.dropped_item_generated_batches.is_empty() {
                pass.set_pipeline(&self.pipeline);
                pass.set_bind_group(0, &self.camera_bind_group, &[]);
                pass.set_bind_group(2, &self.lightmap.bind_group, &[]);
                for (key, batch) in &self.dropped_item_generated_batches {
                    if batch.vertex_count == 0 { continue; }
                    if let Some(cached) = self.dropped_item_generated_cache.get(key) {
                        pass.set_bind_group(1, &cached.texture.bind_group, &[]);
                        pass.set_vertex_buffer(0, batch.vertex_buffer.slice(..));
                        pass.draw(0..batch.vertex_count, 0..1);
                    }
                }
            }
        }
        // Draw the arm over the completed world with an independent depth clear,
        // matching the first-person overlay behavior of the original client.
        {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("first-person Steve arm overlay pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view, resolve_target: None,
                    ops: wgpu::Operations { load: wgpu::LoadOp::Load, store: wgpu::StoreOp::Store },
                })],
                depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                    view: &self.depth_view,
                    depth_ops: Some(wgpu::Operations { load: wgpu::LoadOp::Clear(1.0), store: wgpu::StoreOp::Store }),
                    stencil_ops: None,
                }),
                occlusion_query_set: None, timestamp_writes: None,
            });
            if self.held_item_vertex_count > 0 {
                let texture_bind_group = if self.held_item_uses_atlas {
                    &self.atlas.bind_group
                } else if let Some(texture) = &self.held_item_texture {
                    &texture.bind_group
                } else {
                    &self.atlas.bind_group
                };
                pass.set_pipeline(&self.hand_pipeline);
                pass.set_bind_group(0, &self.hand_camera_bind_group, &[]);
                pass.set_bind_group(1, texture_bind_group, &[]);
                pass.set_bind_group(2, &self.lightmap.bind_group, &[]);
                pass.set_vertex_buffer(0, self.held_item_vertex_buffer.slice(..));
                pass.draw(0..self.held_item_vertex_count, 0..1);
            } else if let Some(hand_texture) = &self.hand_texture {
                pass.set_pipeline(&self.hand_pipeline);
                pass.set_bind_group(0, &self.hand_camera_bind_group, &[]);
                pass.set_bind_group(1, &hand_texture.bind_group, &[]);
                pass.set_bind_group(2, &self.lightmap.bind_group, &[]);
                pass.set_vertex_buffer(0, self.hand_vertex_buffer.slice(..));
                pass.draw(0..self.hand_vertex_count, 0..1);
            }
        }
        if self.inventory_ui.is_some() {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("Minecraft 1.8.9 HUD and inventory GUI pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view, resolve_target: None,
                    ops: wgpu::Operations { load: wgpu::LoadOp::Load, store: wgpu::StoreOp::Store },
                })], depth_stencil_attachment: None, occlusion_query_set: None, timestamp_writes: None,
            });
            pass.set_pipeline(&self.gui_overlay.pipeline);
            pass.set_bind_group(0, &self.gui_overlay.bind_group, &[]);
            pass.set_vertex_buffer(0, self.gui_overlay.vertex_buffer.slice(..));
            pass.draw(0..6, 0..1);
            // Same draw order as GuiContainer: slot contents first, 50%-white hover
            // tint afterwards. This shares the GUI pass and only changes six vertices.
            if self.slot_highlight_visible {
                pass.set_bind_group(0, &self.slot_highlight_sprite.bind_group, &[]);
                pass.set_vertex_buffer(0, self.slot_highlight_sprite.vertex_buffer.slice(..));
                pass.draw(0..6, 0..1);
            }
            if self.hotbar_selection_visible {
                pass.set_bind_group(0, &self.hotbar_selection_sprite.bind_group, &[]);
                pass.set_vertex_buffer(0, self.hotbar_selection_sprite.vertex_buffer.slice(..));
                pass.draw(0..6, 0..1);
            }
            // GuiIngame renders chat after the hotbar. Keep chat text/backgrounds in
            // a separate transparent layer so the selected-slot frame cannot cover glyphs.
            pass.set_pipeline(&self.chat_overlay.pipeline);
            pass.set_bind_group(0, &self.chat_overlay.bind_group, &[]);
            pass.set_vertex_buffer(0, self.chat_overlay.vertex_buffer.slice(..));
            pass.draw(0..6, 0..1);
        }
        // Render the 3D player preview at framebuffer resolution after the scaled GUI
        // panel. This mirrors GuiInventory's OpenGL entity pass and avoids chunky outlines.
        if self.player_preview_visible {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("high-resolution Minecraft inventory player preview"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view, resolve_target: None,
                    ops: wgpu::Operations { load: wgpu::LoadOp::Load, store: wgpu::StoreOp::Store },
                })], depth_stencil_attachment: None, occlusion_query_set: None, timestamp_writes: None,
            });
            pass.set_pipeline(&self.gui_overlay.pipeline);
            pass.set_bind_group(0, &self.player_preview_sprite.bind_group, &[]);
            pass.set_vertex_buffer(0, self.player_preview_sprite.vertex_buffer.slice(..));
            pass.draw(0..6, 0..1);
        }
        // GuiContainer draws the carried stack after the whole inventory, including
        // the avatar preview, so keep the cursor item as the last GUI sprite.
        if self.cursor_stack_visible {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("inventory carried-stack cursor sprite"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view, resolve_target: None,
                    ops: wgpu::Operations { load: wgpu::LoadOp::Load, store: wgpu::StoreOp::Store },
                })], depth_stencil_attachment: None, occlusion_query_set: None, timestamp_writes: None,
            });
            pass.set_pipeline(&self.gui_overlay.pipeline);
            pass.set_bind_group(0, &self.cursor_stack_sprite.bind_group, &[]);
            pass.set_vertex_buffer(0, self.cursor_stack_sprite.vertex_buffer.slice(..));
            pass.draw(0..6, 0..1);
        }
        if self.crosshair_visible {
            let mut pass = encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
                label: Some("centered first-person crosshair pass"),
                color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                    view: &view, resolve_target: None,
                    ops: wgpu::Operations { load: wgpu::LoadOp::Load, store: wgpu::StoreOp::Store },
                })],
                depth_stencil_attachment: None, occlusion_query_set: None, timestamp_writes: None,
            });
            pass.set_pipeline(&self.crosshair_pipeline);
            pass.set_vertex_buffer(0, self.crosshair_vertex_buffer.slice(..));
            pass.draw(0..self.crosshair_vertex_count, 0..1);
        }
        self.queue.submit(Some(encoder.finish())); frame.present(); Ok(())
    }
}
/// EntityLivingBase.getSwingProgress(partialTicks), including its 0->1 wrap interpolation.
fn vanilla_interpolated_swing_progress(previous: f32, current: f32, partial_ticks: f32) -> f32 {
    let mut delta = current - previous;
    if delta < 0.0 {
        delta += 1.0;
    }
    previous + delta * partial_ticks.clamp(0.0, 1.0)
}

fn arm_vertex(position: [f32; 3], normal: [f32; 3], uv: [f32; 2]) -> Vertex {
    Vertex { position, normal, uv, tint: [1.0, 1.0, 1.0], ao: 1.0, sky_light: 1.0, block_light: 1.0, face_shade: 1.0 }
}

fn push_arm_face(vertices: &mut Vec<Vertex>, points: [[f32; 3]; 4], normal: [f32; 3], uv: [f32; 4], texture_height: f32) {
    let [u0, v0, u1, v1] = uv;
    let u0 = u0 / 64.0;
    let u1 = u1 / 64.0;
    let v0 = v0 / texture_height;
    let v1 = v1 / texture_height;
    let tex = [[u0, v1], [u1, v1], [u1, v0], [u0, v0]];
    for index in [0_usize, 1, 2, 0, 2, 3] {
        vertices.push(arm_vertex(points[index], normal, tex[index]));
    }
}

/// Steve right-arm UV layout (4x12x4 pixels), matching ModelBiped's
/// legacy arm texture offset at (40, 16). Works with both 64x32 and 64x64 skins.
fn append_steve_arm_box(
    out: &mut Vec<Vertex>,
    texture_height: f32,
    inflation: f32,
    texture_v_offset: f32,
) {
    // ModelBiped's classic right arm: addBox(-3,-2,-2,4,12,4).
    // The outer-sleeve layer uses the same cuboid inflated by 0.25 pixels.
    let (x0, x1) = (-3.0_f32 - inflation, 1.0_f32 + inflation);
    // Model coordinates have +Y downward; keep y0 as the lower edge so the
    // shared face helper maps the bottom to the lower texture V coordinate.
    let (y0, y1) = (10.0_f32 + inflation, -2.0_f32 - inflation);
    let (z0, z1) = (-2.0_f32 - inflation, 2.0_f32 + inflation);
    let v = texture_v_offset;
    push_arm_face(out, [[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]], [0.0,0.0,1.0], [44.0,20.0+v,48.0,32.0+v], texture_height);
    push_arm_face(out, [[x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0]], [0.0,0.0,-1.0], [52.0,20.0+v,56.0,32.0+v], texture_height);
    push_arm_face(out, [[x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0]], [-1.0,0.0,0.0], [48.0,20.0+v,52.0,32.0+v], texture_height);
    push_arm_face(out, [[x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1]], [1.0,0.0,0.0], [40.0,20.0+v,44.0,32.0+v], texture_height);
    push_arm_face(out, [[x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0]], [0.0,1.0,0.0], [44.0,16.0+v,48.0,20.0+v], texture_height);
    push_arm_face(out, [[x0,y0,z0],[x1,y0,z0],[x1,y0,z1],[x0,y0,z1]], [0.0,-1.0,0.0], [48.0,16.0+v,52.0,20.0+v], texture_height);
}

fn build_steve_arm_vertices(texture_height: f32, swing_progress: f32, equip_progress: f32) -> Vec<Vertex> {
    let mut out = Vec::with_capacity(if texture_height >= 64.0 { 72 } else { 36 });
    append_steve_arm_box(&mut out, texture_height, 0.0, 0.0);
    // ModelPlayer.renderRightArm() also renders bipedRightArmwear. It exists
    // only on modern 64x64 skins and uses texture offset (40,32).
    if texture_height >= 64.0 {
        append_steve_arm_box(&mut out, texture_height, 0.25, 16.0);
    }

    // ItemRenderer.renderPlayerArm() from MCP 1.8.9. Vanilla uses
    // f=-0.3*sin(sqrt(s)*PI), f1=0.4*sin(sqrt(s)*2PI), f2=-0.4*sin(s*PI),
    // then yaw=sin(sqrt(s)*PI)*70 degrees and roll=-sin(s*s*PI)*20 degrees.
    // The fixed matrix suffix is the exact idle pose already used above.
    let swing = swing_progress.clamp(0.0, 1.0);
    let root = swing.sqrt() * std::f32::consts::PI;
    let f = -0.3 * root.sin();
    let f1 = 0.4 * (root * 2.0).sin();
    let f2 = -0.4 * (swing * std::f32::consts::PI).sin();
    let swing_yaw = root.sin() * 70.0_f32.to_radians();
    let swing_roll = -(swing * swing * std::f32::consts::PI).sin() * 20.0_f32.to_radians();
    // OpenGL post-multiplies each transform; glam's column-vector matrices
    // are composed in the same call order here.
    let model_to_view = Mat4::from_translation(Vec3::new(f, f1, f2))
        * Mat4::from_translation(Vec3::new(0.64000005, -0.6, -0.71999997))
        * Mat4::from_translation(Vec3::new(0.0, equip_progress * -0.6, 0.0))
        * Mat4::from_rotation_y(45.0_f32.to_radians())
        * Mat4::from_rotation_y(swing_yaw)
        * Mat4::from_rotation_z(swing_roll)
        * Mat4::from_translation(Vec3::new(-1.0, 3.6, 3.5))
        * Mat4::from_rotation_z(120.0_f32.to_radians())
        * Mat4::from_rotation_x(200.0_f32.to_radians())
        * Mat4::from_rotation_y(-135.0_f32.to_radians())
        * Mat4::from_translation(Vec3::new(5.6, 0.0, 0.0))
        * Mat4::from_translation(Vec3::new(-5.0, 2.0, 0.0) / 16.0)
        * Mat4::from_rotation_z(0.1)
        * Mat4::from_scale(Vec3::splat(1.0 / 16.0));

    for vertex in &mut out {
        let position = Vec3::from_array(vertex.position);
        let normal = Vec3::from_array(vertex.normal);
        vertex.position = model_to_view.transform_point3(position).to_array();
        vertex.normal = model_to_view.transform_vector3(normal).normalize_or_zero().to_array();
    }
    out
}

fn read_steve_skin_dimensions(jar_path: &Path) -> Result<(u32, u32)> {
    let file = File::open(jar_path).map_err(|error| Mc189Error::InvalidData(format!("cannot open client JAR for Steve skin: {error}")))?;
    let mut archive = ZipArchive::new(file).map_err(|error| Mc189Error::InvalidData(format!("cannot read client JAR for Steve skin: {error}")))?;
    let mut entry = archive.by_name("assets/minecraft/textures/entity/steve.png")
        .map_err(|error| Mc189Error::InvalidData(format!("Steve skin is missing from client JAR (textures/entity/steve.png): {error}")))?;
    let mut bytes = Vec::new();
    entry.read_to_end(&mut bytes).map_err(|error| Mc189Error::InvalidData(format!("cannot read Steve skin: {error}")))?;
    let image = image::load_from_memory(&bytes).map_err(|error| Mc189Error::InvalidData(format!("cannot decode Steve skin: {error}")))?;
    let dimensions = (image.width(), image.height());
    if dimensions.0 != 64 || !matches!(dimensions.1, 32 | 64) {
        return Err(Mc189Error::InvalidData(format!("unsupported Steve skin dimensions {}x{}; expected 64x32 or 64x64", dimensions.0, dimensions.1)));
    }
    Ok(dimensions)
}

fn upload_steve_skin(
    device: &wgpu::Device,
    queue: &wgpu::Queue,
    layout: &wgpu::BindGroupLayout,
    jar_path: &Path,
) -> Result<GpuHandTexture> {
    let file = File::open(jar_path).map_err(|error| Mc189Error::InvalidData(format!("cannot open client JAR for Steve skin: {error}")))?;
    let mut archive = ZipArchive::new(file).map_err(|error| Mc189Error::InvalidData(format!("cannot read client JAR for Steve skin: {error}")))?;
    let mut entry = archive.by_name("assets/minecraft/textures/entity/steve.png")
        .map_err(|error| Mc189Error::InvalidData(format!("classic Steve skin is missing from client JAR (textures/entity/steve.png): {error}")))?;
    let mut bytes = Vec::new();
    entry.read_to_end(&mut bytes).map_err(|error| Mc189Error::InvalidData(format!("cannot read Steve skin: {error}")))?;
    let rgba = image::load_from_memory(&bytes).map_err(|error| Mc189Error::InvalidData(format!("cannot decode Steve skin: {error}")))?.to_rgba8();
    if rgba.width() != 64 || !matches!(rgba.height(), 32 | 64) {
        return Err(Mc189Error::InvalidData(format!("unsupported Steve skin dimensions {}x{}; expected 64x32 or 64x64", rgba.width(), rgba.height())));
    }
    let texture = device.create_texture(&wgpu::TextureDescriptor {
        label: Some("Minecraft 1.8.9 classic Steve skin"),
        size: wgpu::Extent3d { width: rgba.width(), height: rgba.height(), depth_or_array_layers: 1 },
        mip_level_count: 1, sample_count: 1, dimension: wgpu::TextureDimension::D2,
        format: wgpu::TextureFormat::Rgba8UnormSrgb,
        usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
        view_formats: &[],
    });
    queue.write_texture(
        wgpu::ImageCopyTexture { texture: &texture, mip_level: 0, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All },
        rgba.as_raw(),
        wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(4 * rgba.width()), rows_per_image: Some(rgba.height()) },
        wgpu::Extent3d { width: rgba.width(), height: rgba.height(), depth_or_array_layers: 1 },
    );
    let view = texture.create_view(&wgpu::TextureViewDescriptor::default());
    let sampler = device.create_sampler(&wgpu::SamplerDescriptor {
        label: Some("Steve skin nearest sampler"), address_mode_u: wgpu::AddressMode::ClampToEdge,
        address_mode_v: wgpu::AddressMode::ClampToEdge, address_mode_w: wgpu::AddressMode::ClampToEdge,
        mag_filter: wgpu::FilterMode::Nearest, min_filter: wgpu::FilterMode::Nearest,
        mipmap_filter: wgpu::FilterMode::Nearest, ..Default::default()
    });
    let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
        label: Some("Steve skin bind group"), layout,
        entries: &[
            wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&view) },
            wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&sampler) },
        ],
    });
    Ok(GpuHandTexture { _texture: texture, bind_group })
}

fn create_depth(device: &wgpu::Device, config: &wgpu::SurfaceConfiguration) -> (wgpu::Texture,wgpu::TextureView) {
    let texture = device.create_texture(&wgpu::TextureDescriptor { label: Some("textured block depth"),
        size: wgpu::Extent3d { width: config.width, height: config.height, depth_or_array_layers:1 }, mip_level_count:1, sample_count:1,
        dimension:wgpu::TextureDimension::D2, format:wgpu::TextureFormat::Depth32Float, usage:wgpu::TextureUsages::RENDER_ATTACHMENT, view_formats:&[] });
    let view = texture.create_view(&wgpu::TextureViewDescriptor::default()); (texture,view)
}

/// Usage: preview-textured-block <client.jar> <atlas-output-directory> <model-id>
pub fn run(jar: &Path, atlas_dir: &Path, model_id: &str) -> Result<()> {
    let (resolved_path, quads) = load_model_quads(jar, model_id)?;
    run_with_quads(atlas_dir, model_id, &resolved_path, quads, None, Vec3::splat(0.5), 0.9)
}

pub fn run_blockstate_variant(jar: &Path, atlas_dir: &Path, blockstate_id: &str, selector: &str, seed: i64) -> Result<()> {
    let (blockstate_path, alternatives) = load_blockstate_variant(jar, blockstate_id, selector)?;
    let selected_index = select_weighted_variant_index(&alternatives, seed).map_err(Mc189Error::InvalidData)?;
    let variant = &alternatives[selected_index];
    // UV lock is handled by the chunk mesher after applying the model rotation.
    // This isolated preview remains explicitly a model-rotation preview.
    if variant.uvlock {
        eprintln!("[preview] selected variant requests uvlock=true; orientation correction is available in the world chunk renderer");
    }
    let (resolved_path, mut quads) = load_model_quads(jar, &variant.model)?;
    apply_blockstate_rotation(&mut quads, variant.x, variant.y);
    let label = format!("{} [{}] seed={}", blockstate_id, if selector.is_empty() { "<default>" } else { selector }, seed);
    run_with_quads(atlas_dir, &label, &resolved_path, quads,
        Some((blockstate_path, variant.x, variant.y, selected_index, alternatives.len(), variant.weight, seed)), Vec3::splat(0.5), 0.9)
}

pub fn run_chunk_preview(atlas_dir: &Path, display_id: &str, quads: Vec<CpuMeshQuad>, camera_target: Vec3, camera_radius: f32) -> Result<()> {
    run_with_quads(atlas_dir, display_id, "combined legacy chunk mesh", quads, None, camera_target, camera_radius)
}

/// Approximate the vanilla overworld sky/fog clear color from the eased celestial
/// angle. The renderer's clear color is the background visible above the loaded
/// terrain; this intentionally remains independent from block light values.
fn vanilla_sky_clear_color(day_time: f64, rain: f32, thunder: f32) -> [f64; 3] {
    let angle = vanilla_celestial_angle(day_time);
    let sun = vanilla_sun_brightness_at(day_time, rain, thunder);
    let daylight = ((sun - 0.2) / 0.8).clamp(0.0, 1.0) as f64;
    let night = [0.006_f64, 0.009, 0.025];
    let day = [0.39_f64, 0.64, 1.0];
    let twilight_distance = (angle - 0.25).abs().min((angle - 0.75).abs()).min(1.0 - (angle - 0.25).abs()).min(1.0 - (angle - 0.75).abs());
    let twilight = (1.0 - (twilight_distance / 0.075) as f64).clamp(0.0, 1.0);
    let weather_dim = 1.0 - (rain.clamp(0.0, 1.0) as f64 * 0.35) - (thunder.clamp(0.0, 1.0) as f64 * 0.15);
    let mut color = [0.0; 3];
    for i in 0..3 {
        color[i] = (night[i] + (day[i] - night[i]) * daylight) * weather_dim;
    }
    // A warm horizon tint at dawn and dusk, fading smoothly into the blue sky.
    let warm = [1.0_f64, 0.43, 0.20];
    let blend = twilight * daylight * 0.48;
    for i in 0..3 { color[i] = color[i] * (1.0 - blend) + warm[i] * blend; }
    color
}

#[cfg(test)]
mod day_night_render_tests {
    use super::vanilla_sky_clear_color;

    #[test]
    fn sky_background_changes_between_day_night_and_twilight() {
        let noon = vanilla_sky_clear_color(6_000.0, 0.0, 0.0);
        let midnight = vanilla_sky_clear_color(18_000.0, 0.0, 0.0);
        let dawn = vanilla_sky_clear_color(23_000.0, 0.0, 0.0);
        assert!(noon[2] > midnight[2] * 10.0);
        assert!(dawn[0] > midnight[0]);
        assert_ne!(noon, midnight);
    }
}

/// Native first-person session with independently uploaded, dynamically streamed chunks.
/// Movement is simulated at a bounded frame delta and collision queries read decoded Anvil data.
pub fn run_gameplay(
    jar_path: &Path,
    atlas_dir: &Path,
    world_path: &Path,
    chunk_quads: HashMap<(i32, i32), Vec<CpuMeshQuad>>,
    player: PlayerState,
    player_inventory: crate::inventory::PlayerInventory,
    collision: LoadedWorldCollision,
    origin_chunk_x: i32,
    origin_chunk_z: i32,
    streamer: ChunkStreamer,
    block_edit_worker: GameplayBlockEditWorker,
    world_io_lock: Arc<Mutex<()>>,
    initial_day_time: i64,
    raining: bool,
    thundering: bool,
) -> Result<()> {
    let mut event_loop = EventLoop::new()
        .map_err(|e| Mc189Error::InvalidData(format!("cannot create gameplay event loop: {e}")))?;
    let window = Arc::new(WindowBuilder::new()
        .with_title("mc189-rs — Minecraft 1.8.9 (first person)")
        .with_inner_size(PhysicalSize::new(1280, 800))
        .build(&event_loop)
        .map_err(|e| Mc189Error::InvalidData(format!("cannot create gameplay window: {e}")))?);
    run_gameplay_on_window(
        jar_path, atlas_dir, world_path, chunk_quads, player, player_inventory, collision, origin_chunk_x, origin_chunk_z,
        streamer, block_edit_worker, world_io_lock, initial_day_time, raining, thundering, &mut event_loop, window,
    )
}

pub fn run_gameplay_on_window(
    jar_path: &Path,
    atlas_dir: &Path,
    world_path: &Path,
    chunk_quads: HashMap<(i32, i32), Vec<CpuMeshQuad>>,
    mut player: PlayerState,
    player_inventory: crate::inventory::PlayerInventory,
    mut collision: LoadedWorldCollision,
    origin_chunk_x: i32,
    origin_chunk_z: i32,
    streamer: ChunkStreamer,
    block_edit_worker: GameplayBlockEditWorker,
    world_io_lock: Arc<Mutex<()>>,
    initial_day_time: i64,
    raining: bool,
    thundering: bool,
    event_loop: &mut EventLoop<()>,
    window: Arc<Window>,
) -> Result<()> {
    let atlas_runtime = AtlasRuntime::load(atlas_dir)?;
    if atlas_runtime.page_count() != 1 {
        return Err(Mc189Error::InvalidData("first-person renderer currently requires a single atlas page".into()));
    }
    let mut cpu_meshes = HashMap::with_capacity(chunk_quads.len());
    let mut initial_faces = 0_usize;
    let mut initial_triangles = 0_usize;
    for (coords, quads) in chunk_quads {
        initial_faces += quads.len();
        let mesh = compile_textured_mesh(&quads, &atlas_runtime)?;
        initial_triangles += mesh.triangles;
        cpu_meshes.insert(coords, mesh);
    }
    println!("Minecraft 1.8.9 Rust — first-person session");
    println!("Loaded collision chunks: {}", collision.chunks.len());
    println!("Initial mesh faces: {} | triangles: {}", initial_faces, initial_triangles);
    println!("Chunk streaming: radius {} chunks ({}x{}), unload beyond {} chunks", STREAM_RADIUS_CHUNKS, STREAM_RADIUS_CHUNKS * 2 + 1, STREAM_RADIUS_CHUNKS * 2 + 1, RETAIN_RADIUS_CHUNKS);
    println!("Controls: WASD move | Space jump | Shift sprint | left-click capture mouse | mouse look | Esc release mouse (Esc again exits)");
    println!("World access: integrated 20 TPS server; it owns Anvil writes and the final save barrier.");
    println!("Autosave: server-owned chunk, player-data, and dropped-item checkpoints every 5 minutes; close waits for edits and disk commit.");
    println!("First-person hand: classic Steve right arm (64x32/64x64 skin, 3D overlay)");
    event_loop.set_control_flow(ControlFlow::Poll);
    window.set_title("mc189-rs — Minecraft 1.8.9 (first person)");
    let mut viewer = pollster::block_on(Viewer::new(window.clone(), &cpu_meshes, atlas_dir, &atlas_runtime, Some(jar_path), player.eye_position(), 64.0, (origin_chunk_x, origin_chunk_z)))?;
    if let Some(ui) = viewer.inventory_ui.as_mut() {
        ui.inventory = player_inventory.clone();
        ui.reset_inventory_animation_tracking();
    } else {
        return Err(Mc189Error::InvalidData("gameplay inventory UI was not initialized".into()));
    }
    viewer.refresh_gui_overlay();
    viewer.refresh_hotbar_selection();
    viewer.refresh_held_item_if_changed();
    // Keep the CPU-side owner-tagged meshes beside their GPU counterparts. This
    // enables a just-broken block to be culled immediately before the expensive
    // full chunk/neighbor mesh transaction returns from the worker.
    let mut cpu_chunk_meshes = cpu_meshes;
    // A streamed full-chunk result may finish after a newer gameplay section
    // patch. Remember which sections are authoritative so an older full result
    // cannot silently overwrite the mined faces/light in those sections.
    let mut gameplay_mesh_section_overrides = HashMap::<(i32, i32), HashSet<u8>>::new();
    let mut immediately_hidden_blocks = HashMap::<(i32, i32), HashSet<[i32; 3]>>::new();
    let mut pending_visual_rollback = HashMap::<u64, ((i32, i32), [i32; 3], CpuMesh)>::new();
    let initial_sun = vanilla_sun_brightness(
        initial_day_time,
        if raining { 1.0 } else { 0.0 },
        if thundering { 1.0 } else { 0.0 },
    );
    update_vanilla_lightmap(&viewer.queue, &viewer.lightmap, initial_sun, 0.0, false);
    viewer.set_world_sky(initial_day_time as f64, if raining { 1.0 } else { 0.0 }, if thundering { 1.0 } else { 0.0 });
    player.yaw = 0.0;
    player.pitch = 0.0;
    // Single-player now runs movement/collision in the same authoritative server
    // crate used by the dedicated process. The render loop only sends input and
    // consumes 20 TPS snapshots; it no longer advances PlayerState itself.
    let integrated_server = IntegratedServer::start(collision.clone(), player, player_inventory.clone(), world_path.to_path_buf(), world_io_lock)?;
    viewer.update_player_camera(player);
    let mut pressed = HashSet::<KeyCode>::new();
    let mut jump_pending = false;
    let mut mouse_captured = false;
    let mut last_frame = Instant::now();
    let mut accumulator = 0.0_f32;
    let mut render_partial_ticks = 0.0_f32;
    let mut world_day_time = initial_day_time;
    let rain_strength = if raining { 1.0 } else { 0.0 };
    let thunder_strength = if thundering { 1.0 } else { 0.0 };
    let flicker_seed = SystemTime::now().duration_since(UNIX_EPOCH)
        .unwrap_or_default().as_nanos() as u64;
    let mut torch_flicker = VanillaTorchFlicker::new(flicker_seed);
    // Audio is resolved from the same launcher's hashed 1.8 asset objects as vanilla.
    // A missing audio device/index is non-fatal and leaves gameplay fully usable.
    let mut block_audio = crate::audio::BlockAudio::load_for_world(world_path, jar_path, flicker_seed);
    // Keep the previous simulation state across render frames. If this is
    // recreated inside AboutToWait, frames without a 20 Hz tick lose the
    // interpolation origin and the camera visibly snaps at the tick rate.
    let mut previous_player = player;
    // This is the pose actually submitted to the renderer. Keep it separate
    // from the authoritative simulation state so asynchronous input/window
    // events cannot briefly replace an interpolated position with a raw tick
    // position between render frames.
    let mut camera_player = player;
    let fixed_step = 1.0 / 20.0;
    let streamer = streamer;
    let block_edit_worker = block_edit_worker;
    let jar_path = jar_path.to_path_buf();
    // None means a streamed full-chunk upload; Some(section_y) is a surgical
    // section replacement produced by a block edit.
    let mut gameplay_mesh_queue: VecDeque<((i32, i32), Option<u8>, Vec<CpuMeshQuad>)> = VecDeque::new();
    let (mesh_compile_tx, mesh_compile_rx) = mpsc::channel::<((i32, i32), Option<u8>, Result<CpuMesh>)>();
    let mut mesh_compile_in_progress = false;
    let mut edit_revision = 0_u64;
    let mut dirty_chunks: HashMap<(i32, i32), DirtyChunkSnapshot> = HashMap::new();
    let mut pending_block_edits: usize = 0;
    let mut pending_edit_chunks: HashMap<(i32, i32), usize> = HashMap::new();
    let mut save_in_progress = false;
    let mut shutdown_requested = false;
    let mut last_autosave = Instant::now();
    let mut last_observed_player_inventory = viewer.inventory_ui.as_ref()
        .map(|ui| ui.inventory.clone()).unwrap_or_default();
    let mut last_observed_player_pose = (player.position, player.yaw, player.pitch);
    let mut player_inventory_revision = 0_u64;
    let mut dirty_player_inventory: Option<PlayerDataSnapshot> = None;
    let mut dirty_entity_items: Option<EntityItemsSnapshot> = None;
    let mut entity_items_revision = 0_u64;
    let mut last_observed_entity_items: Vec<EntityItemSnapshot> = Vec::new();
    let mut has_observed_entity_items_snapshot = false;
    // Remember every chunk that has hosted a server-owned item, even after it moves
    // or is picked up, so a later save can clear stale NBT from its former chunk.
    let mut entity_persistence_chunks: HashSet<(i32, i32)> = collision.chunks.keys().copied().collect();
    const AUTOSAVE_INTERVAL: Duration = Duration::from_secs(300);
    let mut mining_sound_target: Option<BlockPos> = None;
    let mut mining_sound_tick_counter = 0_u8;
    let mut left_mouse_held = false;
    // Every world EntityItem is server-owned. The client keeps render-only replicas.
    let mut server_dropped_items: Vec<(u64, DroppedItem)> = Vec::new();
    let mut render_dropped_items: Vec<DroppedItem> = Vec::new();
    let mut pending_entity_rollbacks: HashMap<u64, Vec<u64>> = HashMap::new();
    let mut pickup_animations: Vec<mining::PickupAnimation> = Vec::new();
    let mut last_stream_center: Option<(i32, i32)> = None;
    let mut streamed_chunk_count = 0_u64;
    let mut server_input_sequence = 0_u64;
    let mut last_server_snapshot_tick = 0_u64;
    window.set_cursor_visible(true);
    window.request_redraw();
    event_loop.run_on_demand(move |event, event_loop| match event {
        Event::DeviceEvent { event: DeviceEvent::MouseMotion { delta }, .. } if mouse_captured => {
            player.yaw += delta.0 as f32 * 0.0025;
            player.pitch = (player.pitch + delta.1 as f32 * 0.0025).clamp(-1.5533, 1.5533);
            // Apply look input immediately, but preserve the interpolated
            // camera position. Passing `player` here would momentarily snap
            // translation to the latest 20 Hz simulation state.
            camera_player.yaw = player.yaw;
            camera_player.pitch = player.pitch;
            viewer.update_player_camera(camera_player);
            window.request_redraw();
        }
        Event::WindowEvent { window_id, event } if window_id == window.id() => match event {
            WindowEvent::CloseRequested => {
                shutdown_requested = true;
                left_mouse_held = false;
                pressed.clear();
                jump_pending = false;
                let _ = integrated_server.set_mining_intent(false);
                let _ = window.set_cursor_grab(winit::window::CursorGrabMode::None);
                mouse_captured = false;
                viewer.set_crosshair_visible(false);
                window.set_cursor_visible(true);
                window.set_title("Minecraft Rust 1.8.9 — Saving world...");
                println!("[world save] close requested; waiting for {} pending block edits before final save...", pending_block_edits);
            },
            WindowEvent::Resized(size) => { viewer.resize(size.width, size.height); viewer.update_player_camera(camera_player); window.request_redraw(); }
            WindowEvent::Focused(false) => {
                pressed.clear(); jump_pending = false; left_mouse_held = false; let _ = integrated_server.set_mining_intent(false);
                if mouse_captured { let _ = window.set_cursor_grab(winit::window::CursorGrabMode::None); mouse_captured = false; viewer.set_crosshair_visible(false); window.set_cursor_visible(true); }
            }
            WindowEvent::CursorMoved { position, .. } => {
                let scale = f64::from(vanilla_gui_scale_factor(viewer.config.width, viewer.config.height));
                let (inventory_open, hover_changed, logical_cursor_changed) = if let Some(ui) = viewer.inventory_ui.as_mut() {
                    let open = ui.screen == crate::inventory::UiScreen::Inventory;
                    let old_logical = ((ui.cursor_position.0 / scale).floor() as i32,
                        (ui.cursor_position.1 / scale).floor() as i32);
                    let hover_changed = ui.set_cursor_position(position.x, position.y, viewer.config.width, viewer.config.height);
                    let new_logical = ((position.x / scale).floor() as i32, (position.y / scale).floor() as i32);
                    (open, hover_changed, old_logical != new_logical)
                } else { (false, false, false) };
                if inventory_open {
                    // GuiScreen receives integer ScaledResolution mouse coordinates. Only
                    // update the CPU-rasterized avatar/carried sprite when that logical
                    // coordinate changes; hover itself is a one-quad GPU update.
                    if hover_changed { viewer.refresh_hover_highlight(); }
                    if logical_cursor_changed {
                        viewer.player_preview_dirty = true;
                        viewer.cursor_stack_dirty = true;
                    }
                    window.request_redraw();
                }
            }
            WindowEvent::MouseInput { state: ElementState::Pressed, button: MouseButton::Left, .. }
                if viewer.inventory_ui.as_ref().is_some_and(|ui| ui.screen == crate::inventory::UiScreen::Inventory) => {
                let (x, y) = viewer.inventory_ui.as_ref().map(|ui| ui.cursor_position).unwrap_or((0.0, 0.0));
                let width = viewer.config.width;
                let height = viewer.config.height;
                let shift_down = pressed.contains(&KeyCode::ShiftLeft) || pressed.contains(&KeyCode::ShiftRight);
                let slot = viewer.inventory_ui.as_ref().and_then(|ui| ui.inventory_slot_at_physical(x, y, width, height));
                if let Some(slot) = slot { let _ = integrated_server.click_inventory_slot(slot, false, shift_down); }
                window.request_redraw();
            }
            WindowEvent::MouseInput { state: ElementState::Pressed, button: MouseButton::Right, .. }
                if viewer.inventory_ui.as_ref().is_some_and(|ui| ui.screen == crate::inventory::UiScreen::Inventory) => {
                let (x, y) = viewer.inventory_ui.as_ref().map(|ui| ui.cursor_position).unwrap_or((0.0, 0.0));
                let width = viewer.config.width;
                let height = viewer.config.height;
                let shift_down = pressed.contains(&KeyCode::ShiftLeft) || pressed.contains(&KeyCode::ShiftRight);
                let slot = viewer.inventory_ui.as_ref().and_then(|ui| ui.inventory_slot_at_physical(x, y, width, height));
                if let Some(slot) = slot { let _ = integrated_server.click_inventory_slot(slot, true, shift_down); }
                window.request_redraw();
            }
            WindowEvent::MouseInput { state: ElementState::Pressed, button: MouseButton::Left, .. }
                if !mouse_captured && viewer.inventory_ui.as_ref().map_or(true, |ui| ui.screen == crate::inventory::UiScreen::Hud) => {
                let grab = window.set_cursor_grab(winit::window::CursorGrabMode::Locked)
                    .or_else(|_| window.set_cursor_grab(winit::window::CursorGrabMode::Confined));
                if grab.is_ok() { mouse_captured = true; viewer.set_crosshair_visible(true); window.set_cursor_visible(false); }
            }
            WindowEvent::MouseInput { state: ElementState::Pressed, button: MouseButton::Left, .. }
                if mouse_captured && viewer.inventory_ui.as_ref().map_or(true, |ui| ui.screen == crate::inventory::UiScreen::Hud) => {
                // Vanilla clickMouse swings immediately; held state drives block damage at 20 Hz.
                left_mouse_held = true;
                viewer.start_hand_swing();
                window.request_redraw();
            }
            WindowEvent::MouseInput { state: ElementState::Released, button: MouseButton::Left, .. } => {
                left_mouse_held = false;
                let _ = integrated_server.set_mining_intent(false);
                window.request_redraw();
            }
            WindowEvent::MouseWheel { delta, .. }
                if viewer.inventory_ui.as_ref().map_or(false, |ui| ui.screen == crate::inventory::UiScreen::Hud) => {
                let wheel = match delta {
                    MouseScrollDelta::LineDelta(_, y) => y,
                    MouseScrollDelta::PixelDelta(position) => position.y as f32,
                };
                if wheel != 0.0 {
                    if let Some(ui) = viewer.inventory_ui.as_ref() {
                        let current = ui.inventory.selected_hotbar as i32;
                        let direction = if wheel > 0.0 { -1 } else { 1 };
                        let _ = integrated_server.select_hotbar((current + direction).rem_euclid(9) as usize);
                    }
                    window.request_redraw();
                }
            }
            WindowEvent::KeyboardInput { event, .. } => {
                if let PhysicalKey::Code(code) = event.physical_key {
                    if event.state == ElementState::Released {
                        pressed.remove(&code);
                    } else {
                        // Track modifiers regardless of the active screen. In HUD mode
                        // Ctrl is otherwise ignored before Q is handled, making Ctrl+Q
                        // indistinguishable from a one-item drop.
                        if matches!(code, KeyCode::ControlLeft | KeyCode::ControlRight | KeyCode::ShiftLeft | KeyCode::ShiftRight) {
                            pressed.insert(code);
                        }
                        use crate::inventory::UiScreen;
                        let screen = viewer.inventory_ui.as_ref().map(|ui| ui.screen).unwrap_or(UiScreen::Hud);
                        match screen {
                            UiScreen::Inventory => {
                                if matches!(code, KeyCode::ShiftLeft | KeyCode::ShiftRight | KeyCode::ControlLeft | KeyCode::ControlRight) {
                                    pressed.insert(code);
                                } else if code == KeyCode::KeyQ && !event.repeat {
                                    let drop_all = control_requests_drop_all(&pressed);
                                    let slot = viewer.inventory_ui.as_ref().and_then(|ui| ui.hovered_drop_slot());
                                    if let Some(slot) = slot {
                                        if integrated_server.drop_inventory_slot(slot, drop_all).is_ok() {
                                            viewer.start_hand_swing();
                                            window.request_redraw();
                                        }
                                    }
                                } else if code == KeyCode::Escape || code == KeyCode::KeyE {
                                    if !event.repeat {
                                        let _ = integrated_server.drop_inventory_cursor();
                                        if let Some(ui) = viewer.inventory_ui.as_mut() { ui.close_screen(); }
                                        viewer.refresh_gui_overlay();
                                        let grab = window.set_cursor_grab(winit::window::CursorGrabMode::Locked)
                                            .or_else(|_| window.set_cursor_grab(winit::window::CursorGrabMode::Confined));
                                        mouse_captured = grab.is_ok();
                                        viewer.set_crosshair_visible(mouse_captured);
                                        window.set_cursor_visible(!mouse_captured);
                                        pressed.clear(); jump_pending = false;
                                        window.request_redraw();
                                    }
                                }
                            }
                            UiScreen::Chat => {
                                if code == KeyCode::Escape && !event.repeat {
                                    if let Some(ui) = viewer.inventory_ui.as_mut() { ui.close_screen(); }
                                } else if (code == KeyCode::Enter || code == KeyCode::NumpadEnter) && !event.repeat {
                                    let submitted = viewer.inventory_ui.as_mut().and_then(|ui| ui.submit_chat());
                                    if let Some(command_line) = submitted {
                                        let parsed = viewer.inventory_ui.as_mut().and_then(|ui| ui.parse_server_inventory_command(&command_line));
                                        match parsed {
                                            Some(crate::inventory::InventoryServerCommand::Give { item_id, count, damage }) => {
                                                let result = integrated_server.give_inventory_item(item_id.clone(), count, damage);
                                                if let Some(ui) = viewer.inventory_ui.as_mut() {
                                                    match result {
                                                        Ok(()) => ui.push_chat(format!("Give request sent: {count} {item_id} (server inventory).")),
                                                        Err(error) => ui.push_chat(format!("Server rejected /give: {error}")),
                                                    }
                                                }
                                            }
                                            Some(crate::inventory::InventoryServerCommand::Clear) => {
                                                let result = integrated_server.clear_inventory();
                                                if let Some(ui) = viewer.inventory_ui.as_mut() {
                                                    match result {
                                                        Ok(()) => ui.push_chat("Clear request sent to integrated server."),
                                                        Err(error) => ui.push_chat(format!("Server rejected /clear: {error}")),
                                                    }
                                                }
                                            }
                                            None => {}
                                        }
                                    }
                                } else if code == KeyCode::Backspace {
                                    if let Some(ui) = viewer.inventory_ui.as_mut() { ui.chat_backspace(); }
                                } else if let Some(text) = event.text.as_deref() {
                                    if let Some(ui) = viewer.inventory_ui.as_mut() { ui.chat_push_text(text); }
                                }
                                let now_hud = viewer.inventory_ui.as_ref().is_some_and(|ui| ui.screen == UiScreen::Hud);
                                if now_hud {
                                    let grab = window.set_cursor_grab(winit::window::CursorGrabMode::Locked)
                                        .or_else(|_| window.set_cursor_grab(winit::window::CursorGrabMode::Confined));
                                    mouse_captured = grab.is_ok();
                                    viewer.set_crosshair_visible(mouse_captured);
                                    window.set_cursor_visible(!mouse_captured);
                                    pressed.clear(); jump_pending = false;
                                }
                                viewer.refresh_gui_overlay();
                                window.request_redraw();
                            }
                            UiScreen::Hud => {
                                if code == KeyCode::Escape && !event.repeat {
                                    if mouse_captured {
                                        let _ = window.set_cursor_grab(winit::window::CursorGrabMode::None);
                                        mouse_captured = false;
                                        viewer.set_crosshair_visible(false);
                                        window.set_cursor_visible(true);
                                    } else {
                                        shutdown_requested = true;
                                        left_mouse_held = false;
                                        pressed.clear();
                                        jump_pending = false;
                                        let _ = integrated_server.set_mining_intent(false);
                                        window.set_title("Minecraft Rust 1.8.9 — Saving world...");
                                        println!("[world save] Escape requested exit; waiting for pending edits and final save...");
                                    }
                                } else if code == KeyCode::KeyE && !event.repeat {
                                    if let Some(ui) = viewer.inventory_ui.as_mut() {
                                        let x = f64::from(viewer.config.width) * 0.5;
                                        let y = f64::from(viewer.config.height) * 0.5;
                                        ui.open_inventory();
                                        ui.set_cursor_position(x, y, viewer.config.width, viewer.config.height);
                                    }
                                    let _ = window.set_cursor_grab(winit::window::CursorGrabMode::None);
                                    mouse_captured = false;
                                    viewer.set_crosshair_visible(false);
                                    window.set_cursor_visible(true);
                                    pressed.clear(); jump_pending = false;
                                    viewer.refresh_gui_overlay();
                                    window.request_redraw();
                                } else if (code == KeyCode::KeyT || code == KeyCode::Slash) && !event.repeat {
                                    if let Some(ui) = viewer.inventory_ui.as_mut() { ui.open_chat(code == KeyCode::Slash); }
                                    let _ = window.set_cursor_grab(winit::window::CursorGrabMode::None);
                                    mouse_captured = false;
                                    viewer.set_crosshair_visible(false);
                                    window.set_cursor_visible(true);
                                    pressed.clear(); jump_pending = false;
                                    viewer.refresh_gui_overlay();
                                    window.request_redraw();
                                } else if let Some(slot) = hotbar_slot_from_key(code) {
                                    let _ = integrated_server.select_hotbar(slot);
                                    window.request_redraw();
                                } else if code == KeyCode::KeyQ && !event.repeat {
                                    let drop_all = control_requests_drop_all(&pressed);
                                    let slot = viewer.inventory_ui.as_ref().and_then(|ui| ui.selected_hotbar_drop_slot());
                                    if let Some(slot) = slot {
                                        if integrated_server.drop_inventory_slot(slot, drop_all).is_ok() {
                                            viewer.start_hand_swing();
                                            window.request_redraw();
                                        }
                                    }
                                } else {
                                    if code == KeyCode::Space && !event.repeat {
                                        jump_pending = true;
                                        let bx = player.position.x.floor() as i32;
                                        let by = player.position.y.floor() as i32 - 1;
                                        let bz = player.position.z.floor() as i32;
                                        eprintln!("[jump diagnostic] keydown | grounded={} | feet=({:.3},{:.3},{:.3}) | velocity_y={:.3} | floor_block=({}, {}, {}) solid={}",
                                            player.on_ground, player.position.x, player.position.y, player.position.z,
                                            player.velocity.y, bx, by, bz, collision.is_solid(bx, by, bz));
                                    }
                                    pressed.insert(code);
                                }
                            }
                        }
                    }
                }
            }
            WindowEvent::RedrawRequested => {
                viewer.refresh_gui_animation_frame(render_partial_ticks);
                // Render dropped entities at the actual display cadence, not only at
                // AboutToWait / fixed-tick cadence. Position and age are interpolated
                // from the two most recent authoritative 20 TPS states.
                render_dropped_items.clear();
                render_dropped_items.extend(server_dropped_items.iter().map(|(_, item)| item.clone()));
                viewer.update_dropped_item_mesh(
                    &render_dropped_items, &pickup_animations, previous_player.position, player.position,
                    &jar_path, &collision, render_partial_ticks,
                );
                viewer.refresh_held_item_if_changed();
                if viewer.player_preview_dirty { viewer.refresh_player_preview(); }
                if viewer.cursor_stack_dirty { viewer.refresh_cursor_stack_sprite(); }
                match viewer.render() {
                    Ok(()) => {},
                    Err(wgpu::SurfaceError::Lost | wgpu::SurfaceError::Outdated) => { let (w,h)=(viewer.config.width,viewer.config.height); viewer.resize(w,h); viewer.update_player_camera(camera_player); },
                    Err(wgpu::SurfaceError::Timeout) => {},
                    Err(wgpu::SurfaceError::OutOfMemory) => {
                        eprintln!("GPU ran out of memory; requesting safe world shutdown");
                        shutdown_requested = true;
                        left_mouse_held = false;
                        pressed.clear();
                    }
                }
            },
            _ => {}
        },
        Event::AboutToWait => {
            let current_chunk = player_chunk_coordinates(
                player.position,
                origin_chunk_x,
                origin_chunk_z,
            );
            if !shutdown_requested && last_stream_center != Some(current_chunk) {
                let _ = streamer.requests.send(current_chunk);
                last_stream_center = Some(current_chunk);
                let chunks_to_unload: Vec<_> = collision.chunks.keys().copied().filter(|&(x, z)| {
                    !(dirty_chunks.contains_key(&(x, z)) || pending_edit_chunks.contains_key(&(x, z)) || (
                        (i64::from(x) - i64::from(current_chunk.0)).abs() <= i64::from(RETAIN_RADIUS_CHUNKS)
                            && (i64::from(z) - i64::from(current_chunk.1)).abs() <= i64::from(RETAIN_RADIUS_CHUNKS)
                    ))
                }).collect();
                for (chunk_x, chunk_z) in chunks_to_unload {
                    collision.chunks.remove(&(chunk_x, chunk_z));
                    let _ = integrated_server.remove_chunk(chunk_x, chunk_z);
                }
                let mut protected: HashSet<_> = dirty_chunks.keys().copied().collect();
                protected.extend(pending_edit_chunks.keys().copied());
                viewer.retain_chunk_meshes(current_chunk, RETAIN_RADIUS_CHUNKS, &protected);
                // CPU owner-tagged meshes mirror the GPU retention window; do not
                // accumulate an unbounded second copy while the player explores.
                cpu_chunk_meshes.retain(|&(x, z), _| {
                    protected.contains(&(x, z))
                        || (i64::from(x) - i64::from(current_chunk.0)).abs() <= i64::from(RETAIN_RADIUS_CHUNKS)
                            && (i64::from(z) - i64::from(current_chunk.1)).abs() <= i64::from(RETAIN_RADIUS_CHUNKS)
                });
                immediately_hidden_blocks.retain(|coords, _| cpu_chunk_meshes.contains_key(coords)
                    || pending_edit_chunks.contains_key(coords));
                gameplay_mesh_section_overrides.retain(|coords, _| cpu_chunk_meshes.contains_key(coords)
                    || pending_edit_chunks.contains_key(coords));
            }
            // Upload at most one completed chunk per event-loop iteration. This
            // spreads GPU buffer creation over frames instead of causing a large
            // burst when the worker finishes several neighboring chunks together.
            if let Ok(result) = streamer.results.try_recv() {
                let within_retention = (i64::from(result.chunk_x) - i64::from(current_chunk.0)).abs() <= i64::from(RETAIN_RADIUS_CHUNKS)
                    && (i64::from(result.chunk_z) - i64::from(current_chunk.1)).abs() <= i64::from(RETAIN_RADIUS_CHUNKS);
                if within_retention {
                    if let Some(chunk) = result.chunk {
                        let coords = (result.chunk_x, result.chunk_z);
                        if !dirty_chunks.contains_key(&coords) && !pending_edit_chunks.contains_key(&coords) {
                            collision.chunks.insert(coords, chunk.clone());
                            let _ = integrated_server.replace_chunk(chunk);
                            // Empty geometry is meaningful: upload it too, otherwise an old
                            // chunk GPU mesh remains visible after its final block is removed.
                            gameplay_mesh_queue.push_back((coords, None, result.quads));
                        }
                        streamed_chunk_count += 1;
                        if streamed_chunk_count % 8 == 0 {
                            println!("[chunk stream] loaded {streamed_chunk_count} additional chunks; active collision chunks: {}", collision.chunks.len());
                        }
                    }
                    if let Some(error) = result.error {
                        eprintln!("[chunk stream] ({},{}): {error}", result.chunk_x, result.chunk_z);
                    }
                }
            }
            // Consume in-memory edits. The worker never writes Anvil files;
            // successful snapshots become dirty and are persisted by the integrated server persistence service.
            while let Ok(result) = block_edit_worker.results.try_recv() {
                pending_block_edits = pending_block_edits.saturating_sub(1);
                let result_coords = (result.chunk_x, result.chunk_z);
                if let Some(count) = pending_edit_chunks.get_mut(&result_coords) {
                    *count = count.saturating_sub(1);
                    if *count == 0 { pending_edit_chunks.remove(&result_coords); }
                }
                if let Some(error) = result.error.as_ref() {
                    eprintln!("[mining worker] revision {}: {error}", result.revision);
                }
                if result.processed {
                    pending_visual_rollback.remove(&result.revision);
                    if let Some(entity_ids) = pending_entity_rollbacks.remove(&result.revision) { let _ = integrated_server.commit_entity_items(entity_ids); }
                    for chunk in result.updated_chunks {
                        let coords = (chunk.x_pos, chunk.z_pos);
                        collision.chunks.insert(coords, chunk.clone());
                        let _ = integrated_server.replace_chunk(chunk.clone());
                        dirty_chunks.insert(coords, DirtyChunkSnapshot { revision: result.revision, chunk });
                    }
                    let mut edit_meshes: Vec<_> = result.meshes.into_iter().collect();
                    // The edited chunk must become visible first; stale streaming
                    // work must not leave a mined hole or adjacent water surface
                    // waiting behind a queue of distant chunks.
                    edit_meshes.sort_by_key(|mesh| (mesh.coords != (result.chunk_x, result.chunk_z), mesh.coords.1, mesh.coords.0, mesh.section_y));
                    for mesh in edit_meshes.into_iter().rev() {
                        gameplay_mesh_queue.retain(|(coords, queued_section_y, _)| {
                            *coords != mesh.coords
                                || (*queued_section_y != None && *queued_section_y != Some(mesh.section_y))
                        });
                        gameplay_mesh_queue.push_front((mesh.coords, Some(mesh.section_y), mesh.quads));
                    }
                    window.request_redraw();
                } else {
                    // A failed in-memory transaction restores the block; no Anvil I/O
                    // has happened, so the disk still contains the previous state.
                    if let Some(entity_ids) = pending_entity_rollbacks.remove(&result.revision) { let _ = integrated_server.remove_entity_items(entity_ids); }
                    if let Some((coords, failed_block, mut previous)) = pending_visual_rollback.remove(&result.revision) {
                        if let Some(hidden) = immediately_hidden_blocks.get_mut(&coords) {
                            hidden.remove(&failed_block);
                            if hidden.is_empty() { immediately_hidden_blocks.remove(&coords); }
                        }
                        if let Some(hidden) = immediately_hidden_blocks.get(&coords) {
                            for block in hidden { previous.hide_block(*block); }
                        }
                        cpu_chunk_meshes.insert(coords, previous.clone());
                        let _ = viewer.insert_chunk_mesh(coords, &previous);
                    }
                    let local_x = (result.chunk_x - origin_chunk_x).saturating_mul(16) + i32::from(result.local_x);
                    let local_z = (result.chunk_z - origin_chunk_z).saturating_mul(16) + i32::from(result.local_z);
                    let _ = collision.set_block_local(local_x, i32::from(result.local_y), local_z, result.expected_id, result.expected_metadata);
                    let _ = integrated_server.set_block(local_x, i32::from(result.local_y), local_z, result.expected_id, result.expected_metadata);
                    viewer.update_mining_crack(None, None);
                    window.request_redraw();
                }
            }
            // Inventory mutations are observed independently from chunk edits. This
            // covers pickups, normal slot clicks, armor changes and selected hotbar.
            let current_player_inventory = viewer.inventory_ui.as_ref()
                .map(|ui| ui.inventory.clone()).unwrap_or_default();
            let current_pose = (player.position, player.yaw, player.pitch);
            let inventory_changed = current_player_inventory != last_observed_player_inventory;
            let pose_changed = current_pose.0.distance_squared(last_observed_player_pose.0) > 0.0001
                || (current_pose.1 - last_observed_player_pose.1).abs() > 0.001
                || (current_pose.2 - last_observed_player_pose.2).abs() > 0.001;
            if inventory_changed || pose_changed {
                player_inventory_revision = player_inventory_revision.wrapping_add(1).max(1);
                let mut patch = current_player_inventory.to_player_nbt();
                // Store vanilla Player.Pos / Rotation fields in world coordinates.
                // The simulation uses origin-relative coordinates to keep floats stable.
                let world_x = f64::from(current_pose.0.x) + f64::from(origin_chunk_x) * 16.0;
                let world_y = f64::from(current_pose.0.y);
                let world_z = f64::from(current_pose.0.z) + f64::from(origin_chunk_z) * 16.0;
                let pose_fields = vec![
                    ("Pos".into(), mc189_storage::NbtTag::List(6, vec![
                        mc189_storage::NbtTag::Double(world_x),
                        mc189_storage::NbtTag::Double(world_y),
                        mc189_storage::NbtTag::Double(world_z),
                    ])),
                    ("Rotation".into(), mc189_storage::NbtTag::List(5, vec![
                        mc189_storage::NbtTag::Float(current_pose.1),
                        mc189_storage::NbtTag::Float(current_pose.2),
                    ])),
                    ("Motion".into(), mc189_storage::NbtTag::List(6, vec![
                        mc189_storage::NbtTag::Double(f64::from(player.velocity.x)),
                        mc189_storage::NbtTag::Double(f64::from(player.velocity.y)),
                        mc189_storage::NbtTag::Double(f64::from(player.velocity.z)),
                    ])),
                ];
                if let mc189_storage::NbtTag::Compound(fields) = &mut patch {
                    fields.extend(pose_fields);
                }
                dirty_player_inventory = Some(PlayerDataSnapshot {
                    revision: player_inventory_revision,
                    player_nbt_patch: patch,
                });
                last_observed_player_inventory = current_player_inventory;
                last_observed_player_pose = current_pose;
            }

            // Complete asynchronous checkpoints. Only clear a dirty entry when the
            // saved snapshot revision is still current; edits made during a checkpoint
            // remain dirty and will be included in the next save.
            while let Ok(result) = integrated_server.try_save_result() {
                save_in_progress = false;
                for (coords, saved_revision) in result.saved {
                    if dirty_chunks.get(&coords).is_some_and(|entry| entry.revision == saved_revision) {
                        dirty_chunks.remove(&coords);
                    }
                }
                if let Some(saved_revision) = result.saved_player_revision {
                    if dirty_player_inventory.as_ref().is_some_and(|snapshot| snapshot.revision == saved_revision) {
                        dirty_player_inventory = None;
                    }
                }
                if let Some(saved_revision) = result.saved_entity_revision {
                    if dirty_entity_items.as_ref().is_some_and(|snapshot| snapshot.revision == saved_revision) {
                        dirty_entity_items = None;
                    }
                }
                if let Some(error) = result.error.as_ref() {
                    eprintln!("[world save] ERROR: {error}");
                    last_autosave = Instant::now();
                    if result.final_flush {
                        shutdown_requested = false;
                        window.set_title("Minecraft Rust 1.8.9 — Save failed (world still open)");
                        println!("[world save] final save failed; world remains open. Fix the error and close again to retry.");
                    }
                } else {
                    last_autosave = Instant::now();
                    println!("[world save] checkpoint complete; {} dirty chunk(s), player_dirty={} remain",
                        dirty_chunks.len(), dirty_player_inventory.is_some());
                    if result.final_flush && dirty_chunks.is_empty() && dirty_player_inventory.is_none() && dirty_entity_items.is_none() {
                        println!("[world save] final flush confirmed; closing world safely.");
                        event_loop.exit();
                        return;
                    }
                }
            }

            // Periodic safety checkpoint; never rewrite Anvil regions on the mining
            // path. The save worker batches every dirty chunk in a region.
            if !shutdown_requested && !save_in_progress
                && (!dirty_chunks.is_empty() || dirty_player_inventory.is_some() || dirty_entity_items.is_some())
                && last_autosave.elapsed() >= AUTOSAVE_INTERVAL
            {
                let snapshots = dirty_chunks.values().cloned().collect::<Vec<_>>();
                let player = dirty_player_inventory.clone();
                let entities = dirty_entity_items.clone();
                match integrated_server.request_save(WorldSaveRequest { snapshots, player, entities, final_flush: false }) {
                    Ok(()) => {
                        save_in_progress = true;
                        println!("[world save] autosave checkpoint queued for {} dirty chunk(s), player_dirty={} entity_dirty={}", dirty_chunks.len(), dirty_player_inventory.is_some(), dirty_entity_items.is_some());
                    }
                    Err(error) => {
                        last_autosave = Instant::now();
                        eprintln!("[world save] could not queue autosave: {error}");
                    }
                }
            }

            // Graceful exit: drain in-memory edits first, then save every dirty chunk
            // and wait for the Anvil region files to be synced before closing.
            if shutdown_requested && pending_block_edits == 0 && !save_in_progress {
                if dirty_chunks.is_empty() && dirty_player_inventory.is_none() && dirty_entity_items.is_none() {
                    println!("[world save] no dirty chunks or player data; closing world.");
                    event_loop.exit();
                    return;
                }
                let snapshots = dirty_chunks.values().cloned().collect::<Vec<_>>();
                let player = dirty_player_inventory.clone();
                let entities = dirty_entity_items.clone();
                match integrated_server.request_save(WorldSaveRequest { snapshots, player, entities, final_flush: true }) {
                    Ok(()) => {
                        save_in_progress = true;
                        println!("[world save] final flush queued for {} dirty chunk(s), player_dirty={} entity_dirty={}; waiting for disk commit...", dirty_chunks.len(), dirty_player_inventory.is_some(), dirty_entity_items.is_some());
                    }
                    Err(error) => {
                        shutdown_requested = false;
                        window.set_title("Minecraft Rust 1.8.9 — Save queue failed (world still open)");
                        eprintln!("[world save] could not queue final flush: {error}; world remains open");
                    }
                }
            }

            // CPU mesh compilation is kept off the window/event thread. Only the
            // queue-backed GPU buffer staging is performed here, avoiding the
            // characteristic 0-FPS pause when a large chunk is mined or streamed.
            if let Ok((coords, section_y, compiled)) = mesh_compile_rx.try_recv() {
                mesh_compile_in_progress = false;
                match compiled {
                    Ok(mut mesh) => {
                        if let Some(section_y) = section_y {
                            if let Some(hidden) = immediately_hidden_blocks.get(&coords) {
                                for block in hidden {
                                    if block[1].clamp(0, 255).div_euclid(16) as u8 == section_y {
                                        mesh.hide_block(*block);
                                    }
                                }
                            }
                            match viewer.insert_chunk_section_mesh(coords, section_y, &mesh) {
                                Ok(()) => {
                                    cpu_chunk_meshes.entry(coords).or_insert_with(CpuMesh::default)
                                        .replace_section(section_y, &mesh);
                                    gameplay_mesh_section_overrides.entry(coords).or_default().insert(section_y);
                                }
                                Err(error) => eprintln!("[chunk mesh] section upload failed for ({},{}) section {}: {error}", coords.0, coords.1, section_y),
                            }
                        } else {
                            // Preserve gameplay section patches that were already
                            // committed to the CPU master. A late streamed full
                            // mesh is older than those in-memory edits and must not
                            // restore the old block faces or light in patched sections.
                            if let (Some(overrides), Some(previous)) = (
                                gameplay_mesh_section_overrides.get(&coords),
                                cpu_chunk_meshes.get(&coords),
                            ) {
                                for section_y in overrides.iter().copied() {
                                    let authoritative_section = previous.section_mesh(section_y);
                                    mesh.replace_section(section_y, &authoritative_section);
                                }
                            }
                            if let Some(hidden) = immediately_hidden_blocks.get(&coords) {
                                for block in hidden { mesh.hide_block(*block); }
                            }
                            match viewer.insert_chunk_mesh(coords, &mesh) {
                                Ok(()) => { cpu_chunk_meshes.insert(coords, mesh); }
                                Err(error) => eprintln!("[chunk mesh] upload failed for ({},{}): {error}", coords.0, coords.1),
                            }
                        }
                    }
                    Err(error) => eprintln!("[chunk mesh] compile failed for ({},{}): {error}", coords.0, coords.1),
                }
                window.request_redraw();
            }
            if !mesh_compile_in_progress {
                if let Some((coords, section_y, quads)) = gameplay_mesh_queue.pop_front() {
                    let tx = mesh_compile_tx.clone();
                    let atlas = atlas_runtime.clone();
                    match thread::Builder::new().name("mc189-mesh-compile".into()).spawn(move || {
                        let compiled = compile_textured_mesh(&quads, &atlas);
                        let _ = tx.send((coords, section_y, compiled));
                    }) {
                        Ok(_) => mesh_compile_in_progress = true,
                        Err(error) => eprintln!("[chunk mesh] could not start compiler worker: {error}"),
                    }
                }
            }
            let now = Instant::now();
            let frame_dt = now.duration_since(last_frame).as_secs_f32().min(0.1);
            last_frame = now;
            accumulator = (accumulator + frame_dt).min(0.25);
            let gameplay_focused = !shutdown_requested && mouse_captured && viewer.inventory_ui.as_ref().map_or(true, |ui| ui.screen == crate::inventory::UiScreen::Hud);
            let input = PlayerInput {
                forward: gameplay_focused && (pressed.contains(&KeyCode::KeyW) || pressed.contains(&KeyCode::ArrowUp)),
                backward: gameplay_focused && (pressed.contains(&KeyCode::KeyS) || pressed.contains(&KeyCode::ArrowDown)),
                left: gameplay_focused && (pressed.contains(&KeyCode::KeyA) || pressed.contains(&KeyCode::ArrowLeft)),
                right: gameplay_focused && (pressed.contains(&KeyCode::KeyD) || pressed.contains(&KeyCode::ArrowRight)),
                jump: false,
                jump_held: gameplay_focused && pressed.contains(&KeyCode::Space),
                sprint: gameplay_focused && (pressed.contains(&KeyCode::ShiftLeft) || pressed.contains(&KeyCode::ShiftRight)),
            };
            while accumulator >= fixed_step {
                for animation in &mut pickup_animations { animation.tick(); }
                pickup_animations.retain(|animation| !animation.is_finished());
                let inventory_animation_active = viewer.inventory_ui.as_mut()
                    .is_some_and(|ui| ui.tick_inventory_animations());
                if inventory_animation_active {
                    viewer.refresh_gui_surface();
                    window.request_redraw();
                }
                previous_player = player;
                // EntityLivingBase.onUpdate() advances the arm animation before
                // Minecraft.sendClickBlockToController() issues this tick's swing.
                viewer.tick_hand_swing();
                let mut tick_input = input;
                tick_input.jump = jump_pending;
                let jump_was_pending = jump_pending;
                server_input_sequence = server_input_sequence.wrapping_add(1).max(1);
                let _ = integrated_server.send_input(server_input_sequence, tick_input, player.yaw, player.pitch);
                // Consume the newest authoritative state. Rendering interpolates
                // between these snapshots; no physics is evaluated on the GPU thread.
                while let Ok(snapshot) = integrated_server.try_snapshot() {
                    if snapshot.tick > last_server_snapshot_tick {
                        last_server_snapshot_tick = snapshot.tick;
                        // Server snapshots own simulation state (position, velocity and
                        // collision flags), but mouse-look is client-local. A delayed
                        // snapshot must never rewind yaw/pitch and fight the mouse.
                        player = reconcile_authoritative_player(player, snapshot.player);
                        if !has_observed_entity_items_snapshot || snapshot.entities != last_observed_entity_items {
                            has_observed_entity_items_snapshot = true;
                            entity_items_revision = entity_items_revision.wrapping_add(1).max(1);
                            for entity in &snapshot.entities {
                                let cx = origin_chunk_x + (entity.position.x.floor() as i32).div_euclid(16);
                                let cz = origin_chunk_z + (entity.position.z.floor() as i32).div_euclid(16);
                                entity_persistence_chunks.insert((cx, cz));
                            }
                            // During graceful shutdown, freeze the entity save snapshot
                            // once the final flush is queued. The server may finish a few
                            // ticks while disk I/O completes; those later ticks must not
                            // keep invalidating the snapshot and prevent a clean exit.
                            if !shutdown_requested || !save_in_progress {
                                dirty_entity_items = Some(EntityItemsSnapshot {
                                    revision: entity_items_revision,
                                    entities: snapshot.entities.clone(),
                                    chunks: entity_persistence_chunks.iter().copied().collect(),
                                    origin_chunk_x,
                                    origin_chunk_z,
                                });
                            }
                            last_observed_entity_items = snapshot.entities.clone();
                        }
                        server_dropped_items = snapshot.entities.into_iter().map(|entity| {
                            let entity_id = entity.entity_id;
                            (entity_id, DroppedItem {
                                item_id: entity.item_id, metadata: entity.metadata, count: entity.count,
                                nbt_tag: entity.nbt_tag, previous_position: entity.previous_position,
                                position: entity.position, velocity: entity.velocity, age: entity.age,
                                pickup_delay: entity.pickup_delay, hover_start: entity.hover_start,
                                pending_edit_revision: None,
                            })
                        }).collect();
                        // A pickup animation/sound is driven only by a confirmed
                        // server transfer, never by client-side proximity prediction.
                        for pickup in snapshot.pickups.iter() {
                            if let Some(mut visual_item) = DroppedItem::from_server_pickup(
                                pickup.item_id, pickup.metadata, pickup.count, pickup.position,
                                pickup.age,
                            ) {
                                visual_item.pickup_delay = 0;
                                pickup_animations.push(mining::PickupAnimation::new(visual_item));
                                if crate::audio::pickup_sound_for_transfer(pickup.count) {
                                    if let Some(audio) = block_audio.as_mut() {
                                        let _ = audio.play_pickup(player.position, player.eye_position(), player.yaw);
                                    }
                                }
                            }
                        }
                        let confirmed_pickup = !snapshot.pickups.is_empty();
                        let inventory_changed = if let (Some(ui), Some(inventory)) = (viewer.inventory_ui.as_mut(), snapshot.inventory) {
                            if confirmed_pickup { ui.apply_authoritative_pickup_inventory(inventory) }
                            else { ui.apply_authoritative_inventory(inventory) }
                        } else { false };
                        if inventory_changed {
                            viewer.refresh_gui_overlay();
                            viewer.refresh_hotbar_selection();
                            viewer.refresh_held_item_if_changed();
                            window.request_redraw();
                        }
                    }
                }
                if !shutdown_requested && mouse_captured && left_mouse_held {
                    let eye = player.eye_position();
                    let direction = player.look_direction();
                    let hit = mining::raycast(eye, direction, 4.5, |pos| collision.is_solid(pos.x, pos.y, pos.z))
                        .and_then(|hit| collision.loaded_state_at(hit.pos.x, hit.pos.y, hit.pos.z)
                            .and_then(|(id, meta)| mining::block_info(id, meta).map(|info| (hit.pos, info, id, meta))));
                    let mining_hit = hit.map(|(pos, info, _, _)| (pos, info));
                    let next_sound_target = mining_hit.map(|(pos, _)| pos);
                    if next_sound_target != mining_sound_target {
                        mining_sound_target = next_sound_target;
                        mining_sound_tick_counter = 0;
                    }
                    // Minecraft.java#sendClickBlockToController calls swingItem on
                    // every held left-click tick while a valid block is targeted.
                    if mining_hit.is_some() { viewer.start_hand_swing(); }
                    let _ = integrated_server.set_mining_intent(true);
                    let mut authoritative_mining_events = Vec::new();
                    while let Ok(event) = integrated_server.try_mining_event() { authoritative_mining_events.push(event); }
                    for server_event in authoritative_mining_events {
                    match server_event.event {
                        MiningEvent::Broken(pos) => {
                            if server_event.broken_tool {
                                if let Some(audio) = block_audio.as_mut() {
                                    let _ = audio.play_item_break(player.position, player.eye_position(), player.yaw);
                                }
                            }
                            // PlayerControllerMP plays the periodic step sound on the
                            // damage tick, followed by RenderGlobal SFX 2001 on break.
                            if let Some((block_id, _)) = server_event.broken_block {
                                if mining_sound_tick_counter % 4 == 0 {
                                    if let Some(audio) = block_audio.as_mut() {
                                        let center = Vec3::new(pos.x as f32 + 0.5, pos.y as f32 + 0.5, pos.z as f32 + 0.5);
                                        audio.play_mining_hit(block_id, center, player.eye_position(), player.yaw);
                                    }
                                }
                                mining_sound_tick_counter = mining_sound_tick_counter.wrapping_add(1);
                                if let Some(audio) = block_audio.as_mut() {
                                    let center = Vec3::new(pos.x as f32 + 0.5, pos.y as f32 + 0.5, pos.z as f32 + 0.5);
                                    audio.play_break(block_id, center, player.eye_position(), player.yaw);
                                }
                            }
                            mining_sound_tick_counter = 0;
                            mining_sound_target = None;
                            viewer.update_mining_crack(None, None);
                            let broken_state = server_event.broken_block;
                            let world_x = origin_chunk_x.saturating_mul(16).saturating_add(pos.x);
                            let world_z = origin_chunk_z.saturating_mul(16).saturating_add(pos.z);
                            let chunk_x = world_x.div_euclid(16);
                            let chunk_z = world_z.div_euclid(16);
                            let local_x = world_x.rem_euclid(16) as u8;
                            let local_z = world_z.rem_euclid(16) as u8;
                            if let Some((block_id, metadata)) = broken_state {
                                // Capture the pre-edit decoded chunk once. The block-edit
                                // worker uses it to seed its cache and validate the old state;
                                // the live collision view is then mutated immediately.
                                let center_snapshot = collision.chunks.get(&(chunk_x, chunk_z)).cloned();
                                let snapshot_result = collision.set_block_local(pos.x, pos.y, pos.z, 0, 0);
                                if let Err(error) = snapshot_result {
                                    eprintln!("[mining] could not update in-memory block at {:?}: {error}", pos);
                                    let _ = integrated_server.remove_entity_items(server_event.spawned_entity_ids.clone());
                                    let _ = integrated_server.set_block(pos.x, pos.y, pos.z, block_id, metadata);
                                } else {
                                    let _ = integrated_server.set_block(pos.x, pos.y, pos.z, 0, 0);
                                    let Some(center_snapshot) = center_snapshot else {
                                        eprintln!("[mining] edited chunk had no pre-edit snapshot; restoring block");
                                        let _ = collision.set_block_local(pos.x, pos.y, pos.z, block_id, metadata);
                                        let _ = integrated_server.set_block(pos.x, pos.y, pos.z, block_id, metadata);
                                        let _ = integrated_server.remove_entity_items(server_event.spawned_entity_ids.clone());
                                        continue;
                                    };
                                    edit_revision = edit_revision.wrapping_add(1).max(1);
                                    if !server_event.spawned_entity_ids.is_empty() { pending_entity_rollbacks.insert(edit_revision, server_event.spawned_entity_ids.clone()); }
                                    let visual_block = [pos.x, pos.y, pos.z];
                                    let previous_visual_mesh = cpu_chunk_meshes.get(&(chunk_x, chunk_z)).cloned();
                                    immediately_hidden_blocks.entry((chunk_x, chunk_z)).or_default().insert(visual_block);
                                    if let Some(mesh) = cpu_chunk_meshes.get_mut(&(chunk_x, chunk_z)) {
                                        let removed_vertices = mesh.hide_block(visual_block);
                                        if removed_vertices > 0 {
                                            let section_y = (pos.y / 16) as u8;
                                            if let Err(error) = viewer.insert_chunk_section_mesh((chunk_x, chunk_z), section_y, mesh) {
                                                eprintln!("[mining visual] immediate section cull upload failed: {error}");
                                            }
                                        }
                                    }
                                    let request = GameplayBlockEditRequest {
                                        revision: edit_revision,
                                        chunk_x, chunk_z,
                                        local_x, local_y: pos.y as u8, local_z,
                                        expected_id: block_id, expected_metadata: metadata,
                                        new_id: 0, new_metadata: 0,
                                        center_snapshot,
                                        origin_chunk_x, origin_chunk_z,
                                    };
                                    // The crack animation has completed when MiningEvent::Broken
                                    // arrives. The server already spawned the EntityItems; now enqueue
                                    // the neighbor-aware chunk/light rebuild independently.
                                    window.request_redraw();
                                    println!("[mining] revision {}: server spawned {} authoritative EntityItem stack(s); queuing chunk/light refresh", edit_revision, server_event.spawned_entity_ids.len());

                                    match block_edit_worker.requests.send(request) {
                                        Ok(()) => {
                                            if let Some(previous) = previous_visual_mesh {
                                                pending_visual_rollback.insert(edit_revision, ((chunk_x, chunk_z), visual_block, previous));
                                            }
                                            pending_block_edits = pending_block_edits.saturating_add(1);
                                            *pending_edit_chunks.entry((chunk_x, chunk_z)).or_insert(0) += 1;
                                        }
                                        Err(error) => {
                                            // The worker did not accept the edit. Roll back the
                                            // server-owned EntityItem IDs and restore collision + mesh.
                                            pending_entity_rollbacks.remove(&edit_revision);
                                            let _ = integrated_server.remove_entity_items(server_event.spawned_entity_ids.clone());
                                            let _ = collision.set_block_local(pos.x, pos.y, pos.z, block_id, metadata);
                                            let _ = integrated_server.set_block(pos.x, pos.y, pos.z, block_id, metadata);
                                            if let Some(hidden) = immediately_hidden_blocks.get_mut(&(chunk_x, chunk_z)) {
                                                hidden.remove(&visual_block);
                                                if hidden.is_empty() { immediately_hidden_blocks.remove(&(chunk_x, chunk_z)); }
                                            }
                                            if let Some(mut previous) = previous_visual_mesh {
                                                if let Some(hidden) = immediately_hidden_blocks.get(&(chunk_x, chunk_z)) {
                                                    for block in hidden { previous.hide_block(*block); }
                                                }
                                                cpu_chunk_meshes.insert((chunk_x, chunk_z), previous.clone());
                                                let _ = viewer.insert_chunk_mesh((chunk_x, chunk_z), &previous);
                                            }
                                            eprintln!("[mining] block edit worker is unavailable; restored block: {error}");
                                        }
                                    }
                                }
                            } else {
                                eprintln!("[mining] lost block state for broken target {:?}; no disk edit queued", pos);
                            }
                            window.request_redraw();
                        }
                        MiningEvent::Progress { stage } => {
                            if let Some(pos) = server_event.target {
                                if let Some((block_id, _)) = collision.loaded_state_at(pos.x, pos.y, pos.z) {
                                    if mining_sound_tick_counter % 4 == 0 {
                                        if let Some(audio) = block_audio.as_mut() {
                                            let center = Vec3::new(pos.x as f32 + 0.5, pos.y as f32 + 0.5, pos.z as f32 + 0.5);
                                            audio.play_mining_hit(block_id, center, player.eye_position(), player.yaw);
                                        }
                                    }
                                    mining_sound_tick_counter = mining_sound_tick_counter.wrapping_add(1);
                                    let light = collision.light_at_local(pos.x, pos.y, pos.z);
                                    viewer.update_mining_crack(Some((pos, stage)), light);
                                }
                            }
                        }
                        MiningEvent::Cancelled => {
                            mining_sound_target = None;
                            mining_sound_tick_counter = 0;
                            viewer.update_mining_crack(None, None)
                        },
                        _ => {}
                    }
                    }
                } else {
                    let _ = integrated_server.set_mining_intent(false);
                    mining_sound_target = None;
                    mining_sound_tick_counter = 0;
                    viewer.update_mining_crack(None, None);
                }
                // World item physics, merging, pickup and despawn are exclusively
                // simulated by the integrated server. This thread only renders snapshots.
                viewer.tick_held_item_equip();
                world_day_time = world_day_time.wrapping_add(1);
                if jump_was_pending {
                    if player.velocity.y > 0.0 && !player.on_ground {
                        eprintln!("[jump diagnostic] jump started | velocity_y={:.3}", player.velocity.y);
                    } else {
                        eprintln!("[jump diagnostic] buffered | grounded={} | velocity_y={:.3}", player.on_ground, player.velocity.y);
                    }
                    jump_pending = false;
                }
                accumulator -= fixed_step;
            }
            // Vanilla updates torch flicker in EntityRenderer.updateRenderer,
            // at render-update cadence rather than at the 20 Hz world tick.
            let flicker = torch_flicker.update();
            let interpolated_day_time = world_day_time as f64 + f64::from(accumulator / fixed_step);
            let sun = vanilla_sun_brightness_at(interpolated_day_time, rain_strength, thunder_strength);
            update_vanilla_lightmap(&viewer.queue, &viewer.lightmap, sun, flicker, false);
            viewer.set_world_sky(interpolated_day_time, rain_strength, thunder_strength);
            // Interpolate only the rendered camera between the last two fixed
            // simulation states. Keep previous_player persistent across frames;
            // otherwise frames without a simulation tick collapse the interval.
            // Collision and gameplay remain deterministic at classic 20 Hz.
            let alpha = (accumulator / fixed_step).clamp(0.0, 1.0);
            render_partial_ticks = alpha;
            viewer.update_hand_swing(alpha);
            camera_player = interpolate_camera_player(previous_player, player, alpha);
            viewer.update_player_camera(camera_player);
            window.request_redraw();
        }
        _ => {}
    }).map_err(|e| Mc189Error::InvalidData(format!("gameplay event loop failed: {e}")))?;
    Ok(())
}


fn legacy_item_registry_name(id: u16) -> Option<&'static str> {
    crate::inventory::legacy_item_name_from_numeric_id(id)
}

fn control_requests_drop_all(pressed: &HashSet<KeyCode>) -> bool {
    pressed.contains(&KeyCode::ControlLeft) || pressed.contains(&KeyCode::ControlRight)
}

fn hotbar_slot_from_key(code: KeyCode) -> Option<usize> {
    Some(match code {
        KeyCode::Digit1 => 0, KeyCode::Digit2 => 1, KeyCode::Digit3 => 2,
        KeyCode::Digit4 => 3, KeyCode::Digit5 => 4, KeyCode::Digit6 => 5,
        KeyCode::Digit7 => 6, KeyCode::Digit8 => 7, KeyCode::Digit9 => 8,
        _ => return None,
    })
}

/// Convert player coordinates relative to the fixed spawn origin into absolute
/// Anvil chunk coordinates. Euclidean division is required for negative positions.
fn player_chunk_coordinates(position: Vec3, origin_chunk_x: i32, origin_chunk_z: i32) -> (i32, i32) {
    (
        origin_chunk_x + (position.x.floor() as i32).div_euclid(16),
        origin_chunk_z + (position.z.floor() as i32).div_euclid(16),
    )
}

/// Build the render-only player pose between fixed simulation ticks.
/// The authoritative player state remains untouched.
fn interpolate_camera_player(
    previous: PlayerState,
    current: PlayerState,
    alpha: f32,
) -> PlayerState {
    let mut camera = current;
    camera.position = previous
        .position
        .lerp(current.position, alpha.clamp(0.0, 1.0));
    camera
}

/// Apply server-owned movement state without allowing stale snapshots to reset
/// the locally controlled camera orientation.
fn reconcile_authoritative_player(local: PlayerState, authoritative: PlayerState) -> PlayerState {
    let mut reconciled = authoritative;
    reconciled.yaw = local.yaw;
    reconciled.pitch = local.pitch.clamp(-std::f32::consts::FRAC_PI_2, std::f32::consts::FRAC_PI_2);
    reconciled
}

fn apply_blockstate_rotation(quads: &mut [CpuMeshQuad], x_degrees: u16, y_degrees: u16) {
    let rotation = Quat::from_rotation_y((y_degrees as f32).to_radians())
        * Quat::from_rotation_x((x_degrees as f32).to_radians());
    for quad in quads {
        for point in &mut quad.positions {
            let p = Vec3::from_array(*point) - Vec3::splat(0.5);
            *point = (rotation * p + Vec3::splat(0.5)).to_array();
        }
        quad.normal = (rotation * Vec3::from_array(quad.normal)).normalize_or_zero().to_array();
    }
}

fn run_with_quads(atlas_dir: &Path, display_id: &str, resolved_path: &str, quads: Vec<CpuMeshQuad>, blockstate: Option<(String, u16, u16, usize, usize, u32, i64)>, camera_target: Vec3, camera_radius: f32) -> Result<()> {
    let atlas_runtime = AtlasRuntime::load(atlas_dir)?;
    if atlas_runtime.page_count() != 1 { return Err(Mc189Error::InvalidData("this first model preview supports a single atlas page; the current atlas has multiple pages".into())); }
    let mesh = compile_textured_mesh(&quads, &atlas_runtime)?;
    println!("Minecraft 1.8.9 textured block model preview");
    if let Some((path, x, y, selected, count, weight, seed)) = blockstate {
        println!("Blockstate: {path}");
        println!("Model: {resolved_path}");
        println!("Weighted alternative: {} of {} (weight={weight})", selected + 1, count);
        println!("Selection seed: {seed} (Java Random 48-bit algorithm)");
        println!("Applied blockstate rotation: x={x}, y={y}, uvlock=false");
    } else if resolved_path == "combined legacy chunk mesh" {
        println!("Chunk mesh: {display_id}");
    } else {
        println!("Model: {display_id} ({resolved_path})");
    }
    println!("Resolved faces: {}", quads.len());
    println!("Triangles: {}", mesh.triangles);
    println!("Atlas page: 0 ({}x{}), nearest filtering", atlas_runtime.page_size(), atlas_runtime.page_size());
    println!("Controls: left mouse drag = orbit, right mouse drag = pan, mouse wheel = zoom, R = reset, Esc = close");
    if resolved_path == "combined legacy chunk mesh" {
        println!("Scope: mapped legacy block states, weighted variants, grass/fence neighbor states and conservative opaque cullfaces; fluid geometry uses static frame-zero liquid sprites (animation scheduling and per-face translucent sorting remain pending), lighting, tile entities, uvlock and unsupported legacy visuals are excluded; biome tint is applied to model faces marked tintindex >= 0.");
    } else {
        println!("Scope: one deterministically selected weighted variant/model; uvlock, tinting, multipart composition, and world lighting are not applied yet.");
    }
    let event_loop = EventLoop::new().map_err(|e| Mc189Error::InvalidData(format!("cannot create event loop: {e}")))?;
    event_loop.set_control_flow(ControlFlow::Wait);
    let window = Arc::new(WindowBuilder::new().with_title(format!("mc189-rs — textured preview: {display_id}"))
        .with_inner_size(PhysicalSize::new(1100,850)).build(&event_loop)
        .map_err(|e| Mc189Error::InvalidData(format!("cannot create preview window: {e}")))?);
    let mut preview_meshes = HashMap::new();
    preview_meshes.insert((0, 0), mesh);
    let mut viewer = pollster::block_on(Viewer::new(window.clone(), &preview_meshes, atlas_dir, &atlas_runtime, None, camera_target, camera_radius, (0, 0)))?;
    let mut orbit_dragging=false; let mut pan_dragging=false; let mut previous: Option<(f64,f64)>=None; window.request_redraw();
    event_loop.run(move |event, event_loop| match event {
        Event::WindowEvent { window_id, event } if window_id==window.id() => match event {
            WindowEvent::CloseRequested => event_loop.exit(),
            WindowEvent::Resized(size) => { viewer.resize(size.width,size.height); window.request_redraw(); }
            WindowEvent::RedrawRequested => match viewer.render() {
                Ok(())=>{}, Err(wgpu::SurfaceError::Lost|wgpu::SurfaceError::Outdated)=>{let (w,h)=(viewer.config.width,viewer.config.height);viewer.resize(w,h);},
                Err(wgpu::SurfaceError::Timeout)=>eprintln!("GPU surface timed out; skipped one frame"),
                Err(wgpu::SurfaceError::OutOfMemory)=>{eprintln!("GPU out of memory; closing preview");event_loop.exit();}
            },
            WindowEvent::MouseInput { state, button:MouseButton::Left,.. }=>{orbit_dragging=state==ElementState::Pressed;previous=None;},
            WindowEvent::MouseInput { state, button:MouseButton::Right,.. }=>{pan_dragging=state==ElementState::Pressed;previous=None;},
            WindowEvent::CursorMoved { position,.. }=>{
                let current=(position.x,position.y);
                if let Some(old)=previous {
                    let dx=current.0-old.0; let dy=current.1-old.1;
                    if orbit_dragging { viewer.orbit(dx,dy); window.request_redraw(); }
                    else if pan_dragging { viewer.pan(dx,dy); window.request_redraw(); }
                }
                previous=Some(current);
            },
            WindowEvent::MouseWheel { delta,.. }=>{let amount=match delta {MouseScrollDelta::LineDelta(_,y)=>y,MouseScrollDelta::PixelDelta(p)=>p.y as f32/40.0};viewer.zoom_by(amount);window.request_redraw();},
            WindowEvent::KeyboardInput { event,.. } if event.state==ElementState::Pressed=>match event.physical_key {
                PhysicalKey::Code(KeyCode::Escape)=>event_loop.exit(), PhysicalKey::Code(KeyCode::KeyR)=>{viewer.reset();window.request_redraw();}, _=>{}
            }, _=>{}
        }, _=>{}
    }).map_err(|e| Mc189Error::InvalidData(format!("preview event loop failed: {e}")))?;
    Ok(())
}

const SHADER: &str = r#"
struct Camera { view_projection: mat4x4<f32>, };
@group(0) @binding(0) var<uniform> camera: Camera;
@group(1) @binding(0) var block_texture: texture_2d<f32>;
@group(1) @binding(1) var block_sampler: sampler;
@group(2) @binding(0) var vanilla_lightmap: texture_2d<f32>;
@group(2) @binding(1) var vanilla_lightmap_sampler: sampler;
struct VertexInput {
    @location(0) position:vec3<f32>, @location(1) normal:vec3<f32>,
    @location(2) uv:vec2<f32>, @location(3) tint:vec3<f32>,
    @location(4) ao:f32, @location(5) sky_light:f32,
    @location(6) block_light:f32, @location(7) face_shade:f32,
};
struct VertexOutput {
    @builtin(position) clip_position:vec4<f32>, @location(0) normal:vec3<f32>,
    @location(1) uv:vec2<f32>, @location(2) tint:vec3<f32>,
    @location(3) ao:f32, @location(4) sky_light:f32,
    @location(5) block_light:f32, @location(6) face_shade:f32,
};
@vertex fn vs_main(input:VertexInput)->VertexOutput {
    var out:VertexOutput;
    out.clip_position=camera.view_projection*vec4<f32>(input.position,1.0);
    out.normal=input.normal; out.uv=input.uv; out.tint=input.tint;
    out.ao=input.ao; out.sky_light=input.sky_light;
    out.block_light=input.block_light; out.face_shade=input.face_shade;
    return out;
}
fn vanilla_lightmap_uv(sky_level:f32, block_level:f32)->vec2<f32> {
    // The CPU lightmap is a 16x16 table indexed as (block light, sky light).
    // Vertex levels are interpolated before sampling, just as the original
    // lightmap coordinates are interpolated across a baked quad.
    return (vec2<f32>(block_level, sky_level) * 15.0 + vec2<f32>(0.5)) / 16.0;
}
@fragment fn fs_main(input:VertexOutput)->@location(0) vec4<f32> {
    let texel=textureSample(block_texture,block_sampler,input.uv);
    if(texel.a<0.1){discard;}
    let lightmap_uv=vanilla_lightmap_uv(input.sky_light,input.block_light);
    let lightmap=textureSample(vanilla_lightmap,vanilla_lightmap_sampler,lightmap_uv).rgb;
    // Vanilla multiplica lightmap*AO*shade en espacio gamma. El atlas es sRGB y la
    // superficie es sRGB (pipeline lineal), asi que el factor se pasa a lineal.
    let illumination=pow(lightmap*input.ao*input.face_shade,vec3<f32>(2.2));
    return vec4<f32>(texel.rgb*input.tint*illumination,texel.a);
}
"#;

#[cfg(test)]
mod tests {
    #[test]
    fn ctrl_q_modifier_is_detected_on_left_or_right_control() {
        use super::control_requests_drop_all;
        use std::collections::HashSet;
        use winit::keyboard::KeyCode;
        let mut pressed = HashSet::new();
        assert!(!control_requests_drop_all(&pressed));
        pressed.insert(KeyCode::ControlLeft);
        assert!(control_requests_drop_all(&pressed));
        pressed.clear();
        pressed.insert(KeyCode::ControlRight);
        assert!(control_requests_drop_all(&pressed));
    }
    use super::*;

    #[test]
    fn held_left_click_swing_wrap_keeps_the_vanilla_full_arc() {
        // MCP EntityLivingBase advances swing progress to 0.5, then
        // Minecraft.sendClickBlockToController restarts the swing. The
        // interpolator must unwrap 0.5 -> 0.0 as 0.5 -> 1.0, not snap to idle.
        assert!((vanilla_interpolated_swing_progress(0.5, 0.0, 0.0) - 0.5).abs() < 1.0e-6);
        assert!((vanilla_interpolated_swing_progress(0.5, 0.0, 0.5) - 0.75).abs() < 1.0e-6);
        assert!((vanilla_interpolated_swing_progress(0.5, 0.0, 1.0) - 1.0).abs() < 1.0e-6);
        assert!((vanilla_interpolated_swing_progress(0.0, 1.0 / 6.0, 0.5) - 1.0 / 12.0).abs() < 1.0e-6);
    }

    #[test]
    fn vanilla_glass_textures_use_the_translucent_pass() {
        assert!(is_translucent_glass_texture("assets/minecraft/textures/blocks/glass.png"));
        assert!(is_translucent_glass_texture("assets/minecraft/textures/blocks/glass_pane_top_blue.png"));
        assert!(is_translucent_glass_texture("assets/minecraft/textures/blocks/glass_white.png"));
        assert!(!is_translucent_glass_texture("assets/minecraft/textures/blocks/sea_lantern.png"));
        assert!(!is_translucent_glass_texture("assets/minecraft/textures/blocks/door_wood_lower.png"));
    }

    #[test]
    fn block_and_generated_item_camera_paths_are_separate_and_vanilla_defaults_match() {
        let default = ItemCameraTransform::default();
        let block = vanilla_first_person_block_matrix(0.0, 0.0, default);
        let generated = vanilla_first_person_item_matrix(0.0, 0.0, default, false);
        let block_values = block.to_cols_array();
        let generated_values = generated.to_cols_array();
        for value in block_values.iter().chain(generated_values.iter()) {
            assert!(value.is_finite());
        }
        assert!(block_values.iter().zip(generated_values.iter())
            .any(|(a, b)| (a - b).abs() > 1.0e-3),
            "block models must include RenderItem's centered-model translation while generated item geometry is already centered");
        let centered_origin = block.transform_point3(Vec3::splat(0.5));
        let generated_origin = generated.transform_point3(Vec3::ZERO);
        assert!(centered_origin.distance(generated_origin) < 1.0e-5,
            "a block model's center must map to the same hand anchor as the already-centered generated-item origin");
        let block_display = ItemCameraTransform {
            rotation: [0.0, 90.0, 0.0], translation: [0.0, 0.25, 0.0], scale: [1.0; 3],
        };
        let changed_block = vanilla_first_person_block_matrix(0.0, 0.0, block_display);
        let unchanged_item = vanilla_first_person_item_matrix(0.0, 0.0, default, false);
        assert!(changed_block.transform_point3(Vec3::X).distance(unchanged_item.transform_point3(Vec3::X)) > 0.1,
            "block-specific display transforms must not mutate the item matrix");
    }

    #[test]
    fn vanilla_first_person_item_matrix_uses_vanilla_scale_and_equip_pose() {
        let transform = ItemCameraTransform::default();
        let block = vanilla_first_person_item_matrix(0.0, 0.0, transform, true);
        let sprite = vanilla_first_person_item_matrix(0.0, 0.0, transform, false);
        assert_eq!(block.to_cols_array().iter().all(|v| v.is_finite()), true);
        assert_eq!(sprite.to_cols_array().iter().all(|v| v.is_finite()), true);
        let block_origin = block.transform_point3(Vec3::ZERO);
        let sprite_origin = sprite.transform_point3(Vec3::ZERO);
        assert!(block_origin.distance(sprite_origin) < 1.0e-6,
            "with zero display translation, both model classes share the same hand anchor");
        let block_x = block.transform_point3(Vec3::X);
        let sprite_x = sprite.transform_point3(Vec3::X);
        assert!(block_x.distance(block_origin) > 0.1);
        assert!((block_x.distance(block_origin) - sprite_x.distance(sprite_origin)).abs() < 1.0e-5,
            "MCP 1.8.9 uses scale(2) on either the GUI-3D or generated-item path, then scale(0.5) for both");
        assert!((sprite_x.distance(sprite_origin) - 0.4).abs() < 1.0e-5,
            "generated sprites must include transformFirstPersonItem scale(0.4), RenderItem preTransform scale(2), and renderItem scale(0.5)");
        let lowered = vanilla_first_person_item_matrix(0.0, 1.0, transform, true)
            .transform_point3(Vec3::ZERO);
        assert!((lowered - block_origin).length() > 0.1,
            "the lowered transform must add vanilla translate(0, -0.6, 0) before rotation");
    }

    #[test]
    fn dropped_item_ground_scale_matches_vanilla_flat_and_block_model_paths() {
        let default = ItemCameraTransform::default();
        let ground = item_ground_transform_matrix(default);
        let flat = ground * Mat4::from_scale(Vec3::splat(0.5));
        let block = Mat4::from_scale(Vec3::splat(0.5))
            * ground
            * Mat4::from_scale(Vec3::splat(0.5))
            * Mat4::from_translation(Vec3::splat(-0.5));
        let flat_width = flat.transform_vector3(Vec3::X).length();
        let block_width = block.transform_vector3(Vec3::X).length();
        assert!((flat_width - 0.5).abs() < 1.0e-6, "RenderEntityItem flat models retain RenderItem's inner 0.5 scale");
        assert!((block_width - 0.25).abs() < 1.0e-6, "GUI-3D block models receive both 0.5 scales");
    }

    #[test]
    fn ground_display_transform_changes_dropped_flat_item_orientation_and_size() {
        let transform = ItemCameraTransform {
            rotation: [0.0, 90.0, 0.0],
            translation: [0.0, 0.125, 0.0],
            scale: [0.5, 0.75, 0.5],
        };
        let matrix = item_ground_transform_matrix(transform);
        let transformed = matrix.transform_vector3(Vec3::X);
        assert!(transformed.z.abs() > 0.49);
        assert!((transformed.length() - 0.5).abs() < 1.0e-6);
    }

    #[test]
    fn generated_item_drop_back_face_matches_vanilla_north_face_without_mirroring_sprite() {
        let mut icon = image::RgbaImage::new(16, 16);
        // Asymmetric silhouette: a one-sided head/handle makes accidental U
        // reflection observable in the baked UV corner mapping.
        icon.put_pixel(3, 4, image::Rgba([255, 255, 255, 255]));
        icon.put_pixel(4, 4, image::Rgba([255, 255, 255, 255]));
        icon.put_pixel(3, 5, image::Rgba([255, 255, 255, 255]));

        let hand = build_generated_item_layer_vertices(&icon);
        let dropped = build_generated_item_drop_vertices(&icon);
        assert_eq!(hand.len(), 54, "first-person hand keeps its original front cutout plus eight exposed silhouette edges");
        assert_eq!(dropped.len(), 60, "world drop adds one six-vertex NORTH/back plane");
        let back = &dropped[dropped.len() - 6..];
        assert!(back.iter().all(|vertex| vertex.normal == [0.0, 0.0, -1.0]
            && (vertex.position[2] + 0.03125).abs() < 1.0e-6));
        assert!(back.iter().all(|vertex| vertex.position[0].abs() <= 0.5 + 1.0e-6
            && vertex.position[1].abs() <= 0.5 + 1.0e-6),
            "the NORTH plane must share the centered XY bounds of the SOUTH plane");
        assert!((back.iter().map(|vertex| vertex.position[0]).sum::<f32>() / back.len() as f32).abs() < 1.0e-6);
        assert!((back.iter().map(|vertex| vertex.position[1]).sum::<f32>() / back.len() as f32).abs() < 1.0e-6);
        let front_uv = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]];
        let back_uv = [back[0].uv, back[1].uv, back[2].uv, back[5].uv];
        assert_eq!(back_uv, front_uv,
            "NORTH's reversed source UV rectangle must be reordered with NORTH's reversed FaceBakery vertex order; the rendered sprite itself must not be mirrored");
        assert!(dropped.iter().any(|vertex| (vertex.face_shade - 0.6).abs() < 1.0e-6));
        assert!(dropped.iter().any(|vertex| (vertex.face_shade - 0.5).abs() < 1.0e-6));
    }

    #[test]
    fn flat_dropped_item_mesh_uses_render_entity_item_half_scale() {
        let base = vec![Vertex {
            position: [1.0, 0.0, 0.0], normal: [0.0, 0.0, 1.0], uv: [0.0; 2], tint: [1.0; 3],
            ao: 1.0, sky_light: 1.0, block_light: 0.0, face_shade: 1.0,
        }];
        let item = DroppedItem {
            item_id: 264, metadata: 0, count: 1, nbt_tag: None,
            previous_position: Vec3::ZERO, position: Vec3::ZERO, velocity: Vec3::ZERO, age: 0,
            pickup_delay: 0, hover_start: 0.0, pending_edit_revision: None,
        };
        let mut rendered = Vec::new();
        append_dropped_item_vertices(&mut rendered, &base, &item, 15, 0, false, ItemCameraTransform::default(), 0.0);
        assert_eq!(rendered.len(), 1);
        assert!((rendered[0].position[0] - 0.5).abs() < 1.0e-6,
            "RenderEntityItem calls the baked-model overload, which keeps the inner scale(0.5) without preTransform(2)");
    }

    #[test]
    fn flat_dropped_item_stack_copies_are_centered_like_mcp_render_entity_item() {
        let base = vec![Vertex {
            position: [0.0; 3], normal: [0.0, 0.0, 1.0], uv: [0.0; 2], tint: [1.0; 3],
            ao: 1.0, sky_light: 1.0, block_light: 0.0, face_shade: 1.0,
        }];
        let item = DroppedItem {
            item_id: 264, metadata: 0, count: 2, nbt_tag: None,
            previous_position: Vec3::ZERO, position: Vec3::ZERO, velocity: Vec3::ZERO, age: 0,
            pickup_delay: 0, hover_start: 0.0, pending_edit_revision: None,
        };
        let mut rendered = Vec::new();
        append_dropped_item_vertices(&mut rendered, &base, &item, 15, 0, false, ItemCameraTransform::default(), 0.0);
        assert_eq!(rendered.len(), 2);
        assert!((rendered[0].position[2] + 0.0234375).abs() < 1.0e-6);
        assert!((rendered[1].position[2] - 0.0234375).abs() < 1.0e-6);
        assert!((rendered.iter().map(|vertex| vertex.position[2]).sum::<f32>() / 2.0).abs() < 1.0e-6,
            "stack copies should stay centred around the entity origin instead of drifting to one side");
    }

    #[test]
    fn generated_item_layer_uses_one_cutout_surface_and_extrudes_nontransparent_edges() {
        let mut icon = image::RgbaImage::new(16, 16);
        icon.put_pixel(7, 8, image::Rgba([255, 255, 255, 255]));
        let vertices = build_generated_item_layer_vertices(&icon);
        assert_eq!(vertices.len(), 30, "one opaque pixel should have one front surface and four side quads; no duplicate back sprite plane");
        assert!(vertices.iter().all(|v| v.position.iter().all(|p| p.is_finite())));
        assert!(vertices.iter().all(|v| v.position[0].abs() <= 0.5 + 1.0e-6));
        assert!(vertices.iter().all(|v| v.position[1].abs() <= 0.5 + 1.0e-6));
        assert!(vertices.iter().all(|v| v.position[2].abs() <= (0.5 / 16.0) + 1.0e-6),
            "generated item layer geometry must be centered on the model origin like ItemLayerModel");
    }

    #[test]
    fn java_random48_matches_java_util_random_seed_one_sequence() {
        let mut random = JavaRandom48::new(1);
        let expected = [0.7308781907032909_f64, 0.41008081149220166_f64, 0.20771484130971707_f64];
        for value in expected { assert!((random.next_double() - value).abs() < f64::EPSILON); }
    }

    #[test]
    fn vanilla_torch_flicker_is_stateful_and_seed_reproducible() {
        let mut a = VanillaTorchFlicker::new(0x189);
        let mut b = VanillaTorchFlicker::new(0x189);
        for _ in 0..100 { assert_eq!(a.update().to_bits(), b.update().to_bits()); }
        assert_ne!(a.x.to_bits(), 0);
    }

    #[test]
    fn vanilla_lightmap_texture_is_16x16_rgba_with_separate_sky_and_torch_axes() {
        let pixels = vanilla_lightmap_pixels();
        assert_eq!(pixels.len(), 16 * 16 * 4);
        let texel = |sky: usize, block: usize| {
            let offset = (sky * 16 + block) * 4;
            [pixels[offset], pixels[offset + 1], pixels[offset + 2], pixels[offset + 3]]
        };
        let clear_sky = texel(15, 0);
        assert_eq!(clear_sky[3], 255);
        assert!(clear_sky[0] >= 249 && clear_sky[1] >= 249 && clear_sky[2] >= 249);
        let warm_torch = texel(0, 8);
        assert_eq!(warm_torch[3], 255);
        assert!(warm_torch[0] > warm_torch[2], "torch light should stay warm: {warm_torch:?}");
        assert_ne!(texel(15, 0), texel(0, 15), "sky and block light use independent texture axes");
    }

    #[test]
    fn crosshair_uses_the_exact_vanilla_189_16x16_sprite_pixel_mask() {
        let vertices = build_crosshair_vertices(1280, 800);
        assert_eq!(vertices.len(), 17 * 6);
        assert_eq!(VANILLA_189_CROSSHAIR_PIXELS.len(), 17);
        // Vanilla positions the 16x16 draw call using ceil-scaled GUI
        // dimensions; at non-divisible resolutions its centre may be half a
        // physical pixel away from the framebuffer's mathematical midpoint.
        assert!(vertices.iter().any(|v| v.position[0].abs() < 0.002 && v.position[1].abs() < 0.002));
        assert!(vertices.iter().all(|v| v.position.iter().all(|c| c.is_finite())));
    }

    #[test]
    fn vanilla_gui_scale_matches_scaled_resolution_auto_at_common_sizes() {
        assert_eq!(vanilla_gui_scale_factor(1280, 800), 3);
        assert_eq!(vanilla_gui_scale_factor(1920, 1080), 4);
        assert_eq!(vanilla_gui_scale_factor(800, 600), 2);
        assert_eq!(vanilla_gui_scale_factor(320, 240), 1);
        // The GUI texture is kept at ScaledResolution size; it is nearest-upscaled on the GPU.
        assert_eq!((1280_u32.div_ceil(vanilla_gui_scale_factor(1280, 800)), 800_u32.div_ceil(vanilla_gui_scale_factor(1280, 800))), (427, 267));
    }

    #[test]
    fn crosshair_uses_scaled_gui_pixels_instead_of_physical_pixels() {
        let vertices = build_crosshair_vertices(1280, 800);
        let scale = vanilla_gui_scale_factor(1280, 800) as f32;
        let xs: Vec<f32> = vertices.iter().map(|v| v.position[0]).collect();
        let ys: Vec<f32> = vertices.iter().map(|v| v.position[1]).collect();
        let width = (xs.iter().copied().fold(f32::NEG_INFINITY, f32::max)
            - xs.iter().copied().fold(f32::INFINITY, f32::min)) * 640.0;
        let height = (ys.iter().copied().fold(f32::NEG_INFINITY, f32::max)
            - ys.iter().copied().fold(f32::INFINITY, f32::min)) * 400.0;
        assert!((width - 9.0 * scale).abs() < 1.0e-4);
        assert!((height - 9.0 * scale).abs() < 1.0e-4);
    }

    #[test]
    fn classic_steve_arm_mesh_uses_six_faces_and_legacy_skin_uvs() {
        for height in [32.0, 64.0] {
            let vertices = build_steve_arm_vertices(height, 0.0, 0.0);
            assert_eq!(vertices.len(), if height >= 64.0 { 72 } else { 36 });
            assert!(vertices.iter().all(|vertex| {
                vertex.uv.iter().all(|value| value.is_finite() && (0.0..=1.0).contains(value))
            }));
            assert!(vertices.iter().all(|vertex| vertex.tint == [1.0, 1.0, 1.0]));
            let max_v = vertices.iter().map(|vertex| vertex.uv[1]).fold(0.0_f32, f32::max);
            let expected_max_v = if height >= 64.0 { 48.0 / height } else { 32.0 / height };
            assert!((max_v - expected_max_v).abs() < 0.0001);
            let base = &vertices[..36];
            if height >= 64.0 {
                let sleeve = &vertices[36..72];
                let sleeve_min_v = sleeve.iter().map(|vertex| vertex.uv[1]).fold(f32::INFINITY, f32::min);
                let sleeve_max_v = sleeve.iter().map(|vertex| vertex.uv[1]).fold(f32::NEG_INFINITY, f32::max);
                assert!((sleeve_min_v - 32.0 / 64.0).abs() < 0.0001);
                assert!((sleeve_max_v - 48.0 / 64.0).abs() < 0.0001);
            }
            let min_x = base.iter().map(|vertex| vertex.position[0]).fold(f32::INFINITY, f32::min);
            let max_x = base.iter().map(|vertex| vertex.position[0]).fold(f32::NEG_INFINITY, f32::max);
            let min_y = base.iter().map(|vertex| vertex.position[1]).fold(f32::INFINITY, f32::min);
            let max_y = base.iter().map(|vertex| vertex.position[1]).fold(f32::NEG_INFINITY, f32::max);
            let min_z = base.iter().map(|vertex| vertex.position[2]).fold(f32::INFINITY, f32::min);
            let max_z = base.iter().map(|vertex| vertex.position[2]).fold(f32::NEG_INFINITY, f32::max);
            // Bounds fingerprint the vanilla matrix plus ModelBiped's idle Z roll.
            assert!((min_x - 0.3286).abs() < 0.002 && (max_x - 0.9053).abs() < 0.002);
            assert!((min_y + 0.9903).abs() < 0.002 && (max_y + 0.2912).abs() < 0.002);
            assert!((min_z + 1.1855).abs() < 0.002 && (max_z + 0.4378).abs() < 0.002);
        }
    }

    #[test]
    fn vanilla_swing_progress_interpolates_sixth_steps_and_wraps_to_one() {
        assert!((vanilla_interpolated_swing_progress(0.0, 1.0 / 6.0, 0.5) - 1.0 / 12.0).abs() < 1.0e-6);
        assert!((vanilla_interpolated_swing_progress(5.0 / 6.0, 0.0, 0.5) - 11.0 / 12.0).abs() < 1.0e-6);
        assert!((vanilla_interpolated_swing_progress(5.0 / 6.0, 0.0, 1.0) - 1.0).abs() < 1.0e-6);
        assert_eq!(vanilla_interpolated_swing_progress(0.0, 0.0, 0.5), 0.0);
    }

    #[test]
    fn first_person_arm_swing_matches_vanilla_curve_and_returns_to_idle() {
        for height in [32.0, 64.0] {
            let idle = build_steve_arm_vertices(height, 0.0, 0.0);
            let mid = build_steve_arm_vertices(height, 0.5, 0.0);
            let end = build_steve_arm_vertices(height, 1.0, 0.0);
            assert_eq!(idle.len(), mid.len());
            assert_eq!(idle.len(), end.len());
            assert!(mid.iter().all(|v| v.position.iter().all(|c| c.is_finite())));
            let displacement_at_mid = idle.iter().zip(&mid)
                .map(|(a, b)| (Vec3::from_array(a.position) - Vec3::from_array(b.position)).length())
                .fold(0.0_f32, f32::max);
            let displacement_at_end = idle.iter().zip(&end)
                .map(|(a, b)| (Vec3::from_array(a.position) - Vec3::from_array(b.position)).length())
                .fold(0.0_f32, f32::max);
            assert!(displacement_at_mid > 0.05, "swing midpoint must move the arm visibly");
            assert!(displacement_at_end < 1.0e-4, "vanilla swing at progress 1 must return to idle");
        }
    }

    #[test]
    fn streamed_chunk_coordinates_use_euclidean_division_for_negative_positions() {
        let origin = (10, -4);
        assert_eq!(player_chunk_coordinates(Vec3::new(0.0, 0.0, 0.0), origin.0, origin.1), origin);
        assert_eq!(player_chunk_coordinates(Vec3::new(-0.1, 0.0, -16.0), origin.0, origin.1), (9, -5));
        assert_eq!(player_chunk_coordinates(Vec3::new(16.0, 0.0, 15.999), origin.0, origin.1), (11, -4));
    }

    #[test]
    fn authoritative_snapshot_does_not_rewind_local_camera_rotation() {
        let mut local = PlayerState::at(Vec3::new(1.0, 2.0, 3.0));
        local.yaw = 1.75;
        local.pitch = -0.65;
        let mut server = PlayerState::at(Vec3::new(9.0, 8.0, 7.0));
        server.yaw = -2.5;
        server.pitch = 0.9;
        server.velocity = Vec3::new(0.1, 0.2, 0.3);
        server.on_ground = true;

        let reconciled = reconcile_authoritative_player(local, server);
        assert_eq!(reconciled.position, server.position);
        assert_eq!(reconciled.velocity, server.velocity);
        assert_eq!(reconciled.on_ground, server.on_ground);
        assert_eq!(reconciled.yaw, local.yaw);
        assert_eq!(reconciled.pitch, local.pitch);
    }

    #[test]
    fn authoritative_snapshot_clamps_local_camera_pitch() {
        let mut local = PlayerState::at(Vec3::ZERO);
        local.pitch = 5.0;
        let reconciled = reconcile_authoritative_player(local, PlayerState::at(Vec3::ONE));
        assert!((reconciled.pitch - std::f32::consts::FRAC_PI_2).abs() < 1.0e-6);
    }

    #[test]
    fn camera_interpolation_changes_only_rendered_position() {
        let mut previous = PlayerState::at(Vec3::new(0.0, 10.0, 0.0));
        previous.yaw = 0.25;
        let mut current = PlayerState::at(Vec3::new(2.0, 12.0, 4.0));
        current.yaw = 1.25;
        current.pitch = -0.5;
        current.velocity = Vec3::new(3.0, 4.0, 5.0);

        let camera = interpolate_camera_player(previous, current, 0.5);

        assert_eq!(camera.position, Vec3::new(1.0, 11.0, 2.0));
        assert_eq!(camera.yaw, current.yaw);
        assert_eq!(camera.pitch, current.pitch);
        assert_eq!(camera.velocity, current.velocity);
        assert_eq!(current.position, Vec3::new(2.0, 12.0, 4.0));
    }

    #[test]
    fn camera_interpolation_clamps_alpha() {
        let previous = PlayerState::at(Vec3::ZERO);
        let current = PlayerState::at(Vec3::new(2.0, 0.0, 0.0));
        assert_eq!(interpolate_camera_player(previous, current, -1.0).position, Vec3::ZERO);
        assert_eq!(interpolate_camera_player(previous, current, 2.0).position, current.position);
    }

    #[test]
    fn vanilla_cutout_plants_cobwebs_and_all_rail_variants_use_the_cutout_path() {
        for path in [
            "assets/minecraft/textures/blocks/tallgrass.png",
            "assets/minecraft/textures/blocks/fern.png",
            "assets/minecraft/textures/blocks/double_plant_grass_bottom.png",
            "assets/minecraft/textures/blocks/double_plant_grass_top.png",
            "assets/minecraft/textures/blocks/double_plant_fern_bottom.png",
            "assets/minecraft/textures/blocks/double_plant_fern_top.png",
            "assets/minecraft/textures/blocks/flower_allium.png",
            "assets/minecraft/textures/blocks/flower_blue_orchid.png",
            "assets/minecraft/textures/blocks/flower_dandelion.png",
            "assets/minecraft/textures/blocks/flower_houstonia.png",
            "assets/minecraft/textures/blocks/flower_oxeye_daisy.png",
            "assets/minecraft/textures/blocks/flower_rose.png",
            "assets/minecraft/textures/blocks/flower_tulip_orange.png",
            "assets/minecraft/textures/blocks/flower_tulip_pink.png",
            "assets/minecraft/textures/blocks/flower_tulip_red.png",
            "assets/minecraft/textures/blocks/flower_tulip_white.png",
            "assets/minecraft/textures/blocks/double_plant_paeonia_top.png",
            "assets/minecraft/textures/blocks/double_plant_rose_top.png",
            "assets/minecraft/textures/blocks/double_plant_syringa_top.png",
            "assets/minecraft/textures/blocks/double_plant_sunflower_back.png",
            "assets/minecraft/textures/blocks/double_plant_sunflower_front.png",
            "assets/minecraft/textures/blocks/mushroom_brown.png",
            "assets/minecraft/textures/blocks/mushroom_red.png",
            "assets/minecraft/textures/blocks/sapling_oak.png",
            "assets/minecraft/textures/blocks/leaves_acacia.png",
            "assets/minecraft/textures/blocks/leaves_big_oak.png",
            "assets/minecraft/textures/blocks/leaves_birch.png",
            "assets/minecraft/textures/blocks/leaves_jungle.png",
            "assets/minecraft/textures/blocks/leaves_oak.png",
            "assets/minecraft/textures/blocks/leaves_spruce.png",
            "assets/minecraft/textures/blocks/reeds.png",
            "assets/minecraft/textures/blocks/web.png",
            "assets/minecraft/textures/blocks/rail_activator.png",
            "assets/minecraft/textures/blocks/rail_activator_powered.png",
            "assets/minecraft/textures/blocks/rail_detector.png",
            "assets/minecraft/textures/blocks/rail_detector_powered.png",
            "assets/minecraft/textures/blocks/rail_golden.png",
            "assets/minecraft/textures/blocks/rail_golden_powered.png",
            "assets/minecraft/textures/blocks/rail_normal.png",
            "assets/minecraft/textures/blocks/rail_normal_turned.png",
        ] {
            assert!(is_cutout_vegetation_texture(path), "{path}");
        }
        assert!(!is_cutout_vegetation_texture("assets/minecraft/textures/blocks/grass_side.png"));
        assert!(!is_cutout_vegetation_texture("assets/minecraft/textures/blocks/stone.png"));
    }

    #[test]
    fn face_uv_rotation_keeps_the_same_rectangle_and_cycles_corners() {
        let base = face_uv_corners(ModelFaceDirection::North, [0.1, 0.2, 0.3, 0.4], 0);
        let rotated = face_uv_corners(ModelFaceDirection::North, [0.1, 0.2, 0.3, 0.4], 90);
        assert_eq!(base, [[0.1, 0.4], [0.3, 0.4], [0.3, 0.2], [0.1, 0.2]]);
        assert_eq!(rotated, [base[3], base[0], base[1], base[2]]);
    }

    #[test]
    fn blockstate_rotation_keeps_block_center_fixed() {
        let mut quads = vec![CpuMeshQuad {
            source_block: None,
            positions: [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [1.0, 1.0, 0.0], [0.0, 1.0, 0.0]],
            uv_rect: [0.0, 0.0, 16.0, 16.0], uv_rotation: 0, uv_corners: None, texture_path: "assets/minecraft/textures/block/stone.png".into(),
            face: ModelFaceDirection::North, cull_face: None, tint_index: -1, tint_color: [1.0, 1.0, 1.0], shade: true, ambient_occlusion: true, normal: [0.0, 0.0, -1.0], vertex_ao: [1.0; 4], vertex_sky_light: [1.0; 4], vertex_block_light: [1.0; 4], vertex_face_shade: [1.0; 4],
        }];
        apply_blockstate_rotation(&mut quads, 0, 90);
        assert!(quads[0].positions[0][0].abs() < 1e-5);
        assert!((quads[0].positions[0][2] - 1.0).abs() < 1e-5);
        assert!((quads[0].normal[0] + 1.0).abs() < 1e-5);
        assert!((quads[0].normal[2]).abs() < 1e-5);
    }

    #[test]
    fn horizontal_face_uvs_use_top_left_texture_origin() {
        let uv = face_uv_corners(ModelFaceDirection::Up, [0.0, 0.0, 1.0, 1.0], 0);
        assert_eq!(uv, [[0.0, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, 0.0]]);
    }

    #[test]
    fn block_breaking_overlay_builds_six_offset_faces_with_requested_stage_uvs() {
        let vertices = build_mining_crack_vertices(BlockPos { x: 3, y: 64, z: -2 }, 4, 11, 6);
        assert_eq!(vertices.len(), 36);
        let min_u = vertices.iter().map(|v| v.uv[0]).fold(f32::INFINITY, f32::min);
        let max_u = vertices.iter().map(|v| v.uv[0]).fold(f32::NEG_INFINITY, f32::max);
        assert!(min_u > 0.40 && min_u < 0.41, "stage 4 starts at its own sprite column: {min_u}");
        assert!(max_u > 0.49 && max_u < 0.50, "stage 4 ends before stage 5: {max_u}");
        assert!(vertices.iter().all(|v| v.position.iter().all(|p| p.is_finite())));
        assert!(vertices.iter().any(|v| v.position[1] > 65.0));
        assert!(vertices.iter().all(|v| (v.sky_light - 11.0 / 15.0).abs() < 1e-6));
        assert!(vertices.iter().all(|v| (v.block_light - 6.0 / 15.0).abs() < 1e-6));
    }

    #[test]
    fn all_ten_vanilla_breaking_stages_select_distinct_strip_frames() {
        let mut previous_start = -1.0_f32;
        for stage in 0..10_u8 {
            let vertices = build_mining_crack_vertices(BlockPos { x: 0, y: 0, z: 0 }, stage, 15, 0);
            let min_u = vertices.iter().map(|v| v.uv[0]).fold(f32::INFINITY, f32::min);
            let expected = (f32::from(stage) * 16.0 + 0.5) / 160.0;
            assert!((min_u - expected).abs() < 1e-6);
            assert!(min_u > previous_start, "each destroy_stage frame must have a distinct UV interval");
            previous_start = min_u;
        }
    }

    #[test]
    fn dropped_item_stack_copy_counts_match_mcp_render_entity_item_thresholds() {
        let base = build_mining_crack_vertices(BlockPos { x: 0, y: 0, z: 0 }, 0, 15, 0);
        for (count, copies) in [(1, 1), (2, 2), (16, 2), (17, 3), (32, 3), (33, 4), (48, 4), (49, 5)] {
            let item = DroppedItem {
                item_id: 264, metadata: 0, count, nbt_tag: None,
                previous_position: Vec3::ZERO, position: Vec3::ZERO, velocity: Vec3::ZERO, age: 0,
                pickup_delay: 0, hover_start: 0.25, pending_edit_revision: None,
            };
            let mut rendered = Vec::new();
            append_dropped_item_vertices(&mut rendered, &base, &item, 15, 0, true, ItemCameraTransform::default(), 0.0);
            assert_eq!(rendered.len(), base.len() * copies, "stack count {count}");
        }
    }

    #[test]
    fn generated_drops_cover_item_ids_used_by_drop_registry() {
        for id in [3, 4, 6, 12, 13, 14, 15, 17, 18, 22, 24, 25, 31, 32, 35,
            37, 38, 39, 40, 46, 47, 48, 49, 50, 66, 79, 86, 98, 106, 111,
            121, 155, 161, 162, 165, 175, 179, 180, 181, 182, 260, 263, 264,
            287, 295, 296, 318, 324, 331, 332, 337, 338, 348, 351, 355, 360, 372,
            388, 391, 392, 394, 397, 404, 406, 425] {
            assert!(legacy_item_registry_name(id).is_some(), "missing legacy item mapping for {id}");
        }
    }

    #[test]
    fn dropped_item_model_transform_keeps_world_light_levels() {
        let item = DroppedItem {
            item_id: 264, metadata: 0, count: 1, nbt_tag: None,
            previous_position: Vec3::new(2.0, 3.0, 4.0), position: Vec3::new(2.0, 3.0, 4.0), velocity: Vec3::ZERO, age: 0, pickup_delay: 0, hover_start: 0.0, pending_edit_revision: None,
        };
        let base = build_mining_crack_vertices(BlockPos { x: 0, y: 0, z: 0 }, 0, 15, 0);
        let mut out = Vec::new();
        append_dropped_item_vertices(&mut out, &base, &item, 7, 3, true, ItemCameraTransform::default(), 0.0);
        assert_eq!(out.len(), base.len());
        assert!(out.iter().all(|v| (v.sky_light - 7.0 / 15.0).abs() < 1e-6));
        assert!(out.iter().all(|v| (v.block_light - 3.0 / 15.0).abs() < 1e-6));
    }
    #[test]
    fn cpu_mesh_section_replacement_preserves_other_sections_and_all_layers() {
        let vertex = Vertex {
            position: [0.0; 3], normal: [0.0, 1.0, 0.0], uv: [0.0; 2], tint: [1.0; 3],
            ao: 1.0, sky_light: 1.0, block_light: 0.0, face_shade: 1.0,
        };
        let low = [2, 8, 3];
        let high = [2, 24, 3];
        let mut master = CpuMesh {
            vertices: vec![vertex; 12], cutout_vertices: vec![vertex; 12],
            translucent_vertices: vec![vertex; 12], fluid_vertices: vec![vertex; 12],
            vertex_owners: vec![low; 6].into_iter().chain(vec![high; 6]).collect(),
            cutout_owners: vec![low; 6].into_iter().chain(vec![high; 6]).collect(),
            translucent_owners: vec![low; 6].into_iter().chain(vec![high; 6]).collect(),
            fluid_owners: vec![low; 6].into_iter().chain(vec![high; 6]).collect(),
            triangles: 16,
        };
        let replacement = CpuMesh {
            vertices: vec![vertex; 3], cutout_vertices: vec![vertex; 3],
            translucent_vertices: vec![vertex; 3], fluid_vertices: vec![vertex; 3],
            vertex_owners: vec![[4, 9, 4]; 3], cutout_owners: vec![[4, 9, 4]; 3],
            translucent_owners: vec![[4, 9, 4]; 3], fluid_owners: vec![[4, 9, 4]; 3],
            triangles: 4,
        };
        master.replace_section(0, &replacement);
        assert_eq!(master.section_mesh(0).total_vertices(), 12);
        assert_eq!(master.section_mesh(1).total_vertices(), 24);
        assert!(master.section_mesh(0).vertex_owners.iter().all(|owner| *owner == [4, 9, 4]));
        assert!(master.section_mesh(1).vertex_owners.iter().all(|owner| *owner == high));
        assert_eq!(master.triangles, 12);

        // An empty replacement must clear only its own section, not its neighbors.
        master.replace_section(0, &CpuMesh::default());
        assert_eq!(master.section_mesh(0).total_vertices(), 0);
        assert_eq!(master.section_mesh(1).total_vertices(), 24);
    }

    #[test]
    fn immediate_block_cull_removes_only_that_block_from_all_render_layers() {
        let vertex = Vertex {
            position: [0.0; 3], normal: [0.0, 1.0, 0.0], uv: [0.0; 2], tint: [1.0; 3],
            ao: 1.0, sky_light: 1.0, block_light: 0.0, face_shade: 1.0,
        };
        let target = [4, 65, 7];
        let other = [5, 65, 7];
        let split_owners = || -> Vec<[i32; 3]> { vec![target; 3].into_iter().chain([other; 3]).collect() };
        let mut mesh = CpuMesh {
            vertices: vec![vertex; 6], cutout_vertices: vec![vertex; 6],
            translucent_vertices: vec![vertex; 6], fluid_vertices: vec![vertex; 6],
            vertex_owners: split_owners(), cutout_owners: split_owners(),
            translucent_owners: split_owners(), fluid_owners: split_owners(), triangles: 8,
        };
        let removed = mesh.hide_block(target);
        assert_eq!(removed, 12, "the target's six vertices must be removed from each of four render layers");
        assert_eq!(mesh.vertices.len(), 3, "neighbor opaque geometry must remain visible");
        assert_eq!(mesh.cutout_vertices.len(), 3, "neighbor cutout geometry must remain visible");
        assert_eq!(mesh.translucent_vertices.len(), 3, "neighbor translucent geometry must remain visible");
        assert_eq!(mesh.fluid_vertices.len(), 3, "neighbor fluid geometry must remain visible");
        assert!(mesh.vertex_owners.iter().all(|owner| *owner == other));
        assert!(mesh.cutout_owners.iter().all(|owner| *owner == other));
        assert!(mesh.translucent_owners.iter().all(|owner| *owner == other));
        assert!(mesh.fluid_owners.iter().all(|owner| *owner == other));
        assert_eq!(mesh.triangles, 4);
    }

    #[test]
    fn dropped_item_render_interpolates_between_fixed_tick_positions() {
        let item = DroppedItem {
            item_id: 264, metadata: 0, count: 1, nbt_tag: None,
            previous_position: Vec3::ZERO, position: Vec3::new(2.0, 0.0, 0.0),
            velocity: Vec3::ZERO, age: 10, pickup_delay: 0, hover_start: 0.0,
            pending_edit_revision: None,
        };
        let base = build_mining_crack_vertices(BlockPos { x: 0, y: 0, z: 0 }, 0, 15, 0);
        let mut out = Vec::new();
        append_dropped_item_vertices(&mut out, &base, &item, 15, 0, true, ItemCameraTransform::default(), 0.5);
        let avg_x = out.iter().map(|v| v.position[0]).sum::<f32>() / out.len() as f32;
        assert!((avg_x - 1.0).abs() < 0.02, "the rendered entity must be halfway between its two physics ticks; average X={avg_x}");
    }

}
