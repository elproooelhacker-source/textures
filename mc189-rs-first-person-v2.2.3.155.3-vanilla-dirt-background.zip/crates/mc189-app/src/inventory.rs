//! First implementation of the Minecraft Java 1.8.9 player inventory and GUI.
//!
//! UI dimensions, slot order, hotbar placement, texture assets and give-stack
//! insertion rules are based on the MCP 1.8.9 client sources. Player inventory
//! stacks load from and save to the vanilla `level.dat` Data.Player compound.
use image::{imageops, Rgba, RgbaImage};
use mc189_core::{Mc189Error, Result};
pub use mc189_server::inventory::{legacy_item_name_from_numeric_id, legacy_numeric_id_from_item_name};
use std::collections::{HashMap, HashSet, VecDeque};
use std::io::Read;
use std::path::Path;
use zip::ZipArchive;
#[cfg(test)]
use mc189_storage::NbtTag;

const GUI_WIDTH: u32 = 176;
const GUI_HEIGHT: u32 = 166;
const INVENTORY_SLOTS: usize = 36;
const HOTBAR_SLOTS: usize = 9;
const MAX_CHAT_LINES: usize = 8;

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum UiScreen {
    #[default]
    Hud,
    Inventory,
    Chat,
}

pub use mc189_server::inventory::{ItemStack, PlayerInventory};

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum InventoryServerCommand {
    Give { item_id: String, count: u16, damage: u16 },
    Clear,
}

#[derive(Clone, Debug)]
pub struct InventoryUi {
    pub inventory: PlayerInventory,
    pub screen: UiScreen,
    pub chat_input: String,
    pub cursor_position: (f64, f64),
    /// GuiContainer.slotUnderMouse, stored as the logical inventory slot index.
    hovered_slot: Option<usize>,
    chat_lines: VecDeque<String>,
    item_models: HashSet<String>,
    inventory_background: RgbaImage,
    widgets: RgbaImage,
    ascii_font: RgbaImage,
    player_skin: RgbaImage,
    item_icon_cache: HashMap<String, RgbaImage>,
    jar_path: std::path::PathBuf,
    /// Vanilla ItemStack.animationsToGo-equivalent timers for main + armor slots.
    slot_animation_ticks: [u8; 40],
    /// Render interpolation between fixed ticks, matching GuiIngame partialTicks.
    animation_partial_ticks: f32,
    observed_slot_stacks: Vec<Option<ItemStack>>,
}

impl InventoryUi {
    pub fn load(jar_path: &Path) -> Result<Self> {
        let mut archive = ZipArchive::new(std::fs::File::open(jar_path)?)
            .map_err(|e| Mc189Error::InvalidData(format!("could not open client JAR for inventory GUI: {e}")))?;
        let inventory_background = read_image(&mut archive, "assets/minecraft/textures/gui/container/inventory.png")?;
        let widgets = read_image(&mut archive, "assets/minecraft/textures/gui/widgets.png")?;
        let ascii_font = read_image(&mut archive, "assets/minecraft/textures/font/ascii.png")?;
        let player_skin = read_image(&mut archive, "assets/minecraft/textures/entity/steve.png")?;
        let mut item_models = HashSet::new();
        for index in 0..archive.len() {
            let entry = archive.by_index(index).map_err(|e| Mc189Error::InvalidData(format!("could not list item models in client JAR: {e}")))?;
            let name = entry.name();
            if let Some(rest) = name.strip_prefix("assets/minecraft/models/item/") {
                if let Some(id) = rest.strip_suffix(".json") {
                    if !id.contains('/') && !id.is_empty() { item_models.insert(id.to_owned()); }
                }
            }
        }
        // These are true 1.8.9 Item registry names whose item model is represented
        // by a metadata-dependent variant model rather than a same-named JSON file.
        for id in ["planks", "wool", "dye", "ink_sack", "stained_glass", "stained_glass_pane",
            "stained_hardened_clay", "carpet", "log", "log2", "leaves", "leaves2", "stone",
            "dirt", "sand", "sandstone", "monster_egg", "stonebrick", "prismarine",
            "red_sandstone", "stone_slab", "wooden_slab", "double_wooden_slab",
            "double_stone_slab", "double_stone_slab2", "wooden_door", "fence", "fence_gate",
            "red_flower", "yellow_flower", "sapling", "tallgrass", "stone_button"] {
            item_models.insert(id.to_owned());
        }
        Ok(Self {
            inventory: PlayerInventory::default(), screen: UiScreen::Hud, chat_input: String::new(),
            cursor_position: (0.0, 0.0), hovered_slot: None, chat_lines: VecDeque::new(), item_models,
            inventory_background, widgets, ascii_font, player_skin,
            item_icon_cache: HashMap::new(), jar_path: jar_path.to_path_buf(),
            slot_animation_ticks: [0; 40], animation_partial_ticks: 0.0,
            observed_slot_stacks: vec![None; 40],
        })
    }

    pub fn push_chat(&mut self, line: impl Into<String>) {
        self.chat_lines.push_back(line.into());
        while self.chat_lines.len() > MAX_CHAT_LINES { self.chat_lines.pop_front(); }
    }

    pub fn open_inventory(&mut self) {
        self.screen = UiScreen::Inventory;
    }

    /// Replace the GUI replica only with a snapshot published by mc189-server.
    /// Inventory mutation commands are sent to the server; the client does not
    /// commit slot changes on its own.
    pub fn apply_authoritative_inventory(&mut self, inventory: PlayerInventory) -> bool {
        if self.inventory == inventory { return false; }
        self.inventory = inventory;
        // Server snapshots at this stage represent container rearrangement or
        // selected-slot changes, not item pickups. Do not trigger receive pops.
        self.suppress_container_move_pop();
        true
    }

    /// Apply a server-confirmed EntityItem transfer and retain vanilla receive
    /// animation semantics for the slot(s) whose stack actually increased.
    pub fn apply_authoritative_pickup_inventory(&mut self, inventory: PlayerInventory) -> bool {
        if self.inventory == inventory { return false; }
        self.inventory = inventory;
        self.sync_inventory_animations();
        true
    }

    /// Reset the change observer after loading a saved inventory. Existing items
    /// are not considered newly collected and therefore do not pop on world join.
    pub fn reset_inventory_animation_tracking(&mut self) {
        self.observed_slot_stacks = self.inventory_animation_snapshot();
        self.slot_animation_ticks.fill(0);
        self.animation_partial_ticks = 0.0;
    }

    /// A pure container rearrangement (pickup/place/swap/shift-click) is not a
    /// newly received item. Adopt its new slot layout without arming GuiIngame's
    /// receive-item pop; existing animations in unrelated slots keep running.
    fn suppress_container_move_pop(&mut self) {
        let current = self.inventory_animation_snapshot();
        for index in 0..40 {
            if self.observed_slot_stacks.get(index) != current.get(index) {
                // Cancel a pickup pop that would otherwise follow the stack into a
                // different slot after a manual container rearrangement.
                self.slot_animation_ticks[index] = 0;
            }
        }
        self.observed_slot_stacks = current;
    }

    fn inventory_animation_snapshot(&self) -> Vec<Option<ItemStack>> {
        let mut snapshot = Vec::with_capacity(40);
        snapshot.extend(self.inventory.slots.iter().take(INVENTORY_SLOTS).cloned());
        snapshot.resize(INVENTORY_SLOTS, None);
        snapshot.extend(self.inventory.armor_slots.iter().take(4).cloned());
        snapshot.resize(40, None);
        snapshot
    }

    /// Observe stack identity/count/damage/NBT changes and arm the five-tick
    /// vanilla pop animation for any slot that now contains an item. This also
    /// catches non-pickup mutations (commands, clicks, crafting, consumption).
    fn sync_inventory_animations(&mut self) -> bool {
        if self.observed_slot_stacks.len() != 40 {
            self.observed_slot_stacks = vec![None; 40];
        }
        let mut changed = false;
        for index in 0..40 {
            let current = if index < INVENTORY_SLOTS {
                self.inventory.slots.get(index).and_then(Option::as_ref)
            } else {
                self.inventory.armor_slots.get(index - INVENTORY_SLOTS).and_then(Option::as_ref)
            };
            if self.observed_slot_stacks[index].as_ref() != current {
                let previous = self.observed_slot_stacks[index].as_ref();
                let received_or_changed_in_place = match (previous, current) {
                    (None, Some(_)) => true,
                    (Some(old), Some(new)) => old.id == new.id && old.nbt_tag == new.nbt_tag,
                    _ => false,
                };
                self.slot_animation_ticks[index] = if received_or_changed_in_place { 5 } else { 0 };
                // Clone only a stack that actually changed. This avoids cloning
                // every stack (including arbitrary NBT payloads) on every tick.
                self.observed_slot_stacks[index] = current.cloned();
                changed = true;
            }
        }
        changed
    }

    /// Advance animations once per 20-Hz client tick. Returns true while an
    /// icon changed or was active so its GUI texture can be recomposed.
    pub fn tick_inventory_animations(&mut self) -> bool {
        // Keep the full five-tick first frame when a mutation is discovered here.
        // Mutations already rendered by an input/pickup event simply advance normally.
        if self.sync_inventory_animations() {
            return true;
        }
        let mut changed = false;
        for ticks in &mut self.slot_animation_ticks {
            if *ticks > 0 {
                *ticks -= 1;
                changed = true;
            }
        }
        changed
    }

    pub fn has_active_inventory_animations(&self) -> bool {
        self.slot_animation_ticks.iter().any(|ticks| *ticks > 0)
    }

    fn slot_animation_scale(&self, index: usize) -> (f32, f32) {
        let ticks = self.slot_animation_ticks.get(index).copied().unwrap_or(0);
        let remaining = (f32::from(ticks) - self.animation_partial_ticks.clamp(0.0, 1.0)).max(0.0);
        if remaining <= 0.0 { return (1.0, 1.0); }
        // GuiIngame.renderHotbarItem: f=animationsToGo-partialTicks;
        // f1=1+f/5, scale(1/f1,(f1+1)/2).
        let f1 = 1.0 + remaining / 5.0;
        (1.0 / f1, (f1 + 1.0) * 0.5)
    }

    pub fn open_chat(&mut self, slash_prefix: bool) {
        self.screen = UiScreen::Chat;
        self.chat_input.clear();
        if slash_prefix { self.chat_input.push('/'); }
    }

    pub fn close_screen(&mut self) {
        // Cursor-stack drop is sent to the integrated server by the event handler.
        self.screen = UiScreen::Hud;
        self.hovered_slot = None;
        self.chat_input.clear();
        self.suppress_container_move_pop();
    }

    pub fn chat_backspace(&mut self) {
        self.chat_input.pop();
    }

    pub fn chat_push_text(&mut self, text: &str) {
        for ch in text.chars() {
            if !ch.is_control() && self.chat_input.chars().count() < 100 { self.chat_input.push(ch); }
        }
    }

    /// Return slash commands for server dispatch; ordinary chat remains a local display line.
    pub fn submit_chat(&mut self) -> Option<String> {
        let line = self.chat_input.trim().to_owned();
        self.chat_input.clear();
        self.screen = UiScreen::Hud;
        if line.is_empty() { return None; }
        if let Some(command) = line.strip_prefix('/') { Some(command.to_owned()) }
        else { self.push_chat(format!("<Player> {line}")); None }
    }

    /// Parse inventory-changing commands without mutating the client replica.
    pub fn parse_server_inventory_command(&mut self, command_line: &str) -> Option<InventoryServerCommand> {
        let parts: Vec<&str> = command_line.split_whitespace().collect();
        if parts.is_empty() { return None; }
        match parts[0].trim_start_matches('/').to_ascii_lowercase().as_str() {
            "clear" if parts.len() == 1 => Some(InventoryServerCommand::Clear),
            "clear" => { self.push_chat("This build supports /clear without target or item filters."); None }
            "give" => {
                let args = &parts[1..];
                if args.is_empty() { self.push_chat("Usage: /give <player> <item> [count] [damage]"); return None; }
                let first_is_target = args[0].starts_with('@')
                    || (args.len() >= 2 && normalize_item_id(args[0].strip_prefix("minecraft:").unwrap_or(args[0]), 0, &self.item_models).is_none());
                let (item_arg, count_arg, damage_arg) = if first_is_target {
                    if args.len() < 2 { self.push_chat("Usage: /give <player> <item> [count] [damage]"); return None; }
                    (args[1], args.get(2).copied(), args.get(3).copied())
                } else { (args[0], args.get(1).copied(), args.get(2).copied()) };
                let count = match count_arg.map(str::parse::<u16>).transpose() {
                    Ok(Some(value @ 1..=64)) => value, Ok(None) => 1,
                    _ => { self.push_chat("Invalid count: expected an integer from 1 to 64."); return None; }
                };
                let damage = match damage_arg.map(str::parse::<u16>).transpose() {
                    Ok(Some(value)) if value <= 32767 => value, Ok(None) => 0,
                    _ => { self.push_chat("Invalid item damage/metadata value."); return None; }
                };
                let raw = item_arg.strip_prefix("minecraft:").unwrap_or(item_arg).to_ascii_lowercase();
                match normalize_item_id(&raw, damage, &self.item_models) {
                    Some((item_id, damage)) => Some(InventoryServerCommand::Give { item_id, count, damage }),
                    None => { self.push_chat(format!("Unknown item '{item_arg}' in this 1.8.9 client registry.")); None }
                }
            }
            "help" => { self.push_chat("Commands: /give <player> <item> [count] [damage], /clear, /help"); None }
            other => { self.push_chat(format!("Unknown or unsupported command: /{other}")); None }
        }
    }

    pub fn selected_hotbar_drop_slot(&self) -> Option<usize> {
        self.inventory.current_item().map(|_| self.inventory.selected_hotbar)
    }
    pub fn hovered_drop_slot(&self) -> Option<usize> {
        if self.screen != UiScreen::Inventory || self.inventory.cursor_stack.is_some() { return None; }
        let slot = self.hovered_slot?;
        let occupied = if slot < INVENTORY_SLOTS { self.inventory.slots.get(slot)?.is_some() }
            else { self.inventory.armor_slots.get(slot - INVENTORY_SLOTS)?.is_some() };
        occupied.then_some(slot)
    }


    #[cfg(test)]
    pub fn select_hotbar(&mut self, slot: usize) -> bool { self.inventory.select_hotbar(slot) }

    /// Update GuiContainer's hovered slot from the current physical cursor position.
    /// Returns true only when the highlighted slot changes, so mouse motion within
    /// one slot does not trigger an unnecessary full GUI texture upload.
    pub fn set_cursor_position(&mut self, physical_x: f64, physical_y: f64, width: u32, height: u32) -> bool {
        self.cursor_position = (physical_x, physical_y);
        let hovered = if self.screen == UiScreen::Inventory {
            self.inventory_slot_at_physical(physical_x, physical_y, width, height)
        } else { None };
        let changed = hovered != self.hovered_slot;
        self.hovered_slot = hovered;
        changed
    }

    /// Provide the selected hotbar item, its resolved 1.8.9 item model id and its
    /// cached vanilla icon to the first-person item renderer. The visual is keyed
    /// by item id + metadata, not stack count, so adding/removing items doesn't
    /// rebuild GPU geometry unnecessarily.
    /// Extract the vanilla 24x22 selected-hotbar frame from widgets.png. The sprite
    /// itself never changes; only its GPU quad moves when the selected index changes.
    pub fn render_hotbar_selection_sprite(&self, scale_factor: u32) -> RgbaImage {
        let scale = scale_factor.max(1);
        let frame = imageops::crop_imm(&self.widgets, 0, 22, 24, 22).to_image();
        imageops::resize(&frame, 24 * scale, 22 * scale, imageops::FilterType::Nearest)
    }

    /// Physical position of GuiIngame's selected-slot frame. It appears on the HUD
    /// and chat overlay, but not on the full inventory screen.
    pub fn hotbar_selection_rect_physical(&self, width: u32, height: u32) -> Option<(i32, i32)> {
        if !matches!(self.screen, UiScreen::Hud | UiScreen::Chat) { return None; }
        let scale = gui_scale_factor(width, height);
        let logical_width = width.div_ceil(scale) as i32;
        let logical_height = height.div_ceil(scale) as i32;
        let left = logical_width / 2 - 91 - 1 + self.inventory.selected_hotbar as i32 * 20;
        let top = logical_height - 22 - 1;
        Some((left * scale as i32, top * scale as i32))
    }

    /// Physical top-left of the vanilla 16x16 GuiContainer hover highlight. This is
    /// rendered as a separate GPU sprite so cursor motion does not rebuild/upload the
    /// full ScaledResolution inventory texture.
    pub fn hovered_slot_rect_physical(&self, width: u32, height: u32) -> Option<(i32, i32)> {
        if self.screen != UiScreen::Inventory { return None; }
        let slot = self.hovered_slot?;
        let scale_factor = gui_scale_factor(width, height);
        let logical_width = width.div_ceil(scale_factor) as i32;
        let logical_height = height.div_ceil(scale_factor) as i32;
        let left = (logical_width - GUI_WIDTH as i32) / 2;
        let top = (logical_height - GUI_HEIGHT as i32) / 2;
        let (slot_x, slot_y) = if slot < HOTBAR_SLOTS {
            (8 + slot as i32 * 18, 142)
        } else if slot < INVENTORY_SLOTS {
            let index = slot - HOTBAR_SLOTS;
            (8 + (index % 9) as i32 * 18, 84 + (index / 9) as i32 * 18)
        } else if slot < INVENTORY_SLOTS + 4 {
            (8, 8 + (3 - (slot - INVENTORY_SLOTS)) as i32 * 18)
        } else { return None; };
        Some(((left + slot_x) * scale_factor as i32, (top + slot_y) * scale_factor as i32))
    }

    pub fn current_held_item_visual(&mut self) -> Option<(String, String, RgbaImage)> {
        let stack = self.inventory.current_item()?.clone();
        let model_id = model_for_metadata(&stack.id, stack.damage);
        let cache_key = format!("{}:{}", stack.id, stack.damage);
        if !self.item_icon_cache.contains_key(&cache_key) {
            let image = load_item_icon(&self.jar_path, &stack.id, stack.damage)
                .unwrap_or_else(|_| fallback_icon());
            self.item_icon_cache.insert(cache_key.clone(), image);
        }
        let icon = self.item_icon_cache.get(&cache_key)?.clone();
        Some((cache_key, model_id, icon))
    }

    /// Click a GUI inventory or hotbar slot. Coordinates are physical framebuffer
    /// pixels; the method maps them through ScaledResolution's automatic GUI scale.
    #[cfg(test)]
    pub fn click_slot(&mut self, physical_x: f64, physical_y: f64, width: u32, height: u32, right_click: bool) -> bool {
        if self.screen != UiScreen::Inventory { return false; }
        let before = self.inventory_animation_snapshot();
        let changed = self.inventory_slot_at_physical(physical_x, physical_y, width, height)
            .map(|slot| if slot >= INVENTORY_SLOTS { self.inventory.click_armor_stack(slot - INVENTORY_SLOTS) }
                else { self.inventory.click_stack(slot, right_click) }).unwrap_or(false);
        // Detect the actual slot mutation rather than trusting the click result;
        // every cursor/container move is suppressed before the next redraw.
        if self.inventory_animation_snapshot() != before { self.suppress_container_move_pop(); }
        changed
    }

    /// Read the item in the slot currently under the GUI cursor.
    /// The slot index is deliberately kept private so gameplay code cannot
    /// depend on InventoryUi's internal slot mapping; callers use this view
    /// before validating a Q/Ctrl+Q drop.
    pub fn hovered_stack(&self) -> Option<&ItemStack> {
        let slot = self.hovered_slot?;
        if slot < INVENTORY_SLOTS {
            self.inventory.slots.get(slot)?.as_ref()
        } else {
            self.inventory.armor_slots.get(slot - INVENTORY_SLOTS)?.as_ref()
        }
    }

    /// InventoryPlayer/GuiContainer shift-click transfer between hotbar (0-8)
    /// and main inventory (9-35), merging compatible stacks before empty slots.
    #[cfg(test)]
    pub fn shift_click_slot(&mut self, physical_x: f64, physical_y: f64, width: u32, height: u32) -> bool {
        if self.screen != UiScreen::Inventory { return false; }
        let Some(source) = self.inventory_slot_at_physical(physical_x, physical_y, width, height) else { return false; };
        let before = self.inventory_animation_snapshot();
        let changed = if source >= INVENTORY_SLOTS {
            self.inventory.shift_move_armor_to_inventory(source - INVENTORY_SLOTS)
        } else if self.inventory.shift_auto_equip(source) {
            true
        } else if source < HOTBAR_SLOTS {
            self.inventory.shift_move_stack(source, HOTBAR_SLOTS, INVENTORY_SLOTS)
        } else {
            self.inventory.shift_move_stack(source, 0, HOTBAR_SLOTS)
        };
        if self.inventory_animation_snapshot() != before { self.suppress_container_move_pop(); }
        changed
    }

    pub fn inventory_slot_at_physical(&self, physical_x: f64, physical_y: f64, width: u32, height: u32) -> Option<usize> {
        let scale_factor = gui_scale_factor(width, height);
        let scale = f64::from(scale_factor);
        let x = physical_x / scale;
        let y = physical_y / scale;
        let logical_width = f64::from(width.div_ceil(scale_factor));
        let logical_height = f64::from(height.div_ceil(scale_factor));
        let left = ((logical_width - f64::from(GUI_WIDTH)) * 0.5).floor();
        let top = ((logical_height - f64::from(GUI_HEIGHT)) * 0.5).floor();
        let local_x = x - left;
        let local_y = y - top;
        if (8.0..24.0).contains(&local_x) && (8.0..80.0).contains(&local_y) {
            let row = ((local_y - 8.0) / 18.0).floor() as usize;
            if row < 4 && (local_x - 8.0) < 16.0 && (local_y - 8.0) % 18.0 < 16.0 {
                return Some(INVENTORY_SLOTS + (3 - row));
            }
        }
        if (8.0..168.0).contains(&local_x) && (142.0..158.0).contains(&local_y) {
            let col = ((local_x - 8.0) / 18.0).floor() as usize;
            let within = (local_x - 8.0) % 18.0;
            return (col < HOTBAR_SLOTS && within < 16.0).then_some(col);
        }
        if (8.0..168.0).contains(&local_x) && (84.0..138.0).contains(&local_y) {
            let row = ((local_y - 84.0) / 18.0).floor() as usize;
            let col = ((local_x - 8.0) / 18.0).floor() as usize;
            let within_x = (local_x - 8.0) % 18.0;
            let within_y = (local_y - 84.0) % 18.0;
            return (row < 3 && col < 9 && within_x < 16.0 && within_y < 16.0)
                .then_some(9 + row * 9 + col);
        }
        None
    }

    pub fn render_overlay(&mut self, width: u32, height: u32) -> RgbaImage {
        self.render_overlay_interpolated(width, height, 0.0)
    }

    /// Render the slot-pop effect at the current display-frame interpolation.
    /// The regular render_overlay entry point remains available for input-driven refreshes.
    pub fn render_overlay_interpolated(&mut self, width: u32, height: u32, partial_ticks: f32) -> RgbaImage {
        self.animation_partial_ticks = partial_ticks.clamp(0.0, 1.0);
        self.sync_inventory_animations();
        let width = width.max(1);
        let height = height.max(1);
        let scale = gui_scale_factor(width, height);
        let logical_width = width.div_ceil(scale);
        let logical_height = height.div_ceil(scale);
        let mut logical = RgbaImage::new(logical_width.max(1), logical_height.max(1));
        match self.screen {
            UiScreen::Hud => {
                self.draw_hotbar(&mut logical);
            }
            UiScreen::Inventory => {
                for pixel in logical.pixels_mut() { *pixel = Rgba([0, 0, 0, 128]); }
                self.draw_inventory_window(&mut logical);
            }
            UiScreen::Chat => {
                self.draw_hotbar(&mut logical);
            }
        }
        // Vanilla draws at ScaledResolution dimensions. The GPU's nearest sampler
        // scales this logical GUI texture to the framebuffer, avoiding a full-size
        // CPU resize and upload whenever a hotbar key is pressed.
        logical
    }

    /// Chat is a later GuiIngame layer than the hotbar/selected-slot frame in vanilla 1.8.9.
    /// Returning a transparent full-frame texture preserves that ordering in the GPU renderer.
    pub fn render_chat_overlay(&mut self, width: u32, height: u32) -> RgbaImage {
        let width = width.max(1);
        let height = height.max(1);
        let scale = gui_scale_factor(width, height);
        let mut logical = RgbaImage::new(width.div_ceil(scale).max(1), height.div_ceil(scale).max(1));
        if matches!(self.screen, UiScreen::Hud | UiScreen::Chat) {
            self.draw_chat_history(&mut logical, 4);
        }
        if self.screen == UiScreen::Chat {
            let y = logical.height().saturating_sub(14) as i32;
            let logical_width = logical.width() as i32;
            fill_rect(&mut logical, 0, y, logical_width, y + 12, [0, 0, 0, 160]);
            self.draw_text(&mut logical, 4, y + 2, &self.chat_input, [255, 255, 255, 255], true);
            let cursor_x = 4 + self.text_width(&self.chat_input) as i32;
            fill_rect(&mut logical, cursor_x, y + 2, cursor_x + 1, y + 10, [255, 255, 255, 255]);
        }
        logical
    }

    fn draw_hotbar(&mut self, canvas: &mut RgbaImage) {
        let width = canvas.width() as i32;
        let height = canvas.height() as i32;
        let left = width / 2 - 91;
        let top = height - 22;
        let widgets = &self.widgets;
        draw_image(canvas, widgets, left, top, 0, 0, 182, 22);
        // The selected-slot frame is drawn by a dedicated GPU sprite. Updating the
        // hotbar index must not re-rasterize and upload the entire HUD texture.
        // Stack pop is clipped per 16x16 slot so tall first frames cannot
        // spill into adjacent hotbar items or outside the HUD frame.
        for slot in 0..HOTBAR_SLOTS {
            let x = width / 2 - 90 + slot as i32 * 20 + 2;
            let y = height - 16 - 3;
            // Each GuiIngame slot owns a 16x16 icon viewport. A larger clip
            // allowed the vanilla pop transform to spill into neighbouring slots.
            self.draw_stack_at(canvas, slot, x, y, (x, y, x + 16, y + 16));
        }
    }

    fn draw_inventory_window(&mut self, canvas: &mut RgbaImage) {
        let left = (canvas.width() as i32 - GUI_WIDTH as i32) / 2;
        let top = (canvas.height() as i32 - GUI_HEIGHT as i32) / 2;
        draw_image(canvas, &self.inventory_background, left, top, 0, 0, GUI_WIDTH, GUI_HEIGHT);
        self.draw_text(canvas, left + 86, top + 16, "Crafting", [64, 64, 64, 255], false);
        // The player preview and carried stack are composed as small, native-resolution
        // GPU sprites after the GUI layer. This matches vanilla's framebuffer-resolved
        // entity rendering and avoids rerasterizing the whole GUI on every mouse move.
        // InventoryPlayer armor order is boots -> helmet, while GuiInventory draws
        // helmet, chestplate, leggings, boots from top to bottom.
        for row in 0..4 {
            let armor_index = 3 - row;
            let x = left + 8;
            let y = top + 8 + row as i32 * 18;
            self.draw_armor_stack_at(canvas, armor_index, x, y, (x, y, x + 16, y + 16));
        }
        // GuiContainer slot order: the 27 main slots, then the 9 hotbar slots visually.
        for row in 0..3 {
            for col in 0..9 {
                let slot = 9 + row * 9 + col;
                let x = left + 8 + col as i32 * 18;
                let y = top + 84 + row as i32 * 18;
                self.draw_stack_at(canvas, slot, x, y, (x, y, x + 16, y + 16));
            }
        }
        for col in 0..HOTBAR_SLOTS {
            let x = left + 8 + col as i32 * 18;
            let y = top + 142;
            self.draw_stack_at(canvas, col, x, y, (x, y, x + 16, y + 16));
        }
        // The 1.8.9 GUI has four armour slots and a 2x2 crafting area. Their frames
        // are already exact in inventory.png; their data/drag operations come later.
    }

    /// Render the avatar into a small physical-pixel sprite rather than the scaled GUI
    /// canvas. Vanilla renders the entity in the framebuffer, even when GUI text is scaled.
    pub fn render_player_preview(&self, scale_factor: u32, gui_left: i32, gui_top: i32) -> RgbaImage {
        let sf = scale_factor.max(1);
        let mut preview = RgbaImage::new(80 * sf, 82 * sf);
        let mouse_x = (gui_left + 51) as f32 - (self.cursor_position.0 / f64::from(sf)).floor() as f32;
        let mouse_y = (gui_top + 25) as f32 - (self.cursor_position.1 / f64::from(sf)).floor() as f32;
        draw_vanilla_player_model(
            &mut preview,
            &self.player_skin,
            51 * sf as i32,
            15 * sf as i32,
            mouse_x,
            mouse_y,
            sf as f32,
        );
        preview
    }

    /// The carried stack is its own GPU sprite so it is positioned in absolute
    /// framebuffer coordinates and remains above Steve when the cursor crosses him.
    pub fn render_cursor_stack_icon(&mut self, scale_factor: u32) -> Option<RgbaImage> {
        let stack = self.inventory.cursor_stack.clone()?;
        let sf = scale_factor.max(1);
        let mut logical = RgbaImage::new(20, 18);
        self.draw_stack_icon(&mut logical, &stack, 0, 0);
        self.draw_durability_bar(&mut logical, &stack, 0, 0, (0, 0, 16, 16));
        if stack.count > 1 { self.draw_count(&mut logical, stack.count, 0, 0); }
        Some(imageops::resize(&logical, 20 * sf, 18 * sf, imageops::FilterType::Nearest))
    }


    fn draw_chat_history(&mut self, canvas: &mut RgbaImage, max_lines: usize) {
        let baseline = canvas.height() as i32 - if self.screen == UiScreen::Hud { 31 } else { 45 };
        let canvas_width = canvas.width() as i32;
        let start = self.chat_lines.len().saturating_sub(max_lines);
        let lines: Vec<String> = self.chat_lines.iter().skip(start).cloned().collect();
        for (index, line) in lines.iter().enumerate() {
            let y = baseline - (lines.len() - 1 - index) as i32 * 10;
            fill_rect(canvas, 2, y - 1, (self.text_width(line) as i32 + 6).min(canvas_width), y + 9, [0, 0, 0, 100]);
            self.draw_text(canvas, 4, y, line, [255, 255, 255, 255], true);
        }
    }

    fn draw_stack_at(&mut self, canvas: &mut RgbaImage, slot: usize, x: i32, y: i32, clip: (i32, i32, i32, i32)) {
        let stack = self.inventory.slots.get(slot).and_then(Option::as_ref).cloned();
        if let Some(stack) = stack {
            let (scale_x, scale_y) = self.slot_animation_scale(slot);
            if scale_x == 1.0 && scale_y == 1.0 {
                self.draw_stack_icon_clipped(canvas, &stack, x, y, clip);
            } else {
                // Rasterize the pop into an isolated 16x16 slot surface first.
                // This is a hard clipping boundary: no animation pixel can leak
                // into the hotbar border, the next slot, or the inventory panel.
                let mut slot_surface = RgbaImage::new(16, 16);
                let pivot_y = if matches!(self.screen, UiScreen::Hud | UiScreen::Chat) { 12 } else { 8 };
                self.draw_stack_icon_scaled(
                    &mut slot_surface, &stack, 0, 0, scale_x, scale_y, pivot_y, (0, 0, 16, 16),
                );
                draw_image_resized(canvas, &slot_surface, x, y, 16, 16);
            }
            // Vanilla renders item overlays after popping the hotbar pop matrix,
            // so the count stays anchored to the slot while only the icon bounces.
            if stack.count > 1 { self.draw_count_clipped(canvas, stack.count, x, y, clip); }
            self.draw_durability_bar(canvas, &stack, x, y, clip);
        }
    }

    fn draw_armor_stack_at(&mut self, canvas: &mut RgbaImage, armor_slot: usize, x: i32, y: i32, clip: (i32, i32, i32, i32)) {
        let stack = self.inventory.armor_slots.get(armor_slot).and_then(Option::as_ref).cloned();
        if let Some(stack) = stack {
            let (scale_x, scale_y) = self.slot_animation_scale(36 + armor_slot);
            if scale_x == 1.0 && scale_y == 1.0 {
                self.draw_stack_icon_clipped(canvas, &stack, x, y, clip);
            } else {
                let mut slot_surface = RgbaImage::new(16, 16);
                self.draw_stack_icon_scaled(&mut slot_surface, &stack, 0, 0, scale_x, scale_y, 8, (0, 0, 16, 16));
                draw_image_resized(canvas, &slot_surface, x, y, 16, 16);
            }
            self.draw_durability_bar(canvas, &stack, x, y, clip);
        }
    }

    fn draw_durability_bar(&self, canvas: &mut RgbaImage, stack: &ItemStack, x: i32, y: i32, clip: (i32, i32, i32, i32)) {
        let Some(maximum) = mc189_server::inventory::max_durability_for_item_id(&stack.id) else { return; };
        if stack.damage == 0 || maximum == 0 { return; }
        // RenderItem.renderItemOverlayIntoGUI (MCP 1.8.9): 13x2 background,
        // 12px dark underlay and 13px green-to-red foreground, using rounded widths.
        let damage = f64::from(stack.damage.min(maximum));
        let max = f64::from(maximum);
        let width = (13.0 - damage * 13.0 / max).round().clamp(0.0, 13.0) as i32;
        let green = (255.0 - damage * 255.0 / max).round().clamp(0.0, 255.0) as u8;
        let red = 255u8.saturating_sub(green);
        let left = x + 2; let top = y + 13;
        let (cx0, cy0, cx1, cy1) = clip;
        let draw = |l: i32, t: i32, r: i32, b: i32, color: [u8;4], canvas: &mut RgbaImage| {
            let l=l.max(cx0); let t=t.max(cy0); let r=r.min(cx1); let b=b.min(cy1);
            if l<r && t<b { fill_rect(canvas,l,t,r,b,color); }
        };
        draw(left,top,left+13,top+2,[0,0,0,255],canvas);
        draw(left,top,left+12,top+1,[((255-green)/4),64,0,255],canvas);
        draw(left,top,left+width,top+1,[red,green,0,255],canvas);
    }

    fn draw_stack_icon(&mut self, canvas: &mut RgbaImage, stack: &ItemStack, x: i32, y: i32) {
        let cache_key = format!("{}:{}", stack.id, stack.damage);
        if !self.item_icon_cache.contains_key(&cache_key) {
            let image = load_item_icon(&self.jar_path, &stack.id, stack.damage).unwrap_or_else(|_| fallback_icon());
            self.item_icon_cache.insert(cache_key.clone(), image);
        }
        if let Some(icon) = self.item_icon_cache.get(&cache_key) {
            if Self::is_full_cube_inventory_item(&stack.id) {
                let cube_icon = Self::render_isometric_block_icon(icon);
                draw_image_resized(canvas, &cube_icon, x, y, 16, 16);
            } else {
                draw_image_resized(canvas, icon, x, y, 16, 16);
            }
        }
    }

    fn draw_stack_icon_clipped(
        &mut self, canvas: &mut RgbaImage, stack: &ItemStack, x: i32, y: i32,
        clip: (i32, i32, i32, i32),
    ) {
        let cache_key = format!("{}:{}", stack.id, stack.damage);
        if !self.item_icon_cache.contains_key(&cache_key) {
            let image = load_item_icon(&self.jar_path, &stack.id, stack.damage).unwrap_or_else(|_| fallback_icon());
            self.item_icon_cache.insert(cache_key.clone(), image);
        }
        if let Some(icon) = self.item_icon_cache.get(&cache_key) {
            if Self::is_full_cube_inventory_item(&stack.id) {
                let cube_icon = Self::render_isometric_block_icon(icon);
                draw_image_resized_clipped(canvas, &cube_icon, x, y, 16, 16, clip);
            } else {
                draw_image_resized_clipped(canvas, icon, x, y, 16, 16, clip);
            }
        }
    }

    fn draw_stack_icon_scaled(
        &mut self, canvas: &mut RgbaImage, stack: &ItemStack, x: i32, y: i32,
        scale_x: f32, scale_y: f32, pivot_y: i32, clip: (i32, i32, i32, i32),
    ) {
        let cache_key = format!("{}:{}", stack.id, stack.damage);
        if !self.item_icon_cache.contains_key(&cache_key) {
            let image = load_item_icon(&self.jar_path, &stack.id, stack.damage).unwrap_or_else(|_| fallback_icon());
            self.item_icon_cache.insert(cache_key.clone(), image);
        }
        let Some(icon) = self.item_icon_cache.get(&cache_key) else { return; };
        let width = (16.0 * scale_x).round().clamp(1.0, 32.0) as u32;
        let height = (16.0 * scale_y).round().clamp(1.0, 32.0) as u32;
        let draw_x = x + 8 - width as i32 / 2;
        let draw_y = y + pivot_y - height as i32 / 2;
        if Self::is_full_cube_inventory_item(&stack.id) {
            let cube_icon = Self::render_isometric_block_icon(icon);
            draw_image_resized_clipped(canvas, &cube_icon, draw_x, draw_y, width, height, clip);
        } else {
            draw_image_resized_clipped(canvas, icon, draw_x, draw_y, width, height, clip);
        }
    }

fn is_full_cube_inventory_item(id: &str) -> bool {
    matches!(id,
        "stone" | "grass" | "dirt" | "cobblestone" | "planks" | "bedrock" |
        "sand" | "gravel" | "gold_ore" | "iron_ore" | "coal_ore" | "log" | "log2" |
        "leaves" | "leaves2" | "sponge" | "glass" | "lapis_ore" | "lapis_block" |
        "dispenser" | "sandstone" | "noteblock" | "gold_block" | "iron_block" |
        "brick_block" | "tnt" | "bookshelf" | "mossy_cobblestone" | "obsidian" |
        "diamond_ore" | "diamond_block" | "redstone_ore" | "ice" | "snow" |
        "clay" | "pumpkin" | "netherrack" | "soul_sand" | "glowstone" |
        "stonebrick" | "melon_block" | "mycelium" | "nether_brick" | "end_stone" |
        "emerald_ore" | "emerald_block" | "redstone_block" | "quartz_block" |
        "hardened_clay" | "coal_block" | "packed_ice" | "hay_block" | "slime" |
        "prismarine" | "sea_lantern" | "red_sandstone" | "purpur_block" | "purpur_pillar" |
        "magma" | "nether_wart_block" | "red_nether_brick" | "bone_block" | "concrete" |
        "concrete_powder" | "terracotta" | "white_glazed_terracotta" | "orange_glazed_terracotta" |
        "magenta_glazed_terracotta" | "light_blue_glazed_terracotta" | "yellow_glazed_terracotta" |
        "lime_glazed_terracotta" | "pink_glazed_terracotta" | "gray_glazed_terracotta" |
        "silver_glazed_terracotta" | "cyan_glazed_terracotta" | "purple_glazed_terracotta" |
        "blue_glazed_terracotta" | "brown_glazed_terracotta" | "green_glazed_terracotta" |
        "red_glazed_terracotta" | "black_glazed_terracotta")
}

/// Small GUI equivalent of RenderItem's isometric presentation for full cube
/// item models. The source sprite is sampled on all three visible faces; vanilla
/// directional brightness is applied to the side faces. Non-cube items retain
/// their native flat/generated sprite.
fn render_isometric_block_icon(texture: &RgbaImage) -> RgbaImage {
    let mut out = RgbaImage::new(16, 16);
    // Each face is a quad (top-left, top-right, bottom-right, bottom-left) and
    // is split into two triangles. UVs map the whole sprite onto each face.
    let faces: [([[f32; 2]; 4], f32); 3] = [
        ([[8.0, 0.0], [15.0, 4.0], [8.0, 8.0], [1.0, 4.0]], 1.0),
        ([[1.0, 4.0], [8.0, 8.0], [8.0, 15.0], [1.0, 11.0]], 0.62),
        ([[15.0, 4.0], [8.0, 8.0], [8.0, 15.0], [15.0, 11.0]], 0.78),
    ];
    let uv = [[0.0_f32, 0.0_f32], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]];
    for (points, shade) in faces {
        for tri in [[0_usize, 1, 2], [0, 2, 3]] {
            let a = points[tri[0]]; let b = points[tri[1]]; let c = points[tri[2]];
            let min_x = a[0].min(b[0]).min(c[0]).floor().max(0.0) as i32;
            let max_x = a[0].max(b[0]).max(c[0]).ceil().min(15.0) as i32;
            let min_y = a[1].min(b[1]).min(c[1]).floor().max(0.0) as i32;
            let max_y = a[1].max(b[1]).max(c[1]).ceil().min(15.0) as i32;
            let denom = (b[1] - c[1]) * (a[0] - c[0]) + (c[0] - b[0]) * (a[1] - c[1]);
            if denom.abs() < 1.0e-5 { continue; }
            for py in min_y..=max_y { for px in min_x..=max_x {
                let x = px as f32 + 0.5; let y = py as f32 + 0.5;
                let wa = ((b[1]-c[1])*(x-c[0])+(c[0]-b[0])*(y-c[1]))/denom;
                let wb = ((c[1]-a[1])*(x-c[0])+(a[0]-c[0])*(y-c[1]))/denom;
                let wc = 1.0-wa-wb;
                if wa < -0.001 || wb < -0.001 || wc < -0.001 { continue; }
                let u = (uv[tri[0]][0]*wa + uv[tri[1]][0]*wb + uv[tri[2]][0]*wc).clamp(0.0, 0.9999);
                let v = (uv[tri[0]][1]*wa + uv[tri[1]][1]*wb + uv[tri[2]][1]*wc).clamp(0.0, 0.9999);
                let src = texture.get_pixel((u*texture.width() as f32) as u32, (v*texture.height() as f32) as u32);
                if src[3] == 0 { continue; }
                out.put_pixel(px as u32, py as u32, Rgba([
                    (src[0] as f32 * shade) as u8, (src[1] as f32 * shade) as u8,
                    (src[2] as f32 * shade) as u8, src[3]]));
            }}
        }
    }
    out
}

    fn draw_count(&self, canvas: &mut RgbaImage, count: u16, x: i32, y: i32) {
        let text = count.to_string();
        let width = self.text_width(&text) as i32;
        self.draw_text(canvas, x + 17 - width, y + 9, &text, [255, 255, 255, 255], true);
    }

    fn draw_count_clipped(&self, canvas: &mut RgbaImage, count: u16, x: i32, y: i32, clip: (i32, i32, i32, i32)) {
        let text = count.to_string();
        let width = self.text_width(&text) as i32;
        self.draw_text_clipped(canvas, x + 17 - width, y + 9, &text, [255, 255, 255, 255], true, clip);
    }

    fn draw_text_clipped(&self, canvas: &mut RgbaImage, x: i32, y: i32, text: &str, color: [u8; 4], shadow: bool, clip: (i32, i32, i32, i32)) {
        let mut cursor_x = x;
        for ch in text.chars() {
            if ch == ' ' { cursor_x += 4; continue; }
            if shadow { self.draw_glyph_clipped(canvas, cursor_x + 1, y + 1, ch, [0, 0, 0, color[3]], clip); }
            self.draw_glyph_clipped(canvas, cursor_x, y, ch, color, clip);
            cursor_x += glyph_width(&self.ascii_font, ch) as i32 + 1;
        }
    }

    fn draw_glyph_clipped(&self, canvas: &mut RgbaImage, x: i32, y: i32, ch: char, color: [u8; 4], clip: (i32, i32, i32, i32)) {
        let code = ch as u32;
        let index = if (32..=255).contains(&code) { code } else { b'?' as u32 };
        let sx = (index % 16) * 8;
        let sy = (index / 16) * 8;
        for gy in 0..8_i32 {
            for gx in 0..8_i32 {
                let px = x + gx;
                let py = y + gy;
                if px < clip.0 || py < clip.1 || px >= clip.2 || py >= clip.3 { continue; }
                let alpha = self.ascii_font.get_pixel((sx as i32 + gx) as u32, (sy as i32 + gy) as u32)[3];
                if alpha == 0 { continue; }
                blend_pixel(canvas, px, py, [color[0], color[1], color[2], ((u16::from(alpha) * u16::from(color[3])) / 255) as u8]);
            }
        }
    }

    fn text_width(&self, text: &str) -> u32 {
        text.chars().map(|ch| glyph_width(&self.ascii_font, ch) as u32 + 1).sum()
    }

    fn draw_text(&self, canvas: &mut RgbaImage, x: i32, y: i32, text: &str, color: [u8; 4], shadow: bool) {
        let mut cursor_x = x;
        for ch in text.chars() {
            if ch == ' ' { cursor_x += 4; continue; }
            if shadow { self.draw_glyph(canvas, cursor_x + 1, y + 1, ch, [0, 0, 0, color[3]]); }
            self.draw_glyph(canvas, cursor_x, y, ch, color);
            cursor_x += glyph_width(&self.ascii_font, ch) as i32 + 1;
        }
    }

    fn draw_glyph(&self, canvas: &mut RgbaImage, x: i32, y: i32, ch: char, color: [u8; 4]) {
        let code = ch as u32;
        let index = if (32..=255).contains(&code) { code } else { b'?' as u32 };
        let sx = (index % 16) * 8;
        let sy = (index / 16) * 8;
        for gy in 0..8_i32 {
            for gx in 0..8_i32 {
                let alpha = self.ascii_font.get_pixel((sx as i32 + gx) as u32, (sy as i32 + gy) as u32)[3];
                if alpha == 0 { continue; }
                blend_pixel(canvas, x + gx, y + gy, [color[0], color[1], color[2], ((u16::from(alpha) * u16::from(color[3])) / 255) as u8]);
            }
        }
    }
}

pub fn gui_scale_factor(width: u32, height: u32) -> u32 {
    let mut scale = 1_u32;
    while width / (scale + 1) >= 320 && height / (scale + 1) >= 240 { scale += 1; }
    scale
}

fn read_image(archive: &mut ZipArchive<std::fs::File>, path: &str) -> Result<RgbaImage> {
    let mut entry = archive.by_name(path).map_err(|e| Mc189Error::InvalidData(format!("required Minecraft GUI texture {path} is missing from client.jar: {e}")))?;
    let mut bytes = Vec::new();
    entry.read_to_end(&mut bytes)?;
    Ok(image::load_from_memory(&bytes).map_err(|e| Mc189Error::InvalidData(format!("cannot decode Minecraft texture {path}: {e}")))?.to_rgba8())
}

fn read_archive_image(archive: &mut ZipArchive<std::fs::File>, path: &str) -> Option<RgbaImage> {
    let mut entry = archive.by_name(path).ok()?;
    let mut bytes = Vec::new();
    entry.read_to_end(&mut bytes).ok()?;
    image::load_from_memory(&bytes).ok().map(|im| im.to_rgba8())
}

pub(crate) fn load_item_icon(jar_path: &Path, id: &str, damage: u16) -> Result<RgbaImage> {
    let file = std::fs::File::open(jar_path)?;
    let mut archive = ZipArchive::new(file).map_err(|e| Mc189Error::InvalidData(format!("cannot open JAR for item icon: {e}")))?;
    let model_id = model_for_metadata(id, damage);
    let texture_ref = resolve_model_texture(&mut archive, &format!("item/{model_id}"), &mut HashSet::new())
        .or_else(|| resolve_model_texture(&mut archive, &format!("item/{id}"), &mut HashSet::new()))
        .unwrap_or_else(|| format!("blocks/{model_id}"));
    let texture_path = format!("assets/minecraft/textures/{}.png", texture_ref.trim_end_matches(".png"));
    let mut icon = read_archive_image(&mut archive, &texture_path)
        .or_else(|| read_archive_image(&mut archive, &format!("assets/minecraft/textures/items/{model_id}.png")))
        .or_else(|| read_archive_image(&mut archive, &format!("assets/minecraft/textures/blocks/{model_id}.png")))
        .ok_or_else(|| Mc189Error::InvalidData(format!("no vanilla sprite for item {id} (model {model_id})")))?;
    if icon.width() != 16 || icon.height() != 16 {
        icon = imageops::resize(&icon, 16, 16, imageops::FilterType::Nearest);
    }
    Ok(icon)
}

fn resolve_model_texture(archive: &mut ZipArchive<std::fs::File>, model_id: &str, visiting: &mut HashSet<String>) -> Option<String> {
    if !visiting.insert(model_id.to_owned()) { return None; }
    let path = format!("assets/minecraft/models/{model_id}.json");
    // ZipArchive::by_name returns a ZipFile that keeps a mutable borrow of
    // the archive alive until it is dropped. Close it before recursively
    // opening a parent model from the same archive.
    let bytes = {
        let mut entry = archive.by_name(&path).ok()?;
        let mut bytes = Vec::new();
        entry.read_to_end(&mut bytes).ok()?;
        bytes
    };
    let model: serde_json::Value = serde_json::from_slice(&bytes).ok()?;
    let parent = model.get("parent").and_then(serde_json::Value::as_str).map(|p| p.strip_prefix("minecraft:").unwrap_or(p).to_owned());
    let mut textures = HashMap::<String, String>::new();
    if let Some(parent) = parent {
        if !parent.starts_with("builtin/") {
            let inherited = resolve_model_texture_map(archive, &parent, visiting);
            textures.extend(inherited);
        }
    }
    if let Some(object) = model.get("textures").and_then(serde_json::Value::as_object) {
        for (key, value) in object {
            if let Some(value) = value.as_str() { textures.insert(key.clone(), value.to_owned()); }
        }
    }
    let preference = ["layer0", "layer1", "all", "side", "front", "top", "end", "cross", "particle"];
    for key in preference {
        if let Some(value) = textures.get(key) {
            if let Some(resolved) = resolve_texture_alias(value, &textures) { return Some(resolved); }
        }
    }
    for value in textures.values() {
        if let Some(resolved) = resolve_texture_alias(value, &textures) { return Some(resolved); }
    }
    None
}

fn resolve_model_texture_map(archive: &mut ZipArchive<std::fs::File>, model_id: &str, visiting: &mut HashSet<String>) -> HashMap<String, String> {
    if !visiting.insert(model_id.to_owned()) { return HashMap::new(); }
    let path = format!("assets/minecraft/models/{model_id}.json");
    let model = (|| {
        // Finish reading and drop ZipFile before resolving the parent, which
        // needs another mutable access to this ZipArchive.
        let bytes = {
            let mut entry = archive.by_name(&path).ok()?;
            let mut bytes = Vec::new();
            entry.read_to_end(&mut bytes).ok()?;
            bytes
        };
        serde_json::from_slice::<serde_json::Value>(&bytes).ok()
    })();
    let Some(model) = model else { visiting.remove(model_id); return HashMap::new(); };
    let mut textures = HashMap::new();
    if let Some(parent) = model.get("parent").and_then(serde_json::Value::as_str) {
        let parent = parent.strip_prefix("minecraft:").unwrap_or(parent);
        if !parent.starts_with("builtin/") { textures.extend(resolve_model_texture_map(archive, parent, visiting)); }
    }
    if let Some(object) = model.get("textures").and_then(serde_json::Value::as_object) {
        for (key, value) in object { if let Some(value) = value.as_str() { textures.insert(key.clone(), value.to_owned()); } }
    }
    visiting.remove(model_id);
    textures
}

fn resolve_texture_alias(value: &str, textures: &HashMap<String, String>) -> Option<String> {
    let mut current = value;
    for _ in 0..8 {
        if let Some(alias) = current.strip_prefix('#') { current = textures.get(alias)?; }
        else { return Some(current.trim_start_matches("minecraft:").trim_start_matches("textures/").trim_end_matches(".png").to_owned()); }
    }
    None
}

fn model_for_metadata(id: &str, damage: u16) -> String {
    let variant = usize::from(damage);
    let color_names = ["white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "silver", "cyan", "purple", "blue", "brown", "green", "red", "black"];
    match id {
        "planks" => ["oak_planks", "spruce_planks", "birch_planks", "jungle_planks", "acacia_planks", "dark_oak_planks"].get(variant).unwrap_or(&"oak_planks").to_string(),
        "wool" => format!("{}_wool", color_names.get(variant).unwrap_or(&"white")),
        "stained_glass" => format!("{}_stained_glass", color_names.get(variant).unwrap_or(&"white")),
        "stained_glass_pane" => format!("{}_stained_glass_pane", color_names.get(variant).unwrap_or(&"white")),
        "stained_hardened_clay" => format!("{}_stained_hardened_clay", color_names.get(variant).unwrap_or(&"white")),
        "carpet" => format!("{}_carpet", color_names.get(variant).unwrap_or(&"white")),
        "log" => ["oak_log", "spruce_log", "birch_log", "jungle_log"].get(variant & 3).unwrap_or(&"oak_log").to_string(),
        "log2" => ["acacia_log", "dark_oak_log"].get(variant & 1).unwrap_or(&"acacia_log").to_string(),
        "leaves" => ["oak_leaves", "spruce_leaves", "birch_leaves", "jungle_leaves"].get(variant & 3).unwrap_or(&"oak_leaves").to_string(),
        "leaves2" => ["acacia_leaves", "dark_oak_leaves"].get(variant & 1).unwrap_or(&"acacia_leaves").to_string(),
        "double_plant" => ["sunflower", "syringa", "double_grass", "double_fern", "double_rose", "double_plant_paeonia_top"].get(variant).unwrap_or(&"sunflower").to_string(),
        "stone" => ["stone", "granite", "polished_granite", "diorite", "polished_diorite", "andesite", "polished_andesite"].get(variant).unwrap_or(&"stone").to_string(),
        "dirt" => ["dirt", "coarse_dirt", "podzol"].get(variant).unwrap_or(&"dirt").to_string(),
        "sand" => ["sand", "red_sand"].get(variant).unwrap_or(&"sand").to_string(),
        "sandstone" => ["sandstone", "chiseled_sandstone", "smooth_sandstone"].get(variant).unwrap_or(&"sandstone").to_string(),
        "stonebrick" => ["stonebrick", "mossy_stonebrick", "cracked_stonebrick", "chiseled_stonebrick"].get(variant).unwrap_or(&"stonebrick").to_string(),
        "prismarine" => ["prismarine", "prismarine_bricks", "dark_prismarine"].get(variant).unwrap_or(&"prismarine").to_string(),
        "red_sandstone" => ["red_sandstone", "chiseled_red_sandstone", "smooth_red_sandstone"].get(variant).unwrap_or(&"red_sandstone").to_string(),
        "monster_egg" => ["stone", "cobblestone", "stonebrick", "mossy_stonebrick", "cracked_stonebrick", "chiseled_stonebrick"].get(variant).unwrap_or(&"stone").to_string(),
        "dye" | "ink_sack" => ["dye_black", "dye_red", "dye_green", "cocoa_beans", "dye_blue", "dye_purple", "dye_cyan", "dye_silver", "dye_gray", "dye_pink", "dye_lime", "dye_yellow", "dye_light_blue", "dye_magenta", "dye_orange", "dye_white"].get(variant).unwrap_or(&"dye_black").to_string(),
        "wooden_door" => "oak_door".to_string(),
        "red_flower" => ["poppy", "blue_orchid", "allium", "houstonia", "red_tulip", "orange_tulip", "white_tulip", "pink_tulip", "oxeye_daisy"].get(variant).unwrap_or(&"poppy").to_string(),
        "yellow_flower" => "dandelion".to_string(),
        "tallgrass" => ["tallgrass", "tallgrass", "fern"].get(variant).unwrap_or(&"tallgrass").to_string(),
        _ => id.to_owned(),
    }
}

fn normalize_item_id(raw: &str, damage: u16, models: &HashSet<String>) -> Option<(String, u16)> {
    if let Ok(number) = raw.parse::<u16>() {
        if let Some(id) = legacy_item_name_from_numeric_id(number) { return normalize_item_id(id, damage, models); }
        return None;
    }
    let aliases: &[(&str, &str, u16)] = &[
        ("grass_block", "grass", 0), ("oak_planks", "planks", 0), ("spruce_planks", "planks", 1),
        ("birch_planks", "planks", 2), ("jungle_planks", "planks", 3), ("acacia_planks", "planks", 4),
        ("dark_oak_planks", "planks", 5), ("white_wool", "wool", 0), ("orange_wool", "wool", 1),
        ("magenta_wool", "wool", 2), ("light_blue_wool", "wool", 3), ("yellow_wool", "wool", 4),
        ("lime_wool", "wool", 5), ("pink_wool", "wool", 6), ("gray_wool", "wool", 7),
        ("light_gray_wool", "wool", 8), ("silver_wool", "wool", 8), ("cyan_wool", "wool", 9),
        ("purple_wool", "wool", 10), ("blue_wool", "wool", 11), ("brown_wool", "wool", 12),
        ("green_wool", "wool", 13), ("red_wool", "wool", 14), ("black_wool", "wool", 15),
        ("oak_door", "wooden_door", 0), ("oak_fence", "fence", 0), ("oak_fence_gate", "fence_gate", 0),
        ("iron_ingots", "iron_ingot", 0), ("gold_ingots", "gold_ingot", 0),
        ("lapis", "dye", 4), ("lapis_lazuli", "dye", 4), ("red_dye", "dye", 1),
        ("green_dye", "dye", 2), ("yellow_dye", "dye", 11), ("bone_meal", "dye", 15),
        ("glass_white", "stained_glass", 0), ("glass_orange", "stained_glass", 1),
    ];
    let (id, damage) = if let Some((_, alias_id, alias_damage)) = aliases.iter().find(|(alias, _, _)| *alias == raw) {
        ((*alias_id).to_owned(), *alias_damage)
    } else { (raw.to_owned(), damage) };
    if models.contains(&id) || models.contains(&model_for_metadata(&id, damage)) { Some((id, damage)) } else { None }
}


fn glyph_width(font: &RgbaImage, ch: char) -> u8 {
    let code = ch as u32;
    let index = if (32..=255).contains(&code) { code } else { u32::from(b'?') };
    let sx = (index % 16) * 8;
    let sy = (index / 16) * 8;
    for x in (0..8_u32).rev() {
        for y in 0..8_u32 {
            if font.get_pixel(sx + x, sy + y)[3] > 0 { return (x + 1).min(8) as u8; }
        }
    }
    3
}

fn fallback_icon() -> RgbaImage {
    let mut image = RgbaImage::new(16, 16);
    for y in 0..16 { for x in 0..16 {
        let color = if (x / 4 + y / 4) % 2 == 0 { [210, 30, 210, 255] } else { [40, 30, 40, 255] };
        image.put_pixel(x, y, Rgba(color));
    }}
    image
}

#[derive(Clone, Copy)]
struct SkinPreviewVertex {
    x: f32,
    y: f32,
    z: f32,
    u: f32,
    v: f32,
}

/// CPU equivalent of ModelPlayer/ModelBiped's small inventory render. The model
/// uses the 1.8.9 classic 64x64 skin layout and the same nominal scale=30/16.
/// It is rasterized only over this small GUI model footprint, never at framebuffer size.
fn draw_vanilla_player_model(
    canvas: &mut RgbaImage,
    skin: &RgbaImage,
    center_x: i32,
    model_top_y: i32,
    mouse_x: f32,
    mouse_y: f32,
    render_scale: f32,
) {
    let mut depth = vec![f32::INFINITY; (canvas.width() as usize).saturating_mul(canvas.height() as usize)];
    // GuiInventory.drawEntityOnScreen: atan(mouseX / 40) * 20/40 degrees.
    let atan_x = (mouse_x / 40.0).atan();
    let body_yaw = (atan_x * 20.0).to_radians();
    let head_yaw = (atan_x * 40.0).to_radians();
    // ModelBiped renders the head relative to renderYawOffset; the entity yaw
    // is applied to the entire model afterwards, so pass the difference here.
    let head_relative_yaw = head_yaw - body_yaw;
    let head_pitch = (-(mouse_y / 40.0).atan() * 20.0).to_radians();
    let scale = (30.0_f32 / 16.0_f32) * render_scale.max(1.0);

    // ModelBiped: head (0,0), body (16,16), right arm (40,16), right leg (0,16).
    draw_skin_cuboid(canvas, skin, &mut depth, [-4.0,-8.0,-4.0,4.0,0.0,4.0], [0,0,8,8,8], center_x, model_top_y, scale, body_yaw, Some((head_relative_yaw, head_pitch)), 1.0);
    draw_skin_cuboid(canvas, skin, &mut depth, [-4.0,0.0,-2.0,4.0,12.0,2.0], [16,16,8,12,4], center_x, model_top_y, scale, body_yaw, None, 0.96);
    draw_skin_cuboid(canvas, skin, &mut depth, [-8.0,0.0,-2.0,-4.0,12.0,2.0], [40,16,4,12,4], center_x, model_top_y, scale, body_yaw, None, 0.92);
    draw_skin_cuboid(canvas, skin, &mut depth, [4.0,0.0,-2.0,8.0,12.0,2.0], [32,48,4,12,4], center_x, model_top_y, scale, body_yaw, None, 0.92);
    draw_skin_cuboid(canvas, skin, &mut depth, [-3.9,12.0,-2.0,0.1,24.0,2.0], [0,16,4,12,4], center_x, model_top_y, scale, body_yaw, None, 0.90);
    draw_skin_cuboid(canvas, skin, &mut depth, [-0.1,12.0,-2.0,3.9,24.0,2.0], [16,48,4,12,4], center_x, model_top_y, scale, body_yaw, None, 0.90);

    // ModelPlayer skin layers: hat, jacket, sleeves and pants. The 64x32 legacy
    // texture predates these layers, so only the base ModelBiped is rendered for it.
    if skin.height() >= 64 {
        draw_skin_cuboid(canvas, skin, &mut depth, [-4.5,-8.5,-4.5,4.5,0.5,4.5], [32,0,8,8,8], center_x, model_top_y, scale, body_yaw, Some((head_relative_yaw, head_pitch)), 1.0);
        draw_skin_cuboid(canvas, skin, &mut depth, [-4.25,-0.25,-2.25,4.25,12.25,2.25], [16,32,8,12,4], center_x, model_top_y, scale, body_yaw, None, 0.96);
        draw_skin_cuboid(canvas, skin, &mut depth, [-8.25,-0.25,-2.25,-3.75,12.25,2.25], [40,32,4,12,4], center_x, model_top_y, scale, body_yaw, None, 0.92);
        draw_skin_cuboid(canvas, skin, &mut depth, [3.75,-0.25,-2.25,8.25,12.25,2.25], [48,48,4,12,4], center_x, model_top_y, scale, body_yaw, None, 0.92);
        draw_skin_cuboid(canvas, skin, &mut depth, [-4.15,11.75,-2.25,0.35,24.25,2.25], [0,32,4,12,4], center_x, model_top_y, scale, body_yaw, None, 0.90);
        draw_skin_cuboid(canvas, skin, &mut depth, [-0.35,11.75,-2.25,4.15,24.25,2.25], [0,48,4,12,4], center_x, model_top_y, scale, body_yaw, None, 0.90);
    }
}

fn draw_skin_cuboid(
    canvas: &mut RgbaImage,
    skin: &RgbaImage,
    depth_buffer: &mut [f32],
    bounds: [f32; 6],
    texture: [u32; 5], // u, v, width, height, depth in ModelBox UV units
    center_x: i32,
    model_top_y: i32,
    scale: f32,
    body_yaw: f32,
    head_rotation: Option<(f32, f32)>,
    shade: f32,
) {
    let [x0,y0,z0,x1,y1,z1] = bounds;
    let [u,v,w,h,d] = texture;
    if u + 2*d + 2*w > skin.width() || v + h + d > skin.height() { return; }
    let p000 = [x0,y0,z0]; let p100 = [x1,y0,z0];
    let p110 = [x1,y1,z0]; let p010 = [x0,y1,z0];
    let p001 = [x0,y0,z1]; let p101 = [x1,y0,z1];
    let p111 = [x1,y1,z1]; let p011 = [x0,y1,z1];
    let uf = u as f32; let vf = v as f32; let wf = w as f32; let hf = h as f32; let df = d as f32;
    // Face UVs follow ModelBox's 1.8.9 net: top, bottom, right, front, left, back.
    let faces: [([[f32;3];4], [[f32;2];4], f32); 6] = [
        ([p000,p100,p110,p010], [[uf+df,vf+df],[uf+df+wf,vf+df],[uf+df+wf,vf+df+hf],[uf+df,vf+df+hf]], shade),
        ([p101,p001,p011,p111], [[uf+df+wf+df,vf+df],[uf+df+wf+df+wf,vf+df],[uf+df+wf+df+wf,vf+df+hf],[uf+df+wf+df,vf+df+hf]], shade*0.70),
        ([p001,p000,p010,p011], [[uf,vf+df],[uf+df,vf+df],[uf+df,vf+df+hf],[uf,vf+df+hf]], shade*0.78),
        ([p100,p101,p111,p110], [[uf+df+wf,vf+df],[uf+df+wf+df,vf+df],[uf+df+wf+df,vf+df+hf],[uf+df+wf,vf+df+hf]], shade*0.82),
        ([p001,p101,p100,p000], [[uf+df,vf],[uf+df+wf,vf],[uf+df+wf,vf+df],[uf+df,vf+df]], shade*0.90),
        ([p010,p110,p111,p011], [[uf+df+wf,vf],[uf+df+wf+wf,vf],[uf+df+wf+wf,vf+df],[uf+df+wf,vf+df]], shade*0.58),
    ];
    for (positions, uvs, face_shade) in faces {
        let mut verts = [SkinPreviewVertex { x:0.0,y:0.0,z:0.0,u:0.0,v:0.0 };4];
        for i in 0..4 {
            let mut p = positions[i];
            if let Some((yaw,pitch)) = head_rotation {
                // ModelBiped head rotates around its model origin before entity yaw.
                let (sy,cy) = yaw.sin_cos();
                let nx = p[0]*cy + p[2]*sy;
                let nz = -p[0]*sy + p[2]*cy;
                p[0] = nx; p[2] = nz;
                let (sp,cp) = pitch.sin_cos();
                let ny = p[1]*cp - p[2]*sp;
                let nz = p[1]*sp + p[2]*cp;
                p[1] = ny; p[2] = nz;
            }
            // RenderManager applies the body yaw around the vertical axis. For a
            // yaw-only rotation, model-space Y is unchanged; X/Z follow the same
            // sine/cosine transform used by the entity renderer.
            let (sy,cy) = body_yaw.sin_cos();
            let rx = p[0]*cy + p[2]*sy;
            let rz = -p[0]*sy + p[2]*cy;
            let screen_x = center_x as f32 + rx*scale;
            // Model y=-8 is the crown; y=24 is the sole. Fit all 32 ModelBiped
            // units into the same 60 GUI pixels produced by vanilla scale=30.
            let screen_y = model_top_y as f32 + (p[1] + 8.0)*scale;
            verts[i] = SkinPreviewVertex { x:screen_x,y:screen_y,z:rz,u:uvs[i][0],v:uvs[i][1] };
        }
        raster_skin_triangle(canvas, skin, depth_buffer, [verts[0],verts[1],verts[2]], face_shade);
        raster_skin_triangle(canvas, skin, depth_buffer, [verts[0],verts[2],verts[3]], face_shade);
    }
}

fn raster_skin_triangle(
    canvas: &mut RgbaImage,
    skin: &RgbaImage,
    depth_buffer: &mut [f32],
    vertices: [SkinPreviewVertex;3],
    shade: f32,
) {
    let [a,b,c] = vertices;
    let denom = (b.y-c.y)*(a.x-c.x) + (c.x-b.x)*(a.y-c.y);
    if denom.abs() < 1.0e-5 { return; }
    let min_x = a.x.min(b.x).min(c.x).floor().max(0.0) as i32;
    let max_x = a.x.max(b.x).max(c.x).ceil().min(canvas.width() as f32-1.0) as i32;
    let min_y = a.y.min(b.y).min(c.y).floor().max(0.0) as i32;
    let max_y = a.y.max(b.y).max(c.y).ceil().min(canvas.height() as f32-1.0) as i32;
    if min_x > max_x || min_y > max_y { return; }
    let width = canvas.width() as usize;
    for y in min_y..=max_y {
        for x in min_x..=max_x {
            let px = x as f32 + 0.5; let py = y as f32 + 0.5;
            let wa = ((b.y-c.y)*(px-c.x) + (c.x-b.x)*(py-c.y)) / denom;
            let wb = ((c.y-a.y)*(px-c.x) + (a.x-c.x)*(py-c.y)) / denom;
            let wc = 1.0 - wa - wb;
            if wa < -1.0e-4 || wb < -1.0e-4 || wc < -1.0e-4 { continue; }
            let z = wa*a.z + wb*b.z + wc*c.z;
            let idx = y as usize * width + x as usize;
            if z >= depth_buffer[idx] { continue; }
            let u = wa*a.u + wb*b.u + wc*c.u;
            let v = wa*a.v + wb*b.v + wc*c.v;
            let sx = u.floor().clamp(0.0, skin.width() as f32-1.0) as u32;
            let sy = v.floor().clamp(0.0, skin.height() as f32-1.0) as u32;
            let texel = skin.get_pixel(sx,sy).0;
            // Vanilla skin layers use alpha testing; fully transparent texels neither
            // draw nor occlude the skin underneath.
            if texel[3] < 10 { continue; }
            depth_buffer[idx] = z;
            let shaded = [
                (f32::from(texel[0])*shade).round().clamp(0.0,255.0) as u8,
                (f32::from(texel[1])*shade).round().clamp(0.0,255.0) as u8,
                (f32::from(texel[2])*shade).round().clamp(0.0,255.0) as u8,
                texel[3],
            ];
            blend_pixel(canvas, x, y, shaded);
        }
    }
}

fn draw_image(canvas: &mut RgbaImage, source: &RgbaImage, x: i32, y: i32, sx: u32, sy: u32, width: u32, height: u32) {
    for dy in 0..height {
        for dx in 0..width {
            if sx + dx >= source.width() || sy + dy >= source.height() { continue; }
            let pixel = source.get_pixel(sx + dx, sy + dy).0;
            blend_pixel(canvas, x + dx as i32, y + dy as i32, pixel);
        }
    }
}

fn draw_image_resized(canvas: &mut RgbaImage, source: &RgbaImage, x: i32, y: i32, width: u32, height: u32) {
    for dy in 0..height {
        for dx in 0..width {
            let sx = dx * source.width() / width.max(1);
            let sy = dy * source.height() / height.max(1);
            blend_pixel(canvas, x + dx as i32, y + dy as i32, source.get_pixel(sx, sy).0);
        }
    }
}

/// Draw a scaled sprite while retaining its original texture mapping, but only
/// inside the specified UI frame rectangle (right/bottom exclusive).
fn draw_image_resized_clipped(
    canvas: &mut RgbaImage, source: &RgbaImage, x: i32, y: i32, width: u32, height: u32,
    clip: (i32, i32, i32, i32),
) {
    if width == 0 || height == 0 || source.width() == 0 || source.height() == 0 { return; }
    let left = x.max(clip.0).max(0);
    let top = y.max(clip.1).max(0);
    let right = (x + width as i32).min(clip.2).min(canvas.width() as i32);
    let bottom = (y + height as i32).min(clip.3).min(canvas.height() as i32);
    if left >= right || top >= bottom { return; }
    for dst_y in top..bottom {
        for dst_x in left..right {
            let local_x = (dst_x - x) as u32;
            let local_y = (dst_y - y) as u32;
            let sx = local_x * source.width() / width;
            let sy = local_y * source.height() / height;
            blend_pixel(canvas, dst_x, dst_y, source.get_pixel(sx, sy).0);
        }
    }
}

fn fill_rect(canvas: &mut RgbaImage, left: i32, top: i32, right: i32, bottom: i32, color: [u8; 4]) {
    for y in top.max(0)..bottom.min(canvas.height() as i32) {
        for x in left.max(0)..right.min(canvas.width() as i32) { blend_pixel(canvas, x, y, color); }
    }
}

fn blend_pixel(canvas: &mut RgbaImage, x: i32, y: i32, source: [u8; 4]) {
    if x < 0 || y < 0 || x >= canvas.width() as i32 || y >= canvas.height() as i32 || source[3] == 0 { return; }
    let dst = canvas.get_pixel_mut(x as u32, y as u32);
    let sa = u32::from(source[3]);
    let da = u32::from(dst[3]);
    let out_a = sa + da * (255 - sa) / 255;
    if out_a == 0 { return; }
    for channel in 0..3 {
        let value = u32::from(source[channel]) * sa + u32::from(dst[channel]) * da * (255 - sa) / 255;
        dst[channel] = (value / out_a).min(255) as u8;
    }
    dst[3] = out_a.min(255) as u8;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn inventory_overlay_is_returned_at_scaled_resolution_not_framebuffer_size() {
        let mut ui = test_ui_with_models(&[]);
        ui.screen = UiScreen::Hud;
        let image = ui.render_overlay(1280, 800);
        assert_eq!(image.dimensions(), (427, 267));
    }

    #[test]
    fn hotbar_selection_frame_moves_without_changing_the_scaled_hud_surface() {
        let mut ui = test_ui_with_models(&[]);
        ui.screen = UiScreen::Hud;
        let width = 1280;
        let height = 800;
        let scale = gui_scale_factor(width, height);
        assert_eq!(ui.render_hotbar_selection_sprite(scale).dimensions(), (24 * scale, 22 * scale));
        let first = ui.hotbar_selection_rect_physical(width, height).unwrap();
        assert!(ui.select_hotbar(8));
        let last = ui.hotbar_selection_rect_physical(width, height).unwrap();
        assert_eq!(last.0 - first.0, 8 * 20 * scale as i32);
        assert_eq!(last.1, first.1);
        ui.screen = UiScreen::Inventory;
        assert_eq!(ui.hotbar_selection_rect_physical(width, height), None);
    }

    #[test]
    fn inventory_slot_hover_tracks_vanilla_slot_rectangle_without_recomposing_overlay() {
        let mut ui = test_ui_with_models(&[]);
        ui.screen = UiScreen::Inventory;
        let width = 854;
        let height = 480;
        let scale = gui_scale_factor(width, height);
        let logical_width = width.div_ceil(scale) as i32;
        let logical_height = height.div_ceil(scale) as i32;
        let left = (logical_width - GUI_WIDTH as i32) / 2;
        let top = (logical_height - GUI_HEIGHT as i32) / 2;
        let x = left + 8 + 2 * 18 + 4;
        let y = top + 142 + 4;
        assert!(ui.set_cursor_position((x * scale as i32) as f64, (y * scale as i32) as f64, width, height));
        assert_eq!(ui.hovered_slot, Some(2));
        assert_eq!(ui.hovered_slot_rect_physical(width, height), Some(((left + 8 + 2 * 18) * scale as i32, (top + 142) * scale as i32)));
        assert!(!ui.set_cursor_position((x * scale as i32) as f64, (y * scale as i32) as f64, width, height),
            "moving within the same slot must not dirty the hover state");
    }

    #[test]
    fn authoritative_inventory_replica_updates_without_local_container_mutation() {
        let mut ui = test_ui_with_models(&[]);
        let mut server_inventory = PlayerInventory::default();
        server_inventory.slots[0] = Some(ItemStack { id: "stone".into(), count: 12, damage: 0, nbt_tag: None });
        assert!(ui.apply_authoritative_inventory(server_inventory.clone()));
        assert_eq!(ui.inventory, server_inventory);
        assert!(!ui.apply_authoritative_inventory(server_inventory));
        assert_eq!(ui.slot_animation_ticks[0], 0, "container replication must not impersonate a pickup animation");
    }

    #[test]
    fn hovered_stack_accessor_resolves_inventory_and_armor_slots_without_exposing_index() {
        let mut ui = test_ui_with_models(&[]);
        ui.screen = UiScreen::Inventory;
        ui.inventory.slots[2] = Some(ItemStack { id: "cobblestone".into(), count: 7, damage: 0, nbt_tag: None });
        ui.hovered_slot = Some(2);
        assert_eq!(ui.hovered_stack().map(|stack| (stack.id.as_str(), stack.count)), Some(("cobblestone", 7)));

        ui.inventory.armor_slots[1] = Some(ItemStack { id: "iron_chestplate".into(), count: 1, damage: 4, nbt_tag: None });
        ui.hovered_slot = Some(INVENTORY_SLOTS + 1);
        assert_eq!(ui.hovered_stack().map(|stack| (stack.id.as_str(), stack.damage)), Some(("iron_chestplate", 4)));

        ui.hovered_slot = None;
        assert!(ui.hovered_stack().is_none());
    }

    #[test]
    fn vanilla_player_preview_renders_a_bounded_three_dimensional_model() {
        let mut canvas = RgbaImage::new(176, 166);
        let skin = RgbaImage::from_pixel(64, 64, Rgba([160, 120, 90, 255]));
        draw_vanilla_player_model(&mut canvas, &skin, 51, 15, 0.0, 0.0, 1.0);
        let mut min_x = i32::MAX; let mut min_y = i32::MAX;
        let mut max_x = i32::MIN; let mut max_y = i32::MIN; let mut filled = 0usize;
        for (x, y, pixel) in canvas.enumerate_pixels() {
            if pixel[3] > 0 {
                min_x = min_x.min(x as i32); min_y = min_y.min(y as i32);
                max_x = max_x.max(x as i32); max_y = max_y.max(y as i32); filled += 1;
            }
        }
        assert!(filled > 500, "Steve model should contain textured pixels");
        assert!(min_x >= 30 && max_x <= 72, "unexpected model width: {min_x}..{max_x}");
        assert!(min_y >= 7 && max_y <= 75, "unexpected model height: {min_y}..{max_y}");
    }

    #[test]
    fn player_preview_sprite_uses_framebuffer_resolution() {
        let mut ui = test_ui_with_models(&[]);
        ui.player_skin = RgbaImage::from_pixel(64, 64, Rgba([160, 120, 90, 255]));
        ui.cursor_position = (640.0, 400.0);
        let preview = ui.render_player_preview(3, 125, 50);
        assert_eq!(preview.dimensions(), (240, 246));
        assert!(preview.pixels().filter(|pixel| pixel[3] > 0).count() > 1_000,
            "high-resolution preview should contain the visible 3D player model");
    }

    #[test]
    fn cursor_stack_sprite_is_scaled_and_contains_count() {
        let mut ui = test_ui_with_models(&[]);
        ui.inventory.cursor_stack = Some(ItemStack { id: "diamond".into(), count: 64, damage: 0, nbt_tag: None });
        let sprite = ui.render_cursor_stack_icon(3).expect("carried stack should have a cursor sprite");
        assert_eq!(sprite.dimensions(), (60, 54));
        assert!(sprite.pixels().any(|pixel| pixel[3] > 0), "cursor sprite should contain item pixels");
    }

    #[test]
    fn player_inventory_round_trips_vanilla_player_nbt_layout() {
        let mut inventory = PlayerInventory::default();
        inventory.slots[0] = Some(ItemStack { id: "stone".into(), count: 64, damage: 0, nbt_tag: None });
        inventory.slots[35] = Some(ItemStack { id: "wool".into(), count: 12, damage: 14, nbt_tag: None });
        inventory.armor_slots[3] = Some(ItemStack {
            id: "diamond_helmet".into(), count: 1, damage: 37,
            nbt_tag: Some(NbtTag::Compound(vec![
                ("display".into(), NbtTag::Compound(vec![("Name".into(), NbtTag::String("Named helmet".into()))])),
                ("ench".into(), NbtTag::List(10, vec![NbtTag::Compound(vec![
                    ("id".into(), NbtTag::Short(0)), ("lvl".into(), NbtTag::Short(4)),
                ])])),
            ])),
        });
        inventory.selected_hotbar = 7;
        inventory.cursor_stack = Some(ItemStack { id: "dirt".into(), count: 2, damage: 0, nbt_tag: None });

        let decoded = PlayerInventory::from_player_nbt(Some(&inventory.to_player_nbt())).unwrap();
        assert_eq!(decoded.slots[0].as_ref().unwrap().id, "stone");
        assert_eq!(decoded.slots[0].as_ref().unwrap().count, 64);
        assert_eq!(decoded.slots[35].as_ref().unwrap().damage, 14);
        assert_eq!(decoded.armor_slots[3].as_ref().unwrap().id, "diamond_helmet");
        assert_eq!(decoded.armor_slots[3].as_ref().unwrap().damage, 37);
        assert_eq!(decoded.armor_slots[3].as_ref().unwrap().nbt_tag, inventory.armor_slots[3].as_ref().unwrap().nbt_tag);
        assert_eq!(decoded.selected_hotbar, 7);
        assert!(decoded.cursor_stack.is_none());
    }

    #[test]
    fn empty_vanilla_inventory_list_uses_tag_end_and_loads_as_empty() {
        let player = NbtTag::Compound(vec![("Inventory".into(), NbtTag::List(0, Vec::new()))]);
        let inventory = PlayerInventory::from_player_nbt(Some(&player)).unwrap();
        assert!(inventory.slots.iter().all(Option::is_none));
        let saved = inventory.to_player_nbt();
        assert_eq!(saved.get("Inventory").and_then(NbtTag::as_list).map(|(kind, entries)| (kind, entries.len())), Some((0, 0)));
    }

    #[test]
    fn item_stacks_with_different_nbt_payloads_do_not_merge() {
        let plain = ItemStack { id: "diamond_sword".into(), count: 1, damage: 0, nbt_tag: None };
        let enchanted = ItemStack {
            id: "diamond_sword".into(), count: 1, damage: 0,
            nbt_tag: Some(NbtTag::Compound(vec![("ench".into(), NbtTag::List(10, vec![
                NbtTag::Compound(vec![("id".into(), NbtTag::Short(16)), ("lvl".into(), NbtTag::Short(5))]),
            ]))])),
        };
        let mut inventory = PlayerInventory::default();
        assert_eq!(inventory.insert(&plain, 1), 1);
        assert_eq!(inventory.insert(&enchanted, 1), 1);
        assert_eq!(inventory.slots[0].as_ref().unwrap().count, 1);
        assert_eq!(inventory.slots[1].as_ref().unwrap().nbt_tag, enchanted.nbt_tag);
    }

    #[test]
    fn hotbar_selection_is_limited_to_nine_slots() {
        let mut inventory = PlayerInventory::default();
        assert!(inventory.select_hotbar(8));
        assert_eq!(inventory.selected_hotbar, 8);
        assert!(!inventory.select_hotbar(9));
    }

    #[test]
    fn give_merges_before_occupying_empty_slots_and_respects_stack_limits() {
        let mut inventory = PlayerInventory::default();
        let stack = ItemStack { id: "diamond".into(), count: 1, damage: 0, nbt_tag: None };
        assert_eq!(inventory.insert(&stack, 64), 64);
        assert_eq!(inventory.slots[0].as_ref().unwrap().count, 64);
        assert_eq!(inventory.insert(&stack, 64), 64);
        assert_eq!(inventory.slots[1].as_ref().unwrap().count, 64);
        let sword = ItemStack { id: "diamond_sword".into(), count: 3, damage: 0, nbt_tag: None };
        assert_eq!(inventory.insert(&sword, 3), 3);
        assert_eq!(inventory.slots[2].as_ref().unwrap().count, 1);
        assert_eq!(inventory.slots[3].as_ref().unwrap().count, 1);
        assert_eq!(inventory.slots[4].as_ref().unwrap().count, 1);
    }

    #[test]
    fn shift_click_moves_and_merges_between_hotbar_and_main_inventory() {
        let mut inventory = PlayerInventory::default();
        inventory.slots[0] = Some(ItemStack { id: "stone".into(), count: 40, damage: 0, nbt_tag: None });
        inventory.slots[9] = Some(ItemStack { id: "stone".into(), count: 32, damage: 0, nbt_tag: None });
        assert!(inventory.shift_move_stack(0, 9, 36));
        assert!(inventory.slots[0].is_none());
        assert_eq!(inventory.slots[9].as_ref().unwrap().count, 64);
        assert_eq!(inventory.slots[10].as_ref().unwrap().count, 8);
        assert!(inventory.shift_move_stack(10, 0, 9));
        assert!(inventory.slots[10].is_none());
        assert_eq!(inventory.slots[0].as_ref().unwrap().count, 8);
    }

    #[test]
    fn shift_click_auto_equips_armor_and_can_move_it_back() {
        let mut inventory = PlayerInventory::default();
        inventory.slots[0] = Some(ItemStack { id: "iron_helmet".into(), count: 1, damage: 0, nbt_tag: None });
        assert!(inventory.shift_auto_equip(0));
        assert!(inventory.slots[0].is_none());
        assert_eq!(inventory.armor_slots[3].as_ref().unwrap().id, "iron_helmet");
        assert!(inventory.shift_move_armor_to_inventory(3));
        assert!(inventory.armor_slots[3].is_none());
        assert_eq!(inventory.slots[0].as_ref().unwrap().id, "iron_helmet");
    }

    #[test]
    fn right_click_splits_stack_and_places_one_item() {
        let mut inventory = PlayerInventory::default();
        inventory.slots[0] = Some(ItemStack { id: "stone".into(), count: 9, damage: 0, nbt_tag: None });
        assert!(inventory.click_stack(0, true));
        assert_eq!(inventory.cursor_stack.as_ref().unwrap().count, 5);
        assert_eq!(inventory.slots[0].as_ref().unwrap().count, 4);
        assert!(inventory.click_stack(1, true));
        assert_eq!(inventory.cursor_stack.as_ref().unwrap().count, 4);
        assert_eq!(inventory.slots[1].as_ref().unwrap().count, 1);
    }

    #[test]
    fn stack_limits_match_common_vanilla_189_items() {
        assert_eq!(mc189_server::inventory::max_stack_size_for_item("diamond_sword"), 1);
        assert_eq!(mc189_server::inventory::max_stack_size_for_item("water_bucket"), 1);
        assert_eq!(mc189_server::inventory::max_stack_size_for_item("bucket"), 1);
        assert_eq!(mc189_server::inventory::max_stack_size_for_item("snowball"), 16);
        assert_eq!(mc189_server::inventory::max_stack_size_for_item("spawn_egg"), 64);
        assert_eq!(mc189_server::inventory::max_stack_size_for_item("written_book"), 1);
        assert_eq!(mc189_server::inventory::max_stack_size_for_item("filled_map"), 1);
        assert_eq!(mc189_server::inventory::max_stack_size_for_item("map"), 64);
        assert_eq!(mc189_server::inventory::max_stack_size_for_item("wooden_door"), 64);
        assert_eq!(mc189_server::inventory::max_stack_size_for_item("diamond"), 64);
    }

    #[test]
    fn stack_change_arms_five_tick_vanilla_pop_and_decays_to_normal_scale() {
        let mut ui = test_ui_with_models(&["cobblestone"]);
        ui.reset_inventory_animation_tracking();
        ui.inventory.slots[0] = Some(ItemStack { id: "cobblestone".into(), count: 1, damage: 0, nbt_tag: None });
        assert!(ui.sync_inventory_animations());
        assert_eq!(ui.slot_animation_ticks[0], 5);
        let (sx, sy) = ui.slot_animation_scale(0);
        assert!((sx - 0.5).abs() < 0.0001);
        assert!((sy - 1.5).abs() < 0.0001);
        for expected in [4, 3, 2, 1, 0] {
            assert!(ui.tick_inventory_animations());
            assert_eq!(ui.slot_animation_ticks[0], expected);
        }
        assert_eq!(ui.slot_animation_scale(0), (1.0, 1.0));
    }

    #[test]
    fn pop_animation_interpolates_smoothly_between_fixed_ticks() {
        let mut ui = test_ui_with_models(&["stone"]);
        ui.inventory.slots[0] = Some(ItemStack { id: "stone".into(), count: 1, damage: 0, nbt_tag: None });
        ui.reset_inventory_animation_tracking();
        ui.inventory.slots[0].as_mut().unwrap().count = 2;
        assert!(ui.sync_inventory_animations());
        let first = ui.slot_animation_scale(0);
        ui.animation_partial_ticks = 0.5;
        let half_tick = ui.slot_animation_scale(0);
        assert!(half_tick.0 > first.0 && half_tick.0 < 1.0);
        assert!(half_tick.1 < first.1 && half_tick.1 > 1.0);
    }

    #[test]
    fn mutation_discovered_by_world_tick_keeps_full_first_pop_frame() {
        let mut ui = test_ui_with_models(&["stone"]);
        ui.inventory.slots[0] = Some(ItemStack { id: "stone".into(), count: 1, damage: 0, nbt_tag: None });
        assert!(ui.tick_inventory_animations());
        assert_eq!(ui.slot_animation_ticks[0], 5);
        assert_eq!(ui.slot_animation_scale(0), (0.5, 1.5));
    }

    #[test]
    fn existing_saved_stacks_do_not_pop_when_animation_tracking_is_reset() {
        let mut ui = test_ui_with_models(&["stone"]);
        ui.inventory.slots[0] = Some(ItemStack { id: "stone".into(), count: 32, damage: 0, nbt_tag: None });
        ui.reset_inventory_animation_tracking();
        assert!(!ui.sync_inventory_animations());
        assert_eq!(ui.slot_animation_ticks[0], 0);
    }

    #[test]
    fn increasing_an_existing_stack_arms_the_same_pop_animation() {
        let mut ui = test_ui_with_models(&["cobblestone"]);
        ui.inventory.slots[0] = Some(ItemStack { id: "cobblestone".into(), count: 1, damage: 0, nbt_tag: None });
        ui.reset_inventory_animation_tracking();
        ui.inventory.slots[0].as_mut().unwrap().count = 2;
        assert!(ui.sync_inventory_animations());
        assert_eq!(ui.slot_animation_ticks[0], 5);
        assert_eq!(ui.slot_animation_scale(0), (0.5, 1.5));
    }

    #[test]
    fn decreasing_a_stack_count_arms_pop_animation_too() {
        let mut ui = test_ui_with_models(&["cobblestone"]);
        ui.inventory.slots[0] = Some(ItemStack { id: "cobblestone".into(), count: 2, damage: 0, nbt_tag: None });
        ui.reset_inventory_animation_tracking();
        ui.inventory.slots[0].as_mut().unwrap().count = 1;
        assert!(ui.sync_inventory_animations());
        assert_eq!(ui.slot_animation_ticks[0], 5);
    }

    #[test]
    fn ground_pickups_update_hotbar_count_and_pop_without_opening_inventory() {
        let mut ui = test_ui_with_models(&["cobblestone"]);
        ui.reset_inventory_animation_tracking();
        let cobblestone = ItemStack { id: "cobblestone".into(), count: 1, damage: 0, nbt_tag: None };

        assert_eq!(ui.screen, UiScreen::Hud);
        assert_eq!(ui.inventory.insert(&cobblestone, 1), 1);
        assert!(ui.sync_inventory_animations());
        assert_eq!(ui.inventory.slots[0].as_ref().map(|stack| stack.count), Some(1));
        assert_eq!(ui.slot_animation_ticks[0], 5);

        assert_eq!(ui.inventory.insert(&cobblestone, 1), 1);
        assert!(ui.sync_inventory_animations());
        assert_eq!(ui.inventory.slots[0].as_ref().map(|stack| stack.count), Some(2));
        assert_eq!(ui.slot_animation_ticks[0], 5);
    }

    #[test]
    fn animated_hotbar_icon_cannot_draw_outside_its_sixteen_pixel_slot() {
        let mut ui = test_ui_with_models(&["stone"]);
        ui.screen = UiScreen::Hud;
        let before = ui.render_overlay(427, 267);
        ui.inventory.slots[0] = Some(ItemStack { id: "stone".into(), count: 1, damage: 0, nbt_tag: None });
        ui.slot_animation_ticks[0] = 5;
        let after = ui.render_overlay(427, 267);
        let slot_x = 427_i32 / 2 - 90 + 2;
        let slot_y = 267_i32 - 16 - 3;
        for y in 0..267_i32 {
            for x in 0..427_i32 {
                if (slot_x..slot_x + 16).contains(&x) && (slot_y..slot_y + 16).contains(&y) { continue; }
                assert_eq!(before.get_pixel(x as u32, y as u32), after.get_pixel(x as u32, y as u32),
                    "animated icon leaked outside its slot at ({x},{y})");
            }
        }
    }

    #[test]
    fn inventory_cursor_move_does_not_arm_receive_pop() {
        let mut ui = test_ui_with_models(&["cobblestone"]);
        ui.screen = UiScreen::Inventory;
        ui.inventory.cursor_stack = Some(ItemStack { id: "cobblestone".into(), count: 12, damage: 0, nbt_tag: None });
        ui.reset_inventory_animation_tracking();
        let width = 427_u32;
        let height = 267_u32;
        let scale = gui_scale_factor(width, height) as i32;
        let left = (width.div_ceil(scale as u32) as i32 - GUI_WIDTH as i32) / 2;
        let top = (height.div_ceil(scale as u32) as i32 - GUI_HEIGHT as i32) / 2;
        // First main-inventory slot (slot 9), where the cursor stack is placed.
        let x = (left + 8 + 1) * scale;
        let y = (top + 84 + 1) * scale;
        assert!(ui.click_slot(f64::from(x), f64::from(y), width, height, false));
        assert!(!ui.sync_inventory_animations());
        assert_eq!(ui.slot_animation_ticks[9], 0);
    }

    #[test]
    fn full_cube_block_items_keep_the_isometric_block_icon_path() {
        assert!(InventoryUi::is_full_cube_inventory_item("cobblestone"));
        assert!(InventoryUi::is_full_cube_inventory_item("stone"));
        assert!(InventoryUi::is_full_cube_inventory_item("grass"));
        assert!(!InventoryUi::is_full_cube_inventory_item("diamond"));
        assert!(!InventoryUi::is_full_cube_inventory_item("iron_pickaxe"));
    }

    #[test]
    fn container_rearrangement_does_not_trigger_receive_item_pop() {
        let mut ui = test_ui_with_models(&["cobblestone"]);
        ui.inventory.slots[0] = Some(ItemStack { id: "cobblestone".into(), count: 12, damage: 0, nbt_tag: None });
        ui.reset_inventory_animation_tracking();
        ui.slot_animation_ticks[0] = 3;
        // Moving the stack between slots is a container operation, not a pickup.
        let moved = ui.inventory.slots[0].take();
        ui.inventory.slots[9] = moved;
        ui.suppress_container_move_pop();
        assert!(!ui.sync_inventory_animations());
        assert_eq!(ui.slot_animation_ticks[0], 0);
        assert_eq!(ui.slot_animation_ticks[9], 0);
    }


    #[test]
    fn numeric_item_names_cover_tools_and_distinguish_slime_block_from_ball() {
        assert_eq!(legacy_item_name_from_numeric_id(278), Some("diamond_pickaxe"));
        assert_eq!(legacy_item_name_from_numeric_id(165), Some("slime_block"));
        assert_eq!(legacy_item_name_from_numeric_id(341), Some("slime_ball"));
        assert_eq!(legacy_item_name_from_numeric_id(343), Some("furnace_minecart"));
        assert_eq!(legacy_item_name_from_numeric_id(183), Some("spruce_fence_gate"));
        assert_eq!(legacy_item_name_from_numeric_id(193), Some("spruce_door"));
    }

    #[test]
    fn item_name_resolves_to_vanilla_numeric_drop_id() {
        assert_eq!(legacy_numeric_id_from_item_name("cobblestone"), Some(4));
        assert_eq!(legacy_numeric_id_from_item_name("stone"), Some(1));
        assert_eq!(legacy_numeric_id_from_item_name("diamond_pickaxe"), Some(278));
        assert_eq!(legacy_numeric_id_from_item_name("iron_door"), Some(330));
        assert_eq!(legacy_numeric_id_from_item_name("redstone"), Some(331));
        assert_eq!(legacy_numeric_id_from_item_name("not_a_vanilla_item"), None);
    }

    #[test]
    fn animated_icon_is_clipped_to_the_requested_ui_frame() {
        let mut canvas = RgbaImage::new(10, 10);
        let mut source = RgbaImage::new(2, 2);
        for pixel in source.pixels_mut() { *pixel = Rgba([255, 255, 255, 255]); }
        draw_image_resized_clipped(&mut canvas, &source, 0, 0, 10, 10, (3, 2, 7, 8));
        for y in 0..10 { for x in 0..10 {
            let inside = (3..7).contains(&x) && (2..8).contains(&y);
            assert_eq!(canvas.get_pixel(x, y)[3] > 0, inside, "pixel ({x},{y}) escaped its clip rectangle");
        }}
    }


    #[test]
    fn q_drops_one_and_ctrl_q_drops_the_remaining_stack_with_nbt() {
        let mut inventory = PlayerInventory::default();
        let tag = NbtTag::Compound(vec![("display".into(), NbtTag::Compound(vec![("Name".into(), NbtTag::String("Named pickaxe".into()))]))]);
        inventory.slots[0] = Some(ItemStack { id: "diamond_pickaxe".into(), count: 3, damage: 42, nbt_tag: Some(tag.clone()) });
        let one = inventory.take_stack_for_drop(0, false).unwrap();
        assert_eq!(one.count, 1);
        assert_eq!(one.damage, 42);
        assert_eq!(one.nbt_tag, Some(tag.clone()));
        assert_eq!(inventory.slots[0].as_ref().unwrap().count, 2);
        let rest = inventory.take_stack_for_drop(0, true).unwrap();
        assert_eq!(rest.count, 2);
        assert_eq!(rest.nbt_tag, Some(tag));
        assert!(inventory.slots[0].is_none());
    }

    fn test_ui_with_models(models: &[&str]) -> InventoryUi {
        InventoryUi {
            inventory: PlayerInventory::default(),
            screen: UiScreen::Hud,
            chat_input: String::new(),
            cursor_position: (0.0, 0.0),
            hovered_slot: None,
            chat_lines: VecDeque::new(),
            item_models: models.iter().map(|model| (*model).to_owned()).collect(),
            inventory_background: RgbaImage::new(256, 256),
            widgets: RgbaImage::new(256, 256),
            ascii_font: RgbaImage::new(128, 128),
            player_skin: RgbaImage::new(64, 64),
            item_icon_cache: HashMap::new(),
            jar_path: std::path::PathBuf::new(),
            slot_animation_ticks: [0; 40],
            animation_partial_ticks: 0.0,
            observed_slot_stacks: vec![None; 40],
        }
    }

    #[test]
    fn give_command_is_parsed_for_server_without_mutating_client_inventory() {
        let mut ui = test_ui_with_models(&["diamond", "wool"]);
        let command = ui.parse_server_inventory_command("give @p minecraft:diamond 64");
        assert_eq!(command, Some(InventoryServerCommand::Give { item_id: "diamond".into(), count: 64, damage: 0 }));
        assert!(ui.inventory.slots.iter().all(Option::is_none));
        let command = ui.parse_server_inventory_command("give @p minecraft:wool 64 14");
        assert_eq!(command, Some(InventoryServerCommand::Give { item_id: "wool".into(), count: 64, damage: 14 }));
        assert!(ui.inventory.slots.iter().all(Option::is_none));
    }

    #[test]
    fn clear_command_is_a_server_intent_and_does_not_clear_client_replica() {
        let mut ui = test_ui_with_models(&["diamond", "iron_helmet"]);
        ui.inventory.slots[0] = Some(ItemStack { id: "diamond".into(), count: 64, damage: 0, nbt_tag: None });
        ui.inventory.armor_slots[3] = Some(ItemStack { id: "iron_helmet".into(), count: 1, damage: 0, nbt_tag: None });
        ui.inventory.cursor_stack = Some(ItemStack { id: "diamond".into(), count: 1, damage: 0, nbt_tag: None });
        assert_eq!(ui.parse_server_inventory_command("clear"), Some(InventoryServerCommand::Clear));
        assert!(ui.inventory.slots[0].is_some());
        assert!(ui.inventory.armor_slots[3].is_some());
        assert!(ui.inventory.cursor_stack.is_some());
    }

    #[test]
    fn metadata_aliases_follow_legacy_1_8_names() {
        let registry = ["planks", "wool", "wooden_door", "red_flower"].into_iter().map(str::to_owned).collect();
        assert_eq!(normalize_item_id("oak_planks", 0, &registry), Some(("planks".into(), 0)));
        assert_eq!(normalize_item_id("red_wool", 0, &registry), Some(("wool".into(), 14)));
        assert_eq!(normalize_item_id("oak_door", 0, &registry), Some(("wooden_door".into(), 0)));
        assert_eq!(model_for_metadata("stained_glass", 11), "blue_stained_glass");
        assert_eq!(model_for_metadata("leaves2", 1), "dark_oak_leaves");
        assert_eq!(model_for_metadata("log2", 0), "acacia_log");
        assert_eq!(model_for_metadata("double_plant", 2), "double_grass");
        assert_eq!(model_for_metadata("double_plant", 5), "double_plant_paeonia_top");
    }
}
