//! First, deliberately limited mapper from vanilla 1.8.9 numeric block IDs + metadata
//! to the variant selectors used by classic blockstate JSON files.
//!
//! This is an audit stage, not a complete block registry. Unknown IDs and states are
//! reported instead of being guessed. Fluids are classified separately because the
//! classic client renders them through a fluid renderer rather than ordinary cube models.

use mc189_core::{Mc189Error, Result};
use mc189_storage::{decode_chunk, RegionHeader};
use serde_json::Value;
use std::collections::{BTreeMap, HashMap, HashSet};
use std::fs::{self, File};
use std::io::Read;
use std::path::{Path, PathBuf};
use zip::ZipArchive;

const MAX_JSON_BYTES: u64 = 4 * 1024 * 1024;

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) enum LegacyTarget {
    Air,
    Fluid(&'static str),
    /// A state whose world appearance is determined by classic numeric metadata or
    /// the legacy block renderer, not by a direct blockstate JSON selector.
    LegacyVisual(&'static str),
    /// A model family whose selected variant depends on world context as well as ID/meta.
    ContextualModel { blockstate: &'static str, variants: &'static [&'static str] },
    /// Legacy log metadata carries both species and axis; texture assignment is performed
    /// after resolving the vanilla log/log2 blockstate family.
    Log { blockstate: &'static str, species: &'static str, axis: &'static str },
    /// Legacy stone metadata selects a vanilla texture while retaining the full-cube stone model.
    StoneVariant { texture: &'static str },
    /// Legacy leaves metadata selects one of six textures and requires biome tint.
    Leaves { model: &'static str, texture: &'static str },
    /// Cross-plane vegetation models selected by classic numeric metadata.
    PlantModel { model: &'static str, tint: bool },
    /// A legacy metadata state that resolves straight to a model file instead of a
    /// blockstates JSON file in the vanilla 1.8.9 resource pipeline.
    DirectModel { model: &'static str },
    Model { blockstate: &'static str, variant: String },
}

fn model(blockstate: &'static str, variant: impl Into<String>) -> LegacyTarget {
    LegacyTarget::Model { blockstate, variant: variant.into() }
}

fn direct_model(model: &'static str) -> LegacyTarget {
    LegacyTarget::DirectModel { model }
}


// Full classic selector sets for context-derived stair and door states. These
// are validated against the actual 1.8.9 blockstate JSON by the coverage audit.
const STAIR_VARIANTS: &[&str] = &[
    "facing=east,half=bottom,shape=straight",
    "facing=west,half=bottom,shape=straight",
    "facing=south,half=bottom,shape=straight",
    "facing=north,half=bottom,shape=straight",
    "facing=east,half=bottom,shape=outer_left",
    "facing=west,half=bottom,shape=outer_left",
    "facing=south,half=bottom,shape=outer_left",
    "facing=north,half=bottom,shape=outer_left",
    "facing=east,half=bottom,shape=outer_right",
    "facing=west,half=bottom,shape=outer_right",
    "facing=south,half=bottom,shape=outer_right",
    "facing=north,half=bottom,shape=outer_right",
    "facing=east,half=bottom,shape=inner_left",
    "facing=west,half=bottom,shape=inner_left",
    "facing=south,half=bottom,shape=inner_left",
    "facing=north,half=bottom,shape=inner_left",
    "facing=east,half=bottom,shape=inner_right",
    "facing=west,half=bottom,shape=inner_right",
    "facing=south,half=bottom,shape=inner_right",
    "facing=north,half=bottom,shape=inner_right",
    "facing=east,half=top,shape=straight",
    "facing=west,half=top,shape=straight",
    "facing=south,half=top,shape=straight",
    "facing=north,half=top,shape=straight",
    "facing=east,half=top,shape=outer_left",
    "facing=west,half=top,shape=outer_left",
    "facing=south,half=top,shape=outer_left",
    "facing=north,half=top,shape=outer_left",
    "facing=east,half=top,shape=outer_right",
    "facing=west,half=top,shape=outer_right",
    "facing=south,half=top,shape=outer_right",
    "facing=north,half=top,shape=outer_right",
    "facing=east,half=top,shape=inner_left",
    "facing=west,half=top,shape=inner_left",
    "facing=south,half=top,shape=inner_left",
    "facing=north,half=top,shape=inner_left",
    "facing=east,half=top,shape=inner_right",
    "facing=west,half=top,shape=inner_right",
    "facing=south,half=top,shape=inner_right",
    "facing=north,half=top,shape=inner_right"
];
const DOOR_VARIANTS: &[&str] = &[
    "facing=east,half=lower,hinge=left,open=false",
    "facing=west,half=lower,hinge=left,open=false",
    "facing=south,half=lower,hinge=left,open=false",
    "facing=north,half=lower,hinge=left,open=false",
    "facing=east,half=lower,hinge=left,open=true",
    "facing=west,half=lower,hinge=left,open=true",
    "facing=south,half=lower,hinge=left,open=true",
    "facing=north,half=lower,hinge=left,open=true",
    "facing=east,half=lower,hinge=right,open=false",
    "facing=west,half=lower,hinge=right,open=false",
    "facing=south,half=lower,hinge=right,open=false",
    "facing=north,half=lower,hinge=right,open=false",
    "facing=east,half=lower,hinge=right,open=true",
    "facing=west,half=lower,hinge=right,open=true",
    "facing=south,half=lower,hinge=right,open=true",
    "facing=north,half=lower,hinge=right,open=true",
    "facing=east,half=upper,hinge=left,open=false",
    "facing=west,half=upper,hinge=left,open=false",
    "facing=south,half=upper,hinge=left,open=false",
    "facing=north,half=upper,hinge=left,open=false",
    "facing=east,half=upper,hinge=left,open=true",
    "facing=west,half=upper,hinge=left,open=true",
    "facing=south,half=upper,hinge=left,open=true",
    "facing=north,half=upper,hinge=left,open=true",
    "facing=east,half=upper,hinge=right,open=false",
    "facing=west,half=upper,hinge=right,open=false",
    "facing=south,half=upper,hinge=right,open=false",
    "facing=north,half=upper,hinge=right,open=false",
    "facing=east,half=upper,hinge=right,open=true",
    "facing=west,half=upper,hinge=right,open=true",
    "facing=south,half=upper,hinge=right,open=true",
    "facing=north,half=upper,hinge=right,open=true"
];

const LEGACY_DYE_MODEL_SUFFIXES: [&str; 16] = [
    "white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
    "silver", "cyan", "purple", "blue", "brown", "green", "red", "black",
];

fn colored_direct_model(prefix: &'static str, metadata: u8) -> Option<LegacyTarget> {
    let color = *LEGACY_DYE_MODEL_SUFFIXES.get(usize::from(metadata))?;
    let model_name = match prefix {
        "wool" => match color {
            "white" => "white_wool", "orange" => "orange_wool", "magenta" => "magenta_wool",
            "light_blue" => "light_blue_wool", "yellow" => "yellow_wool", "lime" => "lime_wool",
            "pink" => "pink_wool", "gray" => "gray_wool", "silver" => "silver_wool",
            "cyan" => "cyan_wool", "purple" => "purple_wool", "blue" => "blue_wool",
            "brown" => "brown_wool", "green" => "green_wool", "red" => "red_wool", "black" => "black_wool",
            _ => return None,
        },
        "glass" => match color {
            "white" => "glass_white", "orange" => "glass_orange", "magenta" => "glass_magenta",
            "light_blue" => "glass_light_blue", "yellow" => "glass_yellow", "lime" => "glass_lime",
            "pink" => "glass_pink", "gray" => "glass_gray", "silver" => "glass_silver",
            "cyan" => "glass_cyan", "purple" => "glass_purple", "blue" => "glass_blue",
            "brown" => "glass_brown", "green" => "glass_green", "red" => "glass_red", "black" => "glass_black",
            _ => return None,
        },
        "hardened_clay" => match color {
            "white" => "hardened_clay_white", "orange" => "hardened_clay_orange", "magenta" => "hardened_clay_magenta",
            "light_blue" => "hardened_clay_light_blue", "yellow" => "hardened_clay_yellow", "lime" => "hardened_clay_lime",
            "pink" => "hardened_clay_pink", "gray" => "hardened_clay_gray", "silver" => "hardened_clay_silver",
            "cyan" => "hardened_clay_cyan", "purple" => "hardened_clay_purple", "blue" => "hardened_clay_blue",
            "brown" => "hardened_clay_brown", "green" => "hardened_clay_green", "red" => "hardened_clay_red", "black" => "hardened_clay_black",
            _ => return None,
        },
        "carpet" => match color {
            "white" => "carpet_white", "orange" => "carpet_orange", "magenta" => "carpet_magenta",
            "light_blue" => "carpet_light_blue", "yellow" => "carpet_yellow", "lime" => "carpet_lime",
            "pink" => "carpet_pink", "gray" => "carpet_gray", "silver" => "carpet_silver",
            "cyan" => "carpet_cyan", "purple" => "carpet_purple", "blue" => "carpet_blue",
            "brown" => "carpet_brown", "green" => "carpet_green", "red" => "carpet_red", "black" => "carpet_black",
            _ => return None,
        },
        _ => return None,
    };
    Some(direct_model(model_name))
}

/// Map the currently supported vanilla 1.8.9 numeric IDs and metadata values.
/// `None` is intentional: unsupported states must never silently substitute a model.
pub(crate) fn map_legacy_block(id: u16, metadata: u8) -> Option<LegacyTarget> {
    let target = match id {
        0 => LegacyTarget::Air,
        8 | 9 => LegacyTarget::Fluid("water"),
        10 | 11 => LegacyTarget::Fluid("lava"),
        // Vanilla 1.8.9 uses the same full-cube model for all seven stone
        // variants. Metadata selects the texture; it does not select another
        // blockstate/model file.
        1 => match metadata {
            0 => model("stone", "normal"),
            1 => LegacyTarget::StoneVariant { texture: "stone_granite" },
            2 => LegacyTarget::StoneVariant { texture: "stone_granite_smooth" },
            3 => LegacyTarget::StoneVariant { texture: "stone_diorite" },
            4 => LegacyTarget::StoneVariant { texture: "stone_diorite_smooth" },
            5 => LegacyTarget::StoneVariant { texture: "stone_andesite" },
            6 => LegacyTarget::StoneVariant { texture: "stone_andesite_smooth" },
            // Reserved pre-flattening stone metadata has no vanilla model; do not
            // quietly render it as a plausible texture.
            _ => return None,
        },
        // Grass block's model depends on the neighbor-derived `snowy` property.
        // Check the full family rather than pretending metadata alone chooses it.
        2 => LegacyTarget::ContextualModel {
            blockstate: "grass",
            variants: &["snowy=false", "snowy=true"],
        },
        3 => match metadata {
            0 => model("dirt", "normal"),
            1 => direct_model("coarse_dirt"),
            2 => direct_model("podzol"),
            _ => return None,
        },
        // Sapling metadata stores species in the low three bits and growth stage in bit 3.
        // Its model is a crossed-plane plant, selected by both properties in blockstates/sapling.json.
        6 => {
            let species = match metadata & 0x07 {
                0 => "oak", 1 => "spruce", 2 => "birch", 3 => "jungle",
                4 => "acacia", 5 => "dark_oak", _ => return None,
            };
            let stage = if metadata & 0x08 == 0 { 0 } else { 1 };
            LegacyTarget::Model { blockstate: "sapling", variant: format!("stage={stage},type={species}") }
        },
        // Ordinary glass has its own blockstate/model and alpha texture. It must not be
        // treated as an unknown state merely because it is non-opaque.
        20 => model("glass", "normal"),
        // Common full-block states with direct selectors in the vanilla 1.8.9 JAR.
        4 => match metadata {
            0 => model("cobblestone", "normal"),
            _ => return None,
        },
        // In this 1.8.9 client, the six legacy plank species resolve to direct model
        // files (oak_planks.json, spruce_planks.json, etc.). There is no
        // assets/minecraft/blockstates/planks.json, so do not invent such a selector.
        5 => match metadata {
            0 => direct_model("oak_planks"),
            1 => direct_model("spruce_planks"),
            2 => direct_model("birch_planks"),
            3 => direct_model("jungle_planks"),
            4 => direct_model("acacia_planks"),
            5 => direct_model("dark_oak_planks"),
            _ => return None,
        },
        7 => model("bedrock", "normal"),
        12 => match metadata {
            0 => model("sand", "normal"),
            1 => direct_model("red_sand"),
            _ => return None,
        },
        13 => model("gravel", "normal"),
        14 => model("gold_ore", "normal"),
        15 => model("iron_ore", "normal"),
        16 => model("coal_ore", "normal"),
        30 => match metadata {
            0 => model("web", "normal"),
            _ => return None,
        },
        // Colored wool uses sixteen separate full-cube models in the vanilla JAR.
        35 => colored_direct_model("wool", metadata)?,
        // Dead bush and flowers use non-cubic cross-plane models. Their classic species
        // metadata is translated to the corresponding vanilla model/blockstate selector.
        32 => match metadata {
            0 => LegacyTarget::PlantModel { model: "block/dead_bush", tint: false },
            _ => return None,
        },
        37 => match metadata {
            0 => model("dandelion", "normal"),
            _ => return None,
        },
        38 => {
            let variant = match metadata {
                0 => "poppy", 1 => "blue_orchid", 2 => "allium", 3 => "houstonia",
                4 => "red_tulip", 5 => "orange_tulip", 6 => "white_tulip",
                7 => "pink_tulip", 8 => "oxeye_daisy", _ => return None,
            };
            model(variant, "normal")
        },
        39 => match metadata {
            0 => model("brown_mushroom", "normal"),
            _ => return None,
        },
        40 => match metadata {
            0 => model("red_mushroom", "normal"),
            _ => return None,
        },
        48 => match metadata {
            0 => model("mossy_cobblestone", "normal"),
            _ => return None,
        },
        49 => match metadata {
            0 => model("obsidian", "normal"),
            _ => return None,
        },
        // Torch metadata selects its mounting direction. State-level model rotation
        // is still a later rendering step; this only resolves the appropriate JSON key.
        50 => match metadata {
            1 => model("torch", "facing=east"),
            2 => model("torch", "facing=west"),
            3 => model("torch", "facing=south"),
            4 => model("torch", "facing=north"),
            5 => model("torch", "facing=up"),
            _ => return None,
        },
        51 => match metadata {
            0..=15 => LegacyTarget::LegacyVisual("fire: age and neighbor-dependent flame geometry/texture behavior"),
            _ => return None,
        },
        // The spawner's cage is a normal blockstate model; its spinning entity preview
        // is a separate tile-entity renderer that must be added later. Preserve that
        // distinction rather than replacing the cage with a generic cube.
        52 => match metadata {
            0 => model("mob_spawner", "normal"),
            _ => return None,
        },
        54 => match metadata {
            2..=5 => LegacyTarget::LegacyVisual("chest: tile-entity renderer, facing and lid animation"),
            _ => return None,
        },
        // Crafting table is a conventional cube model in this resource set.
        58 => match metadata {
            0 => model("crafting_table", "normal"),
            _ => return None,
        },
        // Stair state combines the metadata facing/half with a neighbour-derived shape.
        // The blockstate variant is selected later from the surrounding world, as in 1.8.9.
        53 => LegacyTarget::ContextualModel { blockstate: "oak_stairs", variants: STAIR_VARIANTS },
        67 => LegacyTarget::ContextualModel { blockstate: "stone_stairs", variants: STAIR_VARIANTS },
        108 => LegacyTarget::ContextualModel { blockstate: "brick_stairs", variants: STAIR_VARIANTS },
        109 => LegacyTarget::ContextualModel { blockstate: "stone_brick_stairs", variants: STAIR_VARIANTS },
        114 => LegacyTarget::ContextualModel { blockstate: "nether_brick_stairs", variants: STAIR_VARIANTS },
        128 => LegacyTarget::ContextualModel { blockstate: "sandstone_stairs", variants: STAIR_VARIANTS },
        134 => LegacyTarget::ContextualModel { blockstate: "spruce_stairs", variants: STAIR_VARIANTS },
        135 => LegacyTarget::ContextualModel { blockstate: "birch_stairs", variants: STAIR_VARIANTS },
        136 => LegacyTarget::ContextualModel { blockstate: "jungle_stairs", variants: STAIR_VARIANTS },
        156 => LegacyTarget::ContextualModel { blockstate: "quartz_stairs", variants: STAIR_VARIANTS },
        163 => LegacyTarget::ContextualModel { blockstate: "acacia_stairs", variants: STAIR_VARIANTS },
        164 => LegacyTarget::ContextualModel { blockstate: "dark_oak_stairs", variants: STAIR_VARIANTS },
        180 => LegacyTarget::ContextualModel { blockstate: "red_sandstone_stairs", variants: STAIR_VARIANTS },
        // Legacy door halves share one numeric ID. Both halves are rendered from the
        // full state assembled from current and adjacent block metadata.
        64 => LegacyTarget::ContextualModel { blockstate: "wooden_door", variants: DOOR_VARIANTS },
        71 => LegacyTarget::ContextualModel { blockstate: "iron_door", variants: DOOR_VARIANTS },
        193 => LegacyTarget::ContextualModel { blockstate: "spruce_door", variants: DOOR_VARIANTS },
        194 => LegacyTarget::ContextualModel { blockstate: "birch_door", variants: DOOR_VARIANTS },
        195 => LegacyTarget::ContextualModel { blockstate: "jungle_door", variants: DOOR_VARIANTS },
        196 => LegacyTarget::ContextualModel { blockstate: "acacia_door", variants: DOOR_VARIANTS },
        197 => LegacyTarget::ContextualModel { blockstate: "dark_oak_door", variants: DOOR_VARIANTS },
        // Legacy furnace metadata encodes EnumFacing.getFront(meta): 2 north,
        // 3 south, 4 west, 5 east. The lit furnace has a distinct blockstate/model.
        61 | 62 => {
            let blockstate = if id == 61 { "furnace" } else { "lit_furnace" };
            match metadata {
                2 => model(blockstate, "facing=north"),
                3 => model(blockstate, "facing=south"),
                4 => model(blockstate, "facing=west"),
                5 => model(blockstate, "facing=east"),
                _ => return None,
            }
        }
        // Classic cactus growth age is stored in metadata but does not choose a
        // distinct visual model; all four-bit age values use the same blockstate.
        81 => match metadata {
            0..=15 => model("cactus", "normal"),
            _ => return None,
        },
        // Before the flattened block format, pumpkin metadata is its horizontal
        // facing index: 0 south, 1 west, 2 north, 3 east. Jack o'lantern has a
        // separate block ID and blockstate file.
        86 | 91 => {
            let blockstate = if id == 86 { "pumpkin" } else { "lit_pumpkin" };
            match metadata {
                0 => model(blockstate, "facing=south"),
                1 => model(blockstate, "facing=west"),
                2 => model(blockstate, "facing=north"),
                3 => model(blockstate, "facing=east"),
                _ => return None,
            }
        }
        // Classic rail metadata maps to a shape; the blockstate JSON owns its Y
        // rotation, which the eventual chunk mesher must still apply.
        66 => match metadata {
            0 => model("rail", "shape=north_south"),
            1 => model("rail", "shape=east_west"),
            2 => model("rail", "shape=ascending_east"),
            3 => model("rail", "shape=ascending_west"),
            4 => model("rail", "shape=ascending_north"),
            5 => model("rail", "shape=ascending_south"),
            6 => model("rail", "shape=south_east"),
            7 => model("rail", "shape=south_west"),
            8 => model("rail", "shape=north_west"),
            9 => model("rail", "shape=north_east"),
            _ => return None,
        },
        56 => model("diamond_ore", "normal"),
        57 => model("diamond_block", "normal"),
        // These classic blocks are not selected by a simple one-to-one mapping to
        // `assets/minecraft/blockstates/<legacy-name>.json`; their visual state needs
        // the dedicated metadata-aware path (including axis and neighbor-derived flags).
        17 => {
            let species = match metadata & 0x03 { 0 => "oak", 1 => "spruce", 2 => "birch", 3 => "jungle", _ => unreachable!() };
            let axis = match metadata & 0x0c { 0 => "y", 4 => "x", 8 => "z", 12 => "all", _ => unreachable!() };
            let blockstate = match species {
                "oak" => "oak_log",
                "spruce" => "spruce_log",
                "birch" => "birch_log",
                "jungle" => "jungle_log",
                _ => unreachable!(),
            };
            LegacyTarget::Log { blockstate, species, axis }
        },
        18 => {
            let (model, texture) = match metadata & 0x03 {
                0 => ("block/oak_leaves", "leaves_oak"),
                1 => ("block/spruce_leaves", "leaves_spruce"),
                2 => ("block/birch_leaves", "leaves_birch"),
                3 => ("block/jungle_leaves", "leaves_jungle"),
                _ => unreachable!(),
            };
            LegacyTarget::Leaves { model, texture }
        },
        // Sponge metadata selects the dry/wet vanilla blockstate variants.
        19 => match metadata {
            0 => model("sponge", "wet=false"),
            1 => model("sponge", "wet=true"),
            _ => return None,
        },
        21 => model("lapis_ore", "normal"),
        22 => model("lapis_block", "normal"),
        25 => model("noteblock", "normal"),
        41 => model("gold_block", "normal"),
        42 => model("iron_block", "normal"),
        45 => model("brick_block", "normal"),
        46 => model("tnt", "normal"),
        47 => model("bookshelf", "normal"),
        24 => match metadata {
            0 => model("sandstone", "normal"),
            1 => direct_model("sandstone_chiseled"),
            2 => direct_model("sandstone_smooth"),
            _ => return None,
        },
        // Tall grass is represented by direct crossed-plane models in this 1.8.9
        // client asset set; there is no blockstates/tallgrass.json to resolve.
        31 => match metadata {
            0 => LegacyTarget::PlantModel { model: "block/dead_bush", tint: false },
            1 => LegacyTarget::PlantModel { model: "block/tall_grass", tint: true },
            2 => LegacyTarget::PlantModel { model: "block/fern", tint: true },
            _ => return None,
        },
        73 => model("redstone_ore", "normal"),
        74 => model("lit_redstone_ore", "normal"),
        // Snow-layer metadata stores layers minus one (0..7 => layers=1..8).
        78 => match metadata {
            0..=7 => model("snow_layer", format!("layers={}", metadata + 1)),
            _ => return None,
        },
        79 => model("ice", "normal"),
        80 => model("snow", "normal"),
        82 => model("clay", "normal"),
        // Stained glass and hardened clay use the same legacy dye metadata order.
        95 => colored_direct_model("glass", metadata)?,
        159 => colored_direct_model("hardened_clay", metadata)?,
        // Sugar cane uses a crossed-plane model; its growth metadata does not change
        // the static appearance represented by this preview.
        83 => match metadata {
            0..=15 => LegacyTarget::PlantModel { model: "block/reeds", tint: false },
            _ => return None,
        },
        // Oak fences select one of sixteen connection models from neighboring blocks.
        85 => LegacyTarget::ContextualModel {
            blockstate: "fence",
            variants: &[
                "east=false,north=false,south=false,west=false",
                "east=false,north=true,south=false,west=false",
                "east=true,north=false,south=false,west=false",
                "east=false,north=false,south=true,west=false",
                "east=false,north=false,south=false,west=true",
                "east=true,north=true,south=false,west=false",
                "east=true,north=false,south=true,west=false",
                "east=false,north=false,south=true,west=true",
                "east=false,north=true,south=false,west=true",
                "east=false,north=true,south=true,west=false",
                "east=true,north=false,south=false,west=true",
                "east=true,north=true,south=true,west=false",
                "east=true,north=false,south=true,west=true",
                "east=false,north=true,south=true,west=true",
                "east=true,north=true,south=false,west=true",
                "east=true,north=true,south=true,west=true",
            ],
        },
        // Stone-brick metadata chooses four direct vanilla cube models.
        98 => match metadata {
            0 => direct_model("stonebrick_normal"),
            1 => direct_model("stonebrick_mossy"),
            2 => direct_model("stonebrick_cracked"),
            3 => direct_model("stonebrick_chiseled"),
            _ => return None,
        },
        87 => model("netherrack", "normal"),
        88 => model("soul_sand", "normal"),
        89 => model("glowstone", "normal"),
        97 => match metadata {
            0..=2 => LegacyTarget::LegacyVisual("monster egg: metadata selects stone/cobblestone/stone-brick substrate texture"),
            _ => return None,
        },
        103 => direct_model("melon"),
        110 => LegacyTarget::ContextualModel { blockstate: "mycelium", variants: &["snowy=false", "snowy=true"] },
        112 => model("nether_brick", "normal"),
        121 => model("end_stone", "normal"),
        123 => model("redstone_lamp", "normal"),
        124 => model("lit_redstone_lamp", "normal"),
        129 => model("emerald_ore", "normal"),
        133 => model("emerald_block", "normal"),
        138 => model("beacon", "normal"),
        152 => model("redstone_block", "normal"),
        153 => model("quartz_ore", "normal"),
        165 => model("slime", "normal"),
        168 => match metadata {
            0 => direct_model("prismarine_rough"),
            1 => direct_model("prismarine_bricks"),
            2 => direct_model("prismarine_dark"),
            _ => return None,
        },
        169 => model("sea_lantern", "normal"),
        170 => match metadata & 0x0c {
            0 => model("hay_block", "axis=y"),
            4 => model("hay_block", "axis=x"),
            8 => model("hay_block", "axis=z"),
            _ => return None,
        },
        172 => model("hardened_clay", "normal"),
        173 => model("coal_block", "normal"),
        174 => model("packed_ice", "normal"),
        // Mushroom block faces are selected by the classic face mask metadata, not a
        // single JSON blockstate selector. Their six-face textures need dedicated logic.
        99 => LegacyTarget::LegacyVisual("brown mushroom block: face-mask metadata texture selection"),
        100 => LegacyTarget::LegacyVisual("red mushroom block: face-mask metadata texture selection"),
        // Double plants encode species and upper/lower half in legacy metadata; both halves
        // must be interpreted together before emitting cross-plane geometry.
        175 => {
            let species = match metadata & 0x07 {
                0 => "sunflower", 1 => "syringa", 2 => "grass", 3 => "fern",
                4 => "rose", 5 => "paeonia", _ => return None,
            };
            let half = if metadata & 0x08 == 0 { "bottom" } else { "top" };
            LegacyTarget::PlantModel {
                model: match (species, half) {
                    ("sunflower", "bottom") => "block/double_sunflower_bottom",
                    ("sunflower", _) => "block/double_sunflower_top",
                    ("syringa", "bottom") => "block/double_syringa_bottom",
                    ("syringa", _) => "block/double_syringa_top",
                    ("grass", "bottom") => "block/double_grass_bottom",
                    ("grass", _) => "block/double_grass_top",
                    ("fern", "bottom") => "block/double_fern_bottom",
                    ("fern", _) => "block/double_fern_top",
                    ("rose", "bottom") => "block/double_rose_bottom",
                    ("rose", _) => "block/double_rose_top",
                    ("paeonia", "bottom") => "block/double_paeonia_bottom",
                    _ => "block/double_paeonia_top",
                },
                tint: matches!(species, "grass" | "fern"),
            }
        },
        // Quartz metadata selects the vanilla normal/chiseled/pillar model family.
        // Pillar axis variants share the same side/end texture model; rotation is
        // applied by the blockstate in the full renderer, while this direct mapping
        // preserves the correct geometry and texture set for the common variants.
        155 => match metadata {
            0 => direct_model("quartz_normal"),
            1 => direct_model("quartz_chiseled"),
            2 => direct_model("quartz_lines"),
            3 | 4 => LegacyTarget::LegacyVisual("quartz pillar axis rotation; requires a rotated direct-model path"),
            _ => return None,
        },
        // Carpets are thin direct models, one for each legacy dye color.
        171 => colored_direct_model("carpet", metadata)?,
        161 => match metadata & 0x03 {
            0 => LegacyTarget::Leaves { model: "block/acacia_leaves", texture: "leaves_acacia" },
            1 => LegacyTarget::Leaves { model: "block/dark_oak_leaves", texture: "leaves_big_oak" },
            // The remaining low-bit values are reserved in the classic block.
            _ => return None,
        },
        162 => match metadata & 0x03 {
            0 | 1 => {
                let species = if metadata & 0x03 == 0 { "acacia" } else { "dark_oak" };
                let axis = match metadata & 0x0c { 0 => "y", 4 => "x", 8 => "z", 12 => "all", _ => unreachable!() };
                let blockstate = if species == "acacia" { "acacia_log" } else { "dark_oak_log" };
                LegacyTarget::Log { blockstate, species, axis }
            },
            // In 1.8.x these metadata variants were removed from normal gameplay and
            // have no vanilla model; preserve the unknown status instead of guessing.
            _ => return None,
        },
        _ => return None,
    };
    Some(target)
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum SelectorStatus {
    Found,
    BlockstateFileMissing,
    SelectorMissing,
    MultipartOnly,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum DirectModelStatus {
    Found,
    FileMissing,
    InvalidRoot,
}

fn direct_model_status(
    archive: &mut ZipArchive<File>,
    archive_names: &HashSet<String>,
    model: &str,
) -> std::result::Result<DirectModelStatus, String> {
    let path = format!("assets/minecraft/models/block/{model}.json");
    if !archive_names.contains(&path) {
        return Ok(DirectModelStatus::FileMissing);
    }
    let root = read_json_entry(archive, &path).map_err(|error| error.to_string())?;
    if root.is_object() {
        Ok(DirectModelStatus::Found)
    } else {
        Ok(DirectModelStatus::InvalidRoot)
    }
}

/// Property order in a variant key is an implementation detail of the legacy state
/// mapper. Compare property assignments as sets, but leave opaque keys such as `normal`
/// exact. Do not use subset matching: every state property must be accounted for.
fn selectors_equivalent(left: &str, right: &str) -> bool {
    if left == right { return true; }
    fn parse(value: &str) -> Option<Vec<(String, String)>> {
        let mut pairs = Vec::new();
        for assignment in value.split(',') {
            let (key, val) = assignment.split_once('=')?;
            if key.trim().is_empty() || val.trim().is_empty() { return None; }
            pairs.push((key.trim().to_owned(), val.trim().to_owned()));
        }
        if pairs.is_empty() { return None; }
        pairs.sort();
        Some(pairs)
    }
    match (parse(left), parse(right)) {
        (Some(a), Some(b)) => a == b,
        _ => false,
    }
}

fn parse_region_coords(path: &Path) -> Option<(i32, i32)> {
    let name = path.file_name()?.to_str()?;
    let body = name.strip_prefix("r.")?.strip_suffix(".mca")?;
    let (x, z) = body.split_once('.')?;
    Some((x.parse().ok()?, z.parse().ok()?))
}

fn read_json_entry(archive: &mut ZipArchive<File>, path: &str) -> Result<Value> {
    let entry = archive.by_name(path).map_err(|error| {
        Mc189Error::InvalidData(format!("missing or unreadable JAR entry {path}: {error}"))
    })?;
    if entry.size() > MAX_JSON_BYTES {
        return Err(Mc189Error::InvalidData(format!("JSON entry {path} exceeds {MAX_JSON_BYTES} bytes")));
    }
    let mut limited = entry.take(MAX_JSON_BYTES + 1);
    let mut bytes = Vec::new();
    limited.read_to_end(&mut bytes)?;
    if bytes.len() as u64 > MAX_JSON_BYTES {
        return Err(Mc189Error::InvalidData(format!("JSON entry {path} exceeds {MAX_JSON_BYTES} bytes")));
    }
    serde_json::from_slice(&bytes)
        .map_err(|error| Mc189Error::InvalidData(format!("invalid JSON in {path}: {error}")))
}

fn state_variant_status(
    archive: &mut ZipArchive<File>,
    archive_names: &HashSet<String>,
    blockstate: &str,
    variant: &str,
    cache: &mut HashMap<String, Option<Value>>,
) -> std::result::Result<SelectorStatus, String> {
    let path = format!("assets/minecraft/blockstates/{blockstate}.json");
    if !archive_names.contains(&path) {
        return Ok(SelectorStatus::BlockstateFileMissing);
    }
    if !cache.contains_key(&path) {
        let parsed = read_json_entry(archive, &path).map_err(|error| error.to_string())?;
        cache.insert(path.clone(), Some(parsed));
    }
    let root = cache.get(&path).and_then(Option::as_ref)
        .ok_or_else(|| format!("blockstate JSON {path} was not cached"))?;
    if let Some(variants) = root.get("variants").and_then(Value::as_object) {
        if variants.keys().any(|candidate| selectors_equivalent(variant, candidate)) {
            Ok(SelectorStatus::Found)
        } else {
            Ok(SelectorStatus::SelectorMissing)
        }
    } else if root.get("multipart").is_some() {
        Ok(SelectorStatus::MultipartOnly)
    } else {
        Err(format!("blockstate {path} has neither a variants object nor multipart rules"))
    }
}

fn contextual_variants_exist(
    archive: &mut ZipArchive<File>,
    archive_names: &HashSet<String>,
    blockstate: &str,
    variants: &[&str],
    cache: &mut HashMap<String, Option<Value>>,
) -> std::result::Result<bool, String> {
    for variant in variants {
        if state_variant_status(archive, archive_names, blockstate, variant, cache)? != SelectorStatus::Found {
            return Ok(false);
        }
    }
    Ok(true)
}

/// Scan a real Anvil world and audit the subset of legacy ID/metadata pairs that this
/// milestone knows how to map, checking each candidate selector against the user's JAR.
pub fn audit_world_state_map(world_path: &Path, jar_path: &Path) -> Result<()> {
    if !world_path.is_dir() {
        return Err(Mc189Error::Usage(format!("world path is not a directory: {}", world_path.display())));
    }
    if !jar_path.is_file() {
        return Err(Mc189Error::Usage(format!("client JAR is not a file: {}", jar_path.display())));
    }
    let region_dir = world_path.join("region");
    if !region_dir.is_dir() {
        return Err(Mc189Error::Usage(format!("no region directory found at {}", region_dir.display())));
    }

    let file = File::open(jar_path)?;
    let mut archive = ZipArchive::new(file).map_err(|error| {
        Mc189Error::InvalidData(format!("could not open {} as a ZIP/JAR archive: {error}", jar_path.display()))
    })?;
    let mut archive_names = HashSet::<String>::with_capacity(archive.len());
    for index in 0..archive.len() {
        let entry = archive.by_index(index).map_err(|error| {
            Mc189Error::InvalidData(format!("could not read JAR entry {index}: {error}"))
        })?;
        if !entry.is_dir() { archive_names.insert(entry.name().to_owned()); }
    }

    let mut regions: Vec<PathBuf> = fs::read_dir(&region_dir)?
        .filter_map(|entry| entry.ok().map(|entry| entry.path()))
        .filter(|path| path.extension().is_some_and(|extension| extension == "mca"))
        .collect();
    regions.sort();

    let mut pair_counts = BTreeMap::<(u16, u8), u64>::new();
    let mut chunks_read = 0_u64;
    let mut chunk_failures = 0_u64;
    let mut region_failures = 0_u64;
    for region_path in &regions {
        let header = match RegionHeader::from_file(region_path) {
            Ok(header) => header,
            Err(_) => { region_failures += 1; continue; }
        };
        let region_coords = parse_region_coords(region_path);
        for local_z in 0..32_u8 {
            for local_x in 0..32_u8 {
                if !header.location(local_x, local_z).is_some_and(|entry| entry.is_present()) { continue; }
                match decode_chunk(region_path, local_x, local_z) {
                    Ok(chunk) => {
                        if let Some((region_x, region_z)) = region_coords {
                            let expected_x = region_x.checked_mul(32).and_then(|value| value.checked_add(i32::from(local_x)));
                            let expected_z = region_z.checked_mul(32).and_then(|value| value.checked_add(i32::from(local_z)));
                            if expected_x != Some(chunk.x_pos) || expected_z != Some(chunk.z_pos) {
                                chunk_failures += 1;
                                continue;
                            }
                        }
                        chunks_read += 1;
                        for section in &chunk.sections {
                            for (index, &id) in section.block_ids.iter().enumerate() {
                                let metadata = section.metadata.get(index).copied().unwrap_or(0);
                                *pair_counts.entry((id, metadata)).or_insert(0) += 1;
                            }
                        }
                    }
                    Err(_) => chunk_failures += 1,
                }
            }
        }
    }

    let mut blockstate_cache: HashMap<String, Option<Value>> = HashMap::new();
    let mut pair_combinations = 0_u64;
    let mut air_positions = 0_u64;
    let mut fluid_positions = 0_u64;
    let mut mapped_positions = 0_u64;
    let mut direct_model_positions = 0_u64;
    let mut missing_direct_model_positions = 0_u64;
    let mut contextual_family_positions = 0_u64;
    let mut legacy_visual_positions = 0_u64;
    let mut missing_file_positions = 0_u64;
    let mut selector_mismatch_positions = 0_u64;
    let mut multipart_positions = 0_u64;
    let mut invalid_state_positions = 0_u64;
    let mut unmapped_positions = 0_u64;
    let mut missing_variants = Vec::new();
    let mut missing_state_files = Vec::new();
    let mut direct_model_diagnostics = Vec::new();
    let mut contextual_diagnostics = Vec::new();
    let mut legacy_visuals = Vec::new();
    // Rank all unknown pairs by their impact instead of letting numeric-ID order
    // hide the combinations that affect the most stored blocks.
    let mut unmapped_pairs = Vec::<(u64, String)>::new();

    for ((id, metadata), count) in &pair_counts {
        pair_combinations += 1;
        match map_legacy_block(*id, *metadata) {
            Some(LegacyTarget::Air) => air_positions += *count,
            Some(LegacyTarget::Fluid(_fluid_name)) => {
                // Classic water/lava geometry is produced by the fluid renderer, not by
                // a cube blockstate selector, so it is counted separately from model mapping.
                fluid_positions += *count;
            }
            Some(LegacyTarget::LegacyVisual(reason)) => {
                legacy_visual_positions += *count;
                if legacy_visuals.len() < 18 {
                    legacy_visuals.push(format!("ID {id} meta {metadata}: {reason} ({count} stored positions)"));
                }
            }
            Some(LegacyTarget::StoneVariant { texture }) => {
                let texture_path = format!("assets/minecraft/textures/blocks/{texture}.png");
                if archive_names.contains(&texture_path) {
                    mapped_positions += *count;
                } else {
                    invalid_state_positions += *count;
                    if direct_model_diagnostics.len() < 18 {
                        direct_model_diagnostics.push(format!("ID {id} meta {metadata}: stone variant texture {texture_path} is absent"));
                    }
                }
            }
            Some(LegacyTarget::Log { blockstate, .. }) => {
                let selectors = ["axis=x", "axis=y", "axis=z", "axis=none"];
                match contextual_variants_exist(&mut archive, &archive_names, blockstate, &selectors, &mut blockstate_cache) {
                    Ok(true) => contextual_family_positions += *count,
                    Ok(false) => { legacy_visual_positions += *count; if legacy_visuals.len() < 18 { legacy_visuals.push(format!("ID {id} meta {metadata}: log family {blockstate} needs metadata texture override ({count} positions)")); } },
                    Err(_) => invalid_state_positions += *count,
                }
            }
            Some(LegacyTarget::Leaves { .. }) => {
                match direct_model_status(&mut archive, &archive_names, "leaves") {
                    Ok(DirectModelStatus::Found) => direct_model_positions += *count,
                    Ok(DirectModelStatus::FileMissing) => { missing_direct_model_positions += *count; },
                    Ok(DirectModelStatus::InvalidRoot) | Err(_) => invalid_state_positions += *count,
                }
            }
            Some(LegacyTarget::PlantModel { model, .. }) => {
                let model = model.strip_prefix("block/").unwrap_or(model);
                match direct_model_status(&mut archive, &archive_names, model) {
                    Ok(DirectModelStatus::Found) => direct_model_positions += *count,
                    Ok(DirectModelStatus::FileMissing) => {
                        missing_direct_model_positions += *count;
                        if direct_model_diagnostics.len() < 18 { direct_model_diagnostics.push(format!("ID {id} meta {metadata}: vegetation model {model} is absent")); }
                    },
                    Ok(DirectModelStatus::InvalidRoot) | Err(_) => invalid_state_positions += *count,
                }
            }
            Some(LegacyTarget::DirectModel { model }) => {
                match direct_model_status(&mut archive, &archive_names, model) {
                    Ok(DirectModelStatus::Found) => direct_model_positions += *count,
                    Ok(DirectModelStatus::FileMissing) => {
                        missing_direct_model_positions += *count;
                        if direct_model_diagnostics.len() < 18 {
                            direct_model_diagnostics.push(format!("ID {id} meta {metadata}: direct model assets/minecraft/models/block/{model}.json is absent ({count} stored positions)"));
                        }
                    }
                    Ok(DirectModelStatus::InvalidRoot) => {
                        invalid_state_positions += *count;
                        if direct_model_diagnostics.len() < 18 {
                            direct_model_diagnostics.push(format!("ID {id} meta {metadata}: direct model assets/minecraft/models/block/{model}.json root is not an object"));
                        }
                    }
                    Err(error) => {
                        invalid_state_positions += *count;
                        if direct_model_diagnostics.len() < 18 {
                            direct_model_diagnostics.push(format!("ID {id} meta {metadata}: {error}"));
                        }
                    }
                }
            }
            Some(LegacyTarget::ContextualModel { blockstate, variants }) => {
                match contextual_variants_exist(&mut archive, &archive_names, blockstate, variants, &mut blockstate_cache) {
                    Ok(true) => contextual_family_positions += *count,
                    Ok(false) => {
                        selector_mismatch_positions += *count;
                        if contextual_diagnostics.len() < 18 {
                            contextual_diagnostics.push(format!("ID {id} meta {metadata}: expected contextual selector family {variants:?} in blockstates/{blockstate}.json"));
                        }
                    }
                    Err(error) => {
                        invalid_state_positions += *count;
                        if contextual_diagnostics.len() < 18 {
                            contextual_diagnostics.push(format!("ID {id} meta {metadata}: {error}"));
                        }
                    }
                }
            }
            Some(LegacyTarget::Model { blockstate, variant }) => {
                match state_variant_status(&mut archive, &archive_names, blockstate, &variant, &mut blockstate_cache) {
                    Ok(SelectorStatus::Found) => mapped_positions += *count,
                    Ok(SelectorStatus::BlockstateFileMissing) => {
                        missing_file_positions += *count;
                        if missing_state_files.len() < 18 {
                            missing_state_files.push(format!("ID {id} meta {metadata}: blockstates/{blockstate}.json is absent; JSON selector validation cannot be used for this block"));
                        }
                    }
                    Ok(SelectorStatus::SelectorMissing) => {
                        selector_mismatch_positions += *count;
                        if missing_variants.len() < 25 {
                            missing_variants.push(format!("ID {id} meta {metadata}: selector {variant:?} not present in blockstates/{blockstate}.json"));
                        }
                    }
                    Ok(SelectorStatus::MultipartOnly) => {
                        multipart_positions += *count;
                    }
                    Err(error) => {
                        invalid_state_positions += *count;
                        if missing_variants.len() < 25 { missing_variants.push(format!("ID {id} meta {metadata}: {error}")); }
                    }
                }
            }
            None => {
                unmapped_positions += *count;
                unmapped_pairs.push((*count, format!("ID {id} meta {metadata}: {count} stored positions")));
            }
        }
    }

    let stored_positions: u64 = pair_counts.values().sum();
    println!("Minecraft 1.8.9 legacy state-map coverage audit (read-only)");
    println!("World: {}", world_path.display());
    println!("Client JAR: {}", jar_path.display());
    println!("Region files found: {}", regions.len());
    println!("Chunks decoded and coordinate-validated: {chunks_read}");
    println!("Region read failures: {region_failures}");
    println!("Chunk decode/coordinate failures: {chunk_failures}");
    println!("Stored block positions counted: {stored_positions}");
    println!("Unique legacy ID/metadata pairs observed: {pair_combinations}");
    println!("Air positions (skipped): {air_positions}");
    println!("Fluid positions reserved for the fluid renderer: {fluid_positions}");
    println!("Positions with a directly validated blockstate selector: {mapped_positions}");
    println!("Positions with a directly validated legacy model file: {direct_model_positions}");
    println!("Positions whose expected direct model file is absent: {missing_direct_model_positions}");
    println!("Positions with a verified contextual model family (neighbor-derived state still needed): {contextual_family_positions}");
    println!("Positions classified for a dedicated legacy metadata/special visual path: {legacy_visual_positions}");
    println!("Positions whose expected blockstate JSON file is absent: {missing_file_positions}");
    println!("Positions whose expected selector is absent from an existing JSON: {selector_mismatch_positions}");
    println!("Positions whose blockstate uses multipart instead of variants: {multipart_positions}");
    println!("Positions with malformed/unreadable blockstate definitions: {invalid_state_positions}");
    println!("Positions with ID/metadata not covered by this initial registry: {unmapped_positions}");

    if !missing_state_files.is_empty() {
        println!();
        println!("Missing blockstate files (first {}):", missing_state_files.len());
        for diagnostic in &missing_state_files { println!("  - {diagnostic}"); }
    }
    if !direct_model_diagnostics.is_empty() {
        println!();
        println!("Direct-model diagnostics (first {}):", direct_model_diagnostics.len());
        for diagnostic in &direct_model_diagnostics { println!("  - {diagnostic}"); }
    }
    if !missing_variants.is_empty() {
        println!();
        println!("Selector mismatches or invalid definitions (first {}):", missing_variants.len());
        for diagnostic in &missing_variants { println!("  - {diagnostic}"); }
    }
    if !contextual_diagnostics.is_empty() {
        println!();
        println!("Contextual model-family diagnostics (first {}):", contextual_diagnostics.len());
        for diagnostic in &contextual_diagnostics { println!("  - {diagnostic}"); }
    }
    if !legacy_visuals.is_empty() {
        println!();
        println!("Known legacy/special visual paths not yet rendered (first {}):", legacy_visuals.len());
        for diagnostic in &legacy_visuals { println!("  - {diagnostic}"); }
    }
    if !unmapped_pairs.is_empty() {
        unmapped_pairs.sort_by(|left, right| right.0.cmp(&left.0).then_with(|| left.1.cmp(&right.1)));
        println!();
        println!("Unmapped combinations, sorted by stored-position count (first {}):", unmapped_pairs.len().min(25));
        for (_, pair) in unmapped_pairs.iter().take(25) { println!("  - {pair}"); }
    }
    println!();
    let data_integrity_ok = region_failures == 0 && chunk_failures == 0;
    println!("World data integrity: {}", if data_integrity_ok { "PASS" } else { "REVIEW REQUIRED" });
    let selectors_ok = selector_mismatch_positions == 0
        && invalid_state_positions == 0
        && missing_direct_model_positions == 0
        && contextual_diagnostics.is_empty();
    println!("Blockstate selector checks: {}", if selectors_ok { "PASS FOR CHECKED JSON-BASED STATES" } else { "REVIEW REQUIRED" });
    let coverage_complete = region_failures == 0
        && chunk_failures == 0
        && unmapped_positions == 0
        && missing_file_positions == 0
        && missing_direct_model_positions == 0
        && selector_mismatch_positions == 0
        && invalid_state_positions == 0
        && contextual_family_positions == 0
        && legacy_visual_positions == 0
        && fluid_positions == 0
        && multipart_positions == 0;
    println!("Render-path registry coverage: {}", if coverage_complete { "COMPLETE FOR OBSERVED BLOCKS" } else { "PARTIAL — remaining categories are explicitly reported, not guessed" });
    println!("Scope note: remaining legacy metadata overrides, other special geometry, context-derived properties, fluids, full ID/metadata coverage, exact vanilla UV-lock equivalence, per-block translucent sorting and full GPU-renderer parity remain separate implementation steps.");
    println!("No world files or JAR entries were modified.");
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn invisible_block_regression_families_resolve_to_vanilla_states() {
        assert_eq!(map_legacy_block(20, 0), Some(model("glass", "normal")));
        assert_eq!(map_legacy_block(79, 0), Some(model("ice", "normal")));
        assert_eq!(map_legacy_block(78, 0), Some(model("snow_layer", "layers=1")));
        assert_eq!(map_legacy_block(78, 7), Some(model("snow_layer", "layers=8")));
        assert!(matches!(map_legacy_block(53, 0), Some(LegacyTarget::ContextualModel { blockstate: "oak_stairs", variants }) if variants.len() == 40));
        assert!(matches!(map_legacy_block(67, 4), Some(LegacyTarget::ContextualModel { blockstate: "stone_stairs", variants }) if variants.len() == 40));
        assert!(matches!(map_legacy_block(64, 0), Some(LegacyTarget::ContextualModel { blockstate: "wooden_door", variants }) if variants.len() == 32));
        assert!(matches!(map_legacy_block(71, 8), Some(LegacyTarget::ContextualModel { blockstate: "iron_door", variants }) if variants.len() == 32));
        assert!(matches!(map_legacy_block(193, 0), Some(LegacyTarget::ContextualModel { blockstate: "spruce_door", .. })));
        assert!(matches!(map_legacy_block(197, 0), Some(LegacyTarget::ContextualModel { blockstate: "dark_oak_door", .. })));
    }

    #[test]
    fn stone_metadata_separates_json_model_from_legacy_visual_variants() {
        assert_eq!(map_legacy_block(1, 0), Some(model("stone", "normal")));
        let expected = [
            (1, "stone_granite"),
            (2, "stone_granite_smooth"),
            (3, "stone_diorite"),
            (4, "stone_diorite_smooth"),
            (5, "stone_andesite"),
            (6, "stone_andesite_smooth"),
        ];
        for (metadata, texture) in expected {
            assert_eq!(map_legacy_block(1, metadata), Some(LegacyTarget::StoneVariant { texture }));
        }
        assert_eq!(map_legacy_block(1, 7), None);
        assert_eq!(map_legacy_block(1, 15), None);
    }

    #[test]
    fn grass_uses_both_neighbor_dependent_blockstate_variants() {
        assert_eq!(map_legacy_block(2, 0), Some(LegacyTarget::ContextualModel {
            blockstate: "grass",
            variants: &["snowy=false", "snowy=true"],
        }));
    }

    #[test]
    fn logs_and_leaves_are_not_assumed_to_have_direct_json_selectors() {
        assert!(matches!(map_legacy_block(17, 4), Some(LegacyTarget::Log { blockstate: "oak_log", species: "oak", axis: "x" })));
        assert!(matches!(map_legacy_block(18, 0), Some(LegacyTarget::Leaves { model: "block/oak_leaves", texture: "leaves_oak" })));
        assert!(matches!(map_legacy_block(162, 1), Some(LegacyTarget::Log { blockstate: "dark_oak_log", species: "dark_oak", .. })));
    }

    #[test]
    fn reserved_legacy_metadata_states_are_not_guessed() {
        assert_eq!(map_legacy_block(1, 7), None);
        assert_eq!(map_legacy_block(3, 3), None);
        assert_eq!(map_legacy_block(12, 2), None);
        assert_eq!(map_legacy_block(24, 3), None);
        assert_eq!(map_legacy_block(31, 3), None);
        assert_eq!(map_legacy_block(161, 2), None);
        assert_eq!(map_legacy_block(161, 10), None);
        assert_eq!(map_legacy_block(162, 2), None);
        assert_eq!(map_legacy_block(162, 3), None);
    }

    #[test]
    fn air_and_fluids_are_not_treated_as_cube_models() {
        assert_eq!(map_legacy_block(0, 0), Some(LegacyTarget::Air));
        assert_eq!(map_legacy_block(9, 0), Some(LegacyTarget::Fluid("water")));
        assert_eq!(map_legacy_block(11, 0), Some(LegacyTarget::Fluid("lava")));
    }

    #[test]
    fn common_legacy_cubes_map_to_classic_selectors_and_planks_to_direct_models() {
        assert_eq!(map_legacy_block(4, 0), Some(model("cobblestone", "normal")));
        assert_eq!(map_legacy_block(5, 0), Some(direct_model("oak_planks")));
        assert_eq!(map_legacy_block(5, 1), Some(direct_model("spruce_planks")));
        assert_eq!(map_legacy_block(5, 2), Some(direct_model("birch_planks")));
        assert_eq!(map_legacy_block(5, 3), Some(direct_model("jungle_planks")));
        assert_eq!(map_legacy_block(5, 4), Some(direct_model("acacia_planks")));
        assert_eq!(map_legacy_block(5, 5), Some(direct_model("dark_oak_planks")));
        assert_eq!(map_legacy_block(5, 6), None);
    }

    #[test]
    fn common_legacy_blocks_map_to_verified_selector_families() {
        assert_eq!(map_legacy_block(56, 0), Some(model("diamond_ore", "normal")));
        assert_eq!(map_legacy_block(82, 0), Some(model("clay", "normal")));
        assert_eq!(map_legacy_block(66, 0), Some(model("rail", "shape=north_south")));
        assert_eq!(map_legacy_block(66, 9), Some(model("rail", "shape=north_east")));
        assert_eq!(map_legacy_block(66, 10), None);
        assert!(matches!(map_legacy_block(85, 0), Some(LegacyTarget::ContextualModel { blockstate: "fence", variants }) if variants.len() == 16));
        assert!(matches!(map_legacy_block(99, 0), Some(LegacyTarget::LegacyVisual(_))));
        assert!(matches!(map_legacy_block(100, 10), Some(LegacyTarget::LegacyVisual(_))));
        assert!(matches!(map_legacy_block(175, 10), Some(LegacyTarget::PlantModel { model: "block/double_grass_top", tint: true })));
    }

    #[test]
    fn web_mushrooms_mossy_cobblestone_and_obsidian_map_to_direct_selectors() {
        assert_eq!(map_legacy_block(30, 0), Some(model("web", "normal")));
        assert_eq!(map_legacy_block(39, 0), Some(model("brown_mushroom", "normal")));
        assert_eq!(map_legacy_block(40, 0), Some(model("red_mushroom", "normal")));
        assert_eq!(map_legacy_block(48, 0), Some(model("mossy_cobblestone", "normal")));
        assert_eq!(map_legacy_block(49, 0), Some(model("obsidian", "normal")));
    }

    #[test]
    fn torch_metadata_maps_only_known_mounting_directions() {
        assert_eq!(map_legacy_block(50, 1), Some(model("torch", "facing=east")));
        assert_eq!(map_legacy_block(50, 2), Some(model("torch", "facing=west")));
        assert_eq!(map_legacy_block(50, 3), Some(model("torch", "facing=south")));
        assert_eq!(map_legacy_block(50, 4), Some(model("torch", "facing=north")));
        assert_eq!(map_legacy_block(50, 5), Some(model("torch", "facing=up")));
        assert_eq!(map_legacy_block(50, 0), None);
        assert_eq!(map_legacy_block(50, 6), None);
    }

    #[test]
    fn double_plant_models_match_vanilla_189_archive_names() {
        let expected = [
            (0, "block/double_sunflower_bottom"), (8, "block/double_sunflower_top"),
            (1, "block/double_syringa_bottom"), (9, "block/double_syringa_top"),
            (2, "block/double_grass_bottom"), (10, "block/double_grass_top"),
            (3, "block/double_fern_bottom"), (11, "block/double_fern_top"),
            (4, "block/double_rose_bottom"), (12, "block/double_rose_top"),
            (5, "block/double_paeonia_bottom"), (13, "block/double_paeonia_top"),
        ];
        for (metadata, expected_model) in expected {
            assert!(matches!(map_legacy_block(175, metadata), Some(LegacyTarget::PlantModel { model, .. }) if model == expected_model));
        }
    }

    #[test]
    fn vegetation_and_fire_are_classified_as_special_without_guessing_metadata() {
        assert!(matches!(map_legacy_block(32, 0), Some(LegacyTarget::PlantModel { model: "block/dead_bush", .. })));
        assert_eq!(map_legacy_block(31, 0), Some(LegacyTarget::PlantModel { model: "block/dead_bush", tint: false }));
        assert_eq!(map_legacy_block(31, 1), Some(LegacyTarget::PlantModel { model: "block/tall_grass", tint: true }));
        assert_eq!(map_legacy_block(31, 2), Some(LegacyTarget::PlantModel { model: "block/fern", tint: true }));
        assert_eq!(map_legacy_block(31, 3), None);
        assert_eq!(map_legacy_block(37, 0), Some(model("dandelion", "normal")));
        let flower_states = [
            (0, "poppy"), (1, "blue_orchid"), (2, "allium"), (3, "houstonia"),
            (4, "red_tulip"), (5, "orange_tulip"), (6, "white_tulip"),
            (7, "pink_tulip"), (8, "oxeye_daisy"),
        ];
        for (metadata, blockstate) in flower_states {
            assert_eq!(map_legacy_block(38, metadata), Some(model(blockstate, "normal")));
        }
        assert!(matches!(map_legacy_block(51, 15), Some(LegacyTarget::LegacyVisual(_))));
        assert_eq!(map_legacy_block(38, 9), None);
        assert_eq!(map_legacy_block(51, 16), None);
    }

    #[test]
    fn sixteen_dye_metadata_values_map_to_vanilla_wool_glass_clay_and_carpet_models() {
        let expected = [
            "white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
            "silver", "cyan", "purple", "blue", "brown", "green", "red", "black",
        ];
        for (metadata, color) in expected.into_iter().enumerate() {
            let cases = [
                (35, match color { "white" => "white_wool", "orange" => "orange_wool", "magenta" => "magenta_wool", "light_blue" => "light_blue_wool", "yellow" => "yellow_wool", "lime" => "lime_wool", "pink" => "pink_wool", "gray" => "gray_wool", "silver" => "silver_wool", "cyan" => "cyan_wool", "purple" => "purple_wool", "blue" => "blue_wool", "brown" => "brown_wool", "green" => "green_wool", "red" => "red_wool", _ => "black_wool" }),
                (95, match color { "white" => "glass_white", "orange" => "glass_orange", "magenta" => "glass_magenta", "light_blue" => "glass_light_blue", "yellow" => "glass_yellow", "lime" => "glass_lime", "pink" => "glass_pink", "gray" => "glass_gray", "silver" => "glass_silver", "cyan" => "glass_cyan", "purple" => "glass_purple", "blue" => "glass_blue", "brown" => "glass_brown", "green" => "glass_green", "red" => "glass_red", _ => "glass_black" }),
                (159, match color { "white" => "hardened_clay_white", "orange" => "hardened_clay_orange", "magenta" => "hardened_clay_magenta", "light_blue" => "hardened_clay_light_blue", "yellow" => "hardened_clay_yellow", "lime" => "hardened_clay_lime", "pink" => "hardened_clay_pink", "gray" => "hardened_clay_gray", "silver" => "hardened_clay_silver", "cyan" => "hardened_clay_cyan", "purple" => "hardened_clay_purple", "blue" => "hardened_clay_blue", "brown" => "hardened_clay_brown", "green" => "hardened_clay_green", "red" => "hardened_clay_red", _ => "hardened_clay_black" }),
                (171, match color { "white" => "carpet_white", "orange" => "carpet_orange", "magenta" => "carpet_magenta", "light_blue" => "carpet_light_blue", "yellow" => "carpet_yellow", "lime" => "carpet_lime", "pink" => "carpet_pink", "gray" => "carpet_gray", "silver" => "carpet_silver", "cyan" => "carpet_cyan", "purple" => "carpet_purple", "blue" => "carpet_blue", "brown" => "carpet_brown", "green" => "carpet_green", "red" => "carpet_red", _ => "carpet_black" }),
            ];
            for (id, expected_model) in cases {
                assert_eq!(map_legacy_block(id, metadata as u8), Some(direct_model(expected_model)), "ID/meta {id}/{metadata}");
            }
        }
        for id in [35, 95, 159, 171] { assert_eq!(map_legacy_block(id, 16), None); }
    }

    #[test]
    fn broad_static_solid_block_families_resolve_to_vanilla_blockstates() {
        let cases = [
            (22, "lapis_block"), (25, "noteblock"), (41, "gold_block"), (42, "iron_block"),
            (45, "brick_block"), (46, "tnt"), (47, "bookshelf"), (57, "diamond_block"),
            (80, "snow"), (87, "netherrack"), (88, "soul_sand"), (89, "glowstone"),
            (112, "nether_brick"), (121, "end_stone"),
            (123, "redstone_lamp"), (124, "lit_redstone_lamp"), (129, "emerald_ore"),
            (133, "emerald_block"), (138, "beacon"), (152, "redstone_block"),
            (153, "quartz_ore"), (165, "slime"), (169, "sea_lantern"),
            (172, "hardened_clay"), (173, "coal_block"), (174, "packed_ice"),
        ];
        for (id, blockstate) in cases {
            assert_eq!(map_legacy_block(id, 0), Some(model(blockstate, "normal")), "ID {id}");
        }
        assert_eq!(map_legacy_block(103, 0), Some(direct_model("melon")));
        assert_eq!(map_legacy_block(110, 0), Some(LegacyTarget::ContextualModel { blockstate: "mycelium", variants: &["snowy=false", "snowy=true"] }));
        assert_eq!(map_legacy_block(168, 0), Some(direct_model("prismarine_rough")));
        assert_eq!(map_legacy_block(168, 1), Some(direct_model("prismarine_bricks")));
        assert_eq!(map_legacy_block(168, 2), Some(direct_model("prismarine_dark")));
        assert_eq!(map_legacy_block(168, 3), None);
        assert_eq!(map_legacy_block(170, 0), Some(model("hay_block", "axis=y")));
        assert_eq!(map_legacy_block(170, 4), Some(model("hay_block", "axis=x")));
        assert_eq!(map_legacy_block(170, 8), Some(model("hay_block", "axis=z")));
    }

    #[test]
    fn common_legacy_metadata_variants_resolve_to_verified_vanilla_models() {
        assert_eq!(map_legacy_block(3, 1), Some(direct_model("coarse_dirt")));
        assert_eq!(map_legacy_block(3, 2), Some(direct_model("podzol")));
        assert_eq!(map_legacy_block(12, 1), Some(direct_model("red_sand")));
        assert_eq!(map_legacy_block(19, 0), Some(model("sponge", "wet=false")));
        assert_eq!(map_legacy_block(19, 1), Some(model("sponge", "wet=true")));
        assert_eq!(map_legacy_block(24, 1), Some(direct_model("sandstone_chiseled")));
        assert_eq!(map_legacy_block(24, 2), Some(direct_model("sandstone_smooth")));
        assert_eq!(map_legacy_block(98, 0), Some(direct_model("stonebrick_normal")));
        assert_eq!(map_legacy_block(98, 1), Some(direct_model("stonebrick_mossy")));
        assert_eq!(map_legacy_block(98, 2), Some(direct_model("stonebrick_cracked")));
        assert_eq!(map_legacy_block(98, 3), Some(direct_model("stonebrick_chiseled")));
        assert_eq!(map_legacy_block(155, 0), Some(direct_model("quartz_normal")));
        assert_eq!(map_legacy_block(155, 1), Some(direct_model("quartz_chiseled")));
        assert_eq!(map_legacy_block(155, 2), Some(direct_model("quartz_lines")));
        assert!(matches!(map_legacy_block(155, 3), Some(LegacyTarget::LegacyVisual(_))));
        assert!(matches!(map_legacy_block(155, 4), Some(LegacyTarget::LegacyVisual(_))));
        for (id, meta) in [(3, 3), (12, 2), (19, 2), (24, 3), (98, 4), (155, 5), (155, 6)] {
            assert_eq!(map_legacy_block(id, meta), None, "unexpected ID/meta {id}/{meta}");
        }
    }

    #[test]
    fn cactus_growth_age_uses_one_visual_model() {
        for metadata in 0..=15 {
            assert_eq!(map_legacy_block(81, metadata), Some(model("cactus", "normal")));
        }
    }

    #[test]
    fn crafting_table_and_furnaces_select_verified_classic_variants() {
        assert_eq!(map_legacy_block(58, 0), Some(model("crafting_table", "normal")));
        assert_eq!(map_legacy_block(61, 2), Some(model("furnace", "facing=north")));
        assert_eq!(map_legacy_block(61, 3), Some(model("furnace", "facing=south")));
        assert_eq!(map_legacy_block(61, 4), Some(model("furnace", "facing=west")));
        assert_eq!(map_legacy_block(61, 5), Some(model("furnace", "facing=east")));
        assert_eq!(map_legacy_block(62, 2), Some(model("lit_furnace", "facing=north")));
        assert_eq!(map_legacy_block(62, 5), Some(model("lit_furnace", "facing=east")));
        assert_eq!(map_legacy_block(61, 0), None);
        assert_eq!(map_legacy_block(62, 6), None);
    }

    #[test]
    fn pumpkin_metadata_maps_to_horizontal_facing_variants() {
        for (metadata, facing) in [(0, "south"), (1, "west"), (2, "north"), (3, "east")] {
            assert_eq!(map_legacy_block(86, metadata), Some(model("pumpkin", format!("facing={facing}"))));
            assert_eq!(map_legacy_block(91, metadata), Some(model("lit_pumpkin", format!("facing={facing}"))));
        }
        assert_eq!(map_legacy_block(86, 4), None);
        assert_eq!(map_legacy_block(91, 5), None);
    }

    #[test]
    fn tile_entity_blocks_keep_their_distinct_render_paths() {
        // Spawner cage is selected by JSON; the spinning entity preview remains a
        // separate tile-entity-renderer feature outside this state-map audit.
        assert_eq!(map_legacy_block(52, 0), Some(model("mob_spawner", "normal")));
        // Chest has no corresponding vanilla blockstate JSON and needs its own renderer.
        assert!(matches!(map_legacy_block(54, 2), Some(LegacyTarget::LegacyVisual(_))));
        assert!(matches!(map_legacy_block(54, 5), Some(LegacyTarget::LegacyVisual(_))));
        assert_eq!(map_legacy_block(52, 1), None);
        assert_eq!(map_legacy_block(54, 0), None);
    }

    #[test]
    fn selector_property_order_is_irrelevant_but_property_set_must_match() {
        assert!(selectors_equivalent("axis=y,variant=oak", "variant=oak,axis=y"));
        assert!(!selectors_equivalent("axis=y,variant=oak", "variant=oak,axis=y,check_decay=false"));
        assert!(selectors_equivalent("normal", "normal"));
        assert!(!selectors_equivalent("normal", ""));
    }

    #[test]
    fn legacy_log_metadata_resolves_species_and_axis_for_both_log_families() {
        assert!(matches!(map_legacy_block(17, 0), Some(LegacyTarget::Log { blockstate: "oak_log", species: "oak", axis: "y" })));
        assert!(matches!(map_legacy_block(17, 5), Some(LegacyTarget::Log { blockstate: "spruce_log", species: "spruce", axis: "x" })));
        assert!(matches!(map_legacy_block(17, 10), Some(LegacyTarget::Log { blockstate: "birch_log", species: "birch", axis: "z" })));
        assert!(matches!(map_legacy_block(17, 15), Some(LegacyTarget::Log { blockstate: "jungle_log", species: "jungle", axis: "all" })));
        assert!(matches!(map_legacy_block(162, 4), Some(LegacyTarget::Log { blockstate: "acacia_log", species: "acacia", axis: "x" })));
        assert!(matches!(map_legacy_block(162, 13), Some(LegacyTarget::Log { blockstate: "dark_oak_log", species: "dark_oak", axis: "all" })));
    }

    #[test]
    fn legacy_leaf_metadata_selects_all_six_vanilla_species() {
        assert!(matches!(map_legacy_block(18, 0), Some(LegacyTarget::Leaves { model: "block/oak_leaves", texture: "leaves_oak" })));
        assert!(matches!(map_legacy_block(18, 1), Some(LegacyTarget::Leaves { model: "block/spruce_leaves", texture: "leaves_spruce" })));
        assert!(matches!(map_legacy_block(18, 2), Some(LegacyTarget::Leaves { model: "block/birch_leaves", texture: "leaves_birch" })));
        assert!(matches!(map_legacy_block(18, 3), Some(LegacyTarget::Leaves { model: "block/jungle_leaves", texture: "leaves_jungle" })));
        assert!(matches!(map_legacy_block(161, 0), Some(LegacyTarget::Leaves { model: "block/acacia_leaves", texture: "leaves_acacia" })));
        assert!(matches!(map_legacy_block(161, 1), Some(LegacyTarget::Leaves { model: "block/dark_oak_leaves", texture: "leaves_big_oak" })));
    }


    #[test]
    fn sapling_metadata_selects_all_species_and_growth_stages() {
        assert_eq!(map_legacy_block(6, 0), Some(model("sapling", "stage=0,type=oak")));
        assert_eq!(map_legacy_block(6, 9), Some(model("sapling", "stage=1,type=spruce")));
        assert_eq!(map_legacy_block(6, 2), Some(model("sapling", "stage=0,type=birch")));
        assert_eq!(map_legacy_block(6, 3), Some(model("sapling", "stage=0,type=jungle")));
        assert_eq!(map_legacy_block(6, 4), Some(model("sapling", "stage=0,type=acacia")));
        assert_eq!(map_legacy_block(6, 5), Some(model("sapling", "stage=0,type=dark_oak")));
        assert_eq!(map_legacy_block(6, 6), None);
    }

}
