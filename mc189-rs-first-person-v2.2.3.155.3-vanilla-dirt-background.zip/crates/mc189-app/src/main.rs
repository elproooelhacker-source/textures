mod client_assets;
mod client_atlas;
mod client_atlas_runtime;
mod client_textures;
mod client_resources;
mod inventory;
mod audio;
mod blockstate_resolver;
mod chunk_mesh;
mod gpu_atlas_preview;
mod gpu_block_preview;
mod gpu_preview;
mod legacy_state_map;
mod model_resolver;
mod main_menu;
mod mining;
mod drop_registry;
pub use mc189_server::player;
mod textured_chunk;
mod world_catalog;

use mc189_core::{Mc189Error, Result};
use mc189_protocol::{connect_offline, packet_name, ConnectionState, Direction};
use std::time::Duration;
use mc189_storage::{decode_chunk, inspect_chunk, read_world_metadata, split_chunk_coordinate, RegionHeader, load_mutable_chunk, save_mutable_chunk};
use std::collections::BTreeMap;
use std::env;
use std::fs::{self, File};
use std::io::Read;
use std::path::{Path, PathBuf};
use zip::ZipArchive;

fn main() {
    if let Err(error) = run() {
        eprintln!("error: {error}");
        std::process::exit(1);
    }
}

fn run() -> Result<()> {
    let args: Vec<String> = env::args().skip(1).collect();
    match args.as_slice() {
        [command, path] if command == "inspect-region" => inspect_region(Path::new(path)),
        [command, path] if command == "inspect-world" => inspect_world(Path::new(path)),
        [command, path] if command == "inspect-world-chunks" => inspect_world_chunks(Path::new(path)),
        [command, path] if command == "inspect-world-blocks" => inspect_world_blocks(Path::new(path)),
        [command, path] if command == "inspect-world-meta" => inspect_world_meta(Path::new(path)),
        [command, path] if command == "inspect-player-spawn" => inspect_player_spawn(Path::new(path)),
        [command, saves] if command == "list-worlds" => world_catalog::print_worlds(Path::new(saves)),
        [command, saves, jar, atlas] if command == "main-menu" => {
            client_atlas::ensure_gameplay_atlas(Path::new(jar), Path::new(atlas))?;
            main_menu::run(Path::new(saves), Path::new(jar), Path::new(atlas))
        },
        [command, jar, atlas, world] if command == "play-world" => {
            client_atlas::ensure_gameplay_atlas(Path::new(jar), Path::new(atlas))?;
            let spawn = player::load_world_spawn(Path::new(world))?;
            textured_chunk::play_world(Path::new(jar), Path::new(atlas), Path::new(world), spawn)
        },
        [command, saves, jar, atlas] if command == "select-world" => {
            client_atlas::ensure_gameplay_atlas(Path::new(jar), Path::new(atlas))?;
            let selected = world_catalog::select_world_interactively(Path::new(saves))?;
            let spawn = player::load_world_spawn(&selected.path)?;
            println!("\nSelected: {}", selected.metadata.level_name.as_deref().unwrap_or(&selected.folder_name));
            println!("Spawn: ({:.1}, {:.1}, {:.1})", spawn.x, spawn.y, spawn.z);
            println!("Loading the initial 3x3 chunk area around spawn...");
            textured_chunk::play_world(Path::new(jar), Path::new(atlas), &selected.path, spawn)
        }
        [command, host, port, username] if command == "probe-offline-server" => {
            let port = port.parse::<u16>().map_err(|_| Mc189Error::Usage(format!("invalid server port: {port}")))?;
            let mut connection = connect_offline((host.as_str(), port), host, port, username)
                .map_err(|error| Mc189Error::InvalidData(format!("offline protocol connection failed: {error}")))?;
            println!("Minecraft Java 1.8.9 protocol 47: LOGIN SUCCESS");
            println!("Server: {host}:{port}");
            println!("Player: {}", connection.username);
            println!("Offline UUID: {}", connection.uuid);
            connection.set_read_timeout(Some(Duration::from_secs(4)))
                .map_err(|error| Mc189Error::InvalidData(error.to_string()))?;
            match connection.read_play_packet() {
                Ok(packet) => println!("First PLAY packet: 0x{:02X} ({}) | {} payload bytes", packet.id,
                    packet_name(ConnectionState::Play, Direction::Clientbound, packet.id).unwrap_or("unknown packet"), packet.payload.len()),
                Err(error) => println!("Login succeeded; first PLAY packet was not read before timeout/close: {error}"),
            }
            println!("This diagnostic confirms TCP + offline LOGIN only; world decoding/rendering is the next integration stage.");
            Ok(())
        },
        [command, path] if command == "inspect-client-jar" => inspect_client_jar(Path::new(path)),
        [command, path] if command == "audit-client-models" => client_assets::audit_client_models(Path::new(path)),
        [command, jar, output] if command == "extract-client-textures" => client_textures::extract_client_textures(Path::new(jar), Path::new(output)),
        [command, jar, output] if command == "extract-client-assets" => client_resources::extract_client_assets(Path::new(jar), Path::new(output)),
        [command, assets_root, index, output] if command == "extract-launcher-audio" => client_resources::extract_launcher_audio(Path::new(assets_root), Path::new(index), Path::new(output)),
        [command, texture_root, output] if command == "plan-block-texture-atlas" => client_atlas::build_atlas_layout(Path::new(texture_root), Path::new(output)),
        [command, texture_root, layout, output_dir] if command == "build-block-texture-atlas" => client_atlas::build_block_texture_atlas(Path::new(texture_root), Path::new(layout), Path::new(output_dir)),
        [command, output_dir] if command == "inspect-block-texture-atlas" => inspect_block_texture_atlas(Path::new(output_dir)),
        [command, output_dir] if command == "preview-block-texture-atlas" => gpu_atlas_preview::run(Path::new(output_dir)),
        [command, jar, atlas_dir, model_id] if command == "preview-textured-block" => gpu_block_preview::run(Path::new(jar), Path::new(atlas_dir), model_id),
        [command, jar, atlas_dir, blockstate, selector] if command == "preview-blockstate-variant" => gpu_block_preview::run_blockstate_variant(Path::new(jar), Path::new(atlas_dir), blockstate, selector, 0),
        [command, jar, atlas_dir, blockstate, selector, seed] if command == "preview-blockstate-variant" => {
            let seed = seed.parse::<i64>().map_err(|_| Mc189Error::Usage(format!("invalid weighted selection seed: {seed:?}")))?;
            gpu_block_preview::run_blockstate_variant(Path::new(jar), Path::new(atlas_dir), blockstate, selector, seed)
        }
        [command, jar, blockstate, properties] if command == "inspect-blockstate-multipart" => {
            let parsed = parse_block_properties(properties)?;
            blockstate_resolver::inspect_blockstate_multipart(Path::new(jar), blockstate, &parsed)
        }
        [command, jar, blockstate, selector] if command == "inspect-blockstate-variant" => blockstate_resolver::inspect_blockstate_variant(Path::new(jar), blockstate, selector),
        [command, path] if command == "resolve-client-models" => model_resolver::resolve_client_models(Path::new(path)),
        [command, path] if command == "compile-client-geometry" => model_resolver::compile_client_geometry(Path::new(path)),
        [command, obj] if command == "preview-debug-obj" => gpu_preview::run(Path::new(obj)),
        [command, world, chunk_x, chunk_z, output] if command == "export-debug-chunk-mesh" => {
            let chunk_x = parse_coordinate(chunk_x, "chunk X")?;
            let chunk_z = parse_coordinate(chunk_z, "chunk Z")?;
            chunk_mesh::export_debug_chunk_mesh(Path::new(world), chunk_x, chunk_z, Path::new(output))
        }
        [command, world, jar] if command == "audit-world-state-map" => legacy_state_map::audit_world_state_map(Path::new(world), Path::new(jar)),
        [command, world, jar, atlas, chunk_x, chunk_z] if command == "preview-textured-chunk" => {
            let chunk_x = parse_coordinate(chunk_x, "chunk X")?;
            let chunk_z = parse_coordinate(chunk_z, "chunk Z")?;
            textured_chunk::preview_textured_chunk(Path::new(jar), Path::new(atlas), Path::new(world), chunk_x, chunk_z)
        }
        [command, world, jar, atlas, chunk_x, chunk_z, radius] if command == "preview-textured-region" => {
            let chunk_x = parse_coordinate(chunk_x, "center chunk X")?;
            let chunk_z = parse_coordinate(chunk_z, "center chunk Z")?;
            let radius = radius.parse::<u8>().map_err(|_| Mc189Error::InvalidData("region radius must be an integer from 0 to 4".into()))?;
            textured_chunk::preview_textured_region(Path::new(jar), Path::new(atlas), Path::new(world), chunk_x, chunk_z, radius)
        }
        [command, world, x, y, z] if command == "inspect-block" => {
            let world_x = parse_coordinate(x, "X")?;
            let world_y = parse_coordinate(y, "Y")?;
            let world_z = parse_coordinate(z, "Z")?;
            inspect_block(Path::new(world), world_x, world_y, world_z)
        }
        [command, world, x, y, z, id, meta] if command == "set-world-block" => {
            let world_x=parse_coordinate(x,"X")?; let world_y=parse_coordinate(y,"Y")?; let world_z=parse_coordinate(z,"Z")?;
            let id=id.parse::<u16>().map_err(|_|Mc189Error::Usage(format!("invalid block ID: {id}")))?;
            let meta=meta.parse::<u8>().map_err(|_|Mc189Error::Usage(format!("invalid metadata: {meta}")))?;
            set_world_block(Path::new(world),world_x,world_y,world_z,id,meta)
        }
        _ => {
            println!("mc189-rs — Minecraft 1.8.9 world and resource tools");
            println!();
            println!("Usage:");
            println!("  mc189-app inspect-region <path-to-r.0.0.mca>");
            println!("  mc189-app inspect-world <path-to-world-folder>");
            println!("  mc189-app inspect-world-chunks <path-to-world-folder>");
            println!("  mc189-app inspect-world-blocks <path-to-world-folder>");
            println!("  mc189-app inspect-world-meta <path-to-world-folder>");
            println!("  mc189-app inspect-player-spawn <path-to-world-folder>");
            println!("  mc189-app list-worlds <path-to-.minecraft\\saves>");
            println!("  mc189-app main-menu <path-to-.minecraft\\saves> <path-to-client.jar> <atlas-output-directory>");
            println!("  mc189-app select-world <path-to-.minecraft\\saves> <path-to-client.jar> <atlas-output-directory>");
            println!("  mc189-app probe-offline-server <host> <port> <username>");
            println!("  mc189-app inspect-client-jar <path-to-client.jar>");
            println!("  mc189-app audit-client-models <path-to-client.jar>");
            println!("  mc189-app extract-client-textures <path-to-client.jar> <output-directory>");
            println!("  mc189-app extract-client-assets <path-to-client.jar> <output-assets/minecraft-directory>");
            println!("  mc189-app extract-launcher-audio <.minecraft\\assets> <indexes\\1.8.json> <output-assets/minecraft/sounds>");
            println!("  mc189-app plan-block-texture-atlas <extracted-texture-root> <output-manifest.json>");
            println!("  mc189-app build-block-texture-atlas <extracted-texture-root> <layout-manifest.json> <output-directory>");
            println!("  mc189-app inspect-block-texture-atlas <atlas-output-directory>");
            println!("  mc189-app preview-block-texture-atlas <atlas-output-directory>");
            println!("  mc189-app preview-textured-block <path-to-client.jar> <atlas-output-directory> <model-id>");
            println!("  mc189-app preview-blockstate-variant <path-to-client.jar> <atlas-output-directory> <blockstate-id> <selector> [seed]");
            println!("  mc189-app inspect-blockstate-variant <path-to-client.jar> <blockstate-id> <selector>");
            println!("  mc189-app inspect-blockstate-multipart <path-to-client.jar> <blockstate-id> <key=value,...|->");
            println!("  mc189-app resolve-client-models <path-to-client.jar>");
            println!("  mc189-app compile-client-geometry <path-to-client.jar>");
            println!("  mc189-app export-debug-chunk-mesh <path-to-world-folder> <chunk-x> <chunk-z> <output.obj>");
            println!("  mc189-app preview-debug-obj <path-to-mesh.obj>");
            println!("  mc189-app audit-world-state-map <path-to-world-folder> <path-to-client.jar>");
            println!("  mc189-app preview-textured-chunk <world-folder> <client.jar> <atlas-output-directory> <chunk-x> <chunk-z>");
            println!("  mc189-app preview-textured-region <world-folder> <client.jar> <atlas-output-directory> <center-chunk-x> <center-chunk-z> <radius-chunks-0-to-4>");
            println!("  mc189-app inspect-block <path-to-world-folder> <world-x> <world-y> <world-z>");
            println!("  mc189-app set-world-block <path-to-world-folder> <world-x> <world-y> <world-z> <block-id> <metadata>");
            println!();
            println!("World inspection remains read-only unless set-world-block is explicitly used. set-world-block rewrites one legacy chunk transactionally and retains a region backup. preview-textured-chunk is the first integrated chunk path: it decodes a legacy chunk and horizontal neighbors, resolves supported ID/metadata states and contextual grass/fence variants, caches the JAR model catalog, builds one atlas-UV mesh, and displays it in wgpu; fluids, animated textures, biome tint, lighting, tile entities and unsupported legacy visuals remain explicitly outside this milestone.");
            Ok(())
        }
    }
}


fn inspect_block_texture_atlas(output_dir: &Path) -> Result<()> {
    let atlas = client_atlas_runtime::AtlasRuntime::load(output_dir)?;
    println!("Minecraft 1.8.9 runtime block atlas");
    println!("  Output: {}", output_dir.display());
    println!("  Page dimensions: {}x{}", atlas.page_size(), atlas.page_size());
    println!("  Gutter: {} px", atlas.padding());
    println!("  Static texture entries: {}", atlas.static_texture_count());
    println!("  Animated textures kept separate: {}", atlas.animated_textures().len());
    println!("  Manifest, atlas PNG pages, and dimensions: valid");
    println!("  GPU upload API: available (not invoked by this read-only audit command)");
    Ok(())
}

fn inspect_player_spawn(world_path: &Path) -> Result<()> {
    let spawn = player::load_world_spawn(world_path)?;
    let metadata = read_world_metadata(world_path)?;
    println!("Minecraft 1.8.9 player spawn inspection");
    println!("World: {}", world_path.display());
    println!("Level name: {}", metadata.level_name.as_deref().unwrap_or("<unnamed>"));
    println!("Spawn block: ({},{},{})", metadata.spawn_x.unwrap_or_default(), metadata.spawn_y.unwrap_or_default(), metadata.spawn_z.unwrap_or_default());
    println!("Player feet position: ({:.2}, {:.2}, {:.2})", spawn.x, spawn.y, spawn.z);
    println!("Player eye position: ({:.2}, {:.2}, {:.2})", spawn.x, spawn.y + player::PLAYER_EYE_HEIGHT, spawn.z);
    println!("Classic player collision box: {:.1} x {:.1} blocks", player::PLAYER_WIDTH, player::PLAYER_HEIGHT);
    println!("World was opened read-only; no files were modified.");
    Ok(())
}

fn inspect_world_chunks(world_path: &Path) -> Result<()> {
    if !world_path.is_dir() {
        return Err(Mc189Error::Usage(format!("world path is not a directory: {}", world_path.display())));
    }
    let region_dir = world_path.join("region");
    if !region_dir.is_dir() {
        return Err(Mc189Error::Usage(format!("no region directory found at {}", region_dir.display())));
    }
    let mut regions: Vec<PathBuf> = fs::read_dir(&region_dir)?
        .filter_map(|entry| entry.ok().map(|e| e.path()))
        .filter(|path| path.extension().is_some_and(|ext| ext == "mca"))
        .collect();
    regions.sort();
    let mut checked = 0_usize;
    let mut decoded = 0_usize;
    let mut failed = 0_usize;
    println!("Decoding chunks (read-only): {}", world_path.display());
    for path in &regions {
        let header = match RegionHeader::from_file(path) {
            Ok(header) => header,
            Err(error) => { eprintln!("[REGION ERROR] {}: {error}", path.display()); failed += 1; continue; }
        };
        for z in 0..32_u8 {
            for x in 0..32_u8 {
                if !header.location(x, z).is_some_and(|loc| loc.is_present()) { continue; }
                checked += 1;
                match inspect_chunk(path, x, z) {
                    Ok(chunk) => {
                        decoded += 1;
                        if decoded <= 20 {
                            println!("[OK] {} local ({x},{z}) -> chunk ({},{}) | sections: {} | block arrays: {} | NBT root: {:?}",
                                path.file_name().unwrap_or_default().to_string_lossy(),
                                chunk.x_pos.unwrap_or(i32::MIN), chunk.z_pos.unwrap_or(i32::MIN),
                                chunk.section_count, chunk.block_arrays, chunk.root_name);
                        }
                    }
                    Err(error) => {
                        failed += 1;
                        if failed <= 20 { println!("[FAIL] {} local ({x},{z}): {error}", path.file_name().unwrap_or_default().to_string_lossy()); }
                    }
                }
            }
        }
    }
    println!();
    println!("Chunk entries checked: {checked}");
    println!("Chunks with valid compressed NBT: {decoded}");
    println!("Failed chunk decodes: {failed}");
    if decoded > 20 { println!("Only the first 20 decoded chunks were listed."); }
    if failed > 20 { println!("Only the first 20 failures were listed."); }
    println!("No world files were modified.");
    Ok(())
}


fn inspect_world_blocks(world_path: &Path) -> Result<()> {
    if !world_path.is_dir() {
        return Err(Mc189Error::Usage(format!("world path is not a directory: {}", world_path.display())));
    }
    let region_dir = world_path.join("region");
    if !region_dir.is_dir() {
        return Err(Mc189Error::Usage(format!("no region directory found at {}", region_dir.display())));
    }
    let mut regions: Vec<PathBuf> = fs::read_dir(&region_dir)?
        .filter_map(|entry| entry.ok().map(|e| e.path()))
        .filter(|path| path.extension().is_some_and(|ext| ext == "mca"))
        .collect();
    regions.sort();

    let mut checked = 0_usize;
    let mut decoded = 0_usize;
    let mut failed = 0_usize;
    let mut sections_total = 0_usize;
    let mut block_slots_total = 0_u64;
    let mut non_air_total = 0_u64;
    let mut chunks_with_biomes = 0_usize;
    let mut chunks_with_heightmap = 0_usize;
    let mut coordinate_mismatches = 0_usize;
    let mut id_counts: BTreeMap<u16, u64> = BTreeMap::new();

    println!("Decoding legacy 1.8.9 block arrays (read-only): {}", world_path.display());
    for path in &regions {
        let header = match RegionHeader::from_file(path) {
            Ok(header) => header,
            Err(error) => {
                eprintln!("[REGION ERROR] {}: {error}", path.display());
                failed += 1;
                continue;
            }
        };
        for z in 0..32_u8 {
            for x in 0..32_u8 {
                if !header.location(x, z).is_some_and(|loc| loc.is_present()) { continue; }
                checked += 1;
                match decode_chunk(path, x, z) {
                    Ok(chunk) => {
                        decoded += 1;
                        if let Some((region_x, region_z)) = parse_region_coordinates(path) {
                            let expected_x = region_x.checked_mul(32).and_then(|base| base.checked_add(i32::from(x)));
                            let expected_z = region_z.checked_mul(32).and_then(|base| base.checked_add(i32::from(z)));
                            if expected_x != Some(chunk.x_pos) || expected_z != Some(chunk.z_pos) {
                                coordinate_mismatches += 1;
                                if coordinate_mismatches <= 20 {
                                    println!("[COORDINATE MISMATCH] {} local ({x},{z}): payload says ({},{}), region slot implies ({:?},{:?})",
                                        path.file_name().unwrap_or_default().to_string_lossy(), chunk.x_pos, chunk.z_pos, expected_x, expected_z);
                                }
                            }
                        }
                        sections_total += chunk.sections.len();
                        if chunk.biomes.is_some() { chunks_with_biomes += 1; }
                        if chunk.height_map.is_some() { chunks_with_heightmap += 1; }
                        let mut chunk_slots = 0_usize;
                        let mut chunk_non_air = 0_usize;
                        for section in &chunk.sections {
                            chunk_slots += section.block_ids.len();
                            for &id in &section.block_ids {
                                *id_counts.entry(id).or_insert(0) += 1;
                                if id != 0 { chunk_non_air += 1; }
                            }
                        }
                        block_slots_total += chunk_slots as u64;
                        non_air_total += chunk_non_air as u64;
                        if decoded <= 12 {
                            let section_ys = chunk.sections.iter().map(|s| s.y.to_string()).collect::<Vec<_>>().join(",");
                            println!("[OK] chunk ({},{}) | sections Y=[{}] | block slots: {} | non-air: {} | biomes: {} | heightmap: {}",
                                chunk.x_pos, chunk.z_pos, section_ys, chunk_slots, chunk_non_air,
                                chunk.biomes.is_some(), chunk.height_map.is_some());
                        }
                    }
                    Err(error) => {
                        failed += 1;
                        if failed <= 20 {
                            println!("[FAIL] {} local ({x},{z}): {error}", path.file_name().unwrap_or_default().to_string_lossy());
                        }
                    }
                }
            }
        }
    }

    let mut top_ids: Vec<(u16, u64)> = id_counts.into_iter().collect();
    top_ids.sort_by(|a, b| b.1.cmp(&a.1).then_with(|| a.0.cmp(&b.0)));
    println!();
    println!("Chunk entries checked: {checked}");
    println!("Chunks with decoded legacy block arrays: {decoded}");
    println!("Chunks with decode failures: {failed}");
    println!("Sections decoded: {sections_total}");
    println!("Block positions represented by sections: {block_slots_total}");
    println!("Non-air blocks (ID != 0): {non_air_total}");
    println!("Chunks with 256 biome entries: {chunks_with_biomes}");
    println!("Chunks with 256 heightmap entries: {chunks_with_heightmap}");
    println!("Chunk coordinates inconsistent with region slots: {coordinate_mismatches}");
    println!("Most frequent legacy block IDs (numeric ID; counts include air only in ID 0):");
    for (id, count) in top_ids.iter().take(20) {
        println!("  ID {id:>4}: {count}");
    }
    println!("No world files were modified.");
    Ok(())
}

fn inspect_world_meta(world_path: &Path) -> Result<()> {
    if !world_path.is_dir() {
        return Err(Mc189Error::Usage(format!(
            "world path is not a directory: {}",
            world_path.display()
        )));
    }
    let metadata = read_world_metadata(world_path)?;
    println!("World metadata (read-only): {}", world_path.display());
    println!("NBT root name: {:?}", metadata.root_name);

    if let Some(name) = metadata.level_name.as_deref() {
        println!("Level name: {name}");
    }
    if let Some(version) = metadata.storage_version {
        let label = match version {
            19132 => "McRegion storage format",
            19133 => "Anvil storage format",
            _ => "unrecognized storage format version",
        };
        println!("Storage format version: {version} ({label})");
        println!("Note: this is the world storage-format version, not the exact Minecraft game version.");
    }
    if let Some(game_type) = metadata.game_type {
        let label = match game_type {
            0 => "Survival",
            1 => "Creative",
            2 => "Adventure",
            3 => "Spectator",
            _ => "unknown",
        };
        println!("Game type: {game_type} ({label})");
    }
    if let Some(seed) = metadata.random_seed {
        println!("Random seed: {seed}");
    }
    if metadata.spawn_x.is_some() || metadata.spawn_y.is_some() || metadata.spawn_z.is_some() {
        println!("Spawn X/Y/Z: {:?} / {:?} / {:?}", metadata.spawn_x, metadata.spawn_y, metadata.spawn_z);
    }
    if let Some(time) = metadata.time {
        println!("World time (ticks): {time}");
    }
    if let Some(day_time) = metadata.day_time {
        println!("Day time (ticks): {day_time}");
    }
    if let Some(generator) = metadata.generator_name.as_deref() {
        println!("Generator: {generator}");
    }
    if let Some(options) = metadata.generator_options.as_deref() {
        println!("Generator options: {options}");
    }
    print_byte_option("Hardcore", metadata.hardcore);
    print_byte_option("Allow commands", metadata.allow_commands);
    print_byte_option("Map features", metadata.map_features);
    print_byte_option("Raining", metadata.raining);
    print_byte_option("Thundering", metadata.thundering);
    if let Some(value) = metadata.rain_time {
        println!("Rain time: {value}");
    }
    if let Some(value) = metadata.thunder_time {
        println!("Thunder time: {value}");
    }
    println!("No world files were modified.");
    Ok(())
}

fn print_byte_option(label: &str, value: Option<i8>) {
    if let Some(value) = value {
        println!("{label}: {value}");
    }
}

fn parse_region_coordinates(path: &Path) -> Option<(i32, i32)> {
    let stem = path.file_stem()?.to_str()?;
    let mut parts = stem.split('.');
    if parts.next()? != "r" { return None; }
    let region_x = parts.next()?.parse::<i32>().ok()?;
    let region_z = parts.next()?.parse::<i32>().ok()?;
    if parts.next().is_some() { return None; }
    Some((region_x, region_z))
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct BlockCoordinates {
    world_x: i32,
    world_y: i32,
    world_z: i32,
    chunk_x: i32,
    chunk_z: i32,
    local_x: u8,
    local_y: u8,
    local_z: u8,
    region_x: i32,
    region_z: i32,
    region_local_x: u8,
    region_local_z: u8,
}

fn parse_coordinate(value: &str, axis: &str) -> Result<i32> {
    value.parse::<i32>().map_err(|_| {
        Mc189Error::Usage(format!("invalid {axis} coordinate {value:?}; expected a signed 32-bit integer"))
    })
}

fn resolve_block_coordinates(world_x: i32, world_y: i32, world_z: i32) -> Result<BlockCoordinates> {
    if !(0..=255).contains(&world_y) {
        return Err(Mc189Error::Usage(format!(
            "Y coordinate {world_y} is outside the classic 1.8 world range 0..255"
        )));
    }

    // Euclidean division is important for negative coordinates. Rust integer division
    // truncates toward zero, which would map blocks west/north of origin incorrectly.
    let chunk_x = world_x.div_euclid(16);
    let chunk_z = world_z.div_euclid(16);
    let local_x = world_x.rem_euclid(16) as u8;
    let local_z = world_z.rem_euclid(16) as u8;
    let (region_x, region_local_x) = split_chunk_coordinate(chunk_x);
    let (region_z, region_local_z) = split_chunk_coordinate(chunk_z);

    Ok(BlockCoordinates {
        world_x,
        world_y,
        world_z,
        chunk_x,
        chunk_z,
        local_x,
        local_y: (world_y % 16) as u8,
        local_z,
        region_x,
        region_z,
        region_local_x,
        region_local_z,
    })
}

/// Explicit storage smoke-test/editor command. The runtime mining loop will call the same API.
fn set_world_block(world_path:&Path, world_x:i32, world_y:i32, world_z:i32, id:u16, meta:u8)->Result<()> {
    let c=resolve_block_coordinates(world_x,world_y,world_z)?;
    let mut chunk=load_mutable_chunk(world_path,c.chunk_x,c.chunk_z)?;
    let (old_id,old_meta)=chunk.set_block(c.local_x,world_y as u8,c.local_z,id,meta)?;
    if chunk.is_dirty(){save_mutable_chunk(world_path,&mut chunk)?;}
    println!("Saved block ({world_x},{world_y},{world_z}): {old_id}:{old_meta} -> {id}:{meta}");
    println!("Region r.{}.{}.mca updated with sibling chunks preserved.",c.region_x,c.region_z);
    Ok(())
}

fn inspect_block(world_path: &Path, world_x: i32, world_y: i32, world_z: i32) -> Result<()> {
    if !world_path.is_dir() {
        return Err(Mc189Error::Usage(format!(
            "world path is not a directory: {}",
            world_path.display()
        )));
    }
    let coords = resolve_block_coordinates(world_x, world_y, world_z)?;
    let region_path = world_path
        .join("region")
        .join(format!("r.{}.{}.mca", coords.region_x, coords.region_z));
    if !region_path.is_file() {
        return Err(Mc189Error::InvalidData(format!(
            "region file is not present for block ({world_x},{world_y},{world_z}): {}",
            region_path.display()
        )));
    }

    let header = RegionHeader::from_file(&region_path)?;
    let location = header
        .location(coords.region_local_x, coords.region_local_z)
        .ok_or_else(|| Mc189Error::InvalidData("computed region-local coordinates are invalid".into()))?;
    if !location.is_present() {
        return Err(Mc189Error::InvalidData(format!(
            "no saved chunk exists at chunk ({},{}); refusing to assume that an absent chunk is air",
            coords.chunk_x, coords.chunk_z
        )));
    }

    let chunk = decode_chunk(&region_path, coords.region_local_x, coords.region_local_z)?;
    if chunk.x_pos != coords.chunk_x || chunk.z_pos != coords.chunk_z {
        return Err(Mc189Error::InvalidData(format!(
            "chunk coordinate mismatch: region slot implies ({},{}), NBT says ({},{})",
            coords.chunk_x, coords.chunk_z, chunk.x_pos, chunk.z_pos
        )));
    }

    let y = coords.world_y as u8;
    let block_id = chunk.block_id_at(coords.local_x, y, coords.local_z)
        .ok_or_else(|| Mc189Error::InvalidData("decoded chunk could not answer the block query".into()))?;
    let metadata = chunk.block_metadata_at(coords.local_x, y, coords.local_z)
        .ok_or_else(|| Mc189Error::InvalidData("decoded chunk could not answer the metadata query".into()))?;
    let section_y = coords.world_y / 16;
    let section = chunk.sections.iter().find(|section| i32::from(section.y) == section_y);
    let block_index = (usize::from(coords.local_y) << 8)
        | (usize::from(coords.local_z) << 4)
        | usize::from(coords.local_x);
    let block_light = section.and_then(|s| s.block_light.as_ref()).and_then(|v| v.get(block_index)).copied();
    let sky_light = section.and_then(|s| s.sky_light.as_ref()).and_then(|v| v.get(block_index)).copied();
    let column_index = usize::from(coords.local_z) * 16 + usize::from(coords.local_x);
    let biome = chunk.biomes.as_ref().and_then(|v| v.get(column_index)).copied();
    let height = chunk.height_map.as_ref().and_then(|v| v.get(column_index)).copied();

    println!("Block query (read-only)");
    println!("World coordinate: ({},{},{})", coords.world_x, coords.world_y, coords.world_z);
    println!("Chunk coordinate: ({},{})", coords.chunk_x, coords.chunk_z);
    println!("Chunk local coordinate: ({},{},{})", coords.local_x, coords.local_y, coords.local_z);
    println!("Region file: {}", region_path.display());
    println!("Region-local slot: ({},{})", coords.region_local_x, coords.region_local_z);
    println!("Section Y: {section_y} ({})", if section.is_some() { "stored" } else { "not stored; treated as air" });
    println!("Legacy block ID: {block_id}");
    println!("Block metadata: {metadata}");
    print_optional("Block light (0..15)", block_light);
    print_optional("Sky light (0..15)", sky_light);
    print_optional("Biome ID for column", biome);
    print_optional("HeightMap value for column", height);
    println!("Note: numeric IDs are preserved as stored; mapping IDs/metadata to vanilla or modded block names is a separate registry step.");
    println!("No world files were modified.");
    Ok(())
}

fn print_optional<T: std::fmt::Display>(label: &str, value: Option<T>) {
    match value {
        Some(value) => println!("{label}: {value}"),
        None => println!("{label}: unavailable"),
    }
}

#[cfg(test)]
mod coordinate_tests {
    use super::*;

    #[test]
    fn block_coordinates_handle_negative_world_positions() {
        let c = resolve_block_coordinates(-1, 64, -17).unwrap();
        assert_eq!((c.chunk_x, c.chunk_z), (-1, -2));
        assert_eq!((c.local_x, c.local_y, c.local_z), (15, 0, 15));
        assert_eq!((c.region_x, c.region_z), (-1, -1));
        assert_eq!((c.region_local_x, c.region_local_z), (31, 30));
    }

    #[test]
    fn block_coordinates_resolve_the_reported_world_spawn() {
        let c = resolve_block_coordinates(-256, 64, 244).unwrap();
        assert_eq!((c.chunk_x, c.chunk_z), (-16, 15));
        assert_eq!((c.local_x, c.local_y, c.local_z), (0, 0, 4));
        assert_eq!((c.region_x, c.region_z), (-1, 0));
        assert_eq!((c.region_local_x, c.region_local_z), (16, 15));
    }

    #[test]
    fn block_queries_reject_y_outside_classic_world_height() {
        assert!(resolve_block_coordinates(0, -1, 0).is_err());
        assert!(resolve_block_coordinates(0, 256, 0).is_err());
    }
}

#[derive(Clone, Copy)]
enum ResourceKind {
    Png,
    Json,
    Class,
}

fn inspect_client_jar(jar_path: &Path) -> Result<()> {
    if !jar_path.is_file() {
        return Err(Mc189Error::Usage(format!(
            "client JAR is not a file: {}",
            jar_path.display()
        )));
    }

    let file_size = fs::metadata(jar_path)?.len();
    let file = File::open(jar_path)?;
    let mut archive = ZipArchive::new(file).map_err(|error| {
        Mc189Error::InvalidData(format!(
            "could not open {} as a ZIP/JAR archive: {error}",
            jar_path.display()
        ))
    })?;

    let entry_count = archive.len();
    let mut names = Vec::with_capacity(entry_count);
    let mut block_textures = 0_usize;
    let mut item_textures = 0_usize;
    let mut block_models = 0_usize;
    let mut item_models = 0_usize;
    let mut blockstates = 0_usize;
    let mut minecraft_assets = 0_usize;

    for index in 0..entry_count {
        let entry = archive.by_index(index).map_err(|error| {
            Mc189Error::InvalidData(format!("could not read JAR directory entry {index}: {error}"))
        })?;
        let name = entry.name().to_owned();
        if name.starts_with("assets/minecraft/") {
            minecraft_assets += 1;
        }
        if name.starts_with("assets/minecraft/textures/blocks/") && name.ends_with(".png") {
            block_textures += 1;
        }
        if name.starts_with("assets/minecraft/textures/items/") && name.ends_with(".png") {
            item_textures += 1;
        }
        if name.starts_with("assets/minecraft/models/block/") && name.ends_with(".json") {
            block_models += 1;
        }
        if name.starts_with("assets/minecraft/models/item/") && name.ends_with(".json") {
            item_models += 1;
        }
        if name.starts_with("assets/minecraft/blockstates/") && name.ends_with(".json") {
            blockstates += 1;
        }
        names.push(name);
    }

    let name_set: std::collections::HashSet<&str> = names.iter().map(String::as_str).collect();
    let core_resources: [(&str, ResourceKind); 9] = [
        ("assets/minecraft/textures/blocks/stone.png", ResourceKind::Png),
        ("assets/minecraft/textures/blocks/dirt.png", ResourceKind::Png),
        ("assets/minecraft/textures/blocks/grass_top.png", ResourceKind::Png),
        ("assets/minecraft/textures/blocks/grass_side.png", ResourceKind::Png),
        ("assets/minecraft/textures/blocks/cobblestone.png", ResourceKind::Png),
        ("assets/minecraft/models/block/stone.json", ResourceKind::Json),
        ("assets/minecraft/models/block/cube_all.json", ResourceKind::Json),
        ("assets/minecraft/blockstates/stone.json", ResourceKind::Json),
        ("net/minecraft/client/main/Main.class", ResourceKind::Class),
    ];

    println!("Client JAR resource inspection (read-only)");
    println!("File: {}", jar_path.display());
    println!("Archive size: {file_size} bytes");
    println!("Archive entries: {entry_count}");
    println!("Minecraft assets entries: {minecraft_assets}");
    println!("Block texture PNGs: {block_textures}");
    println!("Item texture PNGs: {item_textures}");
    println!("Block model JSON files: {block_models}");
    println!("Item model JSON files: {item_models}");
    println!("Blockstate JSON files: {blockstates}");
    println!();
    println!("Core resource checks:");

    let mut passed = 0_usize;
    let mut missing = 0_usize;
    let mut invalid = 0_usize;
    for (name, kind) in core_resources {
        if !name_set.contains(name) {
            println!("[MISSING] {name}");
            missing += 1;
            continue;
        }
        let valid = validate_jar_entry(&mut archive, name, kind)?;
        if valid {
            println!("[OK]      {name}");
            passed += 1;
        } else {
            println!("[INVALID] {name} (entry exists but its content signature/format is unexpected)");
            invalid += 1;
        }
    }

    println!();
    println!("Core resources valid: {passed}/{}", core_resources.len());
    println!("Missing core resources: {missing}");
    println!("Invalid core resources: {invalid}");
    if block_textures == 0 || block_models == 0 || blockstates == 0 {
        println!("Warning: one or more resource groups are empty; verify that this is the expected client JAR.");
    }
    println!("Note: this checks archive contents and selected resource signatures, not cryptographic authenticity or the exact game version.");
    println!("The JAR was not extracted or modified.");
    Ok(())
}

fn validate_jar_entry<R: std::io::Read + std::io::Seek>(
    archive: &mut ZipArchive<R>,
    name: &str,
    kind: ResourceKind,
) -> Result<bool> {
    let mut entry = archive.by_name(name).map_err(|error| {
        Mc189Error::InvalidData(format!("JAR directory listed {name} but it could not be opened: {error}"))
    })?;

    // These known resources should be small. Refuse to read unexpectedly large entries.
    const MAX_RESOURCE_BYTES: u64 = 4 * 1024 * 1024;
    if entry.size() > MAX_RESOURCE_BYTES {
        return Ok(false);
    }

    let mut bytes = Vec::with_capacity(entry.size() as usize);
    entry.read_to_end(&mut bytes)?;
    match kind {
        ResourceKind::Png => Ok(bytes.starts_with(&[137, 80, 78, 71, 13, 10, 26, 10])),
        ResourceKind::Json => {
            let Ok(text) = std::str::from_utf8(&bytes) else {
                return Ok(false);
            };
            Ok(text.trim_start().starts_with('{') && text.trim_end().ends_with('}'))
        }
        ResourceKind::Class => Ok(bytes.starts_with(&[0xCA, 0xFE, 0xBA, 0xBE])),
    }
}

#[cfg(test)]
mod resource_path_tests {
    #[test]
    fn resource_directory_checks_match_minecraft_asset_layout() {
        let path = "assets/minecraft/textures/blocks/stone.png";
        assert!(path.starts_with("assets/minecraft/textures/blocks/") && path.ends_with(".png"));
        assert!("assets/minecraft/models/block/stone.json".starts_with("assets/minecraft/models/block/"));
        assert!("assets/minecraft/blockstates/stone.json".starts_with("assets/minecraft/blockstates/"));
        assert!(!"assets/minecraft/textures/items/stone.png".starts_with("assets/minecraft/textures/blocks/"));
    }

    #[test]
    fn class_signature_is_the_java_class_magic_value() {
        assert_eq!(&[0xCA, 0xFE, 0xBA, 0xBE], b"\xCA\xFE\xBA\xBE");
    }
}

fn inspect_region(path: &Path) -> Result<()> {
    let header = RegionHeader::from_file(path)?;
    println!("Region file: {}", path.display());
    println!("File size:   {} bytes", header.file_len());
    println!("Chunks present in header: {}", header.present_chunks());
    println!("Header: valid");
    println!("Note: this command validates the region header only; use inspect-world-chunks or inspect-world-blocks for payload data.");
    Ok(())
}

fn inspect_world(world_path: &Path) -> Result<()> {
    if !world_path.is_dir() {
        return Err(Mc189Error::Usage(format!(
            "world path is not a directory: {}",
            world_path.display()
        )));
    }

    let level_dat = world_path.join("level.dat");
    if !level_dat.is_file() {
        eprintln!("warning: no level.dat found at {}", level_dat.display());
    } else {
        println!("Found level.dat (not decoded yet).");
    }

    let region_dir = world_path.join("region");
    if !region_dir.is_dir() {
        return Err(Mc189Error::Usage(format!(
            "no region directory found at {}",
            region_dir.display()
        )));
    }

    let mut regions: Vec<PathBuf> = fs::read_dir(&region_dir)?
        .filter_map(|entry| entry.ok().map(|e| e.path()))
        .filter(|path| path.extension().is_some_and(|ext| ext == "mca"))
        .collect();
    regions.sort();

    println!("World folder: {}", world_path.display());
    println!("Region directory: {}", region_dir.display());
    println!("Region files found: {}", regions.len());

    let mut valid = 0_usize;
    let mut invalid = 0_usize;
    let mut total_chunks = 0_usize;

    for path in &regions {
        match RegionHeader::from_file(path) {
            Ok(header) => {
                valid += 1;
                total_chunks += header.present_chunks();
                println!(
                    "[OK]   {} — {} chunks in header",
                    path.file_name().unwrap_or_default().to_string_lossy(),
                    header.present_chunks()
                );
            }
            Err(error) => {
                invalid += 1;
                println!(
                    "[FAIL] {} — {}",
                    path.file_name().unwrap_or_default().to_string_lossy(),
                    error
                );
            }
        }
    }

    println!();
    println!("Valid region headers: {valid}");
    println!("Invalid region headers: {invalid}");
    println!("Chunk entries present: {total_chunks}");
    println!("No world files were modified.");

    Ok(())
}

fn parse_block_properties(input: &str) -> Result<BTreeMap<String, String>> {
    let mut properties = BTreeMap::new();
    if input == "-" || input.is_empty() { return Ok(properties); }
    for item in input.split(',') {
        let (key, value) = item.split_once('=').ok_or_else(|| Mc189Error::Usage(format!("invalid property {item:?}; expected key=value")))?;
        if key.trim().is_empty() || value.trim().is_empty() { return Err(Mc189Error::Usage(format!("invalid empty key/value in property {item:?}"))); }
        if properties.insert(key.trim().to_owned(), value.trim().to_owned()).is_some() { return Err(Mc189Error::Usage(format!("duplicate blockstate property {:?}", key.trim()))); }
    }
    Ok(properties)
}
