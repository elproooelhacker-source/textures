//! First integrated textured chunk path for classic 1.8.9 worlds.
//!
//! This renderer intentionally emits only states that the legacy registry can resolve
//! without guessing. Context-sensitive grass and oak-fence states are resolved from
//! neighboring blocks. Fluids, tile entities, and metadata-specific legacy visuals are
//! counted as skipped and are not silently replaced by cubes.
use crate::blockstate_resolver::{load_blockstate_variant, select_weighted_variant_index, VariantModel};
use crate::chunk_mesh::load_chunk;
use crate::legacy_state_map::{map_legacy_block, LegacyTarget};
use crate::model_resolver::{CpuMeshQuad, ModelCatalog};
use glam::{Quat, Vec3};
use mc189_core::{Mc189Error, Result};
use mc189_storage::ChunkData;
pub(crate) use mc189_server::persistence::{DirtyChunkSnapshot, EntityItemsSnapshot, PlayerDataSnapshot, WorldSaveRequest};
use std::collections::{BTreeMap, HashMap, HashSet, VecDeque};
use std::path::{Path, PathBuf};
use std::fs::File;
use std::io::Read;
use std::sync::{mpsc::{self, Receiver, Sender}, Arc, Mutex};
use std::thread;
use zip::ZipArchive;

#[derive(Default)]
struct BuildStats {
    non_air: u64,
    rendered_blocks: u64,
    rendered_quads: u64,
    rendered_logs: u64,
    rendered_stone_variants: u64,
    rendered_leaves: u64,
    rendered_vegetation: u64,
    air: u64,
    fluids: u64,
    rendered_water: u64,
    rendered_lava: u64,
    fluid_quads: u64,
    special: u64,
    unknown: u64,
    uvlock: u64,
    missing_models: u64,
    tinted_grass_blocks: u64,
    tinted_grass_faces: u64,
    missing_biome_grass_blocks: u64,
    tinted_leaves_blocks: u64,
    tinted_leaves_faces: u64,
    missing_biome_leaves_blocks: u64,
    skipped_states: BTreeMap<(u16, u8), u64>,
    rendered_furnaces: BTreeMap<(u16, u8), u64>,
}

struct BuiltChunk {
    quads: Vec<CpuMeshQuad>,
    stats: BuildStats,
    center: Vec3,
    radius: f32,
}


/// Vanilla 1.8.9 grass colorizer. The colormap is read from the original client JAR;
/// biome temperature/downfall select the exact 256x256 lookup pixel.
struct GrassColorMap {
    pixels: image::RgbaImage,
}

struct FoliageColorMap {
    pixels: image::RgbaImage,
}

impl GrassColorMap {
    fn load(jar_path: &Path) -> Result<Self> {
        let file = File::open(jar_path)?;
        let mut archive = ZipArchive::new(file).map_err(|error| Mc189Error::InvalidData(format!("could not open client JAR for biome colormap: {error}")))?;
        let mut entry = archive.by_name("assets/minecraft/textures/colormap/grass.png")
            .map_err(|error| Mc189Error::InvalidData(format!("client JAR is missing vanilla grass colormap: {error}")))?;
        let mut bytes = Vec::new();
        entry.read_to_end(&mut bytes)?;
        let image = image::load_from_memory(&bytes)
            .map_err(|error| Mc189Error::InvalidData(format!("cannot decode vanilla grass colormap: {error}")))?
            .to_rgba8();
        if image.width() != 256 || image.height() != 256 {
            return Err(Mc189Error::InvalidData(format!("grass colormap is {}x{}; expected 256x256", image.width(), image.height())));
        }
        Ok(Self { pixels: image })
    }

    fn color_for_biome(&self, biome_id: u8) -> Option<[f32; 3]> {
        let (temperature, mut downfall) = biome_climate(biome_id)?;
        let temperature = temperature.clamp(0.0, 1.0);
        downfall = (downfall * temperature).clamp(0.0, 1.0);
        // Vanilla ColorizerGrass uses index (humidity_index << 8) | temperature_index.
        // PNG rows are Y and columns are X: temperature is X, humidity is Y.
        let temperature_index = ((1.0 - temperature) * 255.0).floor().clamp(0.0, 255.0) as u32;
        let humidity_index = ((1.0 - downfall) * 255.0).floor().clamp(0.0, 255.0) as u32;
        let pixel = self.pixels.get_pixel(temperature_index, humidity_index).0;
        Some([srgb_to_linear(pixel[0]), srgb_to_linear(pixel[1]), srgb_to_linear(pixel[2])])
    }
}

impl FoliageColorMap {
    fn load(jar_path: &Path) -> Result<Self> {
        let file = File::open(jar_path)?;
        let mut archive = ZipArchive::new(file).map_err(|error| Mc189Error::InvalidData(format!("could not open client JAR for foliage colormap: {error}")))?;
        let mut entry = archive.by_name("assets/minecraft/textures/colormap/foliage.png")
            .map_err(|error| Mc189Error::InvalidData(format!("client JAR is missing vanilla foliage colormap: {error}")))?;
        let mut bytes = Vec::new();
        entry.read_to_end(&mut bytes)?;
        let image = image::load_from_memory(&bytes)
            .map_err(|error| Mc189Error::InvalidData(format!("cannot decode vanilla foliage colormap: {error}")))?
            .to_rgba8();
        if image.width() != 256 || image.height() != 256 {
            return Err(Mc189Error::InvalidData(format!("foliage colormap is {}x{}; expected 256x256", image.width(), image.height())));
        }
        Ok(Self { pixels: image })
    }

    fn color_for_biome(&self, biome_id: u8) -> Option<[f32; 3]> {
        let (temperature, mut downfall) = biome_climate(biome_id)?;
        let temperature = temperature.clamp(0.0, 1.0);
        downfall = (downfall * temperature).clamp(0.0, 1.0);
        // Keep the same vanilla coordinate convention as ColorizerFoliage:
        // temperature is X and temperature-adjusted downfall is Y.
        let temperature_index = ((1.0 - temperature) * 255.0).floor().clamp(0.0, 255.0) as u32;
        let humidity_index = ((1.0 - downfall) * 255.0).floor().clamp(0.0, 255.0) as u32;
        let pixel = self.pixels.get_pixel(temperature_index, humidity_index).0;
        Some([srgb_to_linear(pixel[0]), srgb_to_linear(pixel[1]), srgb_to_linear(pixel[2])])
    }
}

fn srgb_to_linear(value: u8) -> f32 {
    let c = f32::from(value) / 255.0;
    if c <= 0.04045 { c / 12.92 } else { ((c + 0.055) / 1.055).powf(2.4) }
}

/// Vanilla biome registry climate values (temperature, rainfall) for the classic IDs.
/// Mutated biomes reuse the base biome climate where their IDs follow the 1.8 registry.
fn biome_climate(id: u8) -> Option<(f32, f32)> {
    let base = match id {
        0 | 7 | 9 | 24 => (0.5, 0.5),
        1 | 16 => (0.8, 0.4),
        2 | 17 | 37 | 38 | 39 => (2.0, 0.0),
        3 | 20 | 25 | 34 => (0.2, 0.3),
        4 | 18 | 29 => (0.7, 0.8),
        5 | 19 => (0.25, 0.8),
        6 => (0.8, 0.9),
        8 => (2.0, 0.0),
        10 | 11 | 12 | 13 => (0.0, 0.5),
        14 | 15 => (0.9, 1.0),
        21 | 22 => (0.95, 0.9),
        23 => (0.95, 0.8),
        26 => (0.05, 0.3),
        27 | 28 => (0.6, 0.6),
        30 | 31 => (-0.5, 0.4),
        32 | 33 => (0.3, 0.8),
        35 => (1.2, 0.0),
        36 => (1.0, 0.0),
        // Mutated 1.8 biome IDs: map to their corresponding base climate.
        129 => (0.8, 0.4), 130 => (2.0, 0.0), 131 => (0.2, 0.3),
        132 => (0.7, 0.8), 133 => (0.25, 0.8), 134 => (0.8, 0.9),
        140 => (0.0, 0.5), 149 => (0.95, 0.9), 151 => (0.95, 0.8),
        155 | 156 => (0.6, 0.6), 157 => (0.7, 0.8), 158 => (-0.5, 0.4),
        160 | 161 => (0.3, 0.8), 162 => (0.2, 0.3), 163 => (1.2, 0.0),
        164 => (1.0, 0.0), 165 | 166 | 167 => (2.0, 0.0),
        _ => return None,
    };
    Some(base)
}

trait BiomeColorLookup {
    fn color_for_biome(&self, biome_id: u8) -> Option<[f32; 3]>;
}

impl BiomeColorLookup for GrassColorMap {
    fn color_for_biome(&self, biome_id: u8) -> Option<[f32; 3]> {
        GrassColorMap::color_for_biome(self, biome_id)
    }
}

impl BiomeColorLookup for FoliageColorMap {
    fn color_for_biome(&self, biome_id: u8) -> Option<[f32; 3]> {
        FoliageColorMap::color_for_biome(self, biome_id)
    }
}

fn linear_to_srgb(value: f32) -> f32 {
    if value <= 0.0031308 { value * 12.92 } else { 1.055 * value.powf(1.0 / 2.4) - 0.055 }
}

/// BiomeColorHelper.getGrassColorAtPos / getFoliageColorAtPos samples a 3x3
/// neighborhood and averages the integer RGB colors before texture multiplication.
fn biome_tint_at_world<C: BiomeColorLookup>(
    chunks: &HashMap<(i32, i32), ChunkData>, x: i64, z: i64, colormap: &C,
) -> Option<[f32; 3]> {
    let mut sum = [0_u32; 3];
    for dz in -1_i64..=1 { for dx in -1_i64..=1 {
        let color = colormap.color_for_biome(biome_id_at_world(chunks, x + dx, z + dz))?;
        for channel in 0..3 {
            sum[channel] += (linear_to_srgb(color[channel]).clamp(0.0, 1.0) * 255.0).round() as u32;
        }
    }}
    Some([
        srgb_to_linear((sum[0] / 9) as u8),
        srgb_to_linear((sum[1] / 9) as u8),
        srgb_to_linear((sum[2] / 9) as u8),
    ])
}

fn biome_id_at_world(chunks: &HashMap<(i32, i32), ChunkData>, x: i64, z: i64) -> u8 {
    let cx = x.div_euclid(16);
    let cz = z.div_euclid(16);
    let (Ok(cx), Ok(cz)) = (i32::try_from(cx), i32::try_from(cz)) else { return 0; };
    let Some(chunk) = chunks.get(&(cx, cz)) else { return 0; };
    chunk.biomes.as_ref()
        .and_then(|biomes| biomes.get(z.rem_euclid(16) as usize * 16 + x.rem_euclid(16) as usize))
        .copied().unwrap_or(0)
}

fn vanilla_water_color(biome_id: u8) -> [u8; 3] {
    // BiomeGenSwamp sets 0xE0FFAE; the remaining vanilla 1.8.9 biomes
    // retain BiomeGenBase's default white multiplier. The swamp mutation
    // inherits the same water color.
    if matches!(biome_id, 6 | 134) { [224, 255, 174] } else { [255, 255, 255] }
}

fn water_biome_tint(chunks: &HashMap<(i32, i32), ChunkData>, x: i64, z: i64) -> [f32; 3] {
    // BiomeColorHelper.getWaterColorAtPos averages the 3x3 biome neighborhood.
    let mut sum = [0_u32; 3];
    for dx in -1_i64..=1 {
        for dz in -1_i64..=1 {
            let color = vanilla_water_color(biome_id_at_world(chunks, x + dx, z + dz));
            for channel in 0..3 { sum[channel] += u32::from(color[channel]); }
        }
    }
    [
        (sum[0] / 9) as f32 / 255.0,
        (sum[1] / 9) as f32 / 255.0,
        (sum[2] / 9) as f32 / 255.0,
    ]
}

fn block_at(chunks: &HashMap<(i32, i32), ChunkData>, x: i64, y: i32, z: i64) -> u16 {
    if !(0..=255).contains(&y) { return 0; }
    let cx = x.div_euclid(16);
    let cz = z.div_euclid(16);
    let (Ok(cx), Ok(cz)) = (i32::try_from(cx), i32::try_from(cz)) else { return 0; };
    chunks.get(&(cx, cz)).and_then(|chunk| chunk.block_id_at(x.rem_euclid(16) as u8, y as u8, z.rem_euclid(16) as u8)).unwrap_or(0)
}

/// First air Y above the highest light-blocking block, derived from the blocks
/// when the chunk carries no HeightMap (otherwise the whole chunk would be dark).
fn derived_first_air(chunk: &ChunkData, lx: usize, lz: usize) -> i32 {
    for y in (0..256_i32).rev() {
        let id = chunk.block_id_at(lx as u8, y as u8, lz as u8).unwrap_or(0);
        if vanilla_light_opacity(id) > 0 { return y + 1; }
    }
    0
}

fn sky_light_from_heightmap(chunk: &ChunkData, lx: usize, y: i32, lz: usize) -> f32 {
    // Anvil HeightMap stores top_block_y + 1: equality is the first air block.
    let first_air = match chunk.height_map.as_ref().and_then(|h| h.get(lz * 16 + lx)).copied() {
        Some(value) => value,
        None => derived_first_air(chunk, lx, lz),
    };
    if y >= first_air { 1.0 } else { 0.0 }
}

/// The vertex payload returned by the 1.8.9 AmbientOcclusionFace port.
/// Sky and block channels are kept separate and normalized only after the
/// packed-light averaging rules from the original renderer have been applied.
#[derive(Clone, Copy, Debug)]
struct VanillaVertexLighting {
    ao: [f32; 4],
    sky: [f32; 4],
    block: [f32; 4],
    face_shade: [f32; 4],
}

#[derive(Clone, Copy, Debug)]
struct VanillaLightChannels {
    sky: u8,
    block: u8,
}

#[derive(Clone, Copy, Debug)]
struct AoSample {
    ao: f32,
    packed_light: u32,
}

#[derive(Clone, Copy)]
struct AoFaceInfo {
    side_offsets: [[i64; 3]; 4],
    shade: f32,
    non_cubic_weight: bool,
    vertex_translation: [usize; 4],
    /// Each output AO corner has four pairs of bound indices (eight enum
    /// directions). They are the exact bgf$a tables in client.jar.
    orientation_bounds: [[u8; 8]; 4],
}

fn face_direction_offset(face: crate::model_resolver::ModelFaceDirection) -> [i64; 3] {
    use crate::model_resolver::ModelFaceDirection as Face;
    match face {
        Face::Down => [0, -1, 0], Face::Up => [0, 1, 0],
        Face::North => [0, 0, -1], Face::South => [0, 0, 1],
        Face::West => [-1, 0, 0], Face::East => [1, 0, 0],
    }
}

fn ao_face_info(face: crate::model_resolver::ModelFaceDirection) -> AoFaceInfo {
    use crate::model_resolver::ModelFaceDirection as Face;
    // Direction indices are EnumFacing's 1.8.9 order:
    // DOWN=0, UP=1, NORTH=2, SOUTH=3, WEST=4, EAST=5.
    match face {
        Face::Down => AoFaceInfo {
            side_offsets: [[-1,0,0], [1,0,0], [0,0,-1], [0,0,1]],
            shade: 0.5, non_cubic_weight: false,
            vertex_translation: [0,1,2,3], orientation_bounds: [[0;8];4],
        },
        Face::Up => AoFaceInfo {
            side_offsets: [[1,0,0], [-1,0,0], [0,0,-1], [0,0,1]],
            shade: 1.0, non_cubic_weight: false,
            vertex_translation: [2,3,0,1], orientation_bounds: [[0;8];4],
        },
        Face::North => AoFaceInfo {
            side_offsets: [[0,1,0], [0,-1,0], [1,0,0], [-1,0,0]],
            shade: 0.8, non_cubic_weight: true,
            vertex_translation: [3,0,1,2],
            orientation_bounds: [
                [1,10,1,4,7,4,7,10], [1,11,1,5,7,5,7,11],
                [0,11,0,5,6,5,6,11], [0,10,0,4,6,4,6,10],
            ],
        },
        Face::South => AoFaceInfo {
            side_offsets: [[-1,0,0], [1,0,0], [0,-1,0], [0,1,0]],
            shade: 0.8, non_cubic_weight: true,
            vertex_translation: [0,1,2,3],
            orientation_bounds: [
                [1,10,7,10,7,4,1,4], [0,10,6,10,6,4,0,4],
                [0,11,6,11,6,5,0,5], [1,11,7,11,7,5,1,5],
            ],
        },
        Face::West => AoFaceInfo {
            side_offsets: [[0,1,0], [0,-1,0], [0,0,-1], [0,0,1]],
            shade: 0.6, non_cubic_weight: true,
            vertex_translation: [3,0,1,2],
            orientation_bounds: [
                [1,3,1,9,7,9,7,3], [1,2,1,8,7,8,7,2],
                [0,2,0,8,6,8,6,2], [0,3,0,9,6,9,6,3],
            ],
        },
        Face::East => AoFaceInfo {
            side_offsets: [[0,-1,0], [0,1,0], [0,0,-1], [0,0,1]],
            shade: 0.6, non_cubic_weight: true,
            vertex_translation: [1,2,3,0],
            orientation_bounds: [
                [6,3,6,9,0,9,0,3], [6,2,6,8,0,8,0,2],
                [7,2,7,8,1,8,1,2], [7,3,7,9,1,9,1,3],
            ],
        },
    }
}

fn vanilla_light_emission(id: u16) -> u8 {
    // LightValue values from the classic 1.8 block registry for the mapped
    // emissive families. Saved BlockLight can exceed these values and wins.
    match id {
        10 | 11 | 51 | 89 | 91 | 119 | 124 | 138 | 169 => 15,
        50 => 14,
        62 => 13,
        90 => 11,
        74 | 94 | 150 => 9,
        76 | 116 | 130 => 7,
        39 | 40 | 117 | 120 | 122 => 1,
        _ => 0,
    }
}

/// Whether replacing one legacy block can change either vanilla light channel.
/// When both opacity and emission are identical, the existing nibble maps and
/// heightmap remain valid; rebuilding a 3x3 light neighborhood would be pure waste.
#[inline]
fn block_edit_changes_light(old_id: u16, new_id: u16) -> bool {
    vanilla_light_opacity(old_id) != vanilla_light_opacity(new_id)
        || vanilla_light_emission(old_id) != vanilla_light_emission(new_id)
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
enum IncrementalLightChannel { Sky, Block }

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
struct WorldLightPos { x: i64, y: i32, z: i64 }

impl WorldLightPos {
    fn offset(self, dx: i64, dy: i32, dz: i64) -> Self {
        Self { x: self.x + dx, y: self.y + dy, z: self.z + dz }
    }
}

const LIGHT_NEIGHBORS: [(i64, i32, i64); 6] = [
    (1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1),
];

#[inline]
fn world_height_at(chunks: &HashMap<(i32, i32), ChunkData>, x: i64, z: i64) -> Option<i32> {
    let cx = i32::try_from(x.div_euclid(16)).ok()?;
    let cz = i32::try_from(z.div_euclid(16)).ok()?;
    let chunk = chunks.get(&(cx, cz))?;
    let lx = x.rem_euclid(16) as usize;
    let lz = z.rem_euclid(16) as usize;
    Some(chunk.height_map.as_ref()
        .and_then(|height| height.get(lz * 16 + lx)).copied()
        .unwrap_or_else(|| derived_first_air(chunk, lx, lz)))
}

#[inline]
fn world_stored_light(
    chunks: &HashMap<(i32, i32), ChunkData>,
    pos: WorldLightPos,
    channel: IncrementalLightChannel,
) -> u8 {
    // World.getLightFor clamps negative Y to the bottom layer and returns the
    // channel's default value outside the build height (SKY=15, BLOCK=0).
    let y = if pos.y < 0 { 0 } else if pos.y > 255 {
        return if channel == IncrementalLightChannel::Sky { 15 } else { 0 };
    } else { pos.y };
    let (Ok(cx), Ok(cz)) = (i32::try_from(pos.x.div_euclid(16)), i32::try_from(pos.z.div_euclid(16))) else { return 0; };
    let Some(chunk) = chunks.get(&(cx, cz)) else { return if channel == IncrementalLightChannel::Sky { 15 } else { 0 }; };
    let lx = pos.x.rem_euclid(16) as usize;
    let lz = pos.z.rem_euclid(16) as usize;
    let sy = (y / 16) as u8;
    let ly = (y % 16) as usize;
    let index = (ly << 8) | (lz << 4) | lx;
    let section = chunk.sections.iter().find(|section| section.y == sy);
    match channel {
        IncrementalLightChannel::Block => section.and_then(|section| section.block_light.as_ref())
            .and_then(|values| values.get(index)).copied().unwrap_or(0).min(15),
        IncrementalLightChannel::Sky => section.and_then(|section| section.sky_light.as_ref())
            .and_then(|values| values.get(index)).copied().unwrap_or_else(|| {
                if world_height_at(chunks, pos.x, pos.z).is_some_and(|height| y >= height) { 15 } else { 0 }
            }).min(15),
    }
}

fn set_world_stored_light(
    chunks: &mut HashMap<(i32, i32), ChunkData>,
    pos: WorldLightPos,
    channel: IncrementalLightChannel,
    value: u8,
) -> bool {
    if !(0..=255).contains(&pos.y) { return false; }
    let (Ok(cx), Ok(cz)) = (i32::try_from(pos.x.div_euclid(16)), i32::try_from(pos.z.div_euclid(16))) else { return false; };
    let Some(chunk) = chunks.get_mut(&(cx, cz)) else { return false; };
    let lx = pos.x.rem_euclid(16) as usize;
    let lz = pos.z.rem_euclid(16) as usize;
    let sy = (pos.y / 16) as u8;
    let ly = (pos.y % 16) as usize;
    let index = (ly << 8) | (lz << 4) | lx;
    if !chunk.sections.iter().any(|section| section.y == sy) {
        // An absent Anvil section is all air. Materialize its direct-sky baseline
        // when the first incremental light write reaches it; other sections stay
        // sparse and are not forced into 16 full arrays.
        let mut sky = vec![0_u8; 4096];
        for local_y in 0..16_i32 {
            let world_y = i32::from(sy) * 16 + local_y;
            for local_z in 0..16_usize {
                for local_x in 0..16_usize {
                    let first_air = chunk.height_map.as_ref()
                        .and_then(|height| height.get(local_z * 16 + local_x)).copied()
                        .unwrap_or_else(|| derived_first_air(chunk, local_x, local_z));
                    if world_y >= first_air {
                        sky[((local_y as usize) << 8) | (local_z << 4) | local_x] = 15;
                    }
                }
            }
        }
        chunk.sections.push(mc189_storage::ChunkSection {
            y: sy,
            block_ids: vec![0; 4096],
            metadata: vec![0; 4096],
            block_light: Some(vec![0; 4096]),
            sky_light: Some(sky),
        });
        chunk.sections.sort_by_key(|section| section.y);
    }
    let Some(section) = chunk.sections.iter_mut().find(|section| section.y == sy) else { return false; };
    let target = match channel {
        IncrementalLightChannel::Block => section.block_light.get_or_insert_with(|| vec![0; 4096]),
        IncrementalLightChannel::Sky => section.sky_light.get_or_insert_with(|| vec![0; 4096]),
    };
    if target.len() != 4096 { return false; }
    let value = value.min(15);
    let changed = target[index] != value;
    target[index] = value;
    changed
}

fn raw_world_light(
    chunks: &HashMap<(i32, i32), ChunkData>,
    pos: WorldLightPos,
    channel: IncrementalLightChannel,
) -> u8 {
    if pos.y < 0 { return 0; }
    if pos.y > 255 { return if channel == IncrementalLightChannel::Sky { 15 } else { 0 }; }
    let id = block_at(chunks, pos.x, pos.y, pos.z);
    if channel == IncrementalLightChannel::Sky
        && world_height_at(chunks, pos.x, pos.z).is_some_and(|height| pos.y >= height)
    {
        return 15;
    }
    let block_emission = vanilla_light_emission(id);
    // World.getRawLight uses Block.getLightValue() for the opacity exception
    // in BOTH channels. An opaque light emitter therefore attenuates skylight
    // by one rather than sealing it completely.
    let mut opacity = vanilla_light_opacity(id);
    if opacity >= 15 && block_emission > 0 { opacity = 1; }
    opacity = opacity.max(1);
    if opacity >= 15 { return 0; }
    let channel_emission = if channel == IncrementalLightChannel::Block { block_emission } else { 0 };
    if channel_emission >= 14 { return channel_emission; }
    let mut result = channel_emission;
    for (dx, dy, dz) in LIGHT_NEIGHBORS {
        let neighbor = pos.offset(dx, dy, dz);
        let neighbor_level = world_stored_light(chunks, neighbor, channel);
        let candidate = neighbor_level.saturating_sub(opacity);
        result = result.max(candidate);
        if result >= 14 { return result; }
    }
    result
}

fn light_position_in_update_area(
    pos: WorldLightPos,
    center: WorldLightPos,
    vertical_seed_range: Option<(i32, i32)>,
) -> bool {
    let horizontal = (pos.x - center.x).abs() + (pos.z - center.z).abs();
    let vertical_distance = match vertical_seed_range {
        Some((min_y, _)) if pos.y < min_y => min_y - pos.y,
        Some((_, max_y_exclusive)) if pos.y >= max_y_exclusive => pos.y - (max_y_exclusive - 1),
        Some(_) => 0,
        None => (pos.y - center.y).abs(),
    };
    // The union of radius-17 Manhattan volumes around the seeded positions is
    // the same bounded region used by World.checkLightFor. For a HeightMap edit
    // the seeds form one contiguous vertical interval in a single column.
    horizontal + i64::from(vertical_distance) < 17
}

/// Port of World.checkLightFor's two-phase decrease/reseed operation. The first
/// phase removes only values whose exact predecessor contribution disappeared;
/// the second recomputes raw light and propagates surviving sources. For skylight
/// height changes, all cells whose direct-sky state changed are seeded together,
/// mirroring Chunk.relightBlock's vertical-column update without scanning chunks.
fn incremental_relight_channel(
    chunks: &mut HashMap<(i32, i32), ChunkData>,
    center: WorldLightPos,
    seeds: &[WorldLightPos],
    channel: IncrementalLightChannel,
    full_vertical_column: bool,
) -> HashSet<WorldLightPos> {
    let vertical_seed_range = if full_vertical_column {
        let min_y = seeds.iter().filter(|seed| seed.x == center.x && seed.z == center.z)
            .map(|seed| seed.y).min().unwrap_or(center.y);
        let max_y = seeds.iter().filter(|seed| seed.x == center.x && seed.z == center.z)
            .map(|seed| seed.y).max().unwrap_or(center.y);
        Some((min_y, max_y.saturating_add(1)))
    } else { None };
    let mut unique_seeds = HashSet::new();
    let mut remove_queue = VecDeque::<(WorldLightPos, u8)>::new();
    let mut remove_seen = HashSet::<(WorldLightPos, u8)>::new();
    let mut check_queue = VecDeque::<WorldLightPos>::new();
    let mut check_queued = HashSet::<WorldLightPos>::new();
    let mut changed = HashSet::<WorldLightPos>::new();

    for &seed in seeds {
        if !(0..=255).contains(&seed.y) || !light_position_in_update_area(seed, center, vertical_seed_range)
            || !unique_seeds.insert(seed)
        { continue; }
        let old = world_stored_light(chunks, seed, channel);
        let raw = raw_world_light(chunks, seed, channel);
        if raw > old {
            if check_queued.insert(seed) { check_queue.push_back(seed); }
        } else if raw < old && remove_seen.insert((seed, old)) {
            remove_queue.push_back((seed, old));
        }
    }

    while let Some((pos, expected)) = remove_queue.pop_front() {
        if world_stored_light(chunks, pos, channel) != expected { continue; }
        if set_world_stored_light(chunks, pos, channel, 0) {
            changed.insert(pos);
        }
        if expected > 0 {
            for (dx, dy, dz) in LIGHT_NEIGHBORS {
                let neighbor = pos.offset(dx, dy, dz);
                if !(0..=255).contains(&neighbor.y)
                    || !light_position_in_update_area(neighbor, center, vertical_seed_range)
                { continue; }
                let neighbor_opacity = vanilla_light_opacity(block_at(chunks, neighbor.x, neighbor.y, neighbor.z)).max(1);
                // MCP also queues a zero-valued dependent when opacity exactly
                // consumes the predecessor's level. The second pass must inspect
                // that cell because another surviving source may now reach it.
                if neighbor_opacity > expected { continue; }
                let dependent_level = expected - neighbor_opacity;
                if world_stored_light(chunks, neighbor, channel) == dependent_level
                    && remove_seen.insert((neighbor, dependent_level))
                {
                    remove_queue.push_back((neighbor, dependent_level));
                }
            }
        }
        // World.checkLightFor's second pass revisits every entry from the first
        // pass, including dependent entries whose expected light was zero.
        if check_queued.insert(pos) { check_queue.push_back(pos); }
    }

    // Minecraft's second pass recomputes each cleared/under-lit node and fans
    // out only when its value rises. The dedup set is removed on pop so a node
    // can be revisited after another neighbor changes it later in this pass.
    while let Some(pos) = check_queue.pop_front() {
        check_queued.remove(&pos);
        let old = world_stored_light(chunks, pos, channel);
        let raw = raw_world_light(chunks, pos, channel);
        if raw != old {
            if set_world_stored_light(chunks, pos, channel, raw) { changed.insert(pos); }
            if raw > old {
                for (dx, dy, dz) in LIGHT_NEIGHBORS {
                    let neighbor = pos.offset(dx, dy, dz);
                    if !(0..=255).contains(&neighbor.y)
                        || !light_position_in_update_area(neighbor, center, vertical_seed_range)
                    { continue; }
                    if world_stored_light(chunks, neighbor, channel) < raw
                        && check_queued.insert(neighbor)
                    {
                        check_queue.push_back(neighbor);
                    }
                }
            }
        }
    }
    changed
}

fn update_heightmap_column(chunk: &mut ChunkData, x: u8, z: u8) -> i32 {
    let index = usize::from(z) * 16 + usize::from(x);
    if chunk.height_map.as_ref().map_or(true, |height| height.len() != 256) {
        // A missing/corrupt HeightMap must be reconstructed for every column.
        // Initializing the other 255 entries to zero would falsely expose direct
        // skylight through terrain and darken/brighten unrelated parts of the chunk.
        let mut heights = vec![0_i32; 256];
        for column_z in 0_u8..16 {
            for column_x in 0_u8..16 {
                heights[usize::from(column_z) * 16 + usize::from(column_x)] =
                    derived_first_air(chunk, usize::from(column_x), usize::from(column_z));
            }
        }
        chunk.height_map = Some(heights);
    }
    let new = (0_u16..=255).rev().find(|&y| {
        vanilla_light_opacity(chunk.block_id_at(x, y as u8, z).unwrap_or(0)) > 0
    }).map_or(0, |y| i32::from(y) + 1);
    if let Some(height) = chunk.height_map.as_mut() { height[index] = new; }
    new
}

fn loaded_light_area_covers_edit(
    chunks: &HashMap<(i32, i32), ChunkData>,
    center: WorldLightPos,
) -> bool {
    let min_x = (center.x - 17).div_euclid(16);
    let max_x = (center.x + 17).div_euclid(16);
    let min_z = (center.z - 17).div_euclid(16);
    let max_z = (center.z + 17).div_euclid(16);
    (min_x..=max_x).all(|cx| (min_z..=max_z).all(|cz| {
        i32::try_from(cx).ok().zip(i32::try_from(cz).ok()).is_some_and(|key| chunks.contains_key(&key))
    }))
}

fn incremental_light_after_block_edit(
    chunks: &mut HashMap<(i32, i32), ChunkData>,
    chunk_x: i32,
    chunk_z: i32,
    local_x: u8,
    y: u8,
    local_z: u8,
    old_id: u16,
    old_first_air: i32,
) -> Option<HashSet<WorldLightPos>> {
    let center = WorldLightPos {
        x: i64::from(chunk_x) * 16 + i64::from(local_x),
        y: i32::from(y),
        z: i64::from(chunk_z) * 16 + i64::from(local_z),
    };
    if !loaded_light_area_covers_edit(chunks, center) { return None; }

    let edited = (chunk_x, chunk_z);
    let new_id = block_at(chunks, center.x, center.y, center.z);
    let opacity_changed = vanilla_light_opacity(old_id) != vanilla_light_opacity(new_id);
    let new_first_air = {
        let chunk = chunks.get_mut(&edited)?;
        if opacity_changed {
            update_heightmap_column(chunk, local_x, local_z)
        } else {
            chunk.height_map.as_ref().and_then(|height| height.get(usize::from(local_z) * 16 + usize::from(local_x))).copied()
                .unwrap_or(old_first_air)
        }
    };
    let emission_changed = vanilla_light_emission(old_id) != vanilla_light_emission(new_id);
    if !opacity_changed && !emission_changed { return Some(HashSet::new()); }

    // Most worlds already contain saved nibble arrays. If an older or sparse
    // chunk omits them, reconstruct that missing baseline once before applying
    // the local delta; subsequent edits stay on the incremental path.
    if chunks.values().any(|chunk| chunk.sections.iter().any(|section| {
        section.block_light.is_none() || section.sky_light.is_none()
    })) {
        rebuild_missing_block_light(chunks);
    }

    let mut changed = HashSet::new();
    if emission_changed || opacity_changed {
        let block_changes = incremental_relight_channel(
            chunks, center, &[center], IncrementalLightChannel::Block, false,
        );
        changed.extend(block_changes);
    }
    if opacity_changed {
        let mut sky_seeds = vec![center];
        let full_column = old_first_air != new_first_air;
        if full_column {
            let start = old_first_air.min(new_first_air).clamp(0, 256);
            let end = old_first_air.max(new_first_air).clamp(0, 256);
            for seed_y in start..end {
                let seed = WorldLightPos { y: seed_y, ..center };
                sky_seeds.push(seed);
            }
        }
        let sky_changes = incremental_relight_channel(
            chunks, center, &sky_seeds, IncrementalLightChannel::Sky, full_column,
        );
        changed.extend(sky_changes);
    }
    Some(changed)
}

/// Rebuilds missing block- and sky-light nibble arrays in memory. Saved arrays
/// are copied as propagation seeds and are never rewritten. The loaded 3x3
/// chunk halo bounds propagation naturally: light cannot leak into unloaded
/// chunks or mutate the source Anvil files.
fn rebuild_missing_block_light(chunks: &mut HashMap<(i32, i32), ChunkData>) {
    rebuild_block_light_maps(chunks, &HashSet::new());
}

/// Recalculate HeightMap and both light channels after a block mutation. The
/// forced set discards stale saved light for the edited chunk and its one-chunk
/// neighborhood, while outer loaded chunks remain boundary seeds.
pub(crate) fn rebuild_light_after_block_edit(
    chunks: &mut HashMap<(i32, i32), ChunkData>,
    forced_chunks: &HashSet<(i32, i32)>,
) {
    for key in forced_chunks {
        if let Some(chunk) = chunks.get_mut(key) {
            let mut height = vec![0_i32; 256];
            for z in 0_u8..16 {
                for x in 0_u8..16 {
                    let top = (0_u16..=255).rev().find(|&y| {
                        let id = chunk.block_id_at(x, y as u8, z).unwrap_or(0);
                        vanilla_light_opacity(id) > 0
                    });
                    height[usize::from(z) * 16 + usize::from(x)] = top.map_or(0, |y| i32::from(y) + 1);
                }
            }
            chunk.height_map = Some(height);
        }
    }
    rebuild_block_light_maps(chunks, forced_chunks);
}

fn light_source_can_expand(
    chunks: &HashMap<(i32, i32), ChunkData>,
    maps: &HashMap<(i32, i32), Vec<u8>>,
    x: i64,
    y: i32,
    z: i64,
    level: u8,
) -> bool {
    if level <= 1 { return false; }
    for (dx, dy, dz) in [(1_i64,0_i32,0_i64),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)] {
        let nx = x + dx;
        let ny = y + dy;
        let nz = z + dz;
        if !(0..=255).contains(&ny) { continue; }
        let cx = nx.div_euclid(16);
        let cz = nz.div_euclid(16);
        let (Ok(cx), Ok(cz)) = (i32::try_from(cx), i32::try_from(cz)) else { continue; };
        let Some(map) = maps.get(&(cx, cz)) else { continue; };
        let opacity = vanilla_light_opacity(block_at(chunks, nx, ny, nz));
        if opacity >= 15 { continue; }
        let attenuation = opacity.max(1);
        if level <= attenuation { continue; }
        let lx = nx.rem_euclid(16) as usize;
        let lz = nz.rem_euclid(16) as usize;
        let index = ny as usize * 256 + lz * 16 + lx;
        if level - attenuation > map[index] { return true; }
    }
    false
}

fn rebuild_block_light_maps(
    chunks: &mut HashMap<(i32, i32), ChunkData>,
    force_rebuild: &HashSet<(i32, i32)>,
) {
    // Vanilla Anvil chunks normally have stored arrays. Rebuild only if there
    // are missing arrays or if this is an explicit edit invalidation.
    if force_rebuild.is_empty() && !chunks.values().any(|chunk| chunk.sections.iter().any(|section| {
        section.block_light.is_none() || section.sky_light.is_none()
    })) {
        return;
    }
    const COLUMN: usize = 256 * 256;
    let mut light_maps: HashMap<(i32, i32), Vec<u8>> = chunks
        .keys()
        .map(|key| (*key, vec![0_u8; COLUMN]))
        .collect();
    let mut sky_maps: HashMap<(i32, i32), Vec<u8>> = chunks
        .keys()
        .map(|key| (*key, vec![0_u8; COLUMN]))
        .collect();
    let mut queue = VecDeque::new();
    let mut sky_queue = VecDeque::new();

    // Preserve saved values only outside the invalidated neighborhood. Inside
    // it, start from emissions/direct skylight so a removed occluder cannot leave
    // stale values and a removed emitter cannot leave ghost light behind.
    for (&(cx, cz), chunk) in chunks.iter() {
        let reset_saved = force_rebuild.contains(&(cx, cz));
        let map = light_maps.get_mut(&(cx, cz)).expect("light map exists for loaded chunk");
        let column_first_air: Vec<i32> = (0..256_usize).map(|i| {
            match chunk.height_map.as_ref().and_then(|h| h.get(i)).copied() {
                Some(value) => value,
                None => derived_first_air(chunk, i % 16, i / 16),
            }
        }).collect();
        for y in 0_i32..256 {
            let sy = (y / 16) as u8;
            let ly = (y % 16) as usize;
            let section = chunk.sections.iter().find(|section| section.y == sy);
            for z in 0_usize..16 {
                for x in 0_usize..16 {
                    let index = (ly << 8) | (z << 4) | x;
                    let saved = if reset_saved { 0 } else {
                        section.and_then(|section| section.block_light.as_ref())
                            .and_then(|values| values.get(index)).copied().unwrap_or(0).min(15)
                    };
                    let id = section.and_then(|section| section.block_ids.get(index)).copied().unwrap_or(0);
                    let level = saved.max(vanilla_light_emission(id));
                    let global_index = (y as usize) * 256 + z * 16 + x;
                    if level > 0 {
                        map[global_index] = level;
                    }
                    let saved_sky = if reset_saved { 0 } else {
                        section.and_then(|section| section.sky_light.as_ref())
                            .and_then(|values| values.get(index)).copied().unwrap_or(0).min(15)
                    };
                    let direct_sky = if y >= column_first_air[z * 16 + x] { 15 } else { 0 };
                    let sky_level = saved_sky.max(direct_sky);
                    if sky_level > 0 {
                        sky_maps.get_mut(&(cx, cz)).expect("sky map exists for loaded chunk")[global_index] = sky_level;
                    }
                }
            }
        }
    }

    // Seed only light cells that can actually raise at least one neighbor.
    // In particular, direct skylight sets huge open-air columns to level 15;
    // enqueueing every such cell causes hundreds of thousands of useless BFS
    // nodes per edit because all six neighboring cells are already at 15.
    // This boundary-source scan preserves paths into caves/transparent blocks
    // while skipping fully saturated open sky.
    for (&(cx, cz), chunk) in chunks.iter() {
        for y in 0_i32..256 {
            let sy = (y / 16) as u8;
            let ly = (y % 16) as usize;
            let section = chunk.sections.iter().find(|section| section.y == sy);
            for z in 0_usize..16 {
                for x in 0_usize..16 {
                    let index = (ly << 8) | (z << 4) | x;
                    let wx = i64::from(cx) * 16 + x as i64;
                    let wz = i64::from(cz) * 16 + z as i64;
                    let global_index = (y as usize) * 256 + z * 16 + x;
                    let block_level = light_maps[&(cx, cz)][global_index];
                    if block_level > 1 && light_source_can_expand(chunks, &light_maps, wx, y, wz, block_level) {
                        queue.push_back((wx, y, wz, block_level));
                    }
                    let sky_level = sky_maps[&(cx, cz)][global_index];
                    if sky_level > 1 && light_source_can_expand(chunks, &sky_maps, wx, y, wz, sky_level) {
                        sky_queue.push_back((wx, y, wz, sky_level));
                    }
                }
            }
        }
    }

    // Vanilla's light propagation loses at least one level per step. A block
    // with opacity 15 stops propagation; partial opacity (water/leaves/ice)
    // attenuates by its own opacity value.
    while let Some((x, y, z, level)) = queue.pop_front() {
        for (dx, dy, dz) in [(1_i64,0_i32,0_i64),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)] {
            let nx = x + dx;
            let ny = y + dy;
            let nz = z + dz;
            if !(0..=255).contains(&ny) { continue; }
            let cx = nx.div_euclid(16);
            let cz = nz.div_euclid(16);
            let (Ok(cx), Ok(cz)) = (i32::try_from(cx), i32::try_from(cz)) else { continue; };
            let Some(map) = light_maps.get_mut(&(cx, cz)) else { continue; };
            let id = block_at(chunks, nx, ny, nz);
            let opacity = vanilla_light_opacity(id);
            if opacity >= 15 { continue; }
            let attenuation = opacity.max(1);
            if level <= attenuation { continue; }
            let next = level - attenuation;
            let lx = nx.rem_euclid(16) as usize;
            let lz = nz.rem_euclid(16) as usize;
            let index = ny as usize * 256 + lz * 16 + lx;
            if next > map[index] {
                map[index] = next;
                if next > 1 { queue.push_back((nx, ny, nz, next)); }
            }
        }
    }

    // Reconstruct missing sky light from direct-sky heightmap columns and
    // saved SkyLight samples. Lateral propagation loses at least one level.
    while let Some((x, y, z, level)) = sky_queue.pop_front() {
        for (dx, dy, dz) in [(1_i64,0_i32,0_i64),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)] {
            let nx = x + dx;
            let ny = y + dy;
            let nz = z + dz;
            if !(0..=255).contains(&ny) { continue; }
            let cx = nx.div_euclid(16);
            let cz = nz.div_euclid(16);
            let (Ok(cx), Ok(cz)) = (i32::try_from(cx), i32::try_from(cz)) else { continue; };
            let Some(map) = sky_maps.get_mut(&(cx, cz)) else { continue; };
            let id = block_at(chunks, nx, ny, nz);
            let opacity = vanilla_light_opacity(id);
            if opacity >= 15 { continue; }
            let attenuation = opacity.max(1);
            if level <= attenuation { continue; }
            let next = level - attenuation;
            let lx = nx.rem_euclid(16) as usize;
            let lz = nz.rem_euclid(16) as usize;
            let index = ny as usize * 256 + lz * 16 + lx;
            if next > map[index] {
                map[index] = next;
                if next > 1 { sky_queue.push_back((nx, ny, nz, next)); }
            }
        }
    }

    // Materialize only missing arrays in this in-memory copy. Empty sections
    // are represented too, so light can be sampled through otherwise absent
    // air sections without modifying the source Anvil files.
    for (&(cx, cz), chunk) in chunks.iter_mut() {
        let map = &light_maps[&(cx, cz)];
        let sky_map = &sky_maps[&(cx, cz)];
        for sy in 0_u8..16 {
            let start = usize::from(sy) * 16 * 256;
            let values = map[start..start + 16 * 256].to_vec();
            let sky_values = sky_map[start..start + 16 * 256].to_vec();
            if let Some(section) = chunk.sections.iter_mut().find(|section| section.y == sy) {
                if force_rebuild.contains(&(cx, cz)) || section.block_light.is_none() { section.block_light = Some(values); }
                if force_rebuild.contains(&(cx, cz)) || section.sky_light.is_none() { section.sky_light = Some(sky_values); }
            } else {
                chunk.sections.push(mc189_storage::ChunkSection {
                    y: sy,
                    block_ids: vec![0; 4096],
                    metadata: vec![0; 4096],
                    block_light: Some(values),
                    sky_light: Some(sky_values),
                });
            }
        }
    }
}

/// Block.getLightOpacity() values reconstructed from the 1.8.9 MCP
/// registration constructors and subclass defaults. This deliberately does
/// NOT reuse the mesh face-culling list: Block.isOpaqueCube(), lightOpacity and
/// Material.isSolid() are three different vanilla properties.
fn vanilla_light_opacity(id: u16) -> u8 {
    match id {
        8 | 9 => 3,                         // Block.java: flowing/static water
        18 | 161 | 30 => 1,                 // BlockLeaves / BlockWeb constructors
        60 | 43 | 44 | 53 | 67 | 108 | 109 | 114 | 126 | 128
        | 134 | 135 | 136 | 156 | 163 | 164 | 180 | 181 | 182 => 15,
        78 | 116 | 145 | 171 => 0,          // snow layer, enchant table, anvil, carpet
        79 => 3,                            // BlockIce
        _ if vanilla_is_opaque_cube(id) => 15,
        _ => 0,
    }
}

/// Block.isOpaqueCube()/the constructor's `fullBlock` flag from MCP 1.8.9.
/// The slab IDs 43/125/181 are double slabs; their half variants are not
/// opaque cubes even though BlockSlab sets lightOpacity to 255 for both.
fn vanilla_is_opaque_cube(id: u16) -> bool {
    if matches!(id, 43 | 125 | 181) { return true; }
    if id > 197 { return false; }
    !matches!(id,
        0 | 6 | 8..=11 | 18 | 20 | 26..=34 | 36..=40 | 44
        | 50..=55 | 59 | 60 | 63..=72 | 75..=79 | 81 | 83 | 85
        | 90 | 92..=96 | 101..=102 | 104..=107 | 108..=109 | 111 | 113..=118
        | 119..=120 | 122 | 126..=128 | 130..=132 | 134..=136
        | 138..=151 | 154 | 156..=157 | 160..=161 | 163..=167
        | 171 | 175..=178 | 180 | 182..=197
    )
}

fn raw_light_channels_at_world(
    chunks: &HashMap<(i32, i32), ChunkData>, x: i64, y: i32, z: i64,
) -> VanillaLightChannels {
    if y > 255 { return VanillaLightChannels { sky: 15, block: 0 }; }
    if y < 0 { return VanillaLightChannels { sky: 0, block: 0 }; }
    let cx = x.div_euclid(16);
    let cz = z.div_euclid(16);
    // Unknown streaming neighbors are dark until their data arrives; they must
    // not be mistaken for open sky. Meshes are rebuilt after a neighbor loads.
    let (Ok(cx), Ok(cz)) = (i32::try_from(cx), i32::try_from(cz)) else {
        return VanillaLightChannels { sky: 0, block: 0 };
    };
    let Some(chunk) = chunks.get(&(cx, cz)) else {
        return VanillaLightChannels { sky: 0, block: 0 };
    };
    let lx = x.rem_euclid(16) as usize;
    let lz = z.rem_euclid(16) as usize;
    let sy = (y as usize) / 16;
    let ly = (y as usize) % 16;
    let id = block_at(chunks, x, y, z);
    let section = chunk.sections.iter().find(|section| usize::from(section.y) == sy);
    let index = (ly << 8) | (lz << 4) | lx;
    let sky = section.and_then(|s| s.sky_light.as_ref())
        .and_then(|values| values.get(index)).copied().map(|v| v.min(15))
        .unwrap_or_else(|| if section.is_none() || section.and_then(|s| s.sky_light.as_ref()).is_none() {
            if sky_light_from_heightmap(chunk, lx, y, lz) > 0.5 { 15 } else { 0 }
        } else { 0 });
    let saved_block = section.and_then(|s| s.block_light.as_ref())
        .and_then(|values| values.get(index)).copied().unwrap_or(0).min(15);
    let block = saved_block.max(vanilla_light_emission(id));
    let channels = VanillaLightChannels { sky, block };
    // Block.getMixedBrightnessForBlock special-cases liquids: when the packed
    // light at the liquid is zero it samples the block immediately below.
    if sky == 0 && block == 0 && matches!(id, 43 | 44 | 125 | 126 | 181 | 182) {
        let below = raw_light_channels_at_world_no_liquid_fallback(chunks, x, y - 1, z);
        return below;
    }
    channels
}

fn raw_light_channels_at_world_no_liquid_fallback(
    chunks: &HashMap<(i32, i32), ChunkData>, x: i64, y: i32, z: i64,
) -> VanillaLightChannels {
    if y > 255 { return VanillaLightChannels { sky: 15, block: 0 }; }
    if y < 0 { return VanillaLightChannels { sky: 0, block: 0 }; }
    let cx = x.div_euclid(16); let cz = z.div_euclid(16);
    let (Ok(cx), Ok(cz)) = (i32::try_from(cx), i32::try_from(cz)) else { return VanillaLightChannels { sky: 0, block: 0 }; };
    let Some(chunk) = chunks.get(&(cx, cz)) else { return VanillaLightChannels { sky: 0, block: 0 }; };
    let lx = x.rem_euclid(16) as usize; let lz = z.rem_euclid(16) as usize;
    let sy = (y as usize) / 16; let ly = (y as usize) % 16;
    let section = chunk.sections.iter().find(|s| usize::from(s.y) == sy);
    let index = (ly << 8) | (lz << 4) | lx;
    let sky = section.and_then(|s| s.sky_light.as_ref()).and_then(|v| v.get(index)).copied().unwrap_or_else(|| {
        if sky_light_from_heightmap(chunk, lx, y, lz) > 0.5 { 15 } else { 0 }
    }).min(15);
    let id = block_at(chunks, x, y, z);
    let block = section.and_then(|s| s.block_light.as_ref()).and_then(|v| v.get(index)).copied().unwrap_or(0)
        .max(vanilla_light_emission(id)).min(15);
    VanillaLightChannels { sky, block }
}

/// WorldProvider's 1.8.x response plus EntityRenderer's 0.96 + 0.03 lightmap floor.
/// It remains as a test/reference helper; mesh vertices now carry the two channels.
#[cfg(test)]
fn vanilla_lightmap_brightness(level: f32) -> f32 {
    let level = level.clamp(0.0, 15.0) / 15.0;
    let brightness = level / ((1.0 - level) * 3.0 + 1.0);
    (brightness * 0.96 + 0.03).clamp(0.0, 1.0)
}

/// CPU reference for EntityRenderer.updateLightmap (bfk.g) from client.jar.
/// The lightmap table follows EntityRenderer.updateLightmap (bfk.g). The final
/// flag is the vanilla lightning-flash branch, which bypasses sun attenuation.
/// World.getSunBrightness from the 1.8.9 world renderer. `day_time` is the
/// saved DayTime counter; rain and thunder are normalized strengths.
/// WorldProvider.calculateCelestialAngle from Minecraft 1.8.9, including
/// the one-third cosine easing that softens sunrise and sunset.
pub(crate) fn vanilla_celestial_angle(day_time: f64) -> f32 {
    let mut angle = (day_time.rem_euclid(24_000.0) / 24_000.0 - 0.25) as f32;
    if angle < 0.0 { angle += 1.0; }
    if angle > 1.0 { angle -= 1.0; }
    let linear = angle;
    let eased = 1.0 - ((angle * std::f32::consts::PI).cos() + 1.0) * 0.5;
    (linear + (eased - linear) / 3.0).rem_euclid(1.0)
}

/// World.getSunBrightness from Minecraft 1.8.9. Vanilla keeps a 0.2
/// minimum ambient contribution even at midnight, then attenuates for weather.
pub(crate) fn vanilla_sun_brightness(day_time: i64, rain: f32, thunder: f32) -> f32 {
    vanilla_sun_brightness_at(day_time as f64, rain, thunder)
}

pub(crate) fn vanilla_sun_brightness_at(day_time: f64, rain: f32, thunder: f32) -> f32 {
    let celestial = vanilla_celestial_angle(day_time);
    let mut brightness = 1.0 - ((celestial * std::f32::consts::TAU).cos() * 2.0 + 0.2);
    brightness = 1.0 - brightness.clamp(0.0, 1.0);
    brightness *= 1.0 - rain.clamp(0.0, 1.0) * (5.0 / 16.0);
    brightness *= 1.0 - thunder.clamp(0.0, 1.0) * (5.0 / 16.0);
    brightness * 0.8 + 0.2
}

/// World.getSunBrightness from the 1.8.9 world renderer. `day_time` is the
/// saved DayTime counter; rain and thunder are normalized strengths.
pub(crate) fn vanilla_lightmap_rgb(
    sky_level: f32,
    block_level: f32,
    sun_brightness: f32,
    torch_flicker: f32,
    lightning_flash: bool,
) -> [f32; 3] {
    let sun = sun_brightness.clamp(0.0, 1.0);
    let sky_value = sky_level.clamp(0.0, 1.0);
    let sky_table = sky_value / ((1.0 - sky_value) * 3.0 + 1.0);
    let block_value = block_level.clamp(0.0, 1.0);
    let block_table = block_value / ((1.0 - block_value) * 3.0 + 1.0);
    let sky = if lightning_flash { sky_table } else { sky_table * (sun * 0.95 + 0.05) };
    let torch = block_table * (torch_flicker * 0.1 + 1.5);
    let sky_red_green = sky * (sun * 0.65 + 0.35);
    let torch_green = torch * ((torch * 0.6 + 0.4) * 0.6 + 0.4);
    let torch_blue = torch * (torch * torch * 0.6 + 0.4);
    [
        (sky_red_green + torch) * 0.96 + 0.03,
        (sky_red_green + torch_green) * 0.96 + 0.03,
        (sky + torch_blue) * 0.96 + 0.03,
    ].map(|value| {
        // bfk.g aplica `*0.96+0.03` antes y despues del bloque de gamma (gamma=0).
        let first = value.clamp(0.0, 1.0);
        (first * 0.96 + 0.03).clamp(0.0, 1.0)
    })
}

#[cfg(test)]
fn light_at_world(chunks: &HashMap<(i32, i32), ChunkData>, x: i64, y: i32, z: i64) -> f32 {
    let channels = raw_light_channels_at_world(chunks, x, y, z);
    vanilla_lightmap_brightness(f32::from(channels.sky.max(channels.block)))
}

fn block_is_opaque_cube(id: u16) -> bool {
    // The existing verified legacy face-occlusion set represents vanilla full
    // opaque cubes; kept separate from Material translucency and isFullCube.
    occludes_model_face(id)
}

fn block_is_full_cube(id: u16) -> bool {
    // MCP Block.isFullCube() defaults to true. This override set is extracted
    // from the 1.8.9 block classes; notably BlockBreakable (glass/leaves/ice)
    // does NOT override it, while BlockGlass explicitly returns false.
    // Double slabs (43/125/181) return true; half slabs return false.
    !matches!(id,
        6 | 8..=11 | 20 | 26..=34 | 36..=40 | 44 | 50..=55 | 59..=60
        | 63..=72 | 75..=78 | 81 | 83 | 85 | 90 | 92..=96 | 101..=102
        | 104..=109 | 111 | 113..=120 | 122 | 126..=128 | 130..=132
        | 134..=136 | 138..=151 | 154 | 156..=157 | 160 | 163..=164
        | 167 | 171 | 175..=178 | 180 | 182..=197
    )
}

fn block_material_blocks_movement(id: u16) -> bool {
    // Block.isBlockNormalCube() uses Material.blocksMovement(), not
    // Material.isSolid() and not Material.blocksLight(). MaterialLogic,
    // MaterialLiquid, MaterialTransparent and the custom Material.web
    // override return false in MCP 1.8.9.
    !matches!(id,
        0 | 6 | 8..=11 | 30..=32 | 37..=40 | 50..=51 | 55 | 59
        | 65..=66 | 69 | 75..=78 | 83 | 90 | 93..=94 | 104..=106
        | 111 | 115 | 119 | 127 | 131..=132 | 140..=143 | 149..=150
        | 171 | 175
    )
}

fn block_is_ao_occluder(id: u16) -> bool {
    // Exact Block.isBlockNormalCube() predicate, which Block.getAmbientOcclusionLightValue()
    // maps to 0.2. Glass is Material.glass (blocksMovement=true) but
    // BlockGlass.isFullCube=false, so it must not create dark AO corners.
    block_material_blocks_movement(id) && block_is_full_cube(id)
}

fn block_is_translucent(id: u16) -> bool {
    // Block.translucent is initialized in the JAR as !Material.blocksLight().
    // This differs from Material.isOpaque(): glass/leaves/ice are translucent
    // for opacity/culling, but their Material.blocksLight() result is still true.
    // The IDs below use the transparent, liquid, plants, circuits, vine and
    // carpet MaterialLogic families from the 1.8.9 block registry.
    matches!(id,
        0 | 6 | 8..=11 | 27..=28 | 31..=32 | 37..=40 | 50..=51 | 55 | 59 |
        65 | 66 | 69 | 75..=78 | 83 | 90 | 93..=94 | 104..=106 | 111 | 115 | 119 | 127 | 140 |
        131..=132 | 141..=143 | 149..=150 | 171 | 175
    )
}

fn block_ao_value(id: u16) -> f32 {
    // BlockBarrier explicitly overrides getAmbientOcclusionLightValue() to 1.0
    // even though its material blocks movement and it inherits isFullCube=true.
    if id == 166 { return 1.0; }
    if block_is_ao_occluder(id) { 0.2 } else { 1.0 }
}

fn pack_vanilla_light(channels: VanillaLightChannels) -> u32 {
    // getMixedBrightnessForBlock uses sky<<20 | block<<4; after vanilla's
    // packed averaging mask (0x00FF00FF), these are the two 8-bit channels.
    (u32::from(channels.sky) << 20) | (u32::from(channels.block) << 4)
}

fn ao_sample_at(chunks: &HashMap<(i32, i32), ChunkData>, pos: [i64; 3]) -> AoSample {
    let id = block_at(chunks, pos[0], pos[1] as i32, pos[2]);
    let channels = raw_light_channels_at_world(chunks, pos[0], pos[1] as i32, pos[2]);
    AoSample { ao: block_ao_value(id), packed_light: pack_vanilla_light(channels) }
}

fn get_ao_brightness(a: u32, b: u32, c: u32, center: u32) -> u32 {
    let a = if a == 0 { center } else { a };
    let b = if b == 0 { center } else { b };
    let c = if c == 0 { center } else { c };
    (a.wrapping_add(b).wrapping_add(c).wrapping_add(center) >> 2) & 0x00ff_00ff
}

fn get_vertex_brightness(values: [u32; 4], weights: [f32; 4]) -> u32 {
    let mut sky = 0.0;
    let mut block = 0.0;
    for index in 0..4 {
        sky += ((values[index] >> 16) & 0xff) as f32 * weights[index];
        block += (values[index] & 0xff) as f32 * weights[index];
    }
    (((sky as u32) & 0xff) << 16) | ((block as u32) & 0xff)
}

fn unpack_vanilla_light(packed: u32) -> (f32, f32) {
    (f32::from(((packed >> 16) & 0xff) as u8) / 240.0,
     f32::from((packed & 0xff) as u8) / 240.0)
}

fn ao_bounds_and_flags(
    quad: &CpuMeshQuad, wx: i64, y: i32, wz: i64, chunk_origin_x: i64, chunk_origin_z: i64,
    face: crate::model_resolver::ModelFaceDirection, block_id: u16,
) -> ([f32; 12], bool, bool) {
    let mut min = [f32::INFINITY; 3];
    let mut max = [f32::NEG_INFINITY; 3];
    for point in quad.positions {
        let local = [point[0] + chunk_origin_x as f32 - wx as f32,
                     point[1] - y as f32,
                     point[2] + chunk_origin_z as f32 - wz as f32];
        for axis in 0..3 { min[axis] = min[axis].min(local[axis]); max[axis] = max[axis].max(local[axis]); }
    }
    let mut bounds = [0.0_f32; 12];
    // bgf.fillQuadBounds indexes the table by EnumFacing ordinal, not by
    // coordinate-pair order: DOWN=minY, UP=maxY, NORTH=minZ, SOUTH=maxZ,
    // WEST=minX, EAST=maxX. The six flipped entries are 1.0 - each bound.
    bounds[0] = min[1]; bounds[1] = max[1];
    bounds[2] = min[2]; bounds[3] = max[2];
    bounds[4] = min[0]; bounds[5] = max[0];
    for index in 0..6 { bounds[index + 6] = 1.0 - bounds[index]; }

    const EPS: f32 = 0.0001;
    let full_cube = block_is_full_cube(block_id);
    let (plane, boundary, side_axes) = match face {
        crate::model_resolver::ModelFaceDirection::Down => (min[1] == max[1], min[1] < EPS || full_cube, [0,2]),
        crate::model_resolver::ModelFaceDirection::Up => (min[1] == max[1], max[1] > 1.0-EPS || full_cube, [0,2]),
        crate::model_resolver::ModelFaceDirection::North => (min[2] == max[2], min[2] < EPS || full_cube, [0,1]),
        crate::model_resolver::ModelFaceDirection::South => (min[2] == max[2], max[2] > 1.0-EPS || full_cube, [0,1]),
        crate::model_resolver::ModelFaceDirection::West => (min[0] == max[0], min[0] < EPS || full_cube, [2,1]),
        crate::model_resolver::ModelFaceDirection::East => (min[0] == max[0], max[0] > 1.0-EPS || full_cube, [2,1]),
    };
    let flag0 = plane && boundary;
    let a = side_axes[0]; let b = side_axes[1];
    let flag1 = min[a] >= EPS || min[b] >= EPS || max[a] <= 1.0-EPS || max[b] <= 1.0-EPS;
    (bounds, flag0, flag1)
}

fn face_from_normal(normal: [f32; 3]) -> crate::model_resolver::ModelFaceDirection {
    use crate::model_resolver::ModelFaceDirection as Face;
    let absolute = [normal[0].abs(), normal[1].abs(), normal[2].abs()];
    if absolute[1] >= absolute[0] && absolute[1] >= absolute[2] {
        if normal[1] >= 0.0 { Face::Up } else { Face::Down }
    } else if absolute[0] >= absolute[2] {
        if normal[0] >= 0.0 { Face::East } else { Face::West }
    } else if normal[2] >= 0.0 { Face::South } else { Face::North }
}

/// Test/reference helper for the directional face-shading factors used by
/// the 1.8.x block renderer. Production mesh generation reads the same values
/// directly from `ao_face_info`; this keeps the regression test tied to that table.
#[cfg(test)]
fn vanilla_face_shade(normal: [f32; 3]) -> f32 {
    ao_face_info(face_from_normal(normal)).shade
}

fn calculate_flat_vertex_lighting(
    quad: &CpuMeshQuad,
    wx: i64,
    y: i32,
    wz: i64,
    chunk_origin_x: i64,
    chunk_origin_z: i64,
    block_id: u16,
    chunks: &HashMap<(i32, i32), ChunkData>,
) -> VanillaVertexLighting {
    // BlockModelRenderer.renderModelFlatQuads: one packed brightness per quad. The
    // neighbour in the face direction is sampled ONLY when fillQuadBounds sets bit 0
    // (quad is a plane lying on the block boundary / full cube); otherwise the
    // block's own position is used (cross plants, torches, inset faces).
    let face = face_from_normal(quad.normal);
    let offset = face_direction_offset(face);
    let (_, flag0, _) = ao_bounds_and_flags(
        quad, wx, y, wz, chunk_origin_x, chunk_origin_z, face, block_id,
    );
    let (sx, sy, sz) = if flag0 {
        (wx + offset[0], y + offset[1] as i32, wz + offset[2])
    } else {
        (wx, y, wz)
    };
    let sample = raw_light_channels_at_world(chunks, sx, sy, sz);
    let packed = pack_vanilla_light(sample);
    let (sky, block) = unpack_vanilla_light(packed);
    // FaceBakery only bakes the directional colour when the element has shade=true.
    let shade = if quad.shade { ao_face_info(face).shade } else { 1.0 };
    VanillaVertexLighting {
        ao: [1.0; 4],
        sky: [sky; 4],
        block: [block; 4],
        face_shade: [shade; 4],
    }
}

fn calculate_quad_vertex_lighting(
    quad: &CpuMeshQuad, wx: i64, y: i32, wz: i64,
    chunk_origin_x: i64, chunk_origin_z: i64, block_id: u16,
    chunks: &HashMap<(i32, i32), ChunkData>,
) -> VanillaVertexLighting {
    // renderModel: smooth only if AO enabled, block.getLightValue()==0 and model AO.
    if !quad.ambient_occlusion || vanilla_light_emission(block_id) > 0 {
        return calculate_flat_vertex_lighting(
            quad, wx, y, wz, chunk_origin_x, chunk_origin_z, block_id, chunks,
        );
    }
    let face = face_from_normal(quad.normal);
    let info = ao_face_info(face);
    let face_offset = face_direction_offset(face);
    let world_pos = [wx, i64::from(y), wz];
    let (_, face_flag0, face_flag1) = ao_bounds_and_flags(
        quad, wx, y, wz, chunk_origin_x, chunk_origin_z, face, block_id,
    );
    let base_pos = if face_flag0 {
        [world_pos[0] + face_offset[0], world_pos[1] + face_offset[1], world_pos[2] + face_offset[2]]
    } else { world_pos };
    let side_pos: [[i64; 3]; 4] = std::array::from_fn(|index| [
        base_pos[0] + info.side_offsets[index][0],
        base_pos[1] + info.side_offsets[index][1],
        base_pos[2] + info.side_offsets[index][2],
    ]);
    let side_samples = side_pos.map(|position| ao_sample_at(chunks, position));
    // The original tests translucency one block beyond each side sample,
    // in the face-normal direction, not the side sample itself.
    let side_translucent: [bool; 4] = std::array::from_fn(|index| {
        let p = side_pos[index];
        block_is_translucent(block_at(chunks,
            p[0] + face_offset[0], (p[1] + face_offset[1]) as i32, p[2] + face_offset[2]))
    });
    let diagonal_pairs = [(0_usize,2_usize), (0,3), (1,2), (1,3)];
    let diagonal_samples: [AoSample; 4] = std::array::from_fn(|index| {
        let (side, other) = diagonal_pairs[index];
        if side_translucent[side] || side_translucent[other] {
            let p = side_pos[side];
            let d = info.side_offsets[other];
            ao_sample_at(chunks, [p[0]+d[0], p[1]+d[1], p[2]+d[2]])
        } else {
            side_samples[side]
        }
    });

    let center_id = block_at(chunks, base_pos[0], base_pos[1] as i32, base_pos[2]);
    let center_ao = block_ao_value(center_id);
    let mut center_light = pack_vanilla_light(raw_light_channels_at_world(chunks, wx, y, wz));
    let face_neighbor_pos = [wx + face_offset[0], i64::from(y) + face_offset[1], wz + face_offset[2]];
    let face_neighbor_id = block_at(chunks, face_neighbor_pos[0], face_neighbor_pos[1] as i32, face_neighbor_pos[2]);
    if face_flag0 || !block_is_opaque_cube(face_neighbor_id) {
        center_light = pack_vanilla_light(raw_light_channels_at_world(
            chunks, face_neighbor_pos[0], face_neighbor_pos[1] as i32, face_neighbor_pos[2],
        ));
    }

    let side_ao = side_samples.map(|sample| sample.ao);
    let diag_ao = diagonal_samples.map(|sample| sample.ao);
    let corner_ao = [
        (side_ao[3] + side_ao[0] + diag_ao[1] + center_ao) * 0.25,
        (side_ao[2] + side_ao[0] + diag_ao[0] + center_ao) * 0.25,
        (side_ao[2] + side_ao[1] + diag_ao[2] + center_ao) * 0.25,
        (side_ao[3] + side_ao[1] + diag_ao[3] + center_ao) * 0.25,
    ];

    let side_light = side_samples.map(|sample| sample.packed_light);
    let diag_light = diagonal_samples.map(|sample| sample.packed_light);
    let corner_brightness = [
        get_ao_brightness(side_light[3], side_light[0], diag_light[1], center_light),
        get_ao_brightness(side_light[2], side_light[0], diag_light[0], center_light),
        get_ao_brightness(side_light[2], side_light[1], diag_light[2], center_light),
        get_ao_brightness(side_light[3], side_light[1], diag_light[3], center_light),
    ];

    let (bounds, _, _) = ao_bounds_and_flags(quad, wx, y, wz, chunk_origin_x, chunk_origin_z, face, block_id);
    let mut corner_ao_output = corner_ao;
    let mut corner_brightness_output = corner_brightness;
    for corner in 0..4 {
        if face_flag1 && info.non_cubic_weight {
            let orientation = info.orientation_bounds[corner];
            let weights: [f32; 4] = std::array::from_fn(|pair| {
                let a = usize::from(orientation[pair * 2]);
                let b = usize::from(orientation[pair * 2 + 1]);
                bounds[a] * bounds[b]
            });
            // The original renderer applies these four orientation-dependent
            // weights to the four *geometric* corners, then maps them to the
            // baked quad's vertex order with VertexTranslations.
            corner_ao_output[corner] = corner_ao.iter().zip(weights)
                .map(|(value, weight)| *value * weight).sum();
            corner_brightness_output[corner] = get_vertex_brightness(corner_brightness, weights);
        }
    }
    let mut result = VanillaVertexLighting {
        ao: [1.0; 4], sky: [1.0; 4], block: [1.0; 4],
        face_shade: [if quad.shade { info.shade } else { 1.0 }; 4],
    };
    let locals: [[f32; 3]; 4] = quad.positions.map(|point| [
        point[0] + chunk_origin_x as f32 - wx as f32,
        point[1] - y as f32,
        point[2] + chunk_origin_z as f32 - wz as f32,
    ]);
    let mut mid = [0.0_f32; 3];
    for axis in 0..3 {
        let lo = locals.iter().map(|p| p[axis]).fold(f32::INFINITY, f32::min);
        let hi = locals.iter().map(|p| p[axis]).fold(f32::NEG_INFINITY, f32::max);
        mid[axis] = (lo + hi) * 0.5;
    }
    // Corner c lies between the sides listed here (same pairs used for its AO samples).
    const CORNER_SIDES: [(usize, usize); 4] = [(3, 0), (2, 0), (2, 1), (3, 1)];
    for vertex in 0..4_usize {
        let matched = (0..4_usize).find(|&corner| {
            let (a, b) = CORNER_SIDES[corner];
            (0..3_usize).all(|axis| {
                let want = info.side_offsets[a][axis] + info.side_offsets[b][axis];
                if want == 0 { return true; }
                let have = locals[vertex][axis] - mid[axis];
                have.abs() > 1.0e-4 && (have > 0.0) == (want > 0)
            })
        });
        let corner = matched.unwrap_or_else(|| {
            (0..4_usize).find(|&c| info.vertex_translation[c] == vertex).unwrap_or(vertex)
        });
        let (sky, block) = unpack_vanilla_light(corner_brightness_output[corner]);
        result.ao[vertex] = corner_ao_output[corner].clamp(0.0, 1.0);
        result.sky[vertex] = sky.clamp(0.0, 1.0);
        result.block[vertex] = block.clamp(0.0, 1.0);
    }
    result
}

fn block_state_at(chunks: &HashMap<(i32, i32), ChunkData>, x: i64, y: i32, z: i64) -> (u16, u8) {
    if !(0..=255).contains(&y) { return (0, 0); }
    let cx = x.div_euclid(16);
    let cz = z.div_euclid(16);
    let (Ok(cx), Ok(cz)) = (i32::try_from(cx), i32::try_from(cz)) else { return (0, 0); };
    let Some(chunk) = chunks.get(&(cx, cz)) else { return (0, 0); };
    let lx = x.rem_euclid(16) as u8;
    let lz = z.rem_euclid(16) as u8;
    (chunk.block_id_at(lx, y as u8, lz).unwrap_or(0), chunk.block_metadata_at(lx, y as u8, lz).unwrap_or(0))
}

fn fluid_family(id: u16) -> Option<u16> {
    match id { 8 | 9 => Some(8), 10 | 11 => Some(10), _ => None }
}

/// BlockLiquid.getLiquidHeightPercent from vanilla 1.8.9. Falling metadata (8..15)
/// uses level zero for rendering; the renderer separately checks for liquid above.
fn fluid_height_percent(metadata: u8) -> f32 {
    let level = if metadata >= 8 { 0 } else { metadata };
    (f32::from(level) + 1.0) / 9.0
}

fn fluid_height(metadata: u8) -> f32 {
    1.0 - fluid_height_percent(metadata)
}

fn fluid_material_is_solid(id: u16) -> bool {
    // BlockLiquid's corner-height weighting asks Material.isSolid(), not
    // isOpaqueCube()/isFullBlock(). Include transparent-but-solid MCP materials
    // (glass, leaves, cloth, iron, wood, ice, slime, barrier, containers, etc.)
    // and exclude MaterialLogic/MaterialLiquid/MaterialTransparent plant circuits.
    occludes_model_face(id) || matches!(id,
        18 | 20 | 26 | 29 | 33 | 34 | 36 | 43 | 44 | 52 | 54 | 60 | 63 | 68
        | 70..=72 | 79 | 81 | 85 | 92 | 95 | 96 | 101 | 102 | 107..=109
        | 113..=114 | 116..=118 | 120 | 122 | 126 | 128 | 130 | 134..=136
        | 138..=139 | 145..=148 | 151 | 154 | 155..=156 | 160..=161
        | 163..=167 | 176..=178 | 183..=197
    )
}

fn fluid_is_block_solid(id: u16) -> bool {
    // BlockLiquid.isBlockSolid delegates to Block.isBlockSolid except for ice
    // and the same liquid material.
    fluid_family(id).is_none() && id != 79 && fluid_material_is_solid(id)
}

fn fluid_is_full_block(id: u16) -> bool {
    // Block.isFullBlock is initialized from isOpaqueCube in Block's constructor.
    // It is not equivalent to Material.isSolid or to a visually full model.
    vanilla_is_opaque_cube(id)
}

fn fluid_corner_height(
    corner_x: i64,
    y: i32,
    corner_z: i64,
    family: u16,
    chunks: &HashMap<(i32, i32), ChunkData>,
) -> f32 {
    // Exact BlockFluidRenderer.getFluidHeight weighting from MCP 1.8.9.
    let mut count = 0.0_f32;
    let mut total = 0.0_f32;
    for index in 0..4_i64 {
        let x = corner_x - (index & 1);
        let z = corner_z - ((index >> 1) & 1);
        let (above_id, _) = block_state_at(chunks, x, y + 1, z);
        if fluid_family(above_id) == Some(family) {
            return 1.0;
        }
        let (id, metadata) = block_state_at(chunks, x, y, z);
        if fluid_family(id) == Some(family) {
            let percent = 1.0 - fluid_height(metadata);
            if metadata >= 8 || metadata == 0 {
                total += percent * 10.0;
                count += 10.0;
            }
            total += percent;
            count += 1.0;
        } else if !fluid_material_is_solid(id) {
            total += 1.0;
            count += 1.0;
        }
    }
    if count == 0.0 { 0.0 } else { 1.0 - total / count }
}

fn fluid_effective_decay(
    chunks: &HashMap<(i32, i32), ChunkData>, x: i64, y: i32, z: i64, family: u16,
) -> i32 {
    let (id, metadata) = block_state_at(chunks, x, y, z);
    if fluid_family(id) != Some(family) { -1 }
    else if metadata >= 8 { 0 }
    else { i32::from(metadata) }
}

/// BlockLiquid.getFlowVector / getFlowDirection from vanilla 1.8.9.
fn fluid_flow_angle(
    wx: i64, y: i32, wz: i64, family: u16, metadata: u8,
    chunks: &HashMap<(i32, i32), ChunkData>,
) -> f32 {
    let current_decay = if metadata >= 8 { 0 } else { i32::from(metadata) };
    let mut flow_x = 0.0_f32;
    let mut flow_z = 0.0_f32;
    for (dx, dz) in [(0_i64, -1_i64), (0, 1), (-1, 0), (1, 0)] {
        let nx = wx + dx;
        let nz = wz + dz;
        let (neighbor_id, _) = block_state_at(chunks, nx, y, nz);
        let mut neighbor_decay = fluid_effective_decay(chunks, nx, y, nz, family);
        if neighbor_decay < 0 {
            if !fluid_material_is_solid(neighbor_id) {
                neighbor_decay = fluid_effective_decay(chunks, nx, y - 1, nz, family);
                if neighbor_decay >= 0 {
                    let difference = neighbor_decay - (current_decay - 8);
                    flow_x += dx as f32 * difference as f32;
                    flow_z += dz as f32 * difference as f32;
                }
            }
        } else {
            let difference = neighbor_decay - current_decay;
            flow_x += dx as f32 * difference as f32;
            flow_z += dz as f32 * difference as f32;
        }
    }
    if metadata >= 8 {
        for (dx, dz) in [(0_i64, -1_i64), (0, 1), (-1, 0), (1, 0)] {
            let (side_id, _) = block_state_at(chunks, wx + dx, y, wz + dz);
            let (above_side_id, _) = block_state_at(chunks, wx + dx, y + 1, wz + dz);
            if fluid_is_block_solid(side_id) || fluid_is_block_solid(above_side_id) {
                let length = (flow_x * flow_x + flow_z * flow_z).sqrt();
                if length > 0.0 { flow_x /= length; flow_z /= length; }
                // Vanilla adds (0,-6,0) and normalizes; Y does not affect the texture angle.
                break;
            }
        }
    }
    if flow_x == 0.0 && flow_z == 0.0 { -1000.0 }
    else { flow_z.atan2(flow_x) - std::f32::consts::FRAC_PI_2 }
}

fn fluid_quad(
    positions: [[f32; 3]; 4],
    face: crate::model_resolver::ModelFaceDirection,
    texture: &str,
    uv_corners: Option<[[f32; 2]; 4]>,
    tint: [f32; 3],
) -> CpuMeshQuad {
    let normal = match face {
        crate::model_resolver::ModelFaceDirection::Down => [0.0, -1.0, 0.0],
        crate::model_resolver::ModelFaceDirection::Up => [0.0, 1.0, 0.0],
        crate::model_resolver::ModelFaceDirection::North => [0.0, 0.0, -1.0],
        crate::model_resolver::ModelFaceDirection::South => [0.0, 0.0, 1.0],
        crate::model_resolver::ModelFaceDirection::West => [-1.0, 0.0, 0.0],
        crate::model_resolver::ModelFaceDirection::East => [1.0, 0.0, 0.0],
    };
    CpuMeshQuad {
        source_block: None,
        positions,
        uv_rect: [0.0, 0.0, 16.0, 16.0],
        uv_rotation: 0,
        uv_corners,
        texture_path: format!("assets/minecraft/textures/blocks/{texture}_frame0.png"),
        face,
        cull_face: None,
        tint_index: -1,
        tint_color: tint,
        shade: true,
        ambient_occlusion: true,
        normal,
        vertex_ao: [1.0; 4], vertex_sky_light: [1.0; 4], vertex_block_light: [1.0; 4], vertex_face_shade: [1.0; 4],
    }
}

fn fluid_should_render_sides_above(
    wx: i64, y: i32, wz: i64, family: u16,
    chunks: &HashMap<(i32, i32), ChunkData>,
) -> bool {
    // BlockLiquid.shouldRenderSides: inspect the 3x3 area one block above.
    for dx in -1_i64..=1 {
        for dz in -1_i64..=1 {
            let (id, _) = block_state_at(chunks, wx + dx, y + 1, wz + dz);
            if fluid_family(id) != Some(family) && !fluid_is_full_block(id) {
                return true;
            }
        }
    }
    false
}

fn build_fluid_quads(
    id: u16, metadata: u8, x: u8, y: i32, z: u8,
    wx: i64, wz: i64, chunks: &HashMap<(i32, i32), ChunkData>,
) -> Vec<CpuMeshQuad> {
    let Some(family) = fluid_family(id) else { return Vec::new(); };
    let (still_texture, flow_texture) = if family == 8 { ("water_still", "water_flow") } else { ("lava_still", "lava_flow") };
    let liquid_tint = if family == 8 { water_biome_tint(chunks, wx, wz) } else { [1.0; 3] };
    let base_y = y as f32;
    let epsilon = 0.001_f32;
    // Vanilla corner order: NW, SW, SE, NE.
    let mut heights = [
        fluid_corner_height(wx, y, wz, family, chunks),
        fluid_corner_height(wx, y, wz + 1, family, chunks),
        fluid_corner_height(wx + 1, y, wz + 1, family, chunks),
        fluid_corner_height(wx + 1, y, wz, family, chunks),
    ];
    let (above_id, _) = block_state_at(chunks, wx, y + 1, wz);
    let mut quads = Vec::with_capacity(7);

    // Vanilla applies the 0.001 top inset only when the top face is emitted;
    // falling columns with same-fluid blocks above keep their exact corner height.
    if fluid_family(above_id) != Some(family) {
        for height in &mut heights { *height -= epsilon; }
        let [north_west, south_west, south_east, north_east] = heights;
        let flow_angle = fluid_flow_angle(wx, y, wz, family, metadata, chunks);
        let top_quad = if flow_angle < -999.0 {
            fluid_quad(
                [[x as f32, base_y + north_west, z as f32],
                 [x as f32, base_y + south_west, z as f32 + 1.0],
                 [x as f32 + 1.0, base_y + south_east, z as f32 + 1.0],
                 [x as f32 + 1.0, base_y + north_east, z as f32]],
                crate::model_resolver::ModelFaceDirection::Up, still_texture,
                Some([[0.0, 0.0], [0.0, 16.0], [16.0, 16.0], [16.0, 0.0]]), liquid_tint,
            )
        } else {
            let sin = flow_angle.sin() * 0.25;
            let cos = flow_angle.cos() * 0.25;
            let uv = [
                [8.0 + (-cos - sin) * 16.0, 8.0 + (-cos + sin) * 16.0],
                [8.0 + (-cos + sin) * 16.0, 8.0 + ( cos + sin) * 16.0],
                [8.0 + ( cos + sin) * 16.0, 8.0 + ( cos - sin) * 16.0],
                [8.0 + ( cos - sin) * 16.0, 8.0 + (-cos - sin) * 16.0],
            ];
            fluid_quad(
                [[x as f32, base_y + north_west, z as f32],
                 [x as f32, base_y + south_west, z as f32 + 1.0],
                 [x as f32 + 1.0, base_y + south_east, z as f32 + 1.0],
                 [x as f32 + 1.0, base_y + north_east, z as f32]],
                crate::model_resolver::ModelFaceDirection::Up, flow_texture, Some(uv), liquid_tint,
            )
        };
        quads.push(top_quad.clone());
        if fluid_should_render_sides_above(wx, y, wz, family, chunks) {
            let mut reverse_winding = top_quad;
            reverse_winding.positions = [
                reverse_winding.positions[0], reverse_winding.positions[3],
                reverse_winding.positions[2], reverse_winding.positions[1],
            ];
            if let Some(uv) = reverse_winding.uv_corners {
                reverse_winding.uv_corners = Some([uv[0], uv[3], uv[2], uv[1]]);
            }
            quads.push(reverse_winding);
        }
    }
    let [north_west, south_west, south_east, north_east] = heights;

    // Bottom face follows BlockLiquid.shouldSideBeRendered: it is hidden by
    // another same fluid block or a solid block below.
    let (below_id, _) = block_state_at(chunks, wx, y - 1, wz);
    if fluid_family(below_id) != Some(family) && !occludes_model_face(below_id) {
        quads.push(fluid_quad(
            [[x as f32, base_y, z as f32 + 1.0], [x as f32, base_y, z as f32],
             [x as f32 + 1.0, base_y, z as f32], [x as f32 + 1.0, base_y, z as f32 + 1.0]],
            crate::model_resolver::ModelFaceDirection::Down, still_texture,
            Some([[0.0, 16.0], [0.0, 0.0], [16.0, 0.0], [16.0, 16.0]]), [0.5; 3],
        ));
    }

    // Vanilla emits a side only when the neighboring material differs and the
    // neighboring block does not occlude that face. Same-fluid boundaries are
    // omitted; their corner heights meet continuously at the shared edge.
    let sides = [
        (crate::model_resolver::ModelFaceDirection::North, 0_i64, -1_i64,
         north_west, north_east,
         [[x as f32, 0.0, z as f32 + epsilon], [x as f32 + 1.0, 0.0, z as f32 + epsilon], [x as f32 + 1.0, 0.0, z as f32 + epsilon], [x as f32, 0.0, z as f32 + epsilon]],
         [0.8; 3]),
        (crate::model_resolver::ModelFaceDirection::South, 0, 1,
         south_east, south_west,
         [[x as f32 + 1.0, 0.0, z as f32 + 1.0 - epsilon], [x as f32, 0.0, z as f32 + 1.0 - epsilon], [x as f32, 0.0, z as f32 + 1.0 - epsilon], [x as f32 + 1.0, 0.0, z as f32 + 1.0 - epsilon]],
         [0.8; 3]),
        (crate::model_resolver::ModelFaceDirection::West, -1, 0,
         south_west, north_west,
         [[x as f32 + epsilon, 0.0, z as f32 + 1.0], [x as f32 + epsilon, 0.0, z as f32], [x as f32 + epsilon, 0.0, z as f32], [x as f32 + epsilon, 0.0, z as f32 + 1.0]],
         [0.6; 3]),
        (crate::model_resolver::ModelFaceDirection::East, 1, 0,
         north_east, south_east,
         [[x as f32 + 1.0 - epsilon, 0.0, z as f32], [x as f32 + 1.0 - epsilon, 0.0, z as f32 + 1.0], [x as f32 + 1.0 - epsilon, 0.0, z as f32 + 1.0], [x as f32 + 1.0 - epsilon, 0.0, z as f32]],
         [0.6; 3]),
    ];
    for (face, dx, dz, upper_a, upper_b, mut positions, shade) in sides {
        let (neighbor_id, _) = block_state_at(chunks, wx + dx, y, wz + dz);
        if fluid_family(neighbor_id) == Some(family) || occludes_model_face(neighbor_id) { continue; }
        let top_a = base_y + upper_a;
        let top_b = base_y + upper_b;
        positions[0][1] = top_a;
        positions[1][1] = top_b;
        positions[2][1] = base_y;
        positions[3][1] = base_y;
        let uv = [
            [0.0, (1.0 - upper_a) * 8.0],
            [8.0, (1.0 - upper_b) * 8.0],
            [8.0, 8.0],
            [0.0, 8.0],
        ];
        let tint = [liquid_tint[0] * shade[0], liquid_tint[1] * shade[1], liquid_tint[2] * shade[2]];
        quads.push(fluid_quad(positions, face, flow_texture, Some(uv), tint));
    }
    quads
}

fn occludes_model_face(id: u16) -> bool {
    // MCP Block.shouldSideBeRendered defaults to !isOpaqueCube() for full
    // block bounds. This also keeps liquids visible beside packed ice, slime,
    // barriers, leaves and other non-opaque blocks.
    vanilla_is_opaque_cube(id)
}

fn should_cull_model_face(current_id: u16, current_meta: u8, neighbor_id: u16, neighbor_meta: u8) -> bool {
    // Opaque full cubes hide adjoining faces. Transparent block cubes need one
    // additional rule: two touching glass blocks of the same glass variant must
    // not both submit the coincident interior faces (which caused visible z-fighting).
    occludes_model_face(neighbor_id)
        || (current_id == 20 && neighbor_id == 20)
        || (current_id == 95 && neighbor_id == 95 && (current_meta & 0x0f) == (neighbor_meta & 0x0f))
}

fn rotated_face_offset(face: crate::model_resolver::ModelFaceDirection, rx: u16, ry: u16) -> (i64, i32, i64) {
    let vector = match face {
        crate::model_resolver::ModelFaceDirection::Down => Vec3::NEG_Y,
        crate::model_resolver::ModelFaceDirection::Up => Vec3::Y,
        crate::model_resolver::ModelFaceDirection::North => Vec3::NEG_Z,
        crate::model_resolver::ModelFaceDirection::South => Vec3::Z,
        crate::model_resolver::ModelFaceDirection::West => Vec3::NEG_X,
        crate::model_resolver::ModelFaceDirection::East => Vec3::X,
    };
    let rotation = Quat::from_rotation_y(-(ry as f32).to_radians()) * Quat::from_rotation_x((rx as f32).to_radians());
    let direction = rotation * vector;
    (direction.x.round() as i64, direction.y.round() as i32, direction.z.round() as i64)
}

fn connects_fence(id: u16) -> bool {
    // Vanilla fence connection contract: full opaque blocks, fences and fence gates.
    occludes_model_face(id) || matches!(id, 85 | 107 | 113 | 183..=192)
}

fn cached_variant_model(
    jar: &Path,
    context: &mut ChunkBuildContext,
    blockstate: &str,
    selector: &str,
    seed: i64,
) -> Option<(String, u16, u16, bool)> {
    let key = (blockstate.to_owned(), selector.to_owned());
    if context.failed_variant_keys.contains(&key) { return None; }
    if !context.variant_cache.contains_key(&key) {
        match load_blockstate_variant(jar, blockstate, selector) {
            Ok((_, alternatives)) if !alternatives.is_empty() => {
                context.variant_cache.insert(key.clone(), alternatives);
            }
            Ok((_, _)) => {
                if context.failed_variant_keys.insert(key.clone()) {
                    eprintln!("[chunk mesh] blockstate has no model alternatives: {} selector {:?}; only this block state will be skipped", blockstate, selector);
                }
                return None;
            }
            Err(error) => {
                if context.failed_variant_keys.insert(key.clone()) {
                    eprintln!("[chunk mesh] cannot resolve {} selector {:?}: {}; skipping only this state, keeping the rest of the chunk", blockstate, selector, error);
                }
                return None;
            }
        }
    }
    let alternatives = context.variant_cache.get(&key)?;
    let index = match select_weighted_variant_index(alternatives, seed) {
        Ok(index) => index,
        Err(error) => {
            if context.failed_variant_keys.insert(key.clone()) {
                eprintln!("[chunk mesh] invalid variant list for {} selector {:?}: {}; skipping only this state", blockstate, selector, error);
            }
            return None;
        }
    };
    let choice = alternatives.get(index)?;
    Some((choice.model.clone(), choice.x, choice.y, choice.uvlock))
}

fn stair_state(id: u16, metadata: u8) -> Option<(&'static str, bool)> {
    if !matches!(id, 53 | 67 | 108 | 109 | 114 | 128 | 134 | 135 | 136 | 156 | 163 | 164 | 180) { return None; }
    let facing = match metadata & 0x03 { 0 => "east", 1 => "west", 2 => "south", _ => "north" };
    Some((facing, metadata & 0x04 != 0))
}

fn same_stair_at(
    chunks: &HashMap<(i32, i32), ChunkData>, x: i64, y: i32, z: i64,
    facing: &str, top: bool,
) -> bool {
    let (id, meta) = block_state_at(chunks, x, y, z);
    matches!(stair_state(id, meta), Some((other_facing, other_top)) if other_facing == facing && other_top == top)
}

fn stair_selector(chunks: &HashMap<(i32, i32), ChunkData>, wx: i64, y: i32, wz: i64) -> Option<String> {
    let (id, meta) = block_state_at(chunks, wx, y, wz);
    let (facing, top) = stair_state(id, meta)?;
    let half = if top { "top" } else { "bottom" };
    let mut shape = "straight";
    // Match BlockStairs.func_176307_f (outer corners): inspect the stair directly
    // in the current facing direction and suppress a corner when the parallel stair
    // occupies the same side. Different stair materials still connect, as in vanilla.
    let front = match facing { "east" => (wx + 1, y, wz), "west" => (wx - 1, y, wz), "south" => (wx, y, wz + 1), _ => (wx, y, wz - 1) };
    let (fid, fm) = block_state_at(chunks, front.0, front.1, front.2);
    if let Some((ff, ftop)) = stair_state(fid, fm) {
        if ftop == top {
            let candidate = match (facing, ff) {
                ("east", "north") => Some((if top { "outer_right" } else { "outer_left" }, wz + 1)),
                ("east", "south") => Some((if top { "outer_left" } else { "outer_right" }, wz - 1)),
                ("west", "north") => Some((if top { "outer_left" } else { "outer_right" }, wz + 1)),
                ("west", "south") => Some((if top { "outer_right" } else { "outer_left" }, wz - 1)),
                ("south", "west") => Some((if top { "outer_left" } else { "outer_right" }, wx + 1)),
                ("south", "east") => Some((if top { "outer_right" } else { "outer_left" }, wx - 1)),
                ("north", "west") => Some((if top { "outer_right" } else { "outer_left" }, wx + 1)),
                ("north", "east") => Some((if top { "outer_left" } else { "outer_right" }, wx - 1)),
                _ => None,
            };
            if let Some((candidate_shape, side_coord)) = candidate {
                let blocked = match facing {
                    "east" | "west" => same_stair_at(chunks, wx, y, side_coord, facing, top),
                    "south" | "north" => same_stair_at(chunks, side_coord, y, wz, facing, top),
                    _ => false,
                };
                if !blocked { shape = candidate_shape; }
            }
        }
    }
    // Match BlockStairs.func_176305_g (inner corners) when no outer corner won.
    if shape == "straight" {
        let back = match facing { "east" => (wx - 1, y, wz), "west" => (wx + 1, y, wz), "south" => (wx, y, wz - 1), _ => (wx, y, wz + 1) };
        let (bid, bm) = block_state_at(chunks, back.0, back.1, back.2);
        if let Some((bf, btop)) = stair_state(bid, bm) {
            if btop == top {
                let candidate = match (facing, bf) {
                    ("east", "north") => Some((if top { "inner_right" } else { "inner_left" }, wz - 1)),
                    ("east", "south") => Some((if top { "inner_left" } else { "inner_right" }, wz + 1)),
                    ("west", "north") => Some((if top { "inner_left" } else { "inner_right" }, wz - 1)),
                    ("west", "south") => Some((if top { "inner_right" } else { "inner_left" }, wz + 1)),
                    ("south", "west") => Some((if top { "inner_left" } else { "inner_right" }, wx - 1)),
                    ("south", "east") => Some((if top { "inner_right" } else { "inner_left" }, wx + 1)),
                    ("north", "west") => Some((if top { "inner_right" } else { "inner_left" }, wx - 1)),
                    ("north", "east") => Some((if top { "inner_left" } else { "inner_right" }, wx + 1)),
                    _ => None,
                };
                if let Some((candidate_shape, side_coord)) = candidate {
                    let blocked = match facing {
                        "east" | "west" => same_stair_at(chunks, wx, y, side_coord, facing, top),
                        "south" | "north" => same_stair_at(chunks, side_coord, y, wz, facing, top),
                        _ => false,
                    };
                    if !blocked { shape = candidate_shape; }
                }
            }
        }
    }
    Some(format!("facing={facing},half={half},shape={shape}"))
}

fn door_selector(blockstate: &str, chunks: &HashMap<(i32, i32), ChunkData>, wx: i64, y: i32, wz: i64) -> Option<String> {
    let expected_id = match blockstate {
        "wooden_door" => 64, "iron_door" => 71, "spruce_door" => 193,
        "birch_door" => 194, "jungle_door" => 195, "acacia_door" => 196,
        "dark_oak_door" => 197, _ => return None,
    };
    let (id, metadata) = block_state_at(chunks, wx, y, wz);
    if id != expected_id { return None; }
    let upper = metadata & 0x08 != 0;
    let (lower_id, lower_meta) = if upper { block_state_at(chunks, wx, y - 1, wz) } else { (id, metadata) };
    let (upper_id, upper_meta) = if upper { (id, metadata) } else { block_state_at(chunks, wx, y + 1, wz) };
    let lower_meta = if lower_id == expected_id { lower_meta } else { if upper { 0 } else { metadata } };
    let upper_meta = if upper_id == expected_id { upper_meta } else { 0 };
    let facing = match lower_meta & 0x03 { 0 => "east", 1 => "south", 2 => "west", _ => "north" };
    let hinge = if upper_meta & 0x01 != 0 { "right" } else { "left" };
    let open = lower_meta & 0x04 != 0;
    Some(format!("facing={facing},half={},hinge={hinge},open={open}", if upper { "upper" } else { "lower" }))
}

fn contextual_selector(blockstate: &str, chunks: &HashMap<(i32, i32), ChunkData>, wx: i64, y: i32, wz: i64) -> Option<String> {
    if matches!(blockstate, "oak_stairs" | "stone_stairs" | "brick_stairs" | "stone_brick_stairs" | "nether_brick_stairs" | "sandstone_stairs" | "spruce_stairs" | "birch_stairs" | "jungle_stairs" | "quartz_stairs" | "acacia_stairs" | "dark_oak_stairs" | "red_sandstone_stairs") {
        return stair_selector(chunks, wx, y, wz);
    }
    if matches!(blockstate, "wooden_door" | "iron_door" | "spruce_door" | "birch_door" | "jungle_door" | "acacia_door" | "dark_oak_door") {
        return door_selector(blockstate, chunks, wx, y, wz);
    }
    match blockstate {
        "grass" | "mycelium" => {
            // In vanilla 1.8.9 both grass and mycelium expose the same contextual
            // snowy property. Snow layers (78) and ice (79) switch mycelium to
            // the snow-covered model; all other blocks retain the normal model.
            let above = block_at(chunks, wx, y + 1, wz);
            Some(format!("snowy={}", matches!(above, 78 | 79)))
        }
        "fence" => {
            let east = connects_fence(block_at(chunks, wx + 1, y, wz));
            let north = connects_fence(block_at(chunks, wx, y, wz - 1));
            let south = connects_fence(block_at(chunks, wx, y, wz + 1));
            let west = connects_fence(block_at(chunks, wx - 1, y, wz));
            Some(format!("east={east},north={north},south={south},west={west}"))
        }
        _ => None,
    }
}

fn position_seed(x: i64, y: i64, z: i64) -> i64 {
    // Stable renderer seed per world position. Java Random performs the final 48-bit
    // state transition; this hash avoids repeating one identical choice at every block.
    x.wrapping_mul(3_129_871) ^ z.wrapping_mul(116_129_781) ^ y
}

fn should_apply_grass_biome_tint(block_id: u16, quad: &CpuMeshQuad) -> bool {
    block_id == 2 && (quad.tint_index >= 0 || quad.texture_path.ends_with("/grass_side_overlay.png"))
}

fn lock_uv_to_world(quad: &mut CpuMeshQuad, block_x: f32, block_y: f32, block_z: f32) {
    // FaceBakery's uvlock keeps block textures aligned to the final world-facing
    // face after blockstate rotations. Coordinates are recalculated from the rotated
    // vertex positions in the model's local block space, then sampled across the
    // entire texture sprite (0..16 pixels), rather than dropping the whole stair.
    use crate::model_resolver::ModelFaceDirection as Face;
    let face = match quad.normal {
        [nx, ny, nz] if ny < -0.5 && ny.abs() >= nx.abs() && ny.abs() >= nz.abs() => Face::Down,
        [nx, ny, nz] if ny > 0.5 && ny.abs() >= nx.abs() && ny.abs() >= nz.abs() => Face::Up,
        [nx, _, nz] if nz < -0.5 && nz.abs() >= nx.abs() => Face::North,
        [nx, _, nz] if nz > 0.5 && nz.abs() >= nx.abs() => Face::South,
        [nx, _, _] if nx < 0.0 => Face::West,
        _ => Face::East,
    };
    let mut uvs = [[0.0_f32; 2]; 4];
    for (index, point) in quad.positions.iter().enumerate() {
        let x = (point[0] - block_x).clamp(0.0, 1.0);
        let y = (point[1] - block_y).clamp(0.0, 1.0);
        let z = (point[2] - block_z).clamp(0.0, 1.0);
        let (u, v) = match face {
            Face::Down => (x, 1.0 - z),
            Face::Up => (x, z),
            Face::North => (1.0 - x, 1.0 - y),
            Face::South => (x, 1.0 - y),
            Face::West => (z, 1.0 - y),
            Face::East => (1.0 - z, 1.0 - y),
        };
        uvs[index] = [u * 16.0, v * 16.0];
    }
    quad.uv_rect = [0.0, 0.0, 16.0, 16.0];
    quad.uv_rotation = 0;
    quad.uv_corners = Some(uvs);
}

fn transform_instance(quad: &CpuMeshQuad, x: f32, y: f32, z: f32, rx: u16, ry: u16) -> CpuMeshQuad {
    let rotation = Quat::from_rotation_y(-(ry as f32).to_radians()) * Quat::from_rotation_x((rx as f32).to_radians());
    let mut result = quad.clone();
    for point in &mut result.positions {
        let local = Vec3::from_array(*point) - Vec3::splat(0.5);
        *point = (rotation * local + Vec3::splat(0.5) + Vec3::new(x, y, z)).to_array();
    }
    result.normal = (rotation * Vec3::from_array(result.normal)).normalize_or_zero().to_array();
    result
}

fn inset_door_boundary_faces(quad: &mut CpuMeshQuad, block_x: f32, block_z: f32) {
    const EPSILON: f32 = 0.001;
    const PLANE_TOLERANCE: f32 = 1.0e-5;
    for axis in [0_usize, 2_usize] {
        let first = quad.positions[0][axis];
        if !quad.positions.iter().all(|point| (point[axis] - first).abs() <= PLANE_TOLERANCE) {
            continue;
        }
        let block_min = if axis == 0 { block_x } else { block_z };
        let block_max = block_min + 1.0;
        let offset = if (first - block_min).abs() <= PLANE_TOLERANCE {
            EPSILON
        } else if (first - block_max).abs() <= PLANE_TOLERANCE {
            -EPSILON
        } else {
            0.0
        };
        if offset != 0.0 {
            for point in &mut quad.positions { point[axis] += offset; }
        }
    }
}

pub(crate) struct ChunkBuildContext {
    grass_colormap: GrassColorMap,
    foliage_colormap: FoliageColorMap,
    model_catalog: ModelCatalog,
    variant_cache: HashMap<(String, String), Vec<VariantModel>>,
    failed_variant_keys: HashSet<(String, String)>,
}

pub(crate) const STREAM_RADIUS_CHUNKS: i32 = 5;
pub(crate) const RETAIN_RADIUS_CHUNKS: i32 = 7;

pub(crate) struct ChunkStreamResult {
    pub chunk_x: i32,
    pub chunk_z: i32,
    pub chunk: Option<ChunkData>,
    pub quads: Vec<CpuMeshQuad>,
    pub error: Option<String>,
}

pub(crate) struct ChunkStreamer {
    pub requests: Sender<(i32, i32)>,
    pub results: Receiver<ChunkStreamResult>,
}

/// Immutable snapshot for one mined-block transaction. The snapshot contains
/// the center chunk immediately before the optimistic block mutation; the worker
/// validates the old state and applies the same delta to its authoritative cache.
/// Region I/O, lighting propagation and CPU mesh generation run off the render thread.
pub(crate) struct GameplayBlockEditRequest {
    pub revision: u64,
    pub chunk_x: i32,
    pub chunk_z: i32,
    pub local_x: u8,
    pub local_y: u8,
    pub local_z: u8,
    pub expected_id: u16,
    pub expected_metadata: u8,
    pub new_id: u16,
    pub new_metadata: u8,
    /// Pre-edit center snapshot from the live in-memory world. It seeds the
    /// worker cache if this chunk has not yet been touched during this session.
    pub center_snapshot: ChunkData,
    pub origin_chunk_x: i32,
    pub origin_chunk_z: i32,
}

#[derive(Clone)]
pub(crate) struct GameplayChunkMeshUpdate {
    pub coords: (i32, i32),
    pub section_y: u8,
    pub quads: Vec<CpuMeshQuad>,
}

pub(crate) struct GameplayBlockEditResult {
    pub revision: u64,
    pub chunk_x: i32,
    pub chunk_z: i32,
    pub local_x: u8,
    pub local_y: u8,
    pub local_z: u8,
    pub expected_id: u16,
    pub expected_metadata: u8,
    /// `processed` means the edit and its in-memory lighting/mesh work completed;
    /// it does not mean the Anvil files have been written yet.
    pub processed: bool,
    pub updated_chunks: Vec<ChunkData>,
    pub meshes: Vec<GameplayChunkMeshUpdate>,
    pub error: Option<String>,
}

pub(crate) struct GameplayBlockEditWorker {
    pub requests: Sender<GameplayBlockEditRequest>,
    pub results: Receiver<GameplayBlockEditResult>,
}

/// In-memory edit worker. It owns a session cache of decoded chunks and performs
/// lighting propagation plus CPU mesh construction. It never touches Anvil files;
/// the integrated server receives immutable snapshots and owns disk persistence.
pub(crate) fn start_gameplay_block_edit_worker(jar: PathBuf, world: PathBuf, world_io_lock: Arc<Mutex<()>>) -> Result<GameplayBlockEditWorker> {
    let context = ChunkBuildContext::load(&jar)?;
    let (request_tx, request_rx) = mpsc::channel::<GameplayBlockEditRequest>();
    let (result_tx, result_rx) = mpsc::channel::<GameplayBlockEditResult>();
    thread::Builder::new().name("mc189-block-edit-worker".into()).spawn(move || {
        let mut context = context;
        let mut working_chunks: HashMap<(i32, i32), ChunkData> = HashMap::new();
        while let Ok(request) = request_rx.recv() {
            let revision = request.revision;
            let started = std::time::Instant::now();
            let result = process_gameplay_block_edit(&jar, &world, &world_io_lock, &mut context, &mut working_chunks, request);
            eprintln!(
                "[mining worker] revision {} in-memory light/mesh transaction: {:.1} ms (processed={})",
                revision, started.elapsed().as_secs_f64() * 1000.0, result.processed
            );
            if result_tx.send(result).is_err() { break; }
        }
    }).map_err(|error| Mc189Error::InvalidData(format!("cannot start block edit worker: {error}")))?;
    Ok(GameplayBlockEditWorker { requests: request_tx, results: result_rx })
}


fn chunk_light_signature(chunk: &ChunkData) -> (Option<Vec<i32>>, Vec<(u8, Option<Vec<u8>>, Option<Vec<u8>>)>) {
    (chunk.height_map.clone(), chunk.sections.iter().map(|section| {
        (section.y, section.block_light.clone(), section.sky_light.clone())
    }).collect())
}

fn process_gameplay_block_edit(
    jar: &Path,
    world: &Path,
    world_io_lock: &Mutex<()>,
    context: &mut ChunkBuildContext,
    working_chunks: &mut HashMap<(i32, i32), ChunkData>,
    request: GameplayBlockEditRequest,
) -> GameplayBlockEditResult {
    let mut result = GameplayBlockEditResult {
        revision: request.revision,
        chunk_x: request.chunk_x, chunk_z: request.chunk_z,
        local_x: request.local_x, local_y: request.local_y, local_z: request.local_z,
        expected_id: request.expected_id, expected_metadata: request.expected_metadata,
        processed: false, updated_chunks: Vec::new(), meshes: Vec::new(), error: None,
    };
    let mut updated_fallback: Vec<ChunkData> = Vec::new();
    let mut meshes_fallback: Vec<GameplayChunkMeshUpdate> = Vec::new();
    let mut mesh_error: Option<String> = None;
    let operation = (|| -> Result<(Vec<ChunkData>, Vec<GameplayChunkMeshUpdate>, Option<String>)> {
        let center_key = (request.chunk_x, request.chunk_z);
        let mut chunks = HashMap::new();
        // Reuse modified in-memory chunks first. Missing neighbors are decoded from
        // Anvil only once and cached for subsequent edits in this play session.
        for dz in -2_i32..=2 {
            for dx in -2_i32..=2 {
                let key = (request.chunk_x.saturating_add(dx), request.chunk_z.saturating_add(dz));
                if let Some(cached) = working_chunks.get(&key) {
                    chunks.insert(key, cached.clone());
                } else if key != center_key {
                    let loaded = {
                        let _io_guard = world_io_lock.lock().map_err(|_| Mc189Error::InvalidData("world I/O lock was poisoned".into()))?;
                        load_chunk(world, key.0, key.1)?
                    };
                    if let Some(loaded) = loaded {
                        working_chunks.insert(key, loaded.clone());
                        chunks.insert(key, loaded);
                    }
                }
            }
        }

        // A first edit seeds the worker from the pre-edit live snapshot, validates
        // the expected old state, then applies the block delta. A previously edited
        // chunk keeps the worker's latest derived-light state and receives only this delta.
        let target_section_y = request.local_y / 16;
        let target_section_was_missing = !chunks.get(&center_key)
            .unwrap_or(&request.center_snapshot).sections.iter()
            .any(|section| section.y == target_section_y);
        let mut old_first_air = 0_i32;
        if let Some(cached) = chunks.get_mut(&center_key) {
            old_first_air = cached.height_map.as_ref()
                .and_then(|height| height.get(usize::from(request.local_z) * 16 + usize::from(request.local_x))).copied()
                .unwrap_or_else(|| derived_first_air(cached, usize::from(request.local_x), usize::from(request.local_z)));
            let before = Some((cached.block_id_at(request.local_x, request.local_y, request.local_z).unwrap_or(0), cached.block_metadata_at(request.local_x, request.local_y, request.local_z).unwrap_or(0)));
            if before != Some((request.expected_id, request.expected_metadata)) {
                return Err(Mc189Error::InvalidData(format!(
                    "in-memory block state mismatch for edit {}: expected ({},{}), found {:?}",
                    request.revision, request.expected_id, request.expected_metadata, before
                )));
            }
            cached.set_block(request.local_x, request.local_y, request.local_z, request.new_id, request.new_metadata)?;
        } else {
            let mut seed = request.center_snapshot.clone();
            old_first_air = seed.height_map.as_ref()
                .and_then(|height| height.get(usize::from(request.local_z) * 16 + usize::from(request.local_x))).copied()
                .unwrap_or_else(|| derived_first_air(&seed, usize::from(request.local_x), usize::from(request.local_z)));
            let current = Some((seed.block_id_at(request.local_x, request.local_y, request.local_z).unwrap_or(0), seed.block_metadata_at(request.local_x, request.local_y, request.local_z).unwrap_or(0)));
            if current != Some((request.expected_id, request.expected_metadata)) {
                return Err(Mc189Error::InvalidData(format!(
                    "pre-edit snapshot state mismatch for edit {}: expected ({},{}), found {:?}",
                    request.revision, request.expected_id, request.expected_metadata, current
                )));
            }
            seed.set_block(request.local_x, request.local_y, request.local_z, request.new_id, request.new_metadata)?;
            working_chunks.insert(center_key, seed.clone());
            chunks.insert(center_key, seed);
        }

        // ChunkData::set_block creates a newly occupied section with zero-filled
        // light arrays. Those zeros are not valid skylight for an otherwise empty
        // section, whose baseline comes from the HeightMap. Mark only that newly
        // materialized section as missing so the one-time baseline reconstruction
        // can seed it correctly before the incremental decrease/reseed pass.
        if target_section_was_missing {
            if let Some(section) = chunks.get_mut(&center_key)
                .and_then(|chunk| chunk.sections.iter_mut().find(|section| section.y == target_section_y))
            {
                section.block_light = None;
                section.sky_light = None;
            }
        }
        let missing_light_baseline_needed = chunks.values().any(|chunk| chunk.sections.iter().any(|section| {
            section.block_light.is_none() || section.sky_light.is_none()
        }));

        // Apply the same local light decrease/reseed sequence as World.checkLightFor
        // instead of discarding every saved light nibble in the surrounding 3x3.
        // A full neighborhood relight is retained only when the vanilla radius-17
        // loaded-area precondition cannot be met by the chunks currently in memory.
        let needs_light_rebuild = block_edit_changes_light(request.expected_id, request.new_id);
        let mut light_changed_positions = HashSet::<WorldLightPos>::new();
        let mut updated_keys = HashSet::from([center_key]);
        if needs_light_rebuild {
            match incremental_light_after_block_edit(
                &mut chunks,
                request.chunk_x,
                request.chunk_z,
                request.local_x,
                request.local_y,
                request.local_z,
                request.expected_id,
                old_first_air,
            ) {
                Some(changed) => {
                    for pos in changed {
                        let cx = i32::try_from(pos.x.div_euclid(16)).unwrap_or(request.chunk_x);
                        let cz = i32::try_from(pos.z.div_euclid(16)).unwrap_or(request.chunk_z);
                        updated_keys.insert((cx, cz));
                        light_changed_positions.insert(pos);
                    }
                }
                None => {
                    // Vanilla checkLightFor returns false when the 17-block area
                    // is not loaded. Keep the prior conservative path in that rare
                    // case so the edge of the loaded world is never partially lit.
                    let request_chunk_x = request.chunk_x;
                    let request_chunk_z = request.chunk_z;
                    let force: HashSet<_> = (-1_i32..=1).flat_map(|dz| {
                        (-1_i32..=1).map(move |dx| (request_chunk_x.saturating_add(dx), request_chunk_z.saturating_add(dz)))
                    }).filter(|key| chunks.contains_key(key)).collect();
                    let before: HashMap<_, _> = force.iter().filter_map(|key| {
                        chunks.get(key).map(|chunk| (*key, chunk_light_signature(chunk)))
                    }).collect();
                    rebuild_light_after_block_edit(&mut chunks, &force);
                    for key in force {
                        if before.get(&key).is_some_and(|signature| {
                            chunks.get(&key).is_some_and(|chunk| chunk_light_signature(chunk) != *signature)
                        }) {
                            updated_keys.insert(key);
                            // A full fallback may alter any section in this chunk.
                            for section_y in 0_u8..16 {
                                let pos = WorldLightPos {
                                    x: i64::from(key.0) * 16 + 8,
                                    y: i32::from(section_y) * 16 + 8,
                                    z: i64::from(key.1) * 16 + 8,
                                };
                                light_changed_positions.insert(pos);
                            }
                        }
                    }
                }
            }
        }
        if chunks.values().any(|chunk| chunk.sections.iter().any(|section| {
            section.block_light.is_none() || section.sky_light.is_none()
        })) {
            rebuild_missing_block_light(&mut chunks);
        }

        // Capture block/height/light mutations for persistence. A one-time
        // reconstruction of absent derived arrays is kept in the worker cache,
        // but does not make otherwise untouched neighboring chunks dirty.
        updated_fallback = updated_keys.iter().filter_map(|key| chunks.get(key).cloned()).collect();

        // All missing light arrays were prepared above, before this immutable mesh
        // snapshot is taken. A section edit therefore never repeats a full light
        // map scan or clones neighboring ChunkData while rebuilding geometry.
        let mesh_chunks = chunks;
        if missing_light_baseline_needed {
            // A sparse/legacy chunk without saved nibble arrays needs one global
            // baseline reconstruction. Keep those derived arrays in the worker
            // cache so the same chunks do not trigger that baseline scan again.
            for (key, chunk) in &mesh_chunks {
                working_chunks.insert(*key, chunk.clone());
            }
        } else {
            // Normal edits replace only chunks whose block, HeightMap or light
            // values changed; copying all 25 cached neighbors per mining action
            // would recreate avoidable CPU/memory work outside the light solver.
            for key in &updated_keys {
                if let Some(chunk) = mesh_chunks.get(key) {
                    working_chunks.insert(*key, chunk.clone());
                }
            }
        }

        // Geometry is rebuilt at 16-block section granularity. The changed block
        // affects adjacent faces and smooth-light/AO samples up to two cells away;
        // each changed light sample marks only sections whose vertices can read it.
        let mut mesh_targets = HashSet::<((i32, i32), u8)>::new();
        let edit_world = WorldLightPos {
            x: i64::from(request.chunk_x) * 16 + i64::from(request.local_x),
            y: i32::from(request.local_y),
            z: i64::from(request.chunk_z) * 16 + i64::from(request.local_z),
        };
        let mut mark_near = |pos: WorldLightPos| {
            let min_y = (pos.y - 2).max(0);
            let max_y = (pos.y + 2).min(255);
            let min_cx = (pos.x - 2).div_euclid(16);
            let max_cx = (pos.x + 2).div_euclid(16);
            let min_cz = (pos.z - 2).div_euclid(16);
            let max_cz = (pos.z + 2).div_euclid(16);
            for cx in min_cx..=max_cx {
                for cz in min_cz..=max_cz {
                    let (Ok(cx), Ok(cz)) = (i32::try_from(cx), i32::try_from(cz)) else { continue; };
                    if !mesh_chunks.contains_key(&(cx, cz)) { continue; }
                    for sy in (min_y / 16) as u8..=(max_y / 16) as u8 {
                        mesh_targets.insert(((cx, cz), sy));
                    }
                }
            }
        };
        mark_near(edit_world);
        for pos in light_changed_positions { mark_near(pos); }
        drop(mark_near);

        let mut ordered_targets: Vec<_> = mesh_targets.into_iter().collect();
        ordered_targets.sort_by_key(|&((x, z), section_y)| {
            ((x, z) != center_key, z, x, section_y)
        });
        let mut meshes = Vec::new();
        for (key, section_y) in ordered_targets {
            match build_chunk_section_from_ready_neighborhood(jar, key.0, key.1, section_y, &mesh_chunks, context) {
                Ok(mut built) => {
                    let offset_x = ((i64::from(key.0) - i64::from(request.origin_chunk_x)) * 16) as f32;
                    let offset_z = ((i64::from(key.1) - i64::from(request.origin_chunk_z)) * 16) as f32;
                    translate_quads(&mut built.quads, offset_x, offset_z);
                    meshes.push(GameplayChunkMeshUpdate { coords: key, section_y, quads: built.quads });
                }
                Err(error) => { mesh_error = Some(format!("mesh rebuild for chunk ({},{}) section {}: {error}", key.0, key.1, section_y)); break; }
            }
        }
        meshes_fallback = meshes.clone();
        Ok((updated_fallback.clone(), meshes, mesh_error.clone()))
    })();
    match operation {
        Ok((updated_chunks, meshes, mesh_error)) => {
            result.processed = true;
            result.updated_chunks = updated_chunks;
            result.meshes = meshes;
            result.error = mesh_error;
        }
        Err(error) => {
            result.processed = false;
            result.updated_chunks = updated_fallback;
            result.meshes = meshes_fallback;
            result.error = Some(error.to_string());
        }
    }
    result
}

/// Owns the model/texture resolution caches on one background thread. The worker
/// always chooses the nearest missing chunk around the latest player chunk, so a
/// long queue from an old position cannot delay the new area indefinitely.
pub(crate) fn start_chunk_streamer(
    context: ChunkBuildContext,
    jar: PathBuf,
    world: PathBuf,
    origin_chunk_x: i32,
    origin_chunk_z: i32,
    initially_loaded: Vec<(i32, i32)>,
    world_io_lock: Arc<Mutex<()>>,
) -> Result<ChunkStreamer> {
    let (request_tx, request_rx) = mpsc::channel::<(i32, i32)>();
    let (result_tx, result_rx) = mpsc::channel::<ChunkStreamResult>();
    let _worker = thread::Builder::new()
        .name("mc189-chunk-streamer".into())
        .spawn(move || {
            let mut context = context;
            let mut attempted: HashSet<(i32, i32)> = initially_loaded.into_iter().collect();
            let mut center: Option<(i32, i32)> = None;
            loop {
                while let Ok(next_center) = request_rx.try_recv() {
                    center = Some(next_center);
                }
                let Some((center_x, center_z)) = center else {
                    match request_rx.recv() {
                        Ok(next_center) => { center = Some(next_center); continue; }
                        Err(_) => break,
                    }
                };

                attempted.retain(|&(x, z)| {
                    (i64::from(x) - i64::from(center_x)).abs() <= i64::from(RETAIN_RADIUS_CHUNKS)
                        && (i64::from(z) - i64::from(center_z)).abs() <= i64::from(RETAIN_RADIUS_CHUNKS)
                });
                let mut candidates = Vec::new();
                for dz in -STREAM_RADIUS_CHUNKS..=STREAM_RADIUS_CHUNKS {
                    for dx in -STREAM_RADIUS_CHUNKS..=STREAM_RADIUS_CHUNKS {
                        if let (Some(x), Some(z)) = (center_x.checked_add(dx), center_z.checked_add(dz)) {
                            if !attempted.contains(&(x, z)) {
                                candidates.push(((i64::from(dx) * i64::from(dx) + i64::from(dz) * i64::from(dz)), x, z));
                            }
                        }
                    }
                }
                candidates.sort_by_key(|&(distance, x, z)| (distance, z, x));
                let Some((_, chunk_x, chunk_z)) = candidates.into_iter().next() else {
                    match request_rx.recv() {
                        Ok(next_center) => { center = Some(next_center); }
                        Err(_) => break,
                    }
                    continue;
                };
                attempted.insert((chunk_x, chunk_z));

                let result = {
                    let _io_guard = world_io_lock.lock().unwrap_or_else(|poisoned| poisoned.into_inner());
                    match load_chunk(&world, chunk_x, chunk_z) {
                        Ok(Some(chunk)) => match build_chunk_from_selected(
                            &jar, &world, chunk_x, chunk_z, &chunk, &mut context,
                        ) {
                            Ok(mut built) => {
                                let offset_x = ((i64::from(chunk_x) - i64::from(origin_chunk_x)) * 16) as f32;
                                let offset_z = ((i64::from(chunk_z) - i64::from(origin_chunk_z)) * 16) as f32;
                                translate_quads(&mut built.quads, offset_x, offset_z);
                                ChunkStreamResult { chunk_x, chunk_z, chunk: Some(chunk), quads: built.quads, error: None }
                            }
                            Err(error) => ChunkStreamResult { chunk_x, chunk_z, chunk: Some(chunk), quads: Vec::new(), error: Some(error.to_string()) },
                        },
                        Ok(None) => ChunkStreamResult { chunk_x, chunk_z, chunk: None, quads: Vec::new(), error: None },
                        Err(error) => ChunkStreamResult { chunk_x, chunk_z, chunk: None, quads: Vec::new(), error: Some(error.to_string()) },
                    }
                };
                if result_tx.send(result).is_err() { break; }
            }
        })
        .map_err(|error| Mc189Error::InvalidData(format!("cannot start chunk streaming worker: {error}")))?;
    Ok(ChunkStreamer { requests: request_tx, results: result_rx })
}

impl ChunkBuildContext {
    fn load(jar: &Path) -> Result<Self> {
        Ok(Self {
            grass_colormap: GrassColorMap::load(jar)?,
            foliage_colormap: FoliageColorMap::load(jar)?,
            model_catalog: ModelCatalog::load(jar)?,
            variant_cache: HashMap::new(),
            failed_variant_keys: HashSet::new(),
        })
    }
}

fn build_chunk(jar: &Path, world: &Path, chunk_x: i32, chunk_z: i32, context: &mut ChunkBuildContext) -> Result<BuiltChunk> {
    let selected = load_chunk(world, chunk_x, chunk_z)?.ok_or_else(|| Mc189Error::InvalidData(format!("chunk ({chunk_x},{chunk_z}) is not present in this world")))?;
    build_chunk_from_selected(jar, world, chunk_x, chunk_z, &selected, context)
}

pub(crate) fn rebuild_chunk_quads_for_gameplay(
    jar: &Path, world: &Path, chunk_x: i32, chunk_z: i32,
    selected: &ChunkData, origin_chunk_x: i32, origin_chunk_z: i32,
) -> Result<Vec<CpuMeshQuad>> {
    let mut context = ChunkBuildContext::load(jar)?;
    let mut built = build_chunk_from_selected(jar, world, chunk_x, chunk_z, selected, &mut context)?;
    let offset_x = ((i64::from(chunk_x) - i64::from(origin_chunk_x)) * 16) as f32;
    let offset_z = ((i64::from(chunk_z) - i64::from(origin_chunk_z)) * 16) as f32;
    translate_quads(&mut built.quads, offset_x, offset_z);
    Ok(built.quads)
}

fn build_chunk_from_selected(
    jar: &Path,
    world: &Path,
    chunk_x: i32,
    chunk_z: i32,
    selected: &ChunkData,
    context: &mut ChunkBuildContext,
) -> Result<BuiltChunk> {
    let mut chunks = HashMap::new();
    chunks.insert((chunk_x, chunk_z), selected.clone());
    // Fluid corner heights sample a 2x2 neighborhood around every vertex,
    // including diagonal chunks at the selected chunk's corners.
    for dx in -1_i32..=1 {
        for dz in -1_i32..=1 {
            if dx == 0 && dz == 0 { continue; }
            if let (Some(nx), Some(nz)) = (chunk_x.checked_add(dx), chunk_z.checked_add(dz)) {
                if let Some(neighbor) = load_chunk(world, nx, nz)? { chunks.insert((nx, nz), neighbor); }
            }
        }
    }
    build_chunk_from_neighborhood(jar, chunk_x, chunk_z, chunks, context)
}

/// Reuses an already loaded neighborhood. Gameplay edits use this to avoid
/// rereading the same region files and rebuilding model caches per block.
fn build_chunk_from_neighborhood(
    jar: &Path,
    chunk_x: i32,
    chunk_z: i32,
    chunks: HashMap<(i32, i32), ChunkData>,
    context: &mut ChunkBuildContext,
) -> Result<BuiltChunk> {
    build_chunk_from_neighborhood_filtered(jar, chunk_x, chunk_z, chunks, context, None)
}

fn build_chunk_from_neighborhood_filtered(
    jar: &Path,
    chunk_x: i32,
    chunk_z: i32,
    mut chunks: HashMap<(i32, i32), ChunkData>,
    context: &mut ChunkBuildContext,
    only_section: Option<u8>,
) -> Result<BuiltChunk> {
    rebuild_missing_block_light(&mut chunks);
    build_chunk_from_ready_neighborhood(jar, chunk_x, chunk_z, &chunks, context, only_section)
}

fn build_chunk_section_from_ready_neighborhood(
    jar: &Path,
    chunk_x: i32,
    chunk_z: i32,
    section_y: u8,
    chunks: &HashMap<(i32, i32), ChunkData>,
    context: &mut ChunkBuildContext,
) -> Result<BuiltChunk> {
    // Gameplay worker owns a prepared immutable neighborhood. Borrow it through
    // rendering of this section instead of cloning every 4 KiB section/light map.
    build_chunk_from_ready_neighborhood(jar, chunk_x, chunk_z, chunks, context, Some(section_y))
}

fn build_chunk_from_ready_neighborhood(
    jar: &Path,
    chunk_x: i32,
    chunk_z: i32,
    chunks: &HashMap<(i32, i32), ChunkData>,
    context: &mut ChunkBuildContext,
    only_section: Option<u8>,
) -> Result<BuiltChunk> {
    let selected = chunks.get(&(chunk_x, chunk_z))
        .ok_or_else(|| Mc189Error::InvalidData(format!("chunk ({chunk_x},{chunk_z}) missing from mesh neighborhood")))?;

    let mut stats = BuildStats::default();
    let mut output = Vec::new();
    let origin_x = i64::from(chunk_x) * 16;
    let origin_z = i64::from(chunk_z) * 16;

    for section in selected.sections.iter().filter(|section| only_section.map_or(true, |target| section.y == target)) {
        for ly in 0_u8..16 {
            let y = i32::from(section.y) * 16 + i32::from(ly);
            if !(0..=255).contains(&y) { continue; }
            for z in 0_u8..16 {
                for x in 0_u8..16 {
                    let index = (usize::from(ly) << 8) | (usize::from(z) << 4) | usize::from(x);
                    let id = *section.block_ids.get(index).ok_or_else(|| Mc189Error::InvalidData(format!("short block ID array in section Y={}", section.y)))?;
                    if id == 0 { stats.air += 1; continue; }
                    stats.non_air += 1;
                    let meta = *section.metadata.get(index).ok_or_else(|| Mc189Error::InvalidData(format!("short metadata array in section Y={}", section.y)))?;
                    let wx = origin_x + i64::from(x);
                    let wz = origin_z + i64::from(z);
                    let target = match map_legacy_block(id, meta) {
                        Some(target) => target,
                        None => { stats.unknown += 1; *stats.skipped_states.entry((id, meta)).or_insert(0) += 1; continue; }
                    };
                    if let LegacyTarget::Fluid(_) = &target {
                        let mut fluid = build_fluid_quads(id, meta, x, y, z, wx, wz, chunks);
                        // BlockFluidRenderer uses packed block brightness for the
                        // liquid block; directional darkening is already baked into
                        // the fluid face tint in build_fluid_quads, so do not apply
                        // AO or face shade a second time here.
                        // BlockLiquid.getMixedBrightnessForBlock: max(propio, bloque de arriba) por canal.
                        let own_light = raw_light_channels_at_world(chunks, wx, y, wz);
                        let above_light = raw_light_channels_at_world(chunks, wx, y + 1, wz);
                        let liquid_light = VanillaLightChannels {
                            sky: own_light.sky.max(above_light.sky),
                            block: own_light.block.max(above_light.block),
                        };
                        let liquid_packed = pack_vanilla_light(liquid_light);
                        let (liquid_sky, liquid_block) = unpack_vanilla_light(liquid_packed);
                        for quad in &mut fluid {
                            quad.source_block = Some([i32::from(x), y, i32::from(z)]);
                            quad.vertex_ao = [1.0; 4];
                            quad.vertex_sky_light = [liquid_sky; 4];
                            quad.vertex_block_light = [liquid_block; 4];
                            quad.vertex_face_shade = [1.0; 4];
                        }
                        if !fluid.is_empty() {
                            if id == 8 || id == 9 { stats.rendered_water += 1; }
                            else { stats.rendered_lava += 1; }
                            stats.fluid_quads += fluid.len() as u64;
                            stats.rendered_blocks += 1;
                            output.append(&mut fluid);
                        } else {
                            stats.fluids += 1;
                        }
                        continue;
                    }
                    let target_plant_tint = matches!(&target, LegacyTarget::PlantModel { tint: true, .. });
                    let stone_texture = match &target {
                        LegacyTarget::StoneVariant { texture } => Some(*texture),
                        _ => None,
                    };
                    let (model_id, rx, ry, uvlock) = match target {
                        LegacyTarget::Air => { stats.air += 1; continue; }
                        LegacyTarget::Fluid(_) => { stats.fluids += 1; continue; }
                        LegacyTarget::LegacyVisual(_) => { stats.special += 1; *stats.skipped_states.entry((id, meta)).or_insert(0) += 1; continue; }
                        LegacyTarget::Model { blockstate, variant } => {
                            let Some(choice) = cached_variant_model(jar, context, blockstate, &variant, position_seed(wx, i64::from(y), wz)) else {
                                stats.missing_models += 1; *stats.skipped_states.entry((id, meta)).or_insert(0) += 1; continue;
                            };
                            choice
                        }
                        LegacyTarget::DirectModel { model } => (model.to_owned(), 0, 0, false),
                        LegacyTarget::StoneVariant { .. } => ("block/stone".to_owned(), 0, 0, false),
                        LegacyTarget::Log { blockstate, species: _, axis } => {
                            let selector = match axis { "all" => "axis=none", other => {
                                match other { "x" | "y" | "z" => {}, _ => return Err(Mc189Error::InvalidData(format!("unsupported log axis {other}"))) }
                                match other { "x" => "axis=x", "y" => "axis=y", _ => "axis=z" }
                            }};
                            let Some(choice) = cached_variant_model(jar, context, blockstate, selector, position_seed(wx, i64::from(y), wz)) else {
                                stats.missing_models += 1; *stats.skipped_states.entry((id, meta)).or_insert(0) += 1; continue;
                            };
                            choice
                        }
                        LegacyTarget::Leaves { model, .. } => (model.to_owned(), 0, 0, false),
                        LegacyTarget::PlantModel { model, .. } => (model.to_owned(), 0, 0, false),
                        LegacyTarget::ContextualModel { blockstate, .. } => {
                            let Some(selector) = contextual_selector(blockstate, chunks, wx, y, wz) else {
                                stats.special += 1; *stats.skipped_states.entry((id, meta)).or_insert(0) += 1; continue;
                            };
                            let Some(choice) = cached_variant_model(jar, context, blockstate, &selector, position_seed(wx, i64::from(y), wz)) else {
                                stats.missing_models += 1; *stats.skipped_states.entry((id, meta)).or_insert(0) += 1; continue;
                            };
                            choice
                        }
                    };
                    if uvlock { stats.uvlock += 1; }
                    let quads = match context.model_catalog.load_model_quads(&model_id) {
                        Ok((_resolved_path, quads)) => quads,
                        Err(_) => { stats.missing_models += 1; *stats.skipped_states.entry((id, meta)).or_insert(0) += 1; continue; }
                    };
                    if quads.is_empty() {
                        stats.missing_models += 1;
                        *stats.skipped_states.entry((id, meta)).or_insert(0) += 1;
                        continue;
                    }
                    let mut block_quads = quads.as_ref().clone();
                    let mut block_tint = [1.0, 1.0, 1.0];
                    if let Some(texture) = stone_texture {
                        let texture_path = format!("assets/minecraft/textures/blocks/{texture}.png");
                        for quad in &mut block_quads { quad.texture_path = texture_path.clone(); }
                    }
                    if id == 17 || id == 162 {
                        let species = if id == 17 { ["oak", "spruce", "birch", "jungle"][(meta & 3) as usize] } else { ["acacia", "dark_oak"][(meta & 1) as usize] };
                        for quad in &mut block_quads {
                            let is_end = if (meta & 0x0c) == 12 { false } else {
                                match meta & 0x0c {
                                    0 => matches!(quad.face, crate::model_resolver::ModelFaceDirection::Up | crate::model_resolver::ModelFaceDirection::Down),
                                    4 => matches!(quad.face, crate::model_resolver::ModelFaceDirection::Up | crate::model_resolver::ModelFaceDirection::Down),
                                    8 => matches!(quad.face, crate::model_resolver::ModelFaceDirection::Up | crate::model_resolver::ModelFaceDirection::Down),
                                    _ => false,
                                }
                            };
                            let texture = if is_end { format!("log_{species}_top") } else { format!("log_{species}") };
                            quad.texture_path = format!("assets/minecraft/textures/blocks/{texture}.png");
                        }
                    }
                    if matches!(id, 18 | 161) {
                        let texture = match map_legacy_block(id, meta) { Some(LegacyTarget::Leaves { texture, .. }) => texture, _ => "leaves_oak" };
                        for quad in &mut block_quads { quad.texture_path = format!("assets/minecraft/textures/blocks/{texture}.png"); }
                        match biome_tint_at_world(chunks, wx, wz, &context.foliage_colormap) {
                            Some(color) => { block_tint = color; stats.tinted_leaves_blocks += 1; }
                            None => { stats.missing_biome_leaves_blocks += 1; }
                        }
                    }
                    let plant_tinted = target_plant_tint || matches!((id, meta), (31, 1 | 2));
                    if id == 2 || plant_tinted {
                        match biome_tint_at_world(chunks, wx, wz, &context.grass_colormap) {
                            Some(color) => { block_tint = color; stats.tinted_grass_blocks += 1; }
                            None => { stats.missing_biome_grass_blocks += 1; }
                        }
                    }
                    for quad in block_quads.iter() {
                        if let Some(cull_face) = quad.cull_face {
                            let (dx, dy, dz) = rotated_face_offset(cull_face, rx, ry);
                            let (neighbor, neighbor_meta) = block_state_at(chunks, wx + dx, y + dy, wz + dz);
                            if should_cull_model_face(id, meta, neighbor, neighbor_meta) { continue; }
                        }
                        let mut instance = transform_instance(quad, f32::from(x), y as f32, f32::from(z), rx, ry);
                        instance.source_block = Some([i32::from(x), y, i32::from(z)]);
                        if uvlock { lock_uv_to_world(&mut instance, f32::from(x), y as f32, f32::from(z)); }
                        if ((id == 2 || id == 18 || id == 161 || plant_tinted) && quad.tint_index >= 0)
                            || should_apply_grass_biome_tint(id, quad) {
                            instance.tint_color = block_tint;
                            if id == 2 || (plant_tinted && !matches!(id, 18 | 161)) { stats.tinted_grass_faces += 1; }
                            if id == 18 || id == 161 { stats.tinted_leaves_faces += 1; }
                        }
                        let lighting = calculate_quad_vertex_lighting(
                            &instance, wx, y, wz, origin_x, origin_z, id, chunks,
                        );
                        instance.vertex_ao = if quad.ambient_occlusion { lighting.ao } else { [1.0; 4] };
                        instance.vertex_sky_light = lighting.sky;
                        instance.vertex_block_light = lighting.block;
                        instance.vertex_face_shade = lighting.face_shade;
                        // Door panels are only 3/16 of a block thick. Their boundary
                        // side faces can be exactly coplanar with the neighbouring
                        // cube face, so inset those boundary planes by 0.001 blocks.
                        // This is geometry-only; vertex-light sampling above remains unchanged.
                        if matches!(id, 64 | 71 | 193..=197) {
                            inset_door_boundary_faces(&mut instance, f32::from(x), f32::from(z));
                        }
                        output.push(instance);
                    }
                    if id == 17 || id == 162 { stats.rendered_logs += 1; }
                    if id == 1 && meta > 0 && meta <= 6 { stats.rendered_stone_variants += 1; }
                    if id == 18 || id == 161 { stats.rendered_leaves += 1; }
                    if matches!(id, 6 | 31 | 32 | 37 | 38 | 83 | 175) { stats.rendered_vegetation += 1; }
                    if id == 61 || id == 62 {
                        *stats.rendered_furnaces.entry((id, meta)).or_insert(0) += 1;
                    }
                    stats.rendered_blocks += 1;
                }
            }
        }
    }
    stats.rendered_quads = output.len() as u64;
    let (center, radius) = if output.is_empty() {
        (Vec3::new(8.0, 0.0, 8.0), 8.0)
    } else {
        let min_y = output.iter().flat_map(|q| q.positions.iter().map(|p| p[1])).fold(f32::INFINITY, f32::min);
        let max_y = output.iter().flat_map(|q| q.positions.iter().map(|p| p[1])).fold(f32::NEG_INFINITY, f32::max);
        (Vec3::new(8.0, (min_y + max_y) * 0.5, 8.0),
         ((8.0_f32).powi(2) + ((max_y - min_y) * 0.5).powi(2) + 8.0_f32.powi(2)).sqrt().max(8.0))
    };
    Ok(BuiltChunk { quads: output, stats, center, radius })
}


fn translate_quads(quads: &mut [CpuMeshQuad], offset_x: f32, offset_z: f32) {
    let owner_dx = offset_x.round() as i32;
    let owner_dz = offset_z.round() as i32;
    for quad in quads {
        for point in &mut quad.positions {
            point[0] += offset_x;
            point[2] += offset_z;
        }
        if let Some(owner) = quad.source_block.as_mut() {
            owner[0] = owner[0].saturating_add(owner_dx);
            owner[2] = owner[2].saturating_add(owner_dz);
        }
    }
}

fn merge_stats(total: &mut BuildStats, part: BuildStats) {
    total.non_air += part.non_air;
    total.rendered_blocks += part.rendered_blocks;
    total.rendered_quads += part.rendered_quads;
    total.rendered_logs += part.rendered_logs;
    total.rendered_stone_variants += part.rendered_stone_variants;
    total.rendered_leaves += part.rendered_leaves;
    total.rendered_vegetation += part.rendered_vegetation;
    total.air += part.air;
    total.fluids += part.fluids;
    total.rendered_water += part.rendered_water;
    total.rendered_lava += part.rendered_lava;
    total.fluid_quads += part.fluid_quads;
    total.special += part.special;
    total.unknown += part.unknown;
    total.uvlock += part.uvlock;
    total.missing_models += part.missing_models;
    total.tinted_grass_blocks += part.tinted_grass_blocks;
    total.tinted_grass_faces += part.tinted_grass_faces;
    total.missing_biome_grass_blocks += part.missing_biome_grass_blocks;
    total.tinted_leaves_blocks += part.tinted_leaves_blocks;
    total.tinted_leaves_faces += part.tinted_leaves_faces;
    total.missing_biome_leaves_blocks += part.missing_biome_leaves_blocks;
    for (state, count) in part.skipped_states {
        *total.skipped_states.entry(state).or_insert(0) += count;
    }
    for (state, count) in part.rendered_furnaces {
        *total.rendered_furnaces.entry(state).or_insert(0) += count;
    }
}

/// Starts a native first-person session at the world's saved spawn. Three-by-three
/// chunks are prepared synchronously; the surrounding area is streamed in the background.
pub fn play_world(jar: &Path, atlas: &Path, world: &Path, spawn_world: Vec3) -> Result<()> {
    play_world_impl(jar, atlas, world, spawn_world, None)
}

/// Starts gameplay in the title screen's existing native window and reusable event loop.
pub fn play_world_in_window(
    jar: &Path,
    atlas: &Path,
    world: &Path,
    spawn_world: Vec3,
    event_loop: &mut winit::event_loop::EventLoop<()>,
    window: std::sync::Arc<winit::window::Window>,
) -> Result<()> {
    play_world_impl(jar, atlas, world, spawn_world, Some((event_loop, window)))
}

fn play_world_impl(
    jar: &Path,
    atlas: &Path,
    world: &Path,
    spawn_world: Vec3,
    existing_window: Option<(&mut winit::event_loop::EventLoop<()>, std::sync::Arc<winit::window::Window>)>,
) -> Result<()> {
    let world_metadata = mc189_storage::read_world_metadata(world)?;
    let saved_player = mc189_storage::read_world_player_data(world)?;
    let player_inventory = crate::inventory::PlayerInventory::from_player_nbt(saved_player.as_ref())?;
    // level.dat Data.Player.Pos is the last committed player location. Use it
    // when valid; malformed or absent coordinates safely fall back to world spawn.
    let spawn_world = saved_player.as_ref()
        .and_then(|player| player.get("Pos"))
        .and_then(|tag| tag.as_list())
        .and_then(|(kind, values)| {
            if kind != 6 || values.len() != 3 { return None; }
            let number = |tag: &mc189_storage::NbtTag| match tag {
                mc189_storage::NbtTag::Double(value) if value.is_finite() => Some(*value as f32),
                _ => None,
            };
            Some(Vec3::new(number(&values[0])?, number(&values[1])?, number(&values[2])?))
        })
        .filter(|position| position.is_finite() && position.y >= 0.0 && position.y < 256.0)
        .unwrap_or(spawn_world);
    let saved_motion = saved_player.as_ref()
        .and_then(|player| player.get("Motion"))
        .and_then(|tag| tag.as_list())
        .and_then(|(kind, values)| {
            if kind != 6 || values.len() != 3 { return None; }
            let number = |tag: &mc189_storage::NbtTag| match tag {
                mc189_storage::NbtTag::Double(value) if value.is_finite() => Some((*value as f32).clamp(-78.4, 78.4)),
                _ => None,
            };
            Some(Vec3::new(number(&values[0])?, number(&values[1])?, number(&values[2])?))
        })
        .filter(|motion| motion.is_finite());
    let saved_rotation = saved_player.as_ref()
        .and_then(|player| player.get("Rotation"))
        .and_then(|tag| tag.as_list())
        .and_then(|(kind, values)| {
            if kind != 5 || values.len() != 2 { return None; }
            match (&values[0], &values[1]) {
                (mc189_storage::NbtTag::Float(yaw), mc189_storage::NbtTag::Float(pitch))
                    if yaw.is_finite() && pitch.is_finite() => Some((*yaw, *pitch)),
                _ => None,
            }
        });
    let initial_day_time = world_metadata.day_time.unwrap_or(0);
    let raining = world_metadata.raining.unwrap_or(0) != 0;
    let thundering = world_metadata.thundering.unwrap_or(0) != 0;
    let center_chunk_x = (spawn_world.x.floor() as i32).div_euclid(16);
    let center_chunk_z = (spawn_world.z.floor() as i32).div_euclid(16);
    // Player coordinates remain local to this fixed origin while chunks stream in
    // and out around the player. This avoids large world-space floats in the camera.
    let origin_chunk_x = center_chunk_x;
    let origin_chunk_z = center_chunk_z;
    let mut context = ChunkBuildContext::load(jar)?;
    let mut chunk_meshes = HashMap::new();
    let mut region_stats = BuildStats::default();
    let mut chunks = HashMap::new();
    for dz in -1_i32..=1 {
        for dx in -1_i32..=1 {
            let cx = center_chunk_x.checked_add(dx).ok_or_else(|| Mc189Error::InvalidData("spawn chunk X overflow".into()))?;
            let cz = center_chunk_z.checked_add(dz).ok_or_else(|| Mc189Error::InvalidData("spawn chunk Z overflow".into()))?;
            if let Some(chunk) = load_chunk(world, cx, cz)? {
                let mut built = build_chunk_from_selected(jar, world, cx, cz, &chunk, &mut context)?;
                translate_quads(&mut built.quads, (dx * 16) as f32, (dz * 16) as f32);
                chunk_meshes.insert((cx, cz), built.quads);
                merge_stats(&mut region_stats, built.stats);
                chunks.insert((cx, cz), chunk);
            }
        }
    }
    if chunks.is_empty() { return Err(Mc189Error::InvalidData("no chunks around the saved spawn are present".into())); }
    let spawn_local = Vec3::new(
        spawn_world.x - (origin_chunk_x * 16) as f32,
        spawn_world.y,
        spawn_world.z - (origin_chunk_z * 16) as f32,
    );
    let collision = crate::player::LoadedWorldCollision { chunks, origin_chunk_x, origin_chunk_z };
    let safe_spawn = crate::player::resolve_safe_spawn(spawn_local, &collision)
        .ok_or_else(|| Mc189Error::InvalidData("could not find a safe standing position in the loaded spawn column; refusing to start underground or inside blocks".into()))?;
    let mut player = crate::player::PlayerState::at(safe_spawn);
    if let Some(motion) = saved_motion { player.velocity = motion; }
    if let Some((yaw, pitch)) = saved_rotation {
        player.yaw = yaw;
        player.pitch = pitch.clamp(-std::f32::consts::FRAC_PI_2, std::f32::consts::FRAC_PI_2);
    }
    region_stats.rendered_quads = chunk_meshes.values().map(|q| q.len() as u64).sum();
    println!("Minecraft 1.8.9 — preparing first-person world");
    println!("World: {}", world.display());
    println!("Saved spawn: ({:.1}, {:.1}, {:.1})", spawn_world.x, spawn_world.y, spawn_world.z);
    println!("Safe player feet position: ({:.1}, {:.1}, {:.1})", safe_spawn.x + (origin_chunk_x * 16) as f32, safe_spawn.y, safe_spawn.z + (origin_chunk_z * 16) as f32);
    println!("Loaded chunks for initial play area: {} / 9", collision.chunks.len());
    println!("Rendered block instances: {}", region_stats.rendered_blocks);
    println!("Generated model quads: {}", region_stats.rendered_quads);
    println!("Rendered water/lava: {}/{}", region_stats.rendered_water, region_stats.rendered_lava);
    println!("Unknown states / missing models: {} / {}", region_stats.unknown, region_stats.missing_models);
    let initially_loaded = collision.chunks.keys().copied().collect();
    let world_io_lock = Arc::new(Mutex::new(()));
    let streamer = start_chunk_streamer(context, jar.to_path_buf(), world.to_path_buf(), origin_chunk_x, origin_chunk_z, initially_loaded, world_io_lock.clone())?;
    let block_edit_worker = start_gameplay_block_edit_worker(jar.to_path_buf(), world.to_path_buf(), world_io_lock.clone())?;
    match existing_window {
        Some((event_loop, window)) => crate::gpu_block_preview::run_gameplay_on_window(
            jar, atlas, world, chunk_meshes, player, player_inventory, collision, origin_chunk_x, origin_chunk_z, streamer, block_edit_worker, world_io_lock,
            initial_day_time, raining, thundering, event_loop, window,
        ),
        None => crate::gpu_block_preview::run_gameplay(
            jar, atlas, world, chunk_meshes, player, player_inventory, collision, origin_chunk_x, origin_chunk_z, streamer, block_edit_worker, world_io_lock,
            initial_day_time, raining, thundering,
        ),
    }
}

/// Builds a square region of chunks around a required center chunk. Each chunk is
/// meshed independently, then translated into region-space before the meshes are joined.
/// Neighbor chunks are still loaded by build_chunk for edge-sensitive block states.
pub fn preview_textured_region(
    jar: &Path, atlas: &Path, world: &Path,
    center_chunk_x: i32, center_chunk_z: i32, radius_chunks: u8,
) -> Result<()> {
    if radius_chunks > 4 {
        return Err(Mc189Error::InvalidData("region radius must be between 0 and 4 chunks (1x1 through 9x9)".into()));
    }
    let mut context = ChunkBuildContext::load(jar)?;
    let mut region_quads = Vec::new();
    let mut region_stats = BuildStats::default();
    let mut loaded_chunks = 0_u32;
    let diameter = i32::from(radius_chunks) * 2 + 1;
    for dz in -i32::from(radius_chunks)..=i32::from(radius_chunks) {
        for dx in -i32::from(radius_chunks)..=i32::from(radius_chunks) {
            let cx = center_chunk_x.checked_add(dx).ok_or_else(|| Mc189Error::InvalidData("region chunk X coordinate overflow".into()))?;
            let cz = center_chunk_z.checked_add(dz).ok_or_else(|| Mc189Error::InvalidData("region chunk Z coordinate overflow".into()))?;
            match load_chunk(world, cx, cz)? {
                None => continue,
                Some(_) => {}
            }
            let mut built = build_chunk(jar, world, cx, cz, &mut context)?;
            let offset_x = (dx * 16) as f32;
            let offset_z = (dz * 16) as f32;
            translate_quads(&mut built.quads, offset_x, offset_z);
            region_quads.append(&mut built.quads);
            merge_stats(&mut region_stats, built.stats);
            loaded_chunks += 1;
        }
    }
    if loaded_chunks == 0 {
        return Err(Mc189Error::InvalidData("no chunks from the requested region are present in this world".into()));
    }
    let min_y = region_quads.iter().flat_map(|q| q.positions.iter().map(|p| p[1])).fold(f32::INFINITY, f32::min);
    let max_y = region_quads.iter().flat_map(|q| q.positions.iter().map(|p| p[1])).fold(f32::NEG_INFINITY, f32::max);
    let extent = diameter as f32 * 16.0;
    let center = Vec3::new(f32::from(radius_chunks) * 16.0 + 8.0, (min_y + max_y) * 0.5, f32::from(radius_chunks) * 16.0 + 8.0);
    let radius = ((extent * 0.5).powi(2) + ((max_y - min_y) * 0.5).powi(2) + (extent * 0.5).powi(2)).sqrt().max(16.0);
    region_stats.rendered_quads = region_quads.len() as u64;
    println!("Minecraft 1.8.9 textured multi-chunk region preview");
    println!("World: {}", world.display());
    println!("Center chunk: ({center_chunk_x},{center_chunk_z})");
    println!("Requested region: {diameter}x{diameter} chunks");
    println!("Loaded chunks: {loaded_chunks} / {}", diameter * diameter);
    println!("Non-air positions: {}", region_stats.non_air);
    println!("Rendered block instances: {}", region_stats.rendered_blocks);
    println!("Generated model quads: {}", region_stats.rendered_quads);
    println!("Rendered log blocks: {}", region_stats.rendered_logs);
    println!("Rendered non-normal stone variants: {}", region_stats.rendered_stone_variants);
    println!("Rendered leaf blocks: {}", region_stats.rendered_leaves);
    println!("Rendered cross-plane vegetation blocks: {}", region_stats.rendered_vegetation);
    println!("Grass/plant faces tinted: {}", region_stats.tinted_grass_faces);
    println!("Leaf faces tinted: {}", region_stats.tinted_leaves_faces);
    println!("Rendered water blocks: {}", region_stats.rendered_water);
    println!("Rendered lava blocks: {}", region_stats.rendered_lava);
    let furnace_total: u64 = region_stats.rendered_furnaces.values().sum();
    println!("Rendered furnaces: {furnace_total}");
    for ((id, metadata), count) in &region_stats.rendered_furnaces {
        let kind = if *id == 62 { "lit" } else { "unlit" };
        let facing = match metadata { 2 => "north", 3 => "south", 4 => "west", 5 => "east", _ => "invalid" };
        println!("  Furnace {kind}, facing={facing}: {count}");
    }
    println!("Generated fluid quads: {}", region_stats.fluid_quads);
    println!("Fluids without visible faces: {}", region_stats.fluids);
    println!("Skipped dedicated legacy visuals: {}", region_stats.special);
    println!("Skipped unknown ID/metadata states: {}", region_stats.unknown);
    println!("UV-locked states rendered with UV correction: {}", region_stats.uvlock);
    println!("Skipped missing/unsupported models: {}", region_stats.missing_models);
    crate::gpu_block_preview::run_chunk_preview(atlas, &format!("region {center_chunk_x},{center_chunk_z} ({diameter}x{diameter})"), region_quads, center, radius)
}

pub fn preview_textured_chunk(jar: &Path, atlas: &Path, world: &Path, chunk_x: i32, chunk_z: i32) -> Result<()> {
    let mut context = ChunkBuildContext::load(jar)?;
    let built = build_chunk(jar, world, chunk_x, chunk_z, &mut context)?;
    println!("Minecraft 1.8.9 textured chunk preview");
    println!("World: {}", world.display());
    println!("Chunk: ({chunk_x},{chunk_z})");
    println!("Non-air positions: {}", built.stats.non_air);
    println!("Air positions: {}", built.stats.air);
    println!("Rendered block instances: {}", built.stats.rendered_blocks);
    println!("Generated model quads: {}", built.stats.rendered_quads);
    println!("Rendered log blocks: {}", built.stats.rendered_logs);
    println!("Rendered non-normal stone variants: {}", built.stats.rendered_stone_variants);
    println!("Rendered leaf blocks: {}", built.stats.rendered_leaves);
    println!("Rendered cross-plane vegetation blocks: {}", built.stats.rendered_vegetation);
    println!("Grass blocks and grass-like vegetation with biome data: {}", built.stats.tinted_grass_blocks);
    println!("Grass/plant faces actually tinted (tintindex >= 0): {}", built.stats.tinted_grass_faces);
    println!("Grass blocks without usable biome data: {}", built.stats.missing_biome_grass_blocks);
    println!("Leaves blocks with foliage biome data: {}", built.stats.tinted_leaves_blocks);
    println!("Leaves faces actually tinted (tintindex >= 0): {}", built.stats.tinted_leaves_faces);
    println!("Leaves blocks without usable biome data: {}", built.stats.missing_biome_leaves_blocks);
    println!("Rendered water blocks: {}", built.stats.rendered_water);
    println!("Rendered lava blocks: {}", built.stats.rendered_lava);
    println!("Generated fluid quads: {}", built.stats.fluid_quads);
    println!("Fluids without visible faces: {}", built.stats.fluids);
    println!("Skipped dedicated legacy visuals: {}", built.stats.special);
    println!("Skipped unknown ID/metadata states: {}", built.stats.unknown);
    println!("UV-locked states rendered with UV correction: {}", built.stats.uvlock);
    println!("Skipped missing/unsupported models: {}", built.stats.missing_models);
    if !built.stats.skipped_states.is_empty() {
        println!("Most frequent skipped states (ID/meta: count):");
        let mut ranked: Vec<_> = built.stats.skipped_states.iter().collect();
        ranked.sort_by_key(|(_, count)| std::cmp::Reverse(**count));
        for ((id, meta), count) in ranked.into_iter().take(12) { println!("  {id}/{meta}: {count}"); }
    }
    crate::gpu_block_preview::run_chunk_preview(atlas, &format!("chunk {chunk_x},{chunk_z}"), built.quads, built.center, built.radius)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn same_light_properties_skip_neighborhood_relight() {
        // Opaque full cubes share opacity 15 and emit no light. Replacing one
        // with another cannot alter either channel or the column heightmap.
        assert!(!block_edit_changes_light(1, 3));
        assert!(!block_edit_changes_light(1, 4));
        // Removing an opaque block opens sky paths; changing an emitter changes
        // block light even if the destination is also transparent.
        assert!(block_edit_changes_light(1, 0));
        assert!(block_edit_changes_light(89, 0));
        // Water and leaves have partial opacity, so these are not safe fast paths.
        assert!(block_edit_changes_light(8, 9) == false);
        assert!(block_edit_changes_light(18, 0));
    }

    fn light_test_neighborhood() -> HashMap<(i32, i32), ChunkData> {
        let mut chunks = HashMap::new();
        for chunk_z in -1_i32..=2 {
            for chunk_x in -1_i32..=2 {
                chunks.insert((chunk_x, chunk_z), ChunkData {
                    x_pos: chunk_x, z_pos: chunk_z, sections: Vec::new(),
                    biomes: Some(vec![1; 256]), height_map: Some(vec![0; 256]),
                });
            }
        }
        chunks
    }

    #[test]
    fn raw_skylight_uses_emitter_opacity_exception_from_vanilla() {
        let mut chunks = light_test_neighborhood();
        let center = chunks.get_mut(&(0, 0)).unwrap();
        center.height_map.as_mut().unwrap().fill(200);
        center.set_block(8, 100, 8, 1, 0).unwrap();
        center.set_block(8, 100, 8, 89, 0).unwrap(); // glowstone: opacity 15, emission 15
        // Supply the adjacent sky sample. Vanilla World.getRawLight checks the
        // block's emission even for SKY, changing opacity 15 to opacity 1.
        let neighbor = WorldLightPos { x: 8, y: 101, z: 8 };
        assert!(set_world_stored_light(&mut chunks, neighbor, IncrementalLightChannel::Sky, 15));
        assert_eq!(raw_world_light(
            &chunks,
            WorldLightPos { x: 8, y: 100, z: 8 },
            IncrementalLightChannel::Sky,
        ), 14);
    }

    #[test]
    fn incremental_block_light_removal_clears_ghost_light_across_chunk_border() {
        let mut chunks = light_test_neighborhood();
        // A torch at X=15 lights the first block of the neighboring chunk.
        chunks.get_mut(&(0, 0)).unwrap().set_block(15, 8, 8, 50, 0).unwrap();
        rebuild_block_light_maps(&mut chunks, &HashSet::from([(0, 0)]));
        let source = WorldLightPos { x: 15, y: 8, z: 8 };
        let neighbor = WorldLightPos { x: 16, y: 8, z: 8 };
        assert_eq!(world_stored_light(&chunks, source, IncrementalLightChannel::Block), 14);
        assert_eq!(world_stored_light(&chunks, neighbor, IncrementalLightChannel::Block), 13);

        chunks.get_mut(&(0, 0)).unwrap().set_block(15, 8, 8, 0, 0).unwrap();
        let changed = incremental_light_after_block_edit(&mut chunks, 0, 0, 15, 8, 8, 50, 0)
            .expect("3x3 loaded test neighborhood satisfies vanilla radius-17 precondition");
        assert!(changed.contains(&source));
        assert!(changed.contains(&neighbor));
        assert_eq!(world_stored_light(&chunks, source, IncrementalLightChannel::Block), 0);
        assert_eq!(world_stored_light(&chunks, neighbor, IncrementalLightChannel::Block), 0);
    }

    #[test]
    fn incremental_light_reseeds_from_a_surviving_neighbor_emitter() {
        let mut chunks = light_test_neighborhood();
        chunks.get_mut(&(0, 0)).unwrap().set_block(13, 8, 8, 50, 0).unwrap();
        chunks.get_mut(&(0, 0)).unwrap().set_block(15, 8, 8, 50, 0).unwrap();
        rebuild_block_light_maps(&mut chunks, &HashSet::from([(0, 0)]));
        let removed_source = WorldLightPos { x: 15, y: 8, z: 8 };
        let beyond_border = WorldLightPos { x: 16, y: 8, z: 8 };
        assert_eq!(world_stored_light(&chunks, beyond_border, IncrementalLightChannel::Block), 13);

        chunks.get_mut(&(0, 0)).unwrap().set_block(15, 8, 8, 0, 0).unwrap();
        let changed = incremental_light_after_block_edit(&mut chunks, 0, 0, 15, 8, 8, 50, 0)
            .expect("3x3 loaded test neighborhood satisfies vanilla radius-17 precondition");
        assert!(changed.contains(&removed_source));
        // The remaining torch is three blocks away from X=16; it must be
        // re-propagated after the stale 14->13 dependency chain is cleared.
        assert_eq!(world_stored_light(&chunks, removed_source, IncrementalLightChannel::Block), 12);
        assert_eq!(world_stored_light(&chunks, beyond_border, IncrementalLightChannel::Block), 11);
    }

    #[test]
    fn incremental_block_light_reopens_path_through_removed_opaque_block() {
        let mut chunks = light_test_neighborhood();
        let center = chunks.get_mut(&(0, 0)).unwrap();
        center.height_map.as_mut().unwrap().fill(200);
        // Build a sealed one-block-wide tunnel so the light cannot simply
        // route around a one-block-thick wall. A lone wall is not a valid
        // zero-light expectation in vanilla: light propagates in six directions.
        for x in 5..=11 {
            for y in 7..=9 {
                for z in 7..=9 {
                    center.set_block(x, y, z, 1, 0).unwrap();
                }
            }
        }
        for x in 6..=10 {
            center.set_block(x, 8, 8, 0, 0).unwrap();
        }
        center.set_block(6, 8, 8, 50, 0).unwrap();
        center.set_block(9, 8, 8, 1, 0).unwrap();
        // Retain the original height of the edited column while keeping this
        // test isolated to BLOCK light rather than direct SKY light.
        center.set_block(9, 199, 8, 1, 0).unwrap();
        // Keep the neighboring columns out of direct skylight too; this test is
        // specifically about block-light attenuation through the removed wall.
        for (key, chunk) in chunks.iter_mut() {
            if *key != (0, 0) { chunk.height_map.as_mut().unwrap().fill(200); }
        }
        rebuild_block_light_maps(&mut chunks, &HashSet::from([(0, 0)]));
        let behind_wall = WorldLightPos { x: 10, y: 8, z: 8 };
        assert_eq!(world_stored_light(&chunks, behind_wall, IncrementalLightChannel::Block), 0);

        chunks.get_mut(&(0, 0)).unwrap().set_block(9, 8, 8, 0, 0).unwrap();
        let changed = incremental_light_after_block_edit(&mut chunks, 0, 0, 9, 8, 8, 1, 200)
            .expect("loaded 4x4 test neighborhood satisfies vanilla radius-17 precondition");
        assert!(changed.contains(&WorldLightPos { x: 9, y: 8, z: 8 }));
        assert_eq!(world_stored_light(&chunks, WorldLightPos { x: 9, y: 8, z: 8 }, IncrementalLightChannel::Block), 11);
        assert_eq!(world_stored_light(&chunks, behind_wall, IncrementalLightChannel::Block), 10);
    }

    #[test]
    fn incremental_skylight_reopens_full_height_column_without_chunk_rebuild() {
        let mut chunks = light_test_neighborhood();
        let column = 8 * 16 + 8;
        chunks.get_mut(&(0, 0)).unwrap().height_map.as_mut().unwrap()[column] = 101;
        chunks.get_mut(&(0, 0)).unwrap().set_block(8, 100, 8, 1, 0).unwrap();
        rebuild_block_light_maps(&mut chunks, &HashSet::from([(0, 0)]));
        let below = WorldLightPos { x: 8, y: 99, z: 8 };
        assert_eq!(world_stored_light(&chunks, below, IncrementalLightChannel::Sky), 14);

        chunks.get_mut(&(0, 0)).unwrap().set_block(8, 100, 8, 0, 0).unwrap();
        let changed = incremental_light_after_block_edit(&mut chunks, 0, 0, 8, 100, 8, 1, 101)
            .expect("3x3 loaded test neighborhood satisfies vanilla radius-17 precondition");
        assert!(changed.contains(&below));
        assert_eq!(chunks.get(&(0, 0)).unwrap().height_map.as_ref().unwrap()[column], 0);
        assert_eq!(world_stored_light(&chunks, below, IncrementalLightChannel::Sky), 15);
    }

    #[test]
    fn incremental_heightmap_rebuild_preserves_unedited_columns_when_map_is_absent() {
        let mut chunk = ChunkData {
            x_pos: 0, z_pos: 0, sections: Vec::new(), biomes: Some(vec![1; 256]),
            height_map: None,
        };
        chunk.set_block(2, 100, 2, 1, 0).unwrap();
        chunk.set_block(9, 64, 9, 1, 0).unwrap();
        // A block already exists at the edit target after mutation, so this helper
        // reconstructs all columns from the current block arrays before publishing.
        let height = update_heightmap_column(&mut chunk, 2, 2);
        let map = chunk.height_map.as_ref().unwrap();
        assert_eq!(height, 101);
        assert_eq!(map[2 * 16 + 2], 101);
        assert_eq!(map[9 * 16 + 9], 65);
        assert_eq!(map[0], 0);
    }

    #[test]
    fn forced_relight_updates_heightmap_and_removes_stale_dark_shadow() {
        let mut section = mc189_storage::ChunkSection {
            y: 0,
            block_ids: vec![0; 4096],
            metadata: vec![0; 4096],
            block_light: Some(vec![0; 4096]),
            sky_light: Some(vec![0; 4096]),
        };
        let index = |x: usize, y: usize, z: usize| (y << 8) | (z << 4) | x;
        section.block_ids[index(4, 8, 4)] = 1;
        // Old save says the column is blocked at Y=9 and stores no sky below it.
        let mut chunk = ChunkData {
            x_pos: 0, z_pos: 0, sections: vec![section], biomes: None,
            height_map: Some(vec![9; 256]),
        };
        chunk.set_block(4, 8, 4, 0, 0).unwrap();
        let mut chunks = HashMap::new();
        chunks.insert((0, 0), chunk);
        let force = HashSet::from([(0, 0)]);
        rebuild_light_after_block_edit(&mut chunks, &force);
        let rebuilt = chunks.get(&(0, 0)).unwrap();
        assert_eq!(rebuilt.height_map.as_ref().unwrap()[4 * 16 + 4], 0);
        assert_eq!(rebuilt.light_at(4, 8, 4), Some((15, 0)));
    }

    #[test]
    fn streaming_retention_radius_exceeds_load_radius() {
        assert!(STREAM_RADIUS_CHUNKS >= 3);
        assert!(RETAIN_RADIUS_CHUNKS > STREAM_RADIUS_CHUNKS);
    }

    #[test]
    fn uvlock_reprojects_rotated_model_vertices_to_world_facing_uv_axes() {
        let mut quad = CpuMeshQuad {
            source_block: None,
            positions: [[2.0, 3.0, 4.0], [3.0, 3.0, 4.0], [3.0, 4.0, 4.0], [2.0, 4.0, 4.0]],
            normal: [0.0, 0.0, -1.0],
            vertex_ao: [1.0; 4], vertex_sky_light: [1.0; 4], vertex_block_light: [1.0; 4], vertex_face_shade: [1.0; 4],
            uv_rect: [0.0, 0.0, 16.0, 16.0], uv_rotation: 0, uv_corners: None,
            texture_path: "assets/minecraft/textures/blocks/stone.png".into(),
            tint_index: -1, tint_color: [1.0, 1.0, 1.0], face: crate::model_resolver::ModelFaceDirection::North,
            cull_face: None, shade: true, ambient_occlusion: true,
        };
        lock_uv_to_world(&mut quad, 2.0, 3.0, 4.0);
        assert_eq!(quad.uv_corners, Some([[16.0, 16.0], [0.0, 16.0], [0.0, 0.0], [16.0, 0.0]]));
        assert_eq!(quad.uv_rect, [0.0, 0.0, 16.0, 16.0]);
    }

    #[test]
    fn region_translation_offsets_chunk_geometry_without_changing_height() {
        let mut quad = CpuMeshQuad {
            source_block: None,
            positions: [[0.0, 4.0, 0.0], [1.0, 4.0, 0.0], [1.0, 5.0, 1.0], [0.0, 5.0, 1.0]],
            normal: [0.0, 1.0, 0.0],
            vertex_ao: [1.0; 4], vertex_sky_light: [1.0; 4], vertex_block_light: [1.0; 4], vertex_face_shade: [1.0; 4],
            uv_rect: [0.0, 0.0, 1.0, 1.0],
            uv_rotation: 0,
            uv_corners: None,
            texture_path: "assets/minecraft/textures/blocks/stone.png".into(),
            tint_index: -1,
            tint_color: [1.0, 1.0, 1.0],
            face: crate::model_resolver::ModelFaceDirection::Up,
            cull_face: None,
            shade: true,
            ambient_occlusion: true,
        };
        translate_quads(std::slice::from_mut(&mut quad), 32.0, -16.0);
        assert_eq!(quad.positions[0], [32.0, 4.0, -16.0]);
        assert_eq!(quad.positions[2], [33.0, 5.0, -15.0]);
        assert_eq!(quad.normal, [0.0, 1.0, 0.0]);
    }

    #[test]
    fn classic_fluid_metadata_maps_source_flowing_and_falling_heights() {
        assert!((fluid_height(0) - 8.0 / 9.0).abs() < 1e-6);
        assert!((fluid_height(7) - 1.0 / 9.0).abs() < 1e-6);
        assert!((fluid_height(8) - 8.0 / 9.0).abs() < 1e-6);
        assert!((fluid_height(15) - 8.0 / 9.0).abs() < 1e-6);
        assert_eq!(fluid_family(8), Some(8));
        assert_eq!(fluid_family(9), Some(8));
        assert_eq!(fluid_family(10), Some(10));
        assert_eq!(fluid_family(11), Some(10));
        assert_eq!(fluid_family(1), None);
    }

    #[test]
    fn vanilla_fluid_corner_averages_neighbors_and_fills_from_fluid_above() {
        let mut section = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        let index = |x: usize, y: usize, z: usize| (y << 8) | (z << 4) | x;
        for (x, z) in [(8, 8), (7, 8), (8, 7), (7, 7)] {
            section.block_ids[index(x, 10, z)] = 9;
        }
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new(); chunks.insert((0, 0), chunk);
        let flat_source_height = fluid_corner_height(8, 10, 8, 8, &chunks);
        assert!((flat_source_height - 8.0 / 9.0).abs() < 1e-6);
        // Vanilla's corner solver immediately reaches full height if any of the
        // four sampled cells has the same liquid directly above it.
        let mut section_above = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        section_above.block_ids[index(8, 11, 8)] = 9;
        let chunk_above = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section_above], biomes: None, height_map: None };
        chunks.insert((0, 0), chunk_above);
        assert_eq!(fluid_corner_height(8, 10, 8, 8, &chunks), 1.0);
    }

    #[test]
    fn fluid_occlusion_uses_mcp_full_block_and_material_properties_separately() {
        assert!(!fluid_is_full_block(20));  // glass is solid material, not fullBlock
        assert!(!fluid_is_full_block(79));  // ice is solid material, not fullBlock
        assert!(!fluid_is_full_block(165)); // slime is not opaque/fullBlock
        assert!(!fluid_is_full_block(166)); // barrier overrides isOpaqueCube=false
        assert!(fluid_is_full_block(174));  // packed ice inherits opaque Block
        assert!(fluid_material_is_solid(20));
        assert!(fluid_material_is_solid(79));
        assert!(fluid_material_is_solid(165));
        assert!(!fluid_material_is_solid(83)); // reeds use Material.plants
        assert!(!fluid_material_is_solid(90)); // portal material is not solid
    }

    #[test]
    fn falling_water_column_uses_full_height_when_same_fluid_is_above() {
        let mut section = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        let index = |x: usize, y: usize, z: usize| (y << 8) | (z << 4) | x;
        section.block_ids[index(8, 10, 8)] = 9;
        section.block_ids[index(8, 11, 8)] = 9;
        section.metadata[index(8, 10, 8)] = 8;
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new(); chunks.insert((0, 0), chunk);
        assert_eq!(fluid_corner_height(8, 10, 8, 8, &chunks), 1.0);
        let quads = build_fluid_quads(9, 8, 8, 10, 8, 8, 8, &chunks);
        assert!(quads.iter().any(|q| q.face == crate::model_resolver::ModelFaceDirection::North));
        assert!(!quads.iter().any(|q| q.face == crate::model_resolver::ModelFaceDirection::Up));
    }

    #[test]
    fn water_closes_only_exposed_shore_edges() {
        let mut section = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        let index = (10 << 8) | (8 << 4) | 8;
        section.block_ids[index] = 9;
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new(); chunks.insert((0, 0), chunk);
        let quads = build_fluid_quads(9, 0, 8, 10, 8, 8, 8, &chunks);
        assert_eq!(quads.len(), 7, "duplicated vanilla top, exposed bottom, and four exposed shore edges");
        assert_eq!(quads.iter().filter(|q| q.face == crate::model_resolver::ModelFaceDirection::Up).count(), 2,
            "vanilla duplicates the top quad when shouldRenderSides above is true");
        assert_eq!(quads.iter().filter(|q| q.face == crate::model_resolver::ModelFaceDirection::Down).count(), 1);
        assert_eq!(quads.iter().filter(|q| matches!(q.face, crate::model_resolver::ModelFaceDirection::North | crate::model_resolver::ModelFaceDirection::South | crate::model_resolver::ModelFaceDirection::East | crate::model_resolver::ModelFaceDirection::West)).count(), 4);
        assert!(quads.iter().all(|q| q.texture_path.contains("water_")));
    }

    #[test]
    fn water_side_is_restored_when_adjacent_block_is_removed() {
        let mut section = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        let index = |x: usize, y: usize, z: usize| (y << 8) | (z << 4) | x;
        section.block_ids[index(8, 10, 8)] = 9;
        section.block_ids[index(7, 10, 8)] = 1;
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new(); chunks.insert((0, 0), chunk);

        let before = build_fluid_quads(9, 0, 8, 10, 8, 8, 8, &chunks);
        assert!(!before.iter().any(|quad| quad.face == crate::model_resolver::ModelFaceDirection::West),
            "opaque stone suppresses the west water side");

        chunks.get_mut(&(0, 0)).unwrap().set_block(7, 10, 8, 0, 0).unwrap();
        let after = build_fluid_quads(9, 0, 8, 10, 8, 8, 8, &chunks);
        assert!(after.iter().any(|quad| quad.face == crate::model_resolver::ModelFaceDirection::West),
            "the west water side must be rebuilt after the stone is mined");
    }

    #[test]
    fn adjacent_equal_height_water_blocks_do_not_emit_internal_walls() {
        let mut section = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        let index = |x: usize, y: usize, z: usize| (y << 8) | (z << 4) | x;
        section.block_ids[index(8, 10, 8)] = 9;
        section.block_ids[index(9, 10, 8)] = 9;
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new(); chunks.insert((0, 0), chunk);
        let quads = build_fluid_quads(9, 0, 8, 10, 8, 8, 8, &chunks);
        assert_eq!(quads.iter().filter(|q| matches!(q.face, crate::model_resolver::ModelFaceDirection::North | crate::model_resolver::ModelFaceDirection::South | crate::model_resolver::ModelFaceDirection::East | crate::model_resolver::ModelFaceDirection::West)).count(), 3);
    }

    #[test]
    fn lava_keeps_visible_vertical_sides() {
        let mut section = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        let index = (10 << 8) | (8 << 4) | 8;
        section.block_ids[index] = 11;
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new(); chunks.insert((0, 0), chunk);
        let quads = build_fluid_quads(11, 0, 8, 10, 8, 8, 8, &chunks);
        assert_eq!(quads.len(), 7);
        assert!(quads.iter().any(|q| q.face == crate::model_resolver::ModelFaceDirection::Up));
        assert!(quads.iter().any(|q| q.face == crate::model_resolver::ModelFaceDirection::Down));
        assert!(quads.iter().any(|q| matches!(q.face, crate::model_resolver::ModelFaceDirection::North | crate::model_resolver::ModelFaceDirection::South | crate::model_resolver::ModelFaceDirection::East | crate::model_resolver::ModelFaceDirection::West)));
    }

    #[test]
    fn vanilla_biome_climates_cover_common_and_mutated_biomes() {
        assert_eq!(biome_climate(1), Some((0.8, 0.4))); // plains
        assert_eq!(biome_climate(6), Some((0.8, 0.9))); // swamp
        assert_eq!(biome_climate(140), Some((0.0, 0.5))); // ice plains spikes
        assert_eq!(biome_climate(149), Some((0.95, 0.9))); // jungle M
        assert_eq!(biome_climate(255), None);
    }

    #[test]
    fn grass_colormap_uses_temperature_as_column_and_humidity_as_row() {
        let mut pixels = image::RgbaImage::new(256, 256);
        for (x, y, pixel) in pixels.enumerate_pixels_mut() {
            *pixel = image::Rgba([x as u8, y as u8, 0, 255]);
        }
        let map = GrassColorMap { pixels };
        let color = map.color_for_biome(1).expect("plains biome has climate data");
        let temperature_index = ((1.0 - 0.8_f32) * 255.0).floor() as u8;
        let humidity_index = ((1.0 - 0.4_f32 * 0.8_f32) * 255.0).floor() as u8;
        assert!((color[0] - srgb_to_linear(temperature_index)).abs() < 1e-6);
        assert!((color[1] - srgb_to_linear(humidity_index)).abs() < 1e-6);
    }

    #[test]
    fn biome_tint_accepts_both_grass_and_foliage_colormaps() {
        let chunk = ChunkData {
            x_pos: 0,
            z_pos: 0,
            sections: Vec::new(),
            biomes: Some(vec![1; 256]),
            height_map: None,
        };
        let grass = GrassColorMap { pixels: image::RgbaImage::from_pixel(256, 256, image::Rgba([80, 180, 60, 255])) };
        let foliage = FoliageColorMap { pixels: image::RgbaImage::from_pixel(256, 256, image::Rgba([60, 150, 40, 255])) };
        let mut chunks = HashMap::new();
        chunks.insert((0, 0), chunk);
        assert!(biome_tint_at_world(&chunks, 0, 0, &grass).is_some());
        assert!(biome_tint_at_world(&chunks, 0, 0, &foliage).is_some());
    }

    #[test]
    fn grass_side_overlay_is_biome_tinted_even_if_model_face_lacks_tintindex() {
        let mut quad = CpuMeshQuad {
            source_block: None,
            positions: [[0.0; 3]; 4], uv_rect: [0.0; 4], uv_rotation: 0, uv_corners: None,
            texture_path: "assets/minecraft/textures/blocks/grass_side_overlay.png".into(),
            face: crate::model_resolver::ModelFaceDirection::North, cull_face: None,
            tint_index: -1, tint_color: [1.0; 3], shade: true, ambient_occlusion: true, normal: [0.0, 0.0, -1.0], vertex_ao: [1.0; 4], vertex_sky_light: [1.0; 4], vertex_block_light: [1.0; 4], vertex_face_shade: [1.0; 4],
        };
        assert!(should_apply_grass_biome_tint(2, &quad));
        assert!(!should_apply_grass_biome_tint(3, &quad));
        quad.texture_path = "assets/minecraft/textures/blocks/grass_side.png".into();
        assert!(!should_apply_grass_biome_tint(2, &quad));
    }

    #[test]
    fn grass_and_foliage_tint_average_the_vanilla_three_by_three_biome_neighborhood() {
        let plains = ChunkData { x_pos: 0, z_pos: 0, sections: Vec::new(), biomes: Some(vec![1; 256]), height_map: None };
        let desert = ChunkData { x_pos: 1, z_pos: 0, sections: Vec::new(), biomes: Some(vec![2; 256]), height_map: None };
        let mut chunks = HashMap::new();
        chunks.insert((0, 0), plains);
        chunks.insert((1, 0), desert);
        // A real vanilla colormap varies by climate coordinates. A flat-color
        // fixture cannot distinguish plains from desert and made this border
        // averaging assertion meaningless.
        let mut pixels = image::RgbaImage::new(256, 256);
        for (x, y, pixel) in pixels.enumerate_pixels_mut() {
            *pixel = image::Rgba([x as u8, y as u8, 80, 255]);
        }
        let map = GrassColorMap { pixels };
        let averaged = biome_tint_at_world(&chunks, 15, 8, &map).expect("all biome samples have known climate");
        let single = map.color_for_biome(1).unwrap();
        assert_ne!(averaged, single, "the border sample must include adjacent biome columns");
    }

    #[test]
    fn vanilla_flow_vector_selects_and_orients_the_flowing_sprite() {
        let mut section = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        let index = |x: usize, y: usize, z: usize| (y << 8) | (z << 4) | x;
        section.block_ids[index(8, 10, 8)] = 9;
        section.block_ids[index(9, 10, 8)] = 9;
        section.metadata[index(9, 10, 8)] = 1;
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new(); chunks.insert((0, 0), chunk);
        let angle = fluid_flow_angle(8, 10, 8, 8, 0, &chunks);
        assert!((angle + std::f32::consts::FRAC_PI_2).abs() < 1e-6);
        let quads = build_fluid_quads(9, 0, 8, 10, 8, 8, 8, &chunks);
        assert!(quads.iter().filter(|q| q.face == crate::model_resolver::ModelFaceDirection::Up)
            .all(|q| q.texture_path.contains("water_flow")));
    }

    #[test]
    fn water_color_uses_vanilla_swamp_multiplier_and_neighbor_average() {
        let chunk = ChunkData {
            x_pos: 0, z_pos: 0, sections: Vec::new(),
            biomes: Some(vec![6; 256]), height_map: None,
        };
        let mut chunks = HashMap::new(); chunks.insert((0, 0), chunk);
        let tint = water_biome_tint(&chunks, 8, 8);
        assert!((tint[0] - 224.0 / 255.0).abs() < 1e-6);
        assert!((tint[1] - 1.0).abs() < 1e-6);
        assert!((tint[2] - 174.0 / 255.0).abs() < 1e-6);
    }

    #[test]
    fn srgb_conversion_maps_black_and_white() {
        assert_eq!(srgb_to_linear(0), 0.0);
        assert!((srgb_to_linear(255) - 1.0).abs() < f32::EPSILON);
    }

    #[test]
    fn position_seed_is_stable_and_position_sensitive() {
        assert_eq!(position_seed(1, 2, 3), position_seed(1, 2, 3));
        assert_ne!(position_seed(1, 2, 3), position_seed(2, 2, 3));
    }
    #[test]
    fn fence_connectivity_includes_gates_and_solid_blocks() {
        assert!(connects_fence(107));
        assert!(connects_fence(183));
        assert!(connects_fence(192));
        assert!(connects_fence(1));
        assert!(!connects_fence(0));
    }
    #[test]
    fn vanilla_y_quarter_turn_rotates_north_face_toward_east() {
        // Minecraft blockstate y=90 is clockwise when viewed from above: north (-Z) -> east (+X).
        assert_eq!(rotated_face_offset(crate::model_resolver::ModelFaceDirection::North, 0, 90), (1, 0, 0));
        assert_eq!(rotated_face_offset(crate::model_resolver::ModelFaceDirection::North, 0, 270), (-1, 0, 0));
    }

    #[test]
    fn vanilla_y_quarter_turn_moves_furnace_front_geometry_to_east() {
        let quad = CpuMeshQuad {
            source_block: None,
            positions: [[0.0, 0.0, 0.0]; 4], normal: [0.0, 0.0, -1.0],
            uv_rect: [0.0; 4], uv_rotation: 0, uv_corners: None, texture_path: String::new(),
            tint_index: -1, tint_color: [1.0; 3],
            face: crate::model_resolver::ModelFaceDirection::North, cull_face: None, shade: true, ambient_occlusion: true, vertex_ao: [1.0; 4], vertex_sky_light: [1.0; 4], vertex_block_light: [1.0; 4], vertex_face_shade: [1.0; 4],
        };
        let transformed = transform_instance(&quad, 0.0, 0.0, 0.0, 0, 90);
        assert!((transformed.normal[0] - 1.0).abs() < 1e-6);
        assert!(transformed.normal[2].abs() < 1e-6);
    }
    #[test]
    fn touching_clear_glass_faces_are_culled_but_different_stained_glass_is_not() {
        assert!(should_cull_model_face(20, 0, 20, 0));
        assert!(!should_cull_model_face(20, 0, 0, 0));
        assert!(should_cull_model_face(95, 3, 95, 3));
        assert!(!should_cull_model_face(95, 3, 95, 4));
    }

    #[test]
    fn door_boundary_face_inset_is_smaller_than_a_pixel_and_moves_only_boundary_planes() {
        let mut quad = CpuMeshQuad {
            source_block: None,
            positions: [[2.0, 4.0, 7.0], [2.0, 5.0, 7.0], [2.0, 5.0, 8.0], [2.0, 4.0, 8.0]],
            uv_rect: [0.0, 0.0, 16.0, 16.0], uv_rotation: 0, uv_corners: None,
            texture_path: "assets/minecraft/textures/blocks/door_wood_lower.png".into(),
            face: crate::model_resolver::ModelFaceDirection::West, cull_face: None,
            tint_index: -1, tint_color: [1.0; 3], shade: true, ambient_occlusion: true,
            normal: [-1.0, 0.0, 0.0], vertex_ao: [1.0; 4], vertex_sky_light: [1.0; 4],
            vertex_block_light: [1.0; 4], vertex_face_shade: [1.0; 4],
        };
        inset_door_boundary_faces(&mut quad, 2.0, 7.0);
        assert!((quad.positions[0][0] - 2.001).abs() < 1.0e-6);
        assert!((quad.positions[1][0] - 2.001).abs() < 1.0e-6);
    }

    #[test]
    fn newly_mapped_opaque_blocks_participate_in_face_occlusion_but_glass_does_not() {
        for id in [19, 22, 25, 35, 41, 42, 45, 46, 47, 57, 80, 87, 88, 89, 98, 103, 110, 112, 121, 123, 124, 129, 133, 152, 153, 159, 168, 169, 170, 172, 173, 174] {
            assert!(occludes_model_face(id), "expected opaque block ID {id} to occlude");
        }
        // ID 138 is the beacon, not the sea lantern. BlockBeacon explicitly
        // overrides both isOpaqueCube() and isFullCube() to return false.
        assert!(!occludes_model_face(138), "beacon must not occlude model faces");
        assert!(!block_is_full_cube(138), "beacon is not a full cube in MCP 1.8.9");
        assert!(occludes_model_face(169), "sea lantern is an opaque cube");
        assert!(!occludes_model_face(20), "glass must not be opaque");
        assert!(!occludes_model_face(79), "ice is not an opaque cube");
        assert!(!occludes_model_face(95), "stained glass must not be treated as opaque");
        assert!(!occludes_model_face(165), "slime is not an opaque cube");
        assert!(!occludes_model_face(166), "barrier's MCP class is not an opaque cube");
        assert!(!occludes_model_face(171), "carpet is not a full opaque cube");
        assert!(occludes_model_face(174), "packed ice inherits opaque Block behavior in 1.8.9");
    }

    #[test]
    fn mycelium_snowy_state_uses_snow_layer_and_ice_above() {
        let mut section = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        section.block_ids[1 << 8] = 78;
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new();
        chunks.insert((0, 0), chunk);
        assert_eq!(contextual_selector("mycelium", &chunks, 0, 0, 0).as_deref(), Some("snowy=true"));
        assert_eq!(contextual_selector("mycelium", &chunks, 0, 1, 0).as_deref(), Some("snowy=false"));
    }

    #[test]
    fn vertex_lighting_samples_world_coordinates_for_negative_chunk_meshes() {
        let mut section = mc189_storage::ChunkSection {
            y: 4, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: Some(vec![0; 4096]), sky_light: Some(vec![0; 4096]),
        };
        // The transformed top-face vertex is at world (-256, 65, 240);
        // its outward sample is world (-256, 66, 240), local section Y=2.
        let index = 2 << 8;
        section.sky_light.as_mut().unwrap()[index] = 6;
        let chunk = ChunkData { x_pos: -16, z_pos: 15, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new();
        chunks.insert((-16, 15), chunk);
        let quad = CpuMeshQuad {
            source_block: None,
            // Block y=65 has its top face at y=66 after transform_instance.
            positions: [[0.0, 66.0, 0.0], [1.0, 66.0, 0.0], [1.0, 66.0, 1.0], [0.0, 66.0, 1.0]],
            uv_rect: [0.0; 4], uv_rotation: 0, uv_corners: None,
            texture_path: "assets/minecraft/textures/blocks/stone.png".into(),
            face: crate::model_resolver::ModelFaceDirection::Up, cull_face: None,
            tint_index: -1, tint_color: [1.0; 3], shade: true, ambient_occlusion: true, normal: [0.0, 1.0, 0.0],
            vertex_ao: [1.0; 4], vertex_sky_light: [1.0; 4], vertex_block_light: [1.0; 4], vertex_face_shade: [1.0; 4],
        };
        let light = calculate_quad_vertex_lighting(&quad, -256, 65, 240, -256, 240, 1, &chunks);
        // getAoBrightness substitutes the center value for zero samples, so
        // this fully dark neighborhood inherits the face-neighbor sky sample.
        assert!((light.sky[0] - 0.4).abs() < 1e-6, "unexpected sky channel: {:?}", light.sky);
        assert!(light.block.iter().all(|value| *value == 0.0));
        assert!(light.ao.iter().all(|value| (*value - 1.0).abs() < 1e-6));
        assert_eq!(light.face_shade, [1.0; 4]);
    }

    #[test]
    fn missing_neighbor_chunk_is_not_treated_as_open_sky() {
        let chunks = HashMap::new();
        assert_eq!(
            light_at_world(&chunks, -257, 66, 240),
            vanilla_lightmap_brightness(0.0),
            "an unloaded neighbor must not inject full-bright light into AO samples",
        );
    }

    #[test]
    fn saved_sky_and_block_light_are_sampled_from_anvil_nibbles() {
        let mut section = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: Some(vec![0; 4096]), sky_light: Some(vec![0; 4096]),
        };
        let index = (3 << 8) | (2 << 4) | 1;
        section.sky_light.as_mut().unwrap()[index] = 6;
        section.block_light.as_mut().unwrap()[index] = 12;
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new();
        chunks.insert((0, 0), chunk);
        let channels = raw_light_channels_at_world(&chunks, 1, 3, 2);
        assert_eq!(channels.sky, 6);
        assert_eq!(channels.block, 12);
        assert!((light_at_world(&chunks, 1, 3, 2) - vanilla_lightmap_brightness(12.0)).abs() < 1e-6);
    }

    #[test]
    fn missing_block_light_is_rebuilt_from_torches_with_vanilla_step_attenuation() {
        let mut ids = vec![0; 4096];
        ids[(4 << 8) | (4 << 4) | 4] = 50;
        let section = mc189_storage::ChunkSection {
            y: 0, block_ids: ids, metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new();
        chunks.insert((0, 0), chunk);
        rebuild_missing_block_light(&mut chunks);
        let chunk = &chunks[&(0, 0)];
        let light = |x: usize, y: usize, z: usize| {
            let section = chunk.sections.iter().find(|section| section.y == 0).unwrap();
            section.block_light.as_ref().unwrap()[(y << 8) | (z << 4) | x]
        };
        assert_eq!(light(4, 4, 4), 14, "torch emission is retained");
        assert_eq!(light(5, 4, 4), 13, "air attenuates by one level");
        assert_eq!(light(6, 4, 4), 12, "light continues with one-level attenuation");
    }

    #[test]
    fn missing_sky_light_reaches_a_cave_from_an_adjacent_open_column() {
        let mut ids = vec![0; 4096];
        // A roof block at x=4,y=4; the cave cell immediately below it is dark
        // by direct heightmap sampling but can receive lateral sky light.
        ids[(4 << 8) | (4 << 4) | 4] = 1;
        let mut height_map = vec![0; 256];
        height_map[4 * 16 + 4] = 5;
        let section = mc189_storage::ChunkSection {
            y: 0, block_ids: ids, metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: Some(height_map) };
        let mut chunks = HashMap::new();
        chunks.insert((0, 0), chunk);
        rebuild_missing_block_light(&mut chunks);
        let section = chunks[&(0, 0)].sections.iter().find(|section| section.y == 0).unwrap();
        let sky = section.sky_light.as_ref().unwrap();
        assert_eq!(sky[(3 << 8) | (4 << 4) | 4], 14, "sky light propagates one level into the air below the roof");
    }

    #[test]
    fn rebuilt_block_light_crosses_loaded_chunk_boundaries() {
        let mut ids = vec![0; 4096];
        ids[(4 << 8) | (4 << 4) | 15] = 50;
        let make_chunk = |x_pos| ChunkData {
            x_pos, z_pos: 0,
            sections: vec![mc189_storage::ChunkSection {
                y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
                block_light: None, sky_light: None,
            }],
            biomes: None, height_map: None,
        };
        let mut source = make_chunk(0);
        source.sections[0].block_ids = ids;
        let mut chunks = HashMap::new();
        chunks.insert((0, 0), source);
        chunks.insert((1, 0), make_chunk(1));
        rebuild_missing_block_light(&mut chunks);
        let east = &chunks[&(1, 0)].sections.iter().find(|section| section.y == 0).unwrap().block_light.as_ref().unwrap();
        assert_eq!(east[(4 << 8) | (4 << 4)], 13, "the first block across x=15/16 receives torch light");
    }

    #[test]
    fn opaque_blocks_stop_rebuilt_light_and_saved_arrays_are_not_replaced() {
        assert_eq!(vanilla_light_opacity(1), 15);   // BlockStone default opaque
        assert_eq!(vanilla_light_opacity(23), 15);  // BlockDispenser default opaque
        assert_eq!(vanilla_light_opacity(18), 1);   // BlockLeaves explicit opacity
        assert_eq!(vanilla_light_opacity(30), 1);   // BlockWeb explicit opacity
        assert_eq!(vanilla_light_opacity(8), 3);    // BlockLiquid setLightOpacity(3)
        assert_eq!(vanilla_light_opacity(20), 0);   // BlockBreakable glass
        assert_eq!(vanilla_light_opacity(44), 15);  // BlockSlab explicitly sets 255
        assert_eq!(vanilla_light_opacity(53), 15);  // BlockStairs explicitly sets 255
        assert_eq!(vanilla_light_opacity(60), 15);  // BlockFarmland explicitly sets 255
        assert_eq!(vanilla_light_opacity(79), 3);   // BlockIce explicit opacity
        assert_eq!(vanilla_light_opacity(145), 0);  // BlockAnvil explicit opacity
        assert_eq!(vanilla_light_opacity(174), 15); // BlockPackedIce is an opaque Block
        let mut ids = vec![0; 4096];
        ids[(4 << 8) | (4 << 4) | 4] = 50;
        // A complete stone plane prevents light from routing around the test wall.
        for y in 0..16 {
            for z in 0..16 {
                ids[(y << 8) | (z << 4) | 5] = 1;
            }
        }
        let section = mc189_storage::ChunkSection {
            y: 0, block_ids: ids, metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        let mut saved = vec![0; 4096];
        saved[(4 << 8) | (4 << 4) | 10] = 7;
        let saved_section = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: Some(saved), sky_light: None,
        };
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let saved_chunk = ChunkData { x_pos: 2, z_pos: 0, sections: vec![saved_section], biomes: None, height_map: None };
        let mut chunks = HashMap::new();
        chunks.insert((0, 0), chunk);
        chunks.insert((2, 0), saved_chunk);
        rebuild_missing_block_light(&mut chunks);
        let values = chunks[&(0, 0)].sections.iter().find(|section| section.y == 0).unwrap().block_light.as_ref().unwrap();
        assert_eq!(values[(4 << 8) | (4 << 4) | 5], 0, "opaque stone receives no propagated light");
        assert_eq!(values[(4 << 8) | (4 << 4) | 6], 0, "stone blocks light behind it");
        let saved_values = chunks[&(2, 0)].sections.iter().find(|section| section.y == 0).unwrap().block_light.as_ref().unwrap();
        assert_eq!(saved_values[(4 << 8) | (4 << 4) | 10], 7, "saved BlockLight remains byte-for-byte unchanged");
    }

    #[test]
    fn ao_neighbor_tables_match_vanilla_189_face_order() {
        use crate::model_resolver::ModelFaceDirection as Face;
        assert_eq!(ao_face_info(Face::Down).side_offsets, [[-1,0,0],[1,0,0],[0,0,-1],[0,0,1]]);
        assert_eq!(ao_face_info(Face::Up).side_offsets, [[1,0,0],[-1,0,0],[0,0,-1],[0,0,1]]);
        assert_eq!(ao_face_info(Face::North).side_offsets, [[0,1,0],[0,-1,0],[1,0,0],[-1,0,0]]);
        assert_eq!(ao_face_info(Face::South).side_offsets, [[-1,0,0],[1,0,0],[0,-1,0],[0,1,0]]);
        assert_eq!(ao_face_info(Face::West).side_offsets, [[0,1,0],[0,-1,0],[0,0,-1],[0,0,1]]);
        assert_eq!(ao_face_info(Face::East).side_offsets, [[0,-1,0],[0,1,0],[0,0,-1],[0,0,1]]);
        assert_eq!(ao_face_info(Face::East).vertex_translation, [1,2,3,0]);
    }

    #[test]
    fn packed_vanilla_light_keeps_sky_and_block_bytes_separate() {
        let packed = pack_vanilla_light(VanillaLightChannels { sky: 6, block: 12 });
        assert_eq!(unpack_vanilla_light(packed), (0.4, 0.8));
        assert_eq!(get_ao_brightness(0, packed, 0, packed), packed);
    }

    #[test]
    fn vanilla_lightmap_keeps_zero_light_dim_instead_of_absolute_black() {
        let dark = vanilla_lightmap_brightness(0.0);
        let low = vanilla_lightmap_brightness(1.0);
        let mid = vanilla_lightmap_brightness(8.0);
        let full = vanilla_lightmap_brightness(15.0);
        assert!((dark - 0.03).abs() < 1e-6);
        assert!(dark > 0.0 && low > dark && mid > low && full > mid);
        assert!((full - 0.99).abs() < 1e-6);
    }

    #[test]
    fn vanilla_face_shade_uses_18x_directional_factors_without_artificial_floor() {
        assert_eq!(vanilla_face_shade([0.0, 1.0, 0.0]), 1.0);
        assert_eq!(vanilla_face_shade([0.0, -1.0, 0.0]), 0.5);
        assert_eq!(vanilla_face_shade([1.0, 0.0, 0.0]), 0.6);
        assert_eq!(vanilla_face_shade([0.0, 0.0, -1.0]), 0.8);
        assert_eq!(block_ao_value(1), 0.2);
        assert_eq!(block_ao_value(0), 1.0);
    }

    #[test]
    fn grass_snowy_state_uses_snow_layer_and_ice_above() {
        let mut section = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        // x=0,y=1,z=0 uses the standard (y<<8)|(z<<4)|x index.
        section.block_ids[1 << 8] = 79;
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new();
        chunks.insert((0, 0), chunk);
        assert_eq!(contextual_selector("grass", &chunks, 0, 0, 0).as_deref(), Some("snowy=true"));
    }

    #[test]
    fn heightmap_first_air_boundary_is_lit_at_equality() {
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: Vec::new(), biomes: None, height_map: Some(vec![64; 256]) };
        let mut chunks = HashMap::new(); chunks.insert((0, 0), chunk);
        assert_eq!(light_at_world(&chunks, 3, 63, 4), vanilla_lightmap_brightness(0.0));
        assert_eq!(light_at_world(&chunks, 3, 64, 4), vanilla_lightmap_brightness(15.0));
        assert_eq!(light_at_world(&chunks, 3, 65, 4), vanilla_lightmap_brightness(15.0));
    }

    #[test]
    fn translate_quads_keeps_source_block_owner_in_session_coordinates() {
        let mut quad = CpuMeshQuad {
            source_block: Some([3, 64, 12]),
            positions: [[0.0, 64.0, 0.0]; 4],
            uv_rect: [0.0, 0.0, 16.0, 16.0], uv_rotation: 0, uv_corners: None,
            texture_path: String::new(), face: crate::model_resolver::ModelFaceDirection::Up,
            cull_face: None, tint_index: -1, tint_color: [1.0; 3], shade: true,
            ambient_occlusion: true, normal: [0.0, 1.0, 0.0],
            vertex_ao: [1.0; 4], vertex_sky_light: [1.0; 4],
            vertex_block_light: [1.0; 4], vertex_face_shade: [1.0; 4],
        };
        translate_quads(std::slice::from_mut(&mut quad), 32.0, -16.0);
        assert_eq!(quad.source_block, Some([35, 64, -4]));
        assert_eq!(quad.positions[0], [32.0, 64.0, -16.0]);
    }

    #[test]
    fn missing_sky_array_uses_heightmap_and_zero_light_keeps_vanilla_lightmap_floor() {
        let section = mc189_storage::ChunkSection { y: 4, block_ids: vec![0; 4096], metadata: vec![0; 4096], block_light: None, sky_light: None };
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: Some(vec![64; 256]) };
        let mut chunks = HashMap::new(); chunks.insert((0, 0), chunk);
        assert_eq!(light_at_world(&chunks, 2, 64, 2), vanilla_lightmap_brightness(15.0));
        assert_eq!(light_at_world(&chunks, 2, 63, 2), vanilla_lightmap_brightness(0.0));
    }

    #[test]
    fn saturated_direct_sky_cells_are_not_requeued_without_a_darker_neighbor() {
        let section = mc189_storage::ChunkSection {
            y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096],
            block_light: None, sky_light: None,
        };
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new(); chunks.insert((0, 0), chunk);
        let mut maps = HashMap::new(); maps.insert((0, 0), vec![15; 65536]);
        assert!(!light_source_can_expand(&chunks, &maps, 8, 8, 8, 15),
            "an already saturated open-sky cell has no work to propagate");
        maps.get_mut(&(0, 0)).unwrap()[(8 * 256) + (8 * 16) + 9] = 0;
        assert!(light_source_can_expand(&chunks, &maps, 8, 8, 8, 15),
            "the same source must be queued when it can light a darker adjacent cell");
    }

    #[test]
    fn saved_sky_channel_survives_missing_block_light_channel() {
        let mut sky = vec![0; 4096]; sky[0] = 9;
        let section = mc189_storage::ChunkSection { y: 0, block_ids: vec![0; 4096], metadata: vec![0; 4096], block_light: None, sky_light: Some(sky) };
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new(); chunks.insert((0, 0), chunk);
        assert!((light_at_world(&chunks, 0, 0, 0) - vanilla_lightmap_brightness(9.0)).abs() < 1e-6);
    }

    #[test]
    fn ao_properties_follow_mcp_is_block_normal_cube_not_opaque_cube() {
        // BlockGlass is full material movement but overrides isFullCube=false.
        assert!(!block_is_full_cube(20));
        assert!(block_is_full_cube(0), "BlockAir inherits Block.isFullCube=true but Material.air.blocksMovement=false");
        assert!(!block_is_full_cube(95), "stained glass uses the non-full BlockGlass geometry");
        assert!(block_is_full_cube(43), "double stone slab is a full cube");
        assert!(block_is_full_cube(125), "double wood slab is a full cube");
        assert!(block_is_full_cube(181), "double red sandstone slab is a full cube");
        assert!(!block_is_full_cube(44), "half stone slab is not a full cube");
        assert!(!block_is_full_cube(126), "half wood slab is not a full cube");
        assert!(!block_is_full_cube(182), "half red sandstone slab is not a full cube");
        assert!(!block_is_opaque_cube(20));
        assert!(block_material_blocks_movement(20));
        assert!(!block_is_translucent(20));
        assert_eq!(block_ao_value(20), 1.0);

        // Leaves and ice inherit BlockBreakable but do not override isFullCube;
        // their Material blocks movement, so vanilla AO treats them as normal cubes.
        assert!(block_is_full_cube(18));
        assert!(block_material_blocks_movement(18));
        assert_eq!(block_ao_value(18), 0.2);
        assert!(block_is_full_cube(161));
        assert!(block_is_full_cube(165), "slime block inherits the full cube method");
        assert!(block_is_full_cube(166), "barrier inherits the full cube method");
        assert_eq!(block_ao_value(166), 1.0, "BlockBarrier overrides getAmbientOcclusionLightValue()");
        assert!(block_is_full_cube(103), "melon block is a normal full cube");
        assert!(block_is_full_cube(79));
        assert!(block_material_blocks_movement(79));
        assert_eq!(block_ao_value(79), 0.2);

        // MaterialLogic/Material.web blocks are not normal cubes.
        assert!(!block_is_full_cube(50));
        assert!(!block_material_blocks_movement(50));
        assert!(block_is_translucent(50));
        assert_eq!(block_ao_value(50), 1.0);
        assert!(!block_material_blocks_movement(6));
        assert!(!block_material_blocks_movement(30));
        assert!(!block_is_full_cube(30));

        assert!(block_is_opaque_cube(1));
        assert!(block_is_full_cube(1));
        assert!(block_material_blocks_movement(1));
        assert_eq!(block_ao_value(1), 0.2);
    }

    #[test]
    fn vertex_translation_maps_geometric_corners_to_baked_vertex_order() {
        let corners = [10_u8, 20, 30, 40];
        let translate = |mapping: [usize; 4]| {
            let mut output = [0_u8; 4];
            for corner in 0..4 { output[mapping[corner]] = corners[corner]; }
            output
        };
        assert_eq!(translate(ao_face_info(crate::model_resolver::ModelFaceDirection::Up).vertex_translation), [30, 40, 10, 20]);
        assert_eq!(translate(ao_face_info(crate::model_resolver::ModelFaceDirection::North).vertex_translation), [20, 30, 40, 10]);
        assert_eq!(translate(ao_face_info(crate::model_resolver::ModelFaceDirection::East).vertex_translation), [40, 10, 20, 30]);
    }

    #[test]
    fn ambientocclusion_false_uses_one_flat_face_light_sample() {
        let mut sky = vec![0_u8; 4096];
        let sample_index = (5 << 8) | (4 << 4) | 5; // north neighbor of (5,5,5)
        sky[sample_index] = 9;
        let section = mc189_storage::ChunkSection {
            y: 0,
            block_ids: vec![0; 4096],
            metadata: vec![0; 4096],
            block_light: None,
            sky_light: Some(sky),
        };
        let chunk = ChunkData { x_pos: 0, z_pos: 0, sections: vec![section], biomes: None, height_map: None };
        let mut chunks = HashMap::new();
        chunks.insert((0, 0), chunk);
        let quad = CpuMeshQuad {
            source_block: None,
            positions: [[5.0, 5.0, 5.0], [6.0, 5.0, 5.0], [6.0, 6.0, 5.0], [5.0, 6.0, 5.0]],
            uv_rect: [0.0, 0.0, 16.0, 16.0], uv_rotation: 0, uv_corners: None,
            texture_path: String::new(), face: crate::model_resolver::ModelFaceDirection::North,
            cull_face: None, tint_index: -1, tint_color: [1.0; 3], shade: true,
            ambient_occlusion: false, normal: [0.0, 0.0, -1.0],
            vertex_ao: [1.0; 4], vertex_sky_light: [1.0; 4],
            vertex_block_light: [1.0; 4], vertex_face_shade: [1.0; 4],
        };
        let lighting = calculate_quad_vertex_lighting(&quad, 5, 5, 5, 0, 0, 1, &chunks);
        assert_eq!(lighting.ao, [1.0; 4]);
        assert_eq!(lighting.sky, [0.6; 4]);
        assert_eq!(lighting.block, [0.0; 4]);
        assert_eq!(lighting.face_shade, [0.8; 4]);
    }

    #[test]
    fn vanilla_sun_brightness_tracks_day_night_and_weather() {
        let noon = vanilla_sun_brightness(6_000, 0.0, 0.0);
        let midnight = vanilla_sun_brightness(18_000, 0.0, 0.0);
        let rainy_noon = vanilla_sun_brightness(6_000, 1.0, 0.0);
        let stormy_noon = vanilla_sun_brightness(6_000, 1.0, 1.0);
        assert!(noon > 0.99, "noon={noon}");
        assert!((midnight - 0.2).abs() < 1.0e-5, "midnight={midnight}");
        assert!(rainy_noon < noon);
        assert!(stormy_noon < rainy_noon);
    }

    #[test]
    fn vanilla_celestial_angle_eases_day_night_transitions() {
        let noon = vanilla_celestial_angle(6_000.0);
        let midnight = vanilla_celestial_angle(18_000.0);
        assert!(noon < 0.001 || noon > 0.999, "noon angle={noon}");
        assert!((midnight - 0.5).abs() < 1.0e-5, "midnight angle={midnight}");
        assert!((vanilla_celestial_angle(30_000.0) - noon).abs() < 1.0e-5);
    }

    #[test]
    fn vanilla_lightmap_combines_sky_and_torch_as_separate_rgb_channels() {
        let daylight = vanilla_lightmap_rgb(1.0, 0.0, 1.0, 0.0, false);
        assert!(daylight.iter().all(|value| (*value - 0.9804).abs() < 1.0e-3));
        let torch = vanilla_lightmap_rgb(0.0, 0.5, 1.0, 0.0, false);
        assert!(torch[0] > torch[1] && torch[1] > torch[2], "torch light should retain vanilla warm hue: {torch:?}");
        let dim_sky = vanilla_lightmap_rgb(1.0, 0.0, 0.0, 0.0, false);
        let lightning = vanilla_lightmap_rgb(1.0, 0.0, 0.0, 0.0, true);
        assert!(dim_sky[0] < lightning[0]);
    }

    #[test]
    fn vanilla_ao_brightness_substitutes_zero_neighbors_with_center() {
        let center = pack_vanilla_light(VanillaLightChannels { sky: 15, block: 7 });
        assert_eq!(get_ao_brightness(0, 0, 0, center), center);
        let a = pack_vanilla_light(VanillaLightChannels { sky: 15, block: 0 });
        let b = pack_vanilla_light(VanillaLightChannels { sky: 0, block: 15 });
        let result = get_ao_brightness(a, b, a, b);
        assert_eq!(result, (120_u32 << 16) | 120_u32);
    }

    #[test]
    fn vanilla_vertex_brightness_averages_sky_and_block_bytes_independently() {
        let values = [
            pack_vanilla_light(VanillaLightChannels { sky: 15, block: 0 }),
            pack_vanilla_light(VanillaLightChannels { sky: 0, block: 15 }),
            pack_vanilla_light(VanillaLightChannels { sky: 15, block: 15 }),
            pack_vanilla_light(VanillaLightChannels { sky: 0, block: 0 }),
        ];
        let averaged = get_vertex_brightness(values, [0.25; 4]);
        assert_eq!(averaged, (120_u32 << 16) | 120_u32);
    }

}
