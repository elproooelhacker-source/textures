//! Safe extraction and inventory of vanilla Minecraft 1.8.9 PNG texture assets.
//! This is an asset-ingestion stage; it deliberately does not claim to render them yet.
use mc189_core::{Mc189Error, Result};
use std::fs::{self, File};
use std::io::Read;
use std::path::{Component, Path, PathBuf};
use zip::ZipArchive;

const TEXTURE_PREFIX: &str = "assets/minecraft/textures/";
const MAX_TEXTURE_BYTES: u64 = 32 * 1024 * 1024;
const PNG_SIGNATURE: &[u8; 8] = b"\x89PNG\r\n\x1a\n";

#[derive(Debug, Clone, PartialEq, Eq)]
struct PngInfo { width: u32, height: u32 }

fn png_info(bytes: &[u8]) -> Result<PngInfo> {
    if bytes.len() < 24 || &bytes[..8] != PNG_SIGNATURE || &bytes[12..16] != b"IHDR" {
        return Err(Mc189Error::InvalidData("invalid or truncated PNG header".into()));
    }
    let width = u32::from_be_bytes(bytes[16..20].try_into().expect("four bytes"));
    let height = u32::from_be_bytes(bytes[20..24].try_into().expect("four bytes"));
    if width == 0 || height == 0 || width > 16_384 || height > 16_384 {
        return Err(Mc189Error::InvalidData(format!("unsupported PNG dimensions {width}x{height}")));
    }
    Ok(PngInfo { width, height })
}

fn safe_relative_path(entry: &str) -> Option<PathBuf> {
    let relative = entry.strip_prefix(TEXTURE_PREFIX)?;
    let path = Path::new(relative);
    if path.components().any(|part| !matches!(part, Component::Normal(_))) { return None; }
    let name = path.file_name()?.to_str()?;
    if !(name.ends_with(".png") || name.ends_with(".png.mcmeta")) { return None; }
    Some(path.to_path_buf())
}

/// Extract only vanilla PNGs below assets/minecraft/textures; the JAR is never modified.
pub fn extract_client_textures(jar_path: &Path, output_dir: &Path) -> Result<()> {
    if !jar_path.is_file() {
        return Err(Mc189Error::Usage(format!("client JAR is not a file: {}", jar_path.display())));
    }
    let file = File::open(jar_path)?;
    let mut archive = ZipArchive::new(file).map_err(|e| Mc189Error::InvalidData(format!("could not open client JAR: {e}")))?;
    fs::create_dir_all(output_dir)?;
    let mut extracted = 0usize;
    let mut block_textures = 0usize;
    let mut animation_metadata = 0usize;
    let mut total_bytes = 0u64;
    let mut failures = 0usize;
    let mut dimensions = std::collections::BTreeMap::<(u32,u32),usize>::new();

    for index in 0..archive.len() {
        let mut entry = archive.by_index(index).map_err(|e| Mc189Error::InvalidData(format!("could not read JAR entry {index}: {e}")))?;
        let name = entry.name().to_owned();
        let Some(relative) = safe_relative_path(&name) else { continue; };
        if entry.size() > MAX_TEXTURE_BYTES {
            failures += 1;
            eprintln!("  skipped oversized texture: {name} ({} bytes)", entry.size());
            continue;
        }
        let mut bytes = Vec::with_capacity(entry.size() as usize);
        entry.read_to_end(&mut bytes)?;
        let is_metadata = name.ends_with(".png.mcmeta");
        let info = if is_metadata {
            match serde_json::from_slice::<serde_json::Value>(&bytes) {
                Ok(value) if value.is_object() => None,
                Ok(_) => { failures += 1; eprintln!("  invalid animation metadata {name}: root must be an object"); continue; }
                Err(error) => { failures += 1; eprintln!("  invalid animation metadata {name}: {error}"); continue; }
            }
        } else {
            match png_info(&bytes) {
                Ok(info) => Some(info),
                Err(error) => { failures += 1; eprintln!("  invalid texture {name}: {error}"); continue; }
            }
        };
        let destination = output_dir.join(&relative);
        if let Some(parent) = destination.parent() { fs::create_dir_all(parent)?; }
        fs::write(&destination, &bytes)?;
        extracted += 1;
        total_bytes += bytes.len() as u64;
        if name.starts_with("assets/minecraft/textures/blocks/") && !is_metadata { block_textures += 1; }
        if is_metadata { animation_metadata += 1; }
        if let Some(info) = info { *dimensions.entry((info.width,info.height)).or_insert(0) += 1; }
    }
    println!("Minecraft 1.8.9 texture extraction");
    println!("  JAR: {}", jar_path.display());
    println!("  Output: {}", output_dir.display());
    println!("  PNG textures extracted: {extracted}");
    println!("  Block textures: {block_textures}");
    println!("  Animation metadata files: {animation_metadata}");
    println!("  Total bytes: {total_bytes}");
    println!("  Invalid/oversized skipped: {failures}");
    println!("  PNG dimensions:");
    for ((width,height),count) in dimensions { println!("    {width}x{height}: {count}"); }
    println!("  Note: PNG headers and animation metadata JSON are validated; pixel atlas generation and GPU sampling are not implemented in this stage.");
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn reads_png_dimensions_from_ihdr() {
        let mut png = vec![0u8;24];
        png[..8].copy_from_slice(PNG_SIGNATURE);
        png[12..16].copy_from_slice(b"IHDR");
        png[16..20].copy_from_slice(&16u32.to_be_bytes());
        png[20..24].copy_from_slice(&32u32.to_be_bytes());
        assert_eq!(png_info(&png).unwrap(), PngInfo { width:16, height:32 });
    }
    #[test]
    fn rejects_invalid_png_and_path_traversal() {
        assert!(png_info(b"not png").is_err());
        assert!(safe_relative_path("assets/minecraft/textures/../evil.png").is_none());
        assert!(safe_relative_path("assets/minecraft/textures/blocks/stone.png").is_some());
        assert!(safe_relative_path("assets/minecraft/textures/blocks/water_still.png.mcmeta").is_some());
    }
}
