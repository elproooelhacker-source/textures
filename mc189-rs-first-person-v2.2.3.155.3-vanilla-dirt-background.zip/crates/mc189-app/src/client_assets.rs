//! Read-only checks for Minecraft 1.8.9-style JSON blockstates and model resources.
//!
//! This is a validation step, not a full reproduction of Minecraft's model loader.
//! In particular, texture-variable inheritance and block-ID/metadata state selection
//! are intentionally deferred to later, separately tested modules.

use mc189_core::{Mc189Error, Result};
use serde_json::Value;
use std::collections::{BTreeSet, HashSet};
use std::fs::File;
use std::io::Read;
use std::path::Path;
use zip::ZipArchive;

const MAX_JSON_BYTES: u64 = 4 * 1024 * 1024;
const MAX_DIAGNOSTICS: usize = 20;
const ASSET_PREFIX: &str = "assets/minecraft/";
const MODEL_PREFIX: &str = "assets/minecraft/models/";
const BLOCKSTATE_PREFIX: &str = "assets/minecraft/blockstates/";

/// Parse all blockstate/model JSON resources in a local client JAR and validate links.
/// The JAR is opened read-only and its entries are never extracted.
pub fn audit_client_models(jar_path: &Path) -> Result<()> {
    if !jar_path.is_file() {
        return Err(Mc189Error::Usage(format!(
            "client JAR is not a file: {}",
            jar_path.display()
        )));
    }

    let file = File::open(jar_path)?;
    let mut archive = ZipArchive::new(file).map_err(|error| {
        Mc189Error::InvalidData(format!(
            "could not open {} as a ZIP/JAR archive: {error}",
            jar_path.display()
        ))
    })?;

    let mut names = Vec::with_capacity(archive.len());
    for index in 0..archive.len() {
        let entry = archive.by_index(index).map_err(|error| {
            Mc189Error::InvalidData(format!("could not read JAR entry {index}: {error}"))
        })?;
        if !entry.is_dir() {
            names.push(entry.name().to_owned());
        }
    }
    let name_set: HashSet<&str> = names.iter().map(String::as_str).collect();

    let mut blockstate_paths: Vec<&str> = names
        .iter()
        .map(String::as_str)
        .filter(|name| {
            name.starts_with(BLOCKSTATE_PREFIX) && name.ends_with(".json")
        })
        .collect();
    blockstate_paths.sort_unstable();

    let mut model_paths: Vec<&str> = names
        .iter()
        .map(String::as_str)
        .filter(|name| name.starts_with(MODEL_PREFIX) && name.ends_with(".json"))
        .collect();
    model_paths.sort_unstable();

    let mut parsed_blockstates = 0_usize;
    let mut invalid_blockstates = 0_usize;
    let mut model_reference_occurrences = 0_usize;
    let mut referenced_models = BTreeSet::new();
    let mut external_model_references = 0_usize;
    let mut invalid_state_model_ids = 0_usize;
    let mut invalid_json_diagnostics = Vec::new();
    let mut blockstate_model_diagnostics = Vec::new();

    for path in &blockstate_paths {
        let value = match read_json_entry(&mut archive, path) {
            Ok(value) => value,
            Err(error) => {
                invalid_blockstates += 1;
                push_diagnostic(
                    &mut invalid_json_diagnostics,
                    format!("invalid blockstate {path}: {error}"),
                );
                continue;
            }
        };
        if !value.is_object() {
            invalid_blockstates += 1;
            push_diagnostic(
                &mut invalid_json_diagnostics,
                format!("invalid blockstate {path}: root must be a JSON object"),
            );
            continue;
        }
        let Some(state_object) = value.as_object() else { unreachable!("object checked above") };
        let has_variants = state_object.get("variants").is_some_and(Value::is_object);
        let has_multipart = state_object.get("multipart").is_some_and(Value::is_array);
        if !has_variants && !has_multipart {
            invalid_blockstates += 1;
            push_diagnostic(
                &mut invalid_json_diagnostics,
                format!("invalid blockstate {path}: expected a variants object or multipart array"),
            );
            continue;
        }
        parsed_blockstates += 1;

        let mut model_ids = Vec::new();
        collect_values_for_key(&value, "model", &mut model_ids);
        for model_id in model_ids {
            model_reference_occurrences += 1;
            if has_external_namespace(model_id) {
                external_model_references += 1;
            } else if let Some(model_path) =
                resolve_resource_id(model_id, "block", "models", ".json")
            {
                referenced_models.insert(model_path);
            } else {
                invalid_state_model_ids += 1;
                push_diagnostic(
                    &mut blockstate_model_diagnostics,
                    format!("{path}: invalid model resource ID {model_id:?}"),
                );
            }
        }
    }

    let mut missing_state_models = Vec::new();
    let mut missing_state_model_count = 0_usize;
    for path in &referenced_models {
        if !name_set.contains(path.as_str()) {
            missing_state_model_count += 1;
            push_diagnostic(&mut missing_state_models, path.clone());
        }
    }

    let mut parsed_models = 0_usize;
    let mut invalid_models = 0_usize;
    let mut parent_references = 0_usize;
    let mut missing_parents = Vec::new();
    let mut missing_parent_count = 0_usize;
    let mut texture_references = 0_usize;
    let mut missing_textures = Vec::new();
    let mut missing_texture_count = 0_usize;
    let mut model_diagnostics = Vec::new();

    for path in &model_paths {
        let value = match read_json_entry(&mut archive, path) {
            Ok(value) => value,
            Err(error) => {
                invalid_models += 1;
                push_diagnostic(
                    &mut model_diagnostics,
                    format!("invalid model {path}: {error}"),
                );
                continue;
            }
        };
        let Some(object) = value.as_object() else {
            invalid_models += 1;
            push_diagnostic(
                &mut model_diagnostics,
                format!("invalid model {path}: root must be a JSON object"),
            );
            continue;
        };
        parsed_models += 1;
        let default_dir = model_parent_directory(path).unwrap_or("block");

        if let Some(parent_value) = object.get("parent") {
            if let Some(parent_id) = parent_value.as_str() {
                parent_references += 1;
                // builtin/* models are game-provided pseudo-models, not ordinary JSON assets.
                if is_builtin_model(parent_id) || has_external_namespace(parent_id) {
                    // Game-provided built-ins and other resource namespaces are not checked against
                    // the vanilla Minecraft namespace in this archive.
                } else if let Some(parent_path) =
                    resolve_resource_id(parent_id, default_dir, "models", ".json")
                {
                    if !name_set.contains(parent_path.as_str()) {
                        missing_parent_count += 1;
                        push_diagnostic(
                            &mut missing_parents,
                            format!("{path} -> {parent_path}"),
                        );
                    }
                } else {
                    push_diagnostic(
                        &mut model_diagnostics,
                        format!("model {path}: invalid parent resource ID {parent_id:?}"),
                    );
                }
            } else {
                push_diagnostic(
                    &mut model_diagnostics,
                    format!("model {path}: parent is present but is not a string"),
                );
            }
        }

        if let Some(textures) = object.get("textures") {
            if let Some(texture_object) = textures.as_object() {
                for (key, texture_value) in texture_object {
                    let Some(texture_id) = texture_value.as_str() else {
                        push_diagnostic(
                            &mut model_diagnostics,
                            format!("model {path}: texture '{key}' is not a string"),
                        );
                        continue;
                    };
                    if texture_id.starts_with('#') {
                        // Alias resolution can cross inherited parent textures and is a later step.
                        continue;
                    }
                    if has_external_namespace(texture_id) {
                        // Other namespaces are not verifiable against the vanilla JAR alone.
                    } else if let Some(texture_path) = resolve_resource_id(
                        texture_id,
                        "",
                        "textures",
                        ".png",
                    ) {
                        texture_references += 1;
                        if !name_set.contains(texture_path.as_str()) {
                            missing_texture_count += 1;
                            push_diagnostic(
                                &mut missing_textures,
                                format!("{path} -> {texture_path}"),
                            );
                        }
                    } else {
                        push_diagnostic(
                            &mut model_diagnostics,
                            format!("model {path}: invalid texture resource ID {texture_id:?}"),
                        );
                    }
                }
            } else {
                push_diagnostic(
                    &mut model_diagnostics,
                    format!("model {path}: 'textures' is not an object"),
                );
            }
        }
    }

    println!("Minecraft 1.8.9 resource-link audit (read-only)");
    println!("File: {}", jar_path.display());
    println!("Archive entries: {}", names.len());
    println!();
    println!("Blockstates:");
    println!("  JSON files found: {}", blockstate_paths.len());
    println!("  Parsed object roots: {parsed_blockstates}");
    println!("  Invalid blockstate JSON: {invalid_blockstates}");
    println!("  Model reference occurrences: {model_reference_occurrences}");
    println!("  Unique vanilla model paths referenced: {}", referenced_models.len());
    println!("  External-namespace model references skipped: {external_model_references}");
    println!("  Invalid model resource IDs: {invalid_state_model_ids}");
    print_diagnostic_list("Invalid blockstate model IDs", &blockstate_model_diagnostics);
    println!("  Missing referenced model files: {missing_state_model_count}");
    print_diagnostic_list("Missing blockstate model references", &missing_state_models);
    print_diagnostic_list("Invalid blockstate JSON diagnostics", &invalid_json_diagnostics);
    println!();
    println!("Models:");
    println!("  JSON files found: {}", model_paths.len());
    println!("  Parsed object roots: {parsed_models}");
    println!("  Invalid model JSON: {invalid_models}");
    println!("  Parent references checked: {parent_references}");
    println!("  Missing parent model files: {missing_parent_count}");
    print_diagnostic_list("Missing model parents", &missing_parents);
    println!("  Direct texture references checked: {texture_references}");
    println!("  Missing direct texture files: {missing_texture_count}");
    print_diagnostic_list("Missing direct model textures", &missing_textures);
    print_diagnostic_list("Model structure diagnostics", &model_diagnostics);
    println!();
    let passed = invalid_blockstates == 0
        && invalid_models == 0
        && invalid_state_model_ids == 0
        && missing_state_model_count == 0
        && missing_parent_count == 0
        && missing_texture_count == 0
        && model_diagnostics.is_empty()
        && invalid_json_diagnostics.is_empty();
    println!("Structural resource-link audit: {}", if passed { "PASS" } else { "REVIEW REQUIRED" });
    println!("Scope note: this does not yet resolve inherited texture aliases, block-ID/metadata variants, rotations, UV locking, or model element geometry.");
    println!("The JAR was not extracted or modified.");
    Ok(())
}

fn read_json_entry<R: Read + std::io::Seek>(
    archive: &mut ZipArchive<R>,
    path: &str,
) -> Result<Value> {
    let mut entry = archive.by_name(path).map_err(|error| {
        Mc189Error::InvalidData(format!("could not open resource entry: {error}"))
    })?;
    if entry.size() > MAX_JSON_BYTES {
        return Err(Mc189Error::InvalidData(format!(
            "JSON entry exceeds {} bytes",
            MAX_JSON_BYTES
        )));
    }
    let expected_size = entry.size() as usize;
    let mut bytes = Vec::with_capacity(expected_size);
    entry.read_to_end(&mut bytes)?;
    serde_json::from_slice(&bytes)
        .map_err(|error| Mc189Error::InvalidData(format!("JSON parse error: {error}")))
}

fn collect_values_for_key<'a>(value: &'a Value, key: &str, out: &mut Vec<&'a str>) {
    match value {
        Value::Object(object) => {
            for (current_key, child) in object {
                if current_key == key {
                    if let Some(value) = child.as_str() {
                        out.push(value);
                    }
                }
                collect_values_for_key(child, key, out);
            }
        }
        Value::Array(items) => {
            for child in items {
                collect_values_for_key(child, key, out);
            }
        }
        _ => {}
    }
}

/// Resolve a resource location to an archive entry path. `default_dir` is used when
/// the location does not explicitly contain a directory, e.g. `stone` in a blockstate.
fn resolve_resource_id(
    resource_id: &str,
    default_dir: &str,
    resource_group: &str,
    extension: &str,
) -> Option<String> {
    let location = match resource_id.split_once(':') {
        Some(("minecraft", location)) => location,
        Some((_other_namespace, _location)) => return None,
        None => resource_id,
    };
    if location.is_empty() || location.starts_with('/') || location.contains('\\') {
        return None;
    }
    let clean_location = location.strip_suffix(extension).unwrap_or(location);
    if clean_location
        .split('/')
        .any(|part| part.is_empty() || part == "." || part == "..")
    {
        return None;
    }
    let relative = if clean_location.contains('/') || default_dir.is_empty() {
        clean_location.to_owned()
    } else {
        format!("{default_dir}/{clean_location}")
    };
    Some(format!("{ASSET_PREFIX}{resource_group}/{relative}{extension}"))
}

fn model_parent_directory(model_path: &str) -> Option<&str> {
    let relative = model_path.strip_prefix(MODEL_PREFIX)?;
    relative.rsplit_once('/').map(|(directory, _)| directory)
}

fn has_external_namespace(resource_id: &str) -> bool {
    resource_id
        .split_once(':')
        .is_some_and(|(namespace, _)| namespace != "minecraft")
}

fn is_builtin_model(parent_id: &str) -> bool {
    matches!(parent_id.split_once(':'), Some(("minecraft", rest)) if rest.starts_with("builtin/"))
        || parent_id.starts_with("builtin/")
}

fn push_diagnostic(items: &mut Vec<String>, diagnostic: String) {
    if items.len() < MAX_DIAGNOSTICS {
        items.push(diagnostic);
    }
}

fn print_diagnostic_list(title: &str, items: &[String]) {
    if items.is_empty() {
        return;
    }
    println!("  {title} (first {} shown):", items.len());
    for item in items {
        println!("    - {item}");
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn bare_blockstate_model_names_resolve_under_block_models() {
        assert_eq!(
            resolve_resource_id("stone", "block", "models", ".json").as_deref(),
            Some("assets/minecraft/models/block/stone.json")
        );
    }

    #[test]
    fn explicit_model_paths_are_preserved() {
        assert_eq!(
            resolve_resource_id("block/cube_all", "block", "models", ".json").as_deref(),
            Some("assets/minecraft/models/block/cube_all.json")
        );
        assert_eq!(
            resolve_resource_id("item/generated", "block", "models", ".json").as_deref(),
            Some("assets/minecraft/models/item/generated.json")
        );
    }

    #[test]
    fn minecraft_namespace_is_accepted_but_other_namespaces_are_external() {
        assert_eq!(
            resolve_resource_id("minecraft:blocks/stone", "", "textures", ".png").as_deref(),
            Some("assets/minecraft/textures/blocks/stone.png")
        );
        assert_eq!(resolve_resource_id("example:blocks/stone", "", "textures", ".png"), None);
        assert!(has_external_namespace("example:blocks/stone"));
        assert!(!has_external_namespace("minecraft:blocks/stone"));
    }

    #[test]
    fn resource_ids_cannot_escape_the_archive_namespace() {
        assert_eq!(resolve_resource_id("../stone", "block", "models", ".json"), None);
        assert_eq!(resolve_resource_id("/stone", "block", "models", ".json"), None);
        assert_eq!(resolve_resource_id("foo\\bar", "block", "models", ".json"), None);
    }

    #[test]
    fn builtin_model_parents_are_not_archive_files() {
        assert!(is_builtin_model("builtin/entity"));
        assert!(is_builtin_model("minecraft:builtin/generated"));
        assert!(!is_builtin_model("block/cube_all"));
    }

    #[test]
    fn discovers_model_references_in_variants_and_multipart_structures() {
        let value: Value = serde_json::from_str(
            r#"{"variants":{"normal":{"model":"stone"},"facing=north":[{"model":"oak_log"}]},"multipart":[{"apply":{"model":"grass_block"}}]}"#,
        )
        .unwrap();
        let mut found = Vec::new();
        collect_values_for_key(&value, "model", &mut found);
        let mut sorted = found;
        sorted.sort_unstable();
        assert_eq!(sorted, vec!["grass_block", "oak_log", "stone"]);
    }
}
