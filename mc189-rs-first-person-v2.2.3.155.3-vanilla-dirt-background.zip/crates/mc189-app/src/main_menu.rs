//! Native Minecraft 1.8.9-style title screen using the original panorama/logo/widgets assets.
use crate::world_catalog;
use mc189_core::{Mc189Error, Result};
use image::{imageops, Rgba, RgbaImage};
use std::fs::File;
use std::io::Read;
use std::path::{Path, PathBuf};
use serde::{Deserialize, Serialize};
use mc189_protocol::{connect_offline, start_play_session, PlayEvent};
use std::sync::mpsc::Receiver;
use std::sync::Arc;
use std::cell::RefCell;
use std::rc::Rc;
use wgpu::util::DeviceExt;
use winit::dpi::PhysicalSize;
use winit::event::{ElementState, Event, MouseButton, WindowEvent};
use winit::event_loop::{ControlFlow, EventLoop};
use winit::platform::run_on_demand::EventLoopExtRunOnDemand;
use winit::keyboard::{KeyCode, PhysicalKey};
use winit::window::{Window, WindowBuilder};

const UI_W: u32 = 854;
const UI_H: u32 = 480;
const BUTTON_X: u32 = (UI_W - BUTTON_W) / 2;
const BUTTON_Y: u32 = 168;
const BUTTON_W: u32 = 200;
const LOGO_W: u32 = 310;
// Corrected lateral panorama assignment for wgpu cube coordinates.
const CUBE_FACE_TO_MINECRAFT_FILE: [usize; 6] = [1, 3, 4, 5, 0, 2];
const LOGO_OPTICAL_OFFSET_X: i32 = 19; // approximately 0.5 cm at 96 DPI in the 854 px menu canvas
const BUTTON_H: u32 = 20;
const BUTTON_GAP: u32 = 4;

#[derive(Clone, Copy, PartialEq, Eq)]
enum Screen { Main, Worlds, CreateWorld, RenameWorld, ConfirmDeleteWorld, Multiplayer, ServerEntry, DirectConnect, ConfirmDelete, Options }
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Action { Options, Singleplayer, Multiplayer, Realms, Language, Quit, Back, Disabled, World(usize), SaveServer, ConnectServer, ConnectSelected, DirectConnect, AddServer, EditServer, DeleteServer, RefreshServers, CreateWorld, RenameWorld, DeleteWorld, ConfirmDeleteWorldYes, ConfirmDeleteWorldNo, SaveWorldName, ConfirmDeleteYes, ConfirmDeleteNo, LaunchSelectedWorld, ToggleCreateAdvanced, CycleCreateMode, ToggleCreateStructures, CycleCreateWorldType, ToggleCreateCheats, ToggleCreateBonus }
#[derive(Clone, Debug)]
struct CreateWorldOptions {
    advanced: bool,
    mode: u8, // 0 survival, 1 hardcore, 2 creative
    structures: bool,
    cheats: bool,
    cheats_user_set: bool,
    bonus_chest: bool,
    world_type: u8, // default, superflat, large biomes, amplified, customized
}
impl Default for CreateWorldOptions {
    fn default() -> Self { Self { advanced:false, mode:0, structures:true, cheats:false, cheats_user_set:false, bonus_chest:false, world_type:0 } }
}
impl CreateWorldOptions {
    fn mode_name(&self) -> &'static str { match self.mode { 1=>"HARDCORE", 2=>"CREATIVE", _=>"SURVIVAL" } }
    fn world_type_name(&self) -> &'static str { match self.world_type { 1=>"FLAT", 2=>"LARGE BIOMES", 3=>"AMPLIFIED", 4=>"CUSTOMIZED", _=>"DEFAULT" } }
}

#[derive(Clone)]
struct UiButton { rect: (u32,u32,u32,u32), label: String, action: Action }

#[derive(Clone, Debug, Serialize, Deserialize)]
struct SavedServer { name: String, host: String, port: u16 }

const DEFAULT_MINECRAFT_PORT: u16 = 25565;
fn selected_port(input: &str) -> std::result::Result<u16, String> {
    if input.trim().is_empty() { return Ok(DEFAULT_MINECRAFT_PORT); }
    input.trim().parse::<u16>().ok().filter(|port| *port > 0)
        .ok_or_else(|| "Invalid port (1-65535); leave it blank to use 25565".to_string())
}

fn server_list_path(saves: &Path) -> PathBuf {
    saves.parent().unwrap_or(saves).join("servers-mc189-rust.json")
}
fn load_servers(saves: &Path) -> Vec<SavedServer> {
    std::fs::read(server_list_path(saves)).ok()
        .and_then(|bytes| serde_json::from_slice(&bytes).ok()).unwrap_or_default()
}
fn save_servers(saves: &Path, servers: &[SavedServer]) -> Result<()> {
    let bytes = serde_json::to_vec_pretty(servers)
        .map_err(|e| Mc189Error::InvalidData(format!("cannot encode server list: {e}")))?;
    std::fs::write(server_list_path(saves), bytes)?;
    Ok(())
}

struct MenuAssets { panorama: Vec<RgbaImage>, logo: RgbaImage, mojang: RgbaImage, options_background: RgbaImage, widgets: Option<RgbaImage>, font: Option<RgbaImage>, splash: String }
impl MenuAssets {
    fn load(jar: &Path) -> Result<Self> {
        let file = File::open(jar)?;
        let mut zip = zip::ZipArchive::new(file).map_err(|e| Mc189Error::InvalidData(format!("cannot open client.jar: {e}")))?;
        let mut panorama = Vec::new();
        for i in 0..6 {
            let path = format!("assets/minecraft/textures/gui/title/background/panorama_{i}.png");
            let mut entry = zip.by_name(&path).map_err(|_| Mc189Error::InvalidData(format!("client.jar is missing {path}")))?;
            let mut bytes = Vec::new(); entry.read_to_end(&mut bytes)?;
            let img = image::load_from_memory(&bytes).map_err(|e| Mc189Error::InvalidData(format!("cannot decode {path}: {e}")))?.to_rgba8();
            if img.width() != 256 || img.height() != 256 {
                return Err(Mc189Error::InvalidData(format!("{path} must be 256x256, got {}x{}", img.width(), img.height())));
            }
            panorama.push(img);
        }
        let logo = read_png(&mut zip, "assets/minecraft/textures/gui/title/minecraft.png")?;
        // Minecraft.java#drawSplashScreen binds this exact 256x256 Mojang texture
        // before constructing GuiMainMenu. Keep it as a real boot phase, not a
        // recreated text logo or a static screenshot.
        let mojang = read_png(&mut zip, "assets/minecraft/textures/gui/title/mojang.png")?;
        if mojang.width() != 256 || mojang.height() != 256 {
            return Err(Mc189Error::InvalidData(format!("Mojang splash texture must be 256x256, got {}x{}", mojang.width(), mojang.height())));
        }
        // GuiScreen.drawBackground() uses this exact vanilla dirt tile on
        // world selection, multiplayer, options and the other non-title GUIs.
        let options_background = read_png(&mut zip, "assets/minecraft/textures/gui/options_background.png")?;
        let widgets = read_png(&mut zip, "assets/minecraft/textures/gui/widgets.png").ok();
        let font = read_png(&mut zip, "assets/minecraft/textures/font/ascii.png").ok();
        let splash = zip.by_name("assets/minecraft/texts/splashes.txt").ok().and_then(|mut e| {
            let mut text = String::new(); e.read_to_string(&mut text).ok()?;
            let lines: Vec<&str> = text.lines().map(str::trim).filter(|x| !x.is_empty() && !x.starts_with('#')).collect();
            if lines.is_empty() { None } else {
                let tick = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).ok()?.as_nanos() as usize;
                Some(lines[tick % lines.len()].to_string())
            }
        }).unwrap_or_else(|| "Also try Minecraft!".to_string());
        Ok(Self { panorama, logo, mojang, options_background, widgets, font, splash })
    }
}
fn read_png(zip: &mut zip::ZipArchive<File>, path: &str) -> Result<RgbaImage> {
    let mut entry = zip.by_name(path).map_err(|_| Mc189Error::InvalidData(format!("client.jar is missing {path}")))?;
    let mut bytes = Vec::new(); entry.read_to_end(&mut bytes)?;
    Ok(image::load_from_memory(&bytes).map_err(|e| Mc189Error::InvalidData(format!("cannot decode {path}: {e}")))?.to_rgba8())
}

struct MenuGpu {
    surface: wgpu::Surface<'static>, device: wgpu::Device, queue: wgpu::Queue,
    config: wgpu::SurfaceConfiguration, pipeline: wgpu::RenderPipeline,
    bind_group: wgpu::BindGroup, uniform: wgpu::Buffer, overlay: wgpu::Texture,
    window_size: PhysicalSize<u32>, started: std::time::Instant,
}
impl MenuGpu {
    async fn new(window: Arc<Window>, assets: &MenuAssets) -> Result<Self> {
        let instance = wgpu::Instance::default();
        let surface = instance.create_surface(window.clone()).map_err(|e| Mc189Error::InvalidData(format!("cannot create menu surface: {e}")))?;
        let adapter = instance.request_adapter(&wgpu::RequestAdapterOptions { power_preference: wgpu::PowerPreference::HighPerformance, compatible_surface: Some(&surface), force_fallback_adapter: false }).await.ok_or_else(|| Mc189Error::InvalidData("no compatible GPU adapter found for title screen".into()))?;
        let (device, queue) = adapter.request_device(&wgpu::DeviceDescriptor { label: Some("mc189 title screen device"), required_features: wgpu::Features::empty(), required_limits: wgpu::Limits::downlevel_defaults() }, None).await.map_err(|e| Mc189Error::InvalidData(format!("cannot create menu GPU device: {e}")))?;
        let cube = device.create_texture(&wgpu::TextureDescriptor { label: Some("Minecraft 1.8.9 title panorama cube"), size: wgpu::Extent3d { width: 256, height: 256, depth_or_array_layers: 6 }, mip_level_count: 1, sample_count: 1, dimension: wgpu::TextureDimension::D2, format: wgpu::TextureFormat::Rgba8UnormSrgb, usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST, view_formats: &[] });
        // Minecraft's file order is front, left, back, right, top, bottom.
        // wgpu cube layers are +X, -X, +Y, -Y, +Z, -Z. The lateral
        // files are intentionally exchanged to match the camera's screen-space
        // handedness; front (+Z) and bottom (-Y) retain their verified layers.
        for (layer, &face_index) in CUBE_FACE_TO_MINECRAFT_FILE.iter().enumerate() {
            let face = &assets.panorama[face_index];
            queue.write_texture(wgpu::ImageCopyTexture { texture: &cube, mip_level: 0, origin: wgpu::Origin3d { x: 0, y: 0, z: layer as u32 }, aspect: wgpu::TextureAspect::All }, face.as_raw(), wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(256*4), rows_per_image: Some(256) }, wgpu::Extent3d { width: 256, height: 256, depth_or_array_layers: 1 });
        }
        let cube_view = cube.create_view(&wgpu::TextureViewDescriptor { label: Some("panorama cube view"), dimension: Some(wgpu::TextureViewDimension::Cube), ..Default::default() });
        let overlay = device.create_texture(&wgpu::TextureDescriptor { label: Some("title screen UI overlay"), size: wgpu::Extent3d { width: UI_W, height: UI_H, depth_or_array_layers: 1 }, mip_level_count: 1, sample_count: 1, dimension: wgpu::TextureDimension::D2, format: wgpu::TextureFormat::Rgba8UnormSrgb, usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST, view_formats: &[] });
        let overlay_view = overlay.create_view(&Default::default());
        let sampler = device.create_sampler(&wgpu::SamplerDescriptor { label: Some("title screen linear sampler"), address_mode_u: wgpu::AddressMode::ClampToEdge, address_mode_v: wgpu::AddressMode::ClampToEdge, mag_filter: wgpu::FilterMode::Linear, min_filter: wgpu::FilterMode::Linear, ..Default::default() });
        let ui_sampler = device.create_sampler(&wgpu::SamplerDescriptor { label: Some("title screen pixel-exact UI sampler"), address_mode_u: wgpu::AddressMode::ClampToEdge, address_mode_v: wgpu::AddressMode::ClampToEdge, mag_filter: wgpu::FilterMode::Nearest, min_filter: wgpu::FilterMode::Nearest, ..Default::default() });
        let uniform = device.create_buffer_init(&wgpu::util::BufferInitDescriptor { label: Some("title screen camera uniforms"), contents: bytemuck::cast_slice(&[0.0_f32, 16.0/9.0, 0.0, 0.0]), usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST });
        let layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor { label: Some("title screen bind layout"), entries: &[
            wgpu::BindGroupLayoutEntry { binding: 0, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: true }, view_dimension: wgpu::TextureViewDimension::Cube, multisampled: false }, count: None },
            wgpu::BindGroupLayoutEntry { binding: 1, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering), count: None },
            wgpu::BindGroupLayoutEntry { binding: 2, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Texture { sample_type: wgpu::TextureSampleType::Float { filterable: true }, view_dimension: wgpu::TextureViewDimension::D2, multisampled: false }, count: None },
            wgpu::BindGroupLayoutEntry { binding: 3, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Buffer { ty: wgpu::BufferBindingType::Uniform, has_dynamic_offset: false, min_binding_size: None }, count: None },
            wgpu::BindGroupLayoutEntry { binding: 4, visibility: wgpu::ShaderStages::FRAGMENT, ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering), count: None },
        ] });
        let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor { label: Some("title screen bind group"), layout: &layout, entries: &[
            wgpu::BindGroupEntry { binding: 0, resource: wgpu::BindingResource::TextureView(&cube_view) },
            wgpu::BindGroupEntry { binding: 1, resource: wgpu::BindingResource::Sampler(&sampler) },
            wgpu::BindGroupEntry { binding: 2, resource: wgpu::BindingResource::TextureView(&overlay_view) },
            wgpu::BindGroupEntry { binding: 3, resource: uniform.as_entire_binding() },
            wgpu::BindGroupEntry { binding: 4, resource: wgpu::BindingResource::Sampler(&ui_sampler) },
        ] });
        let caps = surface.get_capabilities(&adapter);
        let format = caps.formats.iter().copied().find(wgpu::TextureFormat::is_srgb).or_else(|| caps.formats.first().copied()).ok_or_else(|| Mc189Error::InvalidData("GPU surface has no supported format".into()))?;
        let size = window.inner_size();
        let config = wgpu::SurfaceConfiguration { usage: wgpu::TextureUsages::RENDER_ATTACHMENT, format, width: size.width.max(1), height: size.height.max(1), present_mode: caps.present_modes.iter().copied().find(|x| *x == wgpu::PresentMode::Fifo).unwrap_or(caps.present_modes[0]), desired_maximum_frame_latency: 2, alpha_mode: caps.alpha_modes[0], view_formats: vec![] };
        surface.configure(&device, &config);
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor { label: Some("Minecraft panorama and menu shader"), source: wgpu::ShaderSource::Wgsl(MENU_SHADER.into()) });
        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor { label: Some("title screen pipeline layout"), bind_group_layouts: &[&layout], push_constant_ranges: &[] });
        let pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor { label: Some("title screen pipeline"), layout: Some(&pipeline_layout), vertex: wgpu::VertexState { module: &shader, entry_point: "vs_main", buffers: &[] }, fragment: Some(wgpu::FragmentState { module: &shader, entry_point: "fs_main", targets: &[Some(wgpu::ColorTargetState { format, blend: Some(wgpu::BlendState::REPLACE), write_mask: wgpu::ColorWrites::ALL })] }), primitive: wgpu::PrimitiveState { topology: wgpu::PrimitiveTopology::TriangleList, strip_index_format: None, front_face: wgpu::FrontFace::Ccw, cull_mode: None, polygon_mode: wgpu::PolygonMode::Fill, unclipped_depth: false, conservative: false }, depth_stencil: None, multisample: wgpu::MultisampleState::default(), multiview: None });
        Ok(Self { surface, device, queue, config, pipeline, bind_group, uniform, overlay, window_size: size, started: std::time::Instant::now() })
    }
    fn upload_overlay(&self, img: &RgbaImage) { self.queue.write_texture(wgpu::ImageCopyTexture { texture: &self.overlay, mip_level: 0, origin: wgpu::Origin3d::ZERO, aspect: wgpu::TextureAspect::All }, img.as_raw(), wgpu::ImageDataLayout { offset: 0, bytes_per_row: Some(UI_W*4), rows_per_image: Some(UI_H) }, wgpu::Extent3d { width: UI_W, height: UI_H, depth_or_array_layers: 1 }); }
    fn resize(&mut self, size: PhysicalSize<u32>) { if size.width == 0 || size.height == 0 { return; } self.window_size=size; self.config.width=size.width; self.config.height=size.height; self.surface.configure(&self.device,&self.config); }
    fn render(&mut self) -> std::result::Result<(), wgpu::SurfaceError> {
        let elapsed=self.started.elapsed().as_secs_f32();
        self.queue.write_buffer(&self.uniform,0,bytemuck::cast_slice(&[elapsed, self.config.width as f32/self.config.height as f32,0.0_f32,0.0_f32]));
        let frame=self.surface.get_current_texture()?; let view=frame.texture.create_view(&Default::default());
        let mut encoder=self.device.create_command_encoder(&wgpu::CommandEncoderDescriptor{label:Some("title screen frame")});
        { let mut pass=encoder.begin_render_pass(&wgpu::RenderPassDescriptor{label:Some("title screen pass"),color_attachments:&[Some(wgpu::RenderPassColorAttachment{view:&view,resolve_target:None,ops:wgpu::Operations{load:wgpu::LoadOp::Clear(wgpu::Color::BLACK),store:wgpu::StoreOp::Store}})],depth_stencil_attachment:None,occlusion_query_set:None,timestamp_writes:None}); pass.set_pipeline(&self.pipeline);pass.set_bind_group(0,&self.bind_group,&[]);pass.draw(0..3,0..1); }
        self.queue.submit(Some(encoder.finish()));frame.present();Ok(())
    }
}

fn buttons(screen: Screen, worlds: &[world_catalog::SavedWorld], create: &CreateWorldOptions) -> Vec<UiButton> {
    match screen {
        Screen::Main => vec![
            UiButton { rect: (BUTTON_X, 168, BUTTON_W, BUTTON_H), label: "Singleplayer".into(), action: Action::Singleplayer },
            UiButton { rect: (BUTTON_X, 192, BUTTON_W, BUTTON_H), label: "Multiplayer".into(), action: Action::Multiplayer },
            UiButton { rect: (BUTTON_X, 216, BUTTON_W, BUTTON_H), label: "Minecraft Realms".into(), action: Action::Realms },
            UiButton { rect: (UI_W/2-100, 252, 98, BUTTON_H), label: "Options...".into(), action: Action::Options },
            UiButton { rect: (UI_W/2+2, 252, 98, BUTTON_H), label: "Quit Game".into(), action: Action::Quit },
            UiButton { rect: (UI_W/2-124, 252, 20, BUTTON_H), label: "EN".into(), action: Action::Language },
        ],
        Screen::Options => vec![button(0,"BACK",Action::Back)],
        Screen::Multiplayer => vec![
            UiButton { rect:(UI_W/2-154,UI_H-52,100,20), label:"SELECT".into(), action:Action::ConnectSelected },
            UiButton { rect:(UI_W/2-50,UI_H-52,100,20), label:"DIRECT CONNECT".into(), action:Action::DirectConnect },
            UiButton { rect:(UI_W/2+54,UI_H-52,100,20), label:"ADD SERVER".into(), action:Action::AddServer },
            UiButton { rect:(UI_W/2-154,UI_H-28,70,20), label:"EDIT".into(), action:Action::EditServer },
            UiButton { rect:(UI_W/2-74,UI_H-28,70,20), label:"DELETE".into(), action:Action::DeleteServer },
            UiButton { rect:(UI_W/2+4,UI_H-28,70,20), label:"REFRESH".into(), action:Action::RefreshServers },
            UiButton { rect:(UI_W/2+82,UI_H-28,72,20), label:"CANCEL".into(), action:Action::Back },
        ],
        Screen::ServerEntry => vec![
            UiButton { rect:(UI_W/2-104,UI_H-28,100,20), label:"SAVE".into(), action:Action::SaveServer },
            UiButton { rect:(UI_W/2+4,UI_H-28,100,20), label:"CANCEL".into(), action:Action::Back },
            UiButton { rect:(UI_W/2-50,UI_H-52,100,20), label:"CONNECT".into(), action:Action::ConnectServer },
        ],
        Screen::DirectConnect => vec![
            UiButton { rect:(UI_W/2-104,UI_H-28,100,20), label:"CANCEL".into(), action:Action::Back },
            UiButton { rect:(UI_W/2+4,UI_H-28,100,20), label:"JOIN SERVER".into(), action:Action::ConnectServer },
        ],
        Screen::ConfirmDelete => vec![
            UiButton { rect:(UI_W/2-104,UI_H/2+28,100,20), label:"DELETE".into(), action:Action::ConfirmDeleteYes },
            UiButton { rect:(UI_W/2+4,UI_H/2+28,100,20), label:"CANCEL".into(), action:Action::ConfirmDeleteNo },
        ],
        Screen::CreateWorld => {
            let mut out = vec![
                UiButton { rect:(UI_W/2-155,UI_H-28,150,20), label:"CREATE NEW WORLD".into(), action:Action::Disabled },
                UiButton { rect:(UI_W/2+5,UI_H-28,150,20), label:"CANCEL".into(), action:Action::Back },
            ];
            if create.advanced {
                if create.world_type != 4 {
                    out.push(UiButton { rect:(UI_W/2-155,100,150,20), label:format!("STRUCTURES: {}",if create.structures {"ON"}else{"OFF"}), action:Action::ToggleCreateStructures });
                }
                out.push(UiButton { rect:(UI_W/2+5,100,150,20), label:format!("WORLD TYPE: {}",create.world_type_name()), action:Action::CycleCreateWorldType });
                out.push(UiButton { rect:(UI_W/2-155,151,150,20), label:format!("ALLOW CHEATS: {}",if create.cheats && create.mode!=1 {"ON"}else{"OFF"}), action:Action::ToggleCreateCheats });
                out.push(UiButton { rect:(UI_W/2+5,151,150,20), label:format!("BONUS CHEST: {}",if create.bonus_chest && create.mode!=1 {"ON"}else{"OFF"}), action:Action::ToggleCreateBonus });
                out.push(UiButton { rect:(UI_W/2-75,187,150,20), label:"DONE".into(), action:Action::ToggleCreateAdvanced });
            } else {
                out.push(UiButton { rect:(UI_W/2-75,115,150,20), label:format!("GAME MODE: {}",create.mode_name()), action:Action::CycleCreateMode });
                out.push(UiButton { rect:(UI_W/2-75,187,150,20), label:"MORE WORLD OPTIONS...".into(), action:Action::ToggleCreateAdvanced });
            }
            out
        },
        Screen::RenameWorld => vec![
            UiButton { rect:(UI_W/2-104,UI_H/2+42,100,20), label:"SAVE".into(), action:Action::SaveWorldName },
            UiButton { rect:(UI_W/2+4,UI_H/2+42,100,20), label:"CANCEL".into(), action:Action::Back },
        ],
        Screen::ConfirmDeleteWorld => vec![
            UiButton { rect:(UI_W/2-104,UI_H/2+28,100,20), label:"DELETE".into(), action:Action::ConfirmDeleteWorldYes },
            UiButton { rect:(UI_W/2+4,UI_H/2+28,100,20), label:"CANCEL".into(), action:Action::ConfirmDeleteWorldNo },
        ],
        Screen::Worlds => {
            let mut out=vec![];
            for (i,w) in worlds.iter().take(10).enumerate() {
                let name=w.metadata.level_name.as_deref().unwrap_or(&w.folder_name);
                out.push(UiButton{rect:(32,32+(i as u32)*36,790,32),label:name.to_string(),action:Action::World(i)});
            }
            out.push(UiButton{rect:(UI_W/2-154,UI_H-52,150,20),label:"SELECT".into(),action:Action::LaunchSelectedWorld});
            out.push(UiButton{rect:(UI_W/2+4,UI_H-52,150,20),label:"CREATE NEW".into(),action:Action::CreateWorld});
            out.push(UiButton{rect:(UI_W/2-154,UI_H-28,72,20),label:"RENAME".into(),action:Action::Disabled});
            out.push(UiButton{rect:(UI_W/2-76,UI_H-28,72,20),label:"DELETE".into(),action:Action::Disabled});
            out.push(UiButton{rect:(UI_W/2+4,UI_H-28,72,20),label:"RECREATE".into(),action:Action::Disabled});
            out.push(UiButton{rect:(UI_W/2+82,UI_H-28,72,20),label:"CANCEL".into(),action:Action::Back});out
        }
    }
}
fn button(index: u32,label:&str,action:Action)->UiButton { UiButton{rect:(BUTTON_X,BUTTON_Y+index*(BUTTON_H+BUTTON_GAP),BUTTON_W,BUTTON_H),label:label.into(),action} }
fn hit(button:&UiButton,p:(u32,u32))->bool { p.0>=button.rect.0&&p.0<button.rect.0+button.rect.2&&p.1>=button.rect.1&&p.1<button.rect.1+button.rect.3 }

fn make_mojang_overlay(assets: &MenuAssets) -> RgbaImage {
    // Minecraft 1.8.9 Framebuffer starts with white RGB and zero alpha;
    // drawSplashScreen composites the original 256x256 Mojang texture on it.
    let mut canvas = RgbaImage::from_pixel(UI_W, UI_H, Rgba([255, 255, 255, 255]));
    imageops::overlay(&mut canvas, &assets.mojang, ((UI_W - 256) / 2) as i64, ((UI_H - 256) / 2) as i64);
    canvas
}

fn draw_vanilla_dirt_background(canvas: &mut RgbaImage, texture: &RgbaImage) {
    let tile = imageops::resize(texture, 32, 32, imageops::FilterType::Nearest);
    for y in (0..canvas.height()).step_by(32) {
        for x in (0..canvas.width()).step_by(32) {
            for ty in 0..32 {
                for tx in 0..32 {
                    if x + tx >= canvas.width() || y + ty >= canvas.height() { continue; }
                    let source = tile.get_pixel(tx, ty);
                    canvas.put_pixel(x + tx, y + ty, Rgba([
                        ((u16::from(source[0]) * 64) / 255) as u8,
                        ((u16::from(source[1]) * 64) / 255) as u8,
                        ((u16::from(source[2]) * 64) / 255) as u8,
                        255,
                    ]));
                }
            }
        }
    }
}

fn make_overlay(assets:&MenuAssets,screen:Screen,worlds:&[world_catalog::SavedWorld],hover:Option<usize>, servers:&[SavedServer], fields:(&str,&str,&str,&str), status:&str, create_name:&str, create_seed:&str, create:&CreateWorldOptions)->RgbaImage {
    let mut canvas=RgbaImage::from_pixel(UI_W,UI_H,Rgba([0,0,0,0]));
    if screen != Screen::Main {
        // GuiScreen.drawDefaultBackground() -> drawBackground(0): the vanilla
        // options_background dirt texture tiled at 32 GUI pixels and tinted
        // to 25% brightness. Making it opaque also prevents the title panorama
        // from bleeding through on screens that use the dirt backdrop.
        draw_vanilla_dirt_background(&mut canvas, &assets.options_background);
    }
    if screen == Screen::Main {
        // GuiMainMenu draws the split 155x44 logo only on the title screen.
        let logo_x = ((UI_W - LOGO_W) / 2) as i32 + LOGO_OPTICAL_OFFSET_X;
        let logo_top = imageops::crop_imm(&assets.logo, 0, 0, 155, 44).to_image();
        let logo_bottom = imageops::crop_imm(&assets.logo, 0, 45, 155, 44).to_image();
        imageops::overlay(&mut canvas, &logo_top, logo_x as i64, 30);
        imageops::overlay(&mut canvas, &logo_bottom, (logo_x + 155) as i64, 30);
        // Vanilla splash pulse, normalized so the rendered text is about 100 px wide.
        let millis=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d|(d.as_millis()%1000) as f32).unwrap_or(0.0);
        let pulse=(millis/1000.0*std::f32::consts::TAU).sin().abs()*0.1;
        let font_width=assets.splash.chars().map(|c|glyph_width(assets.font.as_ref(),c)+1).sum::<u32>() as f32;
        let scale=(1.8-pulse)*100.0/(font_width+32.0);
        draw_rotated_text(&mut canvas, assets.font.as_ref(), &assets.splash,
            UI_W as i32 / 2 + 90, 70, -20.0, scale, [255, 255, 0, 255]);
    }
    let btns=buttons(screen,worlds,create);
    for (i,b) in btns.iter().enumerate() {
        if let Action::World(row)=b.action {
            let selected=worlds.get(row).map(|world|status==format!("Selected {}",world.metadata.level_name.as_deref().unwrap_or(&world.folder_name))).unwrap_or(false);
            let shade=if selected{48}else if hover==Some(i){62}else{22};
            let (x,y,w,h)=b.rect;
            for py in y..y+h { for px in x..x+w { canvas.put_pixel(px,py,Rgba([shade,shade,shade,220])); } }
            continue;
        }
        let (x,y,w,h)=b.rect;
        if let Some(widget)=&assets.widgets {
            let disabled=b.action==Action::Disabled
                || (matches!(b.action,Action::LaunchSelectedWorld|Action::RenameWorld|Action::DeleteWorld) && !status.starts_with("Selected "))
                || (matches!(b.action,Action::ConnectSelected|Action::EditServer|Action::DeleteServer) && !status.starts_with("Selected "));
            let source_y=if disabled{46}else if hover==Some(i){86}else{66};
            if widget.width()>=200 && widget.height()>=source_y+20 && w<=200 {
                let half=w/2;
                let left=imageops::crop_imm(widget,0,source_y,half,20).to_image();
                let right=imageops::crop_imm(widget,200-half,source_y,w-half,20).to_image();
                imageops::overlay(&mut canvas,&left,x as i64,y as i64);
                imageops::overlay(&mut canvas,&right,(x+half) as i64,y as i64);
            } else { draw_button_fallback(&mut canvas,x,y,w,h,hover==Some(i)); }
        } else { draw_button_fallback(&mut canvas,x,y,w,h,hover==Some(i)); }
        let disabled=b.action==Action::Disabled
            || (matches!(b.action,Action::LaunchSelectedWorld|Action::RenameWorld|Action::DeleteWorld) && !status.starts_with("Selected "))
            || (matches!(b.action,Action::ConnectSelected|Action::EditServer|Action::DeleteServer) && !status.starts_with("Selected "));
        if w > 40 {
            if !disabled { draw_text_centered(&mut canvas,assets.font.as_ref(),&b.label,(x+w/2+1) as i32,(y+7) as i32,[20,20,20,255],1); }
            draw_text_centered(&mut canvas,assets.font.as_ref(),&b.label,(x+w/2) as i32,(y+6) as i32,if disabled{[160,160,160,255]}else if hover==Some(i){[255,255,160,255]}else{[224,224,224,255]},1);
        } else {
            // Small language control; the vanilla widget is a compact square.
            draw_text_centered(&mut canvas,assets.font.as_ref(),"EN",(x+w/2) as i32,(y+6) as i32,[224,224,224,255],1);
        }
    }
    if screen==Screen::Worlds {
        draw_text_centered(&mut canvas,assets.font.as_ref(),"SELECT WORLD",UI_W as i32/2,20,[255,255,255,255],1);
        for (i,world) in worlds.iter().take(10).enumerate() {
            let y=32+(i as u32)*36;
            // GuiSelectWorld.List.drawSlot (1.8.9) uses three text rows and
            // no thumbnail: display name, save folder, then game mode flags.
            let name=world.metadata.level_name.as_deref().filter(|v|!v.trim().is_empty()).unwrap_or(&world.folder_name);
            draw_text(&mut canvas,assets.font.as_ref(),name,34,y as i32+1,[255,255,255,255],1);
            draw_text(&mut canvas,assets.font.as_ref(),&format!("{} (saved world)",world.folder_name),34,y as i32+12,[128,128,128,255],1);
            let mut mode=match world.metadata.game_type.unwrap_or(0){1=>"Creative",2=>"Adventure",3=>"Spectator",_=>"Survival"}.to_string();
            if world.metadata.hardcore.unwrap_or(0)!=0 { mode="Hardcore".into(); }
            if world.metadata.allow_commands.unwrap_or(0)!=0 { mode.push_str(", Cheats"); }
            draw_text(&mut canvas,assets.font.as_ref(),&mode,34,y as i32+23,[128,128,128,255],1);
        }
        if worlds.is_empty(){draw_text_centered(&mut canvas,assets.font.as_ref(),"NO WORLDS FOUND",UI_W as i32/2,210,[255,255,255,255],1);}
        if !status.is_empty(){draw_text_centered(&mut canvas,assets.font.as_ref(),status,UI_W as i32/2,UI_H as i32-68,[220,220,220,255],1);}
    }
    if screen==Screen::Multiplayer {
        draw_text_centered(&mut canvas,assets.font.as_ref(),"PLAY MULTIPLAYER",UI_W as i32/2,20,[255,255,255,255],1);
        for (i,server) in servers.iter().take(10).enumerate() {
            let y=34+i as u32*36;
            let selected=status==format!("Selected {}",server.name);
            let shade=if selected{52}else{18};
            for py in y..y+34 { for px in 32..822 { canvas.put_pixel(px,py,Rgba([shade,shade,shade,220])); } }
            draw_text(&mut canvas,assets.font.as_ref(),&server.name,78,y as i32+5,[255,255,255,255],1);
            draw_text(&mut canvas,assets.font.as_ref(),&format!("{}:{}",server.host,server.port),78,y as i32+19,[170,170,170,255],1);
            draw_text(&mut canvas,assets.font.as_ref(),"?",48,y as i32+12,[180,180,180,255],1);
        }
        if servers.is_empty(){draw_text_centered(&mut canvas,assets.font.as_ref(),"NO SERVERS ADDED",UI_W as i32/2,210,[200,200,200,255],1);}
        draw_text_centered(&mut canvas,assets.font.as_ref(),status,UI_W as i32/2,UI_H as i32-68,[255,220,100,255],1);
    }
    if screen==Screen::ServerEntry {
        draw_text_centered(&mut canvas,assets.font.as_ref(),if fields.0=="My Server"{"ADD SERVER"}else{"EDIT SERVER INFO"},UI_W as i32/2,20,[255,255,255,255],1);
        for y in [170u32,204,238] { for py in y..y+24 { for px in 210..644 { canvas.put_pixel(px,py,Rgba([0,0,0,210])); } } }
        draw_text(&mut canvas,assets.font.as_ref(),"SERVER NAME",210,153,[220,220,220,255],1);
        draw_text(&mut canvas,assets.font.as_ref(),fields.0,218,178,[255,255,255,255],1);
        draw_text(&mut canvas,assets.font.as_ref(),"SERVER ADDRESS",210,187,[220,220,220,255],1);
        draw_text(&mut canvas,assets.font.as_ref(),fields.1,218,212,[255,255,255,255],1);
        draw_text(&mut canvas,assets.font.as_ref(),"PORT (OPTIONAL)  |  USERNAME",210,221,[220,220,220,255],1);
        draw_text(&mut canvas,assets.font.as_ref(),&format!("{}   |   {}",if fields.2.trim().is_empty(){"25565"}else{fields.2},fields.3),218,246,[255,255,255,255],1);
        draw_text_centered(&mut canvas,assets.font.as_ref(),"LEAVE PORT BLANK TO USE 25565",UI_W as i32/2,288,[170,170,170,255],1);
        draw_text_centered(&mut canvas,assets.font.as_ref(),status,UI_W as i32/2,UI_H as i32-68,[255,220,100,255],1);
    }
    if screen==Screen::DirectConnect {
        draw_text_centered(&mut canvas,assets.font.as_ref(),"DIRECT CONNECT",UI_W as i32/2,20,[255,255,255,255],1);
        for y in [204u32,238] { for py in y..y+24 { for px in 210..644 { canvas.put_pixel(px,py,Rgba([0,0,0,210])); } } }
        draw_text(&mut canvas,assets.font.as_ref(),"SERVER ADDRESS",210,187,[220,220,220,255],1);
        draw_text(&mut canvas,assets.font.as_ref(),fields.1,218,212,[255,255,255,255],1);
        draw_text(&mut canvas,assets.font.as_ref(),"PORT (OPTIONAL)",210,221,[220,220,220,255],1);
        draw_text(&mut canvas,assets.font.as_ref(),if fields.2.trim().is_empty(){"25565"}else{fields.2},218,246,[255,255,255,255],1);
        draw_text_centered(&mut canvas,assets.font.as_ref(),"LEAVE PORT BLANK TO USE 25565",UI_W as i32/2,288,[170,170,170,255],1);
        draw_text_centered(&mut canvas,assets.font.as_ref(),status,UI_W as i32/2,UI_H as i32-68,[255,220,100,255],1);
    }
    if screen==Screen::CreateWorld {
        draw_text_centered(&mut canvas,assets.font.as_ref(),"CREATE NEW WORLD",UI_W as i32/2,20,[255,255,255,255],1);
        if create.advanced {
            draw_text(&mut canvas,assets.font.as_ref(),"SEED FOR THE WORLD GENERATOR",UI_W as i32/2-100,47,[190,190,190,255],1);
            for py in 60..82 { for px in UI_W/2-100..UI_W/2+100 { canvas.put_pixel(px,py,Rgba([0,0,0,220])); } }
            draw_text(&mut canvas,assets.font.as_ref(),create_seed,UI_W as i32/2-94,66,[255,255,255,255],1);
            draw_text(&mut canvas,assets.font.as_ref(),"Leave blank for a random seed",UI_W as i32/2-100,85,[150,150,150,255],1);
            draw_text(&mut canvas,assets.font.as_ref(),"GENERATE STRUCTURES: villages, temples, etc.",UI_W as i32/2-150,122,[170,170,170,255],1);
            draw_text(&mut canvas,assets.font.as_ref(),"ALLOW CHEATS: commands and game mode changes",UI_W as i32/2-150,172,[170,170,170,255],1);
            if create.mode==1 { draw_text_centered(&mut canvas,assets.font.as_ref(),"HARDCORE: CHEATS AND BONUS CHEST ARE DISABLED",UI_W as i32/2,278,[255,190,90,255],1); }
        } else {
            draw_text(&mut canvas,assets.font.as_ref(),"ENTER WORLD NAME",UI_W as i32/2-100,47,[190,190,190,255],1);
            for py in 60..82 { for px in UI_W/2-100..UI_W/2+100 { canvas.put_pixel(px,py,Rgba([0,0,0,220])); } }
            draw_text(&mut canvas,assets.font.as_ref(),create_name,UI_W as i32/2-94,66,[255,255,255,255],1);
            let folder: String = create_name.trim().chars().map(|c| if matches!(c, '/' | '\\' | ':' | '*' | '?' | '"' | '<' | '>' | '|') { '_' } else { c }).collect();
            draw_text(&mut canvas,assets.font.as_ref(),&format!("Will be saved as: {}",if folder.is_empty(){"World"}else{&folder}),UI_W as i32/2-100,85,[150,150,150,255],1);
            draw_text(&mut canvas,assets.font.as_ref(),match create.mode {1=>"Hardcore: locked to hard difficulty",2=>"Creative: unlimited blocks and flight",_=>"Survival: gather resources and survive"},UI_W as i32/2-100,137,[170,170,170,255],1);
            draw_text(&mut canvas,assets.font.as_ref(),match create.mode {1=>"One life only",2=>"You can fly and break blocks instantly",_=>"Health, hunger and hostile mobs enabled"},UI_W as i32/2-100,149,[170,170,170,255],1);
        }
        draw_text_centered(&mut canvas,assets.font.as_ref(),"WORLD GENERATION IS NOT ENABLED YET",UI_W as i32/2,UI_H as i32-58,[255,190,90,255],1);
        draw_text_centered(&mut canvas,assets.font.as_ref(),status,UI_W as i32/2,UI_H as i32-44,[220,220,220,255],1);
    }
    if screen==Screen::RenameWorld {
        draw_text_centered(&mut canvas,assets.font.as_ref(),"RENAME WORLD",UI_W as i32/2,UI_H as i32/2-44,[255,255,255,255],1);
        for py in 204..228 { for px in 230..624 { canvas.put_pixel(px,py,Rgba([0,0,0,220])); } }
        draw_text(&mut canvas,assets.font.as_ref(),fields.0,238,212,[255,255,255,255],1);
        draw_text_centered(&mut canvas,assets.font.as_ref(),"ENTER A NEW DISPLAY NAME (1-32 CHARACTERS)",UI_W as i32/2,UI_H as i32/2+4,[190,190,190,255],1);
        draw_text_centered(&mut canvas,assets.font.as_ref(),status,UI_W as i32/2,UI_H as i32/2+72,[255,190,90,255],1);
    }
    if screen==Screen::ConfirmDeleteWorld {
        draw_text_centered(&mut canvas,assets.font.as_ref(),"DELETE WORLD?",UI_W as i32/2,UI_H as i32/2-36,[255,255,255,255],1);
        draw_text_centered(&mut canvas,assets.font.as_ref(),"WORLD WILL BE MOVED TO .MC189-TRASH",UI_W as i32/2,UI_H as i32/2-12,[220,220,220,255],1);
        draw_text_centered(&mut canvas,assets.font.as_ref(),fields.0,UI_W as i32/2,UI_H as i32/2+6,[255,255,255,255],1);
    }
    if screen==Screen::ConfirmDelete {
        draw_text_centered(&mut canvas,assets.font.as_ref(),"DELETE SERVER?",UI_W as i32/2,UI_H as i32/2-28,[255,255,255,255],1);
        draw_text_centered(&mut canvas,assets.font.as_ref(),"THIS CANNOT BE UNDONE",UI_W as i32/2,UI_H as i32/2-8,[220,220,220,255],1);
    }
    if screen==Screen::Options { draw_text_centered(&mut canvas,assets.font.as_ref(),"OPTIONS",UI_W as i32/2,130,[255,255,255,255],2); draw_text_centered(&mut canvas,assets.font.as_ref(),"SETTINGS WILL BE ADDED HERE",UI_W as i32/2,220,[220,220,220,255],1); }
    // Exact lower corners used by GuiMainMenu.drawScreen().
    if screen == Screen::Main {
        draw_text(&mut canvas,assets.font.as_ref(),"Minecraft 1.8.9",2,UI_H as i32-10,[255,255,255,255],1);
        draw_text(&mut canvas,assets.font.as_ref(),"Copyright Mojang AB. Do not distribute!",UI_W as i32-220,UI_H as i32-10,[255,255,255,255],1);
    } else {
        draw_text(&mut canvas,assets.font.as_ref(),"Copyright Mojang AB. Do not distribute!",UI_W as i32-220,UI_H as i32-10,[255,255,255,190],1);
    }
    canvas
}
fn draw_rotated_text(img: &mut RgbaImage, font: Option<&RgbaImage>, text: &str, cx: i32, cy: i32, degrees: f32, scale: f32, color: [u8;4]) {
    let width = (text.chars().map(|c| glyph_width(font,c) as i32 + 1).sum::<i32>() + 2).max(1) as u32;
    let mut stamp = RgbaImage::from_pixel(width, 12, Rgba([0,0,0,0]));
    draw_text(&mut stamp, font, text, 1, 2, color, 1);
    let stamp=imageops::resize(&stamp,((width as f32*scale).round() as u32).max(1),((12.0*scale).round() as u32).max(1),imageops::FilterType::Nearest);
    let angle = degrees.to_radians(); let (sin,cos) = angle.sin_cos();
    let ox = stamp.width() as f32 * 0.5; let oy = stamp.height() as f32 * 0.5;
    for sy in 0..stamp.height() { for sx in 0..stamp.width() {
        let p=stamp.get_pixel(sx,sy); if p[3]==0 {continue;}
        let dx=sx as f32-ox; let dy=sy as f32-oy;
        let x=(cx as f32+dx*cos-dy*sin).round() as i32;
        let y=(cy as f32+dx*sin+dy*cos).round() as i32;
        if x>=0 && y>=0 && (x as u32)<img.width() && (y as u32)<img.height(){img.put_pixel(x as u32,y as u32,*p);}
    }}
}

fn draw_button_fallback(img:&mut RgbaImage,x:u32,y:u32,w:u32,h:u32,hover:bool){
    let base=if hover{[110,110,110,255]}else{[65,65,65,255]};
    for py in y..y+h { for px in x..x+w { let edge=px==x||px==x+w-1||py==y||py==y+h-1; img.put_pixel(px,py,Rgba(if edge{[20,20,20,255]}else{base})); } }
}
fn draw_text_centered(img:&mut RgbaImage,font:Option<&RgbaImage>,text:&str,cx:i32,y:i32,color:[u8;4],scale:i32){let width=text.chars().map(|c|glyph_width(font,c) as i32+1).sum::<i32>()*scale-scale;draw_text(img,font,text,cx-width/2,y,color,scale);}
fn glyph_width(font:Option<&RgbaImage>,ch:char)->u32{if let Some(font)=font{let code=ch as u32;if code<256&&font.width()>=128&&font.height()>=128{let sx=(code as u32%16)*8;let sy=(code as u32/16)*8;let mut right=0;for x in 0..8{for y in 0..8{if font.get_pixel(sx+x,sy+y)[3]>0{right=right.max(x+1);}}}return right.max(1);}}5}
fn draw_text(img: &mut RgbaImage, font: Option<&RgbaImage>, text: &str, x: i32, y: i32, color: [u8; 4], scale: i32) {
    let mut pen = x;
    for ch in text.chars() {
        if let Some(font) = font {
            let code = ch as u32;
            if code < 256 && font.width() >= 128 && font.height() >= 128 {
                let sx = (code % 16) * 8;
                let sy = (code / 16) * 8;
                let width = glyph_width(Some(font), ch);
                for gy in 0..8 {
                    for gx in 0..width {
                        let alpha = font.get_pixel(sx + gx, sy + gy)[3];
                        if alpha == 0 { continue; }
                        for dy in 0..scale {
                            for dx in 0..scale {
                                let px = pen + gx as i32 * scale + dx;
                                let py = y + gy as i32 * scale + dy;
                                if px >= 0 && py >= 0 && (px as u32) < img.width() && (py as u32) < img.height() {
                                    img.put_pixel(px as u32, py as u32, Rgba([color[0], color[1], color[2], ((alpha as u16 * color[3] as u16) / 255) as u8]));
                                }
                            }
                        }
                    }
                }
                pen += (width as i32 + 1) * scale;
                continue;
            }
        }
        let rows = glyph(ch);
        for (ry, bits) in rows.iter().enumerate() {
            for rx in 0..5 {
                if bits & (1 << (4 - rx)) == 0 { continue; }
                for sy in 0..scale {
                    for sx in 0..scale {
                        let px = pen + rx * scale + sx;
                        let py = y + ry as i32 * scale + sy;
                        if px >= 0 && py >= 0 && (px as u32) < img.width() && (py as u32) < img.height() {
                            img.put_pixel(px as u32, py as u32, Rgba(color));
                        }
                    }
                }
            }
        }
        pen += 6 * scale;
    }
}

fn glyph(ch:char)->[u8;7]{match ch.to_ascii_uppercase(){
'A'=>[14,17,17,31,17,17,17],'B'=>[30,17,17,30,17,17,30],'C'=>[14,17,16,16,16,17,14],'D'=>[30,17,17,17,17,17,30],'E'=>[31,16,16,30,16,16,31],'F'=>[31,16,16,30,16,16,16],'G'=>[14,17,16,23,17,17,15],'H'=>[17,17,17,31,17,17,17],'I'=>[14,4,4,4,4,4,14],'J'=>[7,2,2,2,18,18,12],'K'=>[17,18,20,24,20,18,17],'L'=>[16,16,16,16,16,16,31],'M'=>[17,27,21,21,17,17,17],'N'=>[17,25,21,19,17,17,17],'O'=>[14,17,17,17,17,17,14],'P'=>[30,17,17,30,16,16,16],'Q'=>[14,17,17,17,21,18,13],'R'=>[30,17,17,30,20,18,17],'S'=>[15,16,16,14,1,1,30],'T'=>[31,4,4,4,4,4,4],'U'=>[17,17,17,17,17,17,14],'V'=>[17,17,17,17,17,10,4],'W'=>[17,17,17,21,21,21,10],'X'=>[17,17,10,4,10,17,17],'Y'=>[17,17,10,4,4,4,4],'Z'=>[31,1,2,4,8,16,31], '0'=>[14,17,19,21,25,17,14],'1'=>[4,12,4,4,4,4,14],'2'=>[14,17,1,2,4,8,31],'3'=>[30,1,1,14,1,1,30],'4'=>[2,6,10,18,31,2,2],'5'=>[31,16,16,30,1,1,30],'6'=>[14,16,16,30,17,17,14],'7'=>[31,1,2,4,8,8,8],'8'=>[14,17,17,14,17,17,14],'9'=>[14,17,17,15,1,1,14],'.'=>[0,0,0,0,0,12,12],'-'=>[0,0,0,31,0,0,0],':'=>[0,12,12,0,12,12,0],' '=>[0;7],_=>[0;7]}}

pub fn run(saves:&Path,jar:&Path,atlas:&Path)->Result<()> {
    if !saves.is_dir(){return Err(Mc189Error::Usage(format!("saves directory does not exist: {}",saves.display())))}
    let assets=MenuAssets::load(jar)?;
    let mut worlds=world_catalog::discover_worlds(saves)?;
    println!("Minecraft 1.8.9 title screen | panorama, logo and widgets loaded from client.jar");
    let mut event_loop=EventLoop::new().map_err(|e|Mc189Error::InvalidData(format!("cannot create title-screen event loop: {e}")))?;
    event_loop.set_control_flow(ControlFlow::WaitUntil(std::time::Instant::now() + std::time::Duration::from_millis(16)));
    let window=Arc::new(WindowBuilder::new().with_title("Minecraft 1.8.9").with_inner_size(PhysicalSize::new(854,480)).with_min_inner_size(PhysicalSize::new(640,360)).build(&event_loop).map_err(|e|Mc189Error::InvalidData(format!("cannot create title-screen window: {e}")))?);
    let gpu = Rc::new(RefCell::new(Some(pollster::block_on(MenuGpu::new(window.clone(),&assets))?)));
    let gpu_events = gpu.clone();
    let window_events = window.clone();
    let mut create_options=CreateWorldOptions::default(); let mut create_world_name=String::from("New World"); let mut create_world_seed=String::new(); let mut create_focus:Option<u8>=None;
    let mut screen=Screen::Main; let mut cursor=(0,0); let mut current_buttons=buttons(screen,&worlds,&create_options); let mut hover=None; let mut servers=load_servers(saves); let mut server_name=String::from("My Server"); let mut server_host=String::from("127.0.0.1"); let mut server_port=String::new(); let mut username=String::from("Player"); let mut focused:Option<u8>=None; let mut play_events:Option<Receiver<PlayEvent>>=None; let mut status=String::from("Offline handshake: only online-mode=false servers"); let mut selected_server:Option<usize>=None; let mut selected_world:Option<usize>=None; let mut world_name=String::new(); let mut last_world_click:Option<(usize,std::time::Instant)>=None; let launch_world=Arc::new(std::sync::Mutex::new(None::<PathBuf>)); let launch_world_events=launch_world.clone();
    // Keep the original Mojang boot splash visible briefly after the native
    // window/GPU are ready; the main menu replaces it through the event loop.
    let boot_until = std::time::Instant::now() + std::time::Duration::from_millis(1400);
    let mut boot_visible = true;
    let mut overlay=make_mojang_overlay(&assets);gpu.borrow_mut().as_mut().expect("menu GPU is alive").upload_overlay(&overlay);window.request_redraw();
    event_loop.run_on_demand(move |event,event_loop|{match event{
        Event::WindowEvent{window_id,event} if window_id==window_events.id()=>match event{
            WindowEvent::CloseRequested=>event_loop.exit(),
            WindowEvent::Resized(size)=>{gpu_events.borrow_mut().as_mut().expect("menu GPU is alive").resize(size);window_events.request_redraw();},
            WindowEvent::CursorMoved{position,..}=>{let x=(position.x/gpu_events.borrow().as_ref().expect("menu GPU is alive").window_size.width.max(1) as f64*UI_W as f64).clamp(0.0,(UI_W-1) as f64) as u32;let y=(position.y/gpu_events.borrow().as_ref().expect("menu GPU is alive").window_size.height.max(1) as f64*UI_H as f64).clamp(0.0,(UI_H-1) as f64) as u32;cursor=(x,y);let next=current_buttons.iter().position(|b|hit(b,cursor));if next!=hover{hover=next;overlay=make_overlay(&assets,screen,&worlds,hover,&servers,(if screen==Screen::RenameWorld||screen==Screen::ConfirmDeleteWorld{&world_name}else{&server_name},&server_host,&server_port,&username),&status,&create_world_name,&create_world_seed,&create_options);gpu_events.borrow_mut().as_mut().expect("menu GPU is alive").upload_overlay(&overlay);window_events.request_redraw();}},
            WindowEvent::MouseInput{state:ElementState::Released,button:MouseButton::Left,..}=>{
                if screen==Screen::CreateWorld {
                    create_focus=if cursor.0>=UI_W/2-100 && cursor.0<UI_W/2+100 && cursor.1>=60 && cursor.1<82 {Some(if create_options.advanced {1}else{0})} else {None};
                }
                if screen==Screen::ServerEntry || screen==Screen::DirectConnect {
                    focused=if screen==Screen::DirectConnect {
                        if cursor.0>=210&&cursor.0<644&&cursor.1>=204&&cursor.1<228{Some(1)}else if cursor.0>=210&&cursor.0<644&&cursor.1>=238&&cursor.1<262{Some(2)}else{None}
                    } else if cursor.0>=210&&cursor.0<644&&cursor.1>=170&&cursor.1<194{Some(0)}else if cursor.0>=210&&cursor.0<644&&cursor.1>=204&&cursor.1<228{Some(1)}else if cursor.0>=210&&cursor.0<644&&cursor.1>=238&&cursor.1<262{Some(2)}else{None};
                }
                if screen==Screen::Multiplayer && cursor.0>=32&&cursor.0<822&&cursor.1>=34&&cursor.1<394 {
                    let idx=((cursor.1-34)/36) as usize;
                    if let Some(server)=servers.get(idx){selected_server=Some(idx);server_name=server.name.clone();server_host=server.host.clone();server_port=if server.port==DEFAULT_MINECRAFT_PORT { String::new() } else { server.port.to_string() };status=format!("Selected {}",server.name);}
                }
                if screen==Screen::ServerEntry || screen==Screen::DirectConnect || screen==Screen::Multiplayer {
                    overlay=make_overlay(&assets,screen,&worlds,hover,&servers,(if screen==Screen::RenameWorld||screen==Screen::ConfirmDeleteWorld{&world_name}else{&server_name},&server_host,&server_port,&username),&status,&create_world_name,&create_world_seed,&create_options);gpu_events.borrow_mut().as_mut().expect("menu GPU is alive").upload_overlay(&overlay);window_events.request_redraw();
                }
                if let Some(index)=hover{if let Some(b)=current_buttons.get(index){match b.action{
                Action::Quit=>event_loop.exit(),Action::Options=>screen=Screen::Options,Action::Singleplayer=>screen=Screen::Worlds,Action::Multiplayer=>{screen=Screen::Multiplayer;focused=None;},Action::Back=>screen=match screen{Screen::ServerEntry|Screen::DirectConnect|Screen::ConfirmDelete=>Screen::Multiplayer,Screen::CreateWorld|Screen::RenameWorld|Screen::ConfirmDeleteWorld=>Screen::Worlds,_=>Screen::Main},Action::Disabled|Action::Realms|Action::Language=>{},
                Action::AddServer=>{server_name="My Server".into();server_host=String::new();server_port=String::new();screen=Screen::ServerEntry;focused=Some(0);},
                Action::DirectConnect=>{server_name="Direct Connect".into();server_host=String::new();server_port=String::new();screen=Screen::DirectConnect;focused=Some(1);},
                Action::CreateWorld=>{screen=Screen::CreateWorld;create_options=CreateWorldOptions::default();create_world_name="New World".into();create_world_seed.clear();create_focus=Some(0);status="World generation is not enabled yet; settings can be configured.".into();},
                Action::ToggleCreateAdvanced=>{create_options.advanced=!create_options.advanced;create_focus=if create_options.advanced {Some(1)}else{Some(0)};},
                Action::CycleCreateMode=>{create_options.mode=(create_options.mode+1)%3;if create_options.mode==1{if !create_options.cheats_user_set{create_options.cheats=false;}create_options.bonus_chest=false;}else if create_options.mode==2&&!create_options.cheats_user_set{create_options.cheats=true;}else if create_options.mode==0&&!create_options.cheats_user_set{create_options.cheats=false;}},
                Action::ToggleCreateStructures=>{create_options.structures=!create_options.structures;},
                Action::CycleCreateWorldType=>{create_options.world_type=(create_options.world_type+1)%5;},
                Action::ToggleCreateCheats=>{if create_options.mode!=1{create_options.cheats=!create_options.cheats;create_options.cheats_user_set=true;}},
                Action::ToggleCreateBonus=>{if create_options.mode!=1{create_options.bonus_chest=!create_options.bonus_chest;}},
                Action::RenameWorld=>{if selected_world.and_then(|i|worlds.get(i)).is_some(){screen=Screen::RenameWorld;world_name=selected_world.and_then(|i|worlds.get(i)).map(|w|w.metadata.level_name.as_deref().unwrap_or(&w.folder_name).to_string()).unwrap_or_default();focused=Some(0);status.clear();}else{status="Select a world first".into();}},
                Action::DeleteWorld=>{if selected_world.and_then(|i|worlds.get(i)).is_some(){screen=Screen::ConfirmDeleteWorld;}else{status="Select a world first".into();}},
                Action::ConfirmDeleteWorldYes=>{if let Some(world)=selected_world.and_then(|i|worlds.get(i)){match world_catalog::quarantine_world(saves,world){Ok(path)=>status=format!("World moved to {}",path.file_name().unwrap_or_default().to_string_lossy()),Err(e)=>status=format!("Could not delete world: {e}")}}selected_world=None;worlds=world_catalog::discover_worlds(saves).unwrap_or_default();screen=Screen::Worlds;},
                Action::ConfirmDeleteWorldNo=>{screen=Screen::Worlds;},
                Action::SaveWorldName=>{let selected_path=selected_world.and_then(|i|worlds.get(i)).map(|w|w.path.clone());if let Some(world)=selected_world.and_then(|i|worlds.get(i)){match world_catalog::rename_world_display_name(world,&world_name){Ok(())=>status="World renamed".into(),Err(e)=>status=format!("Could not rename world: {e}")}}worlds=world_catalog::discover_worlds(saves).unwrap_or_default();selected_world=selected_path.and_then(|path|worlds.iter().position(|w|w.path==path));if let Some(i)=selected_world{status=format!("Selected {}",worlds[i].metadata.level_name.as_deref().unwrap_or(&worlds[i].folder_name));}screen=Screen::Worlds;},
                Action::LaunchSelectedWorld=>{if let Some(world)=selected_world.and_then(|i|worlds.get(i)){*launch_world_events.lock().unwrap()=Some(world.path.clone());event_loop.exit();return;}},
                Action::ConfirmDeleteYes=>{if let Some(i)=selected_server.take(){if i<servers.len(){servers.remove(i);match save_servers(saves,&servers){Ok(())=>status="Server deleted".into(),Err(e)=>status=format!("Could not save server list: {e}")}}}screen=Screen::Multiplayer;},
                Action::ConfirmDeleteNo=>{screen=Screen::Multiplayer;},
                Action::EditServer=>{screen=Screen::ServerEntry;focused=Some(0);},
                Action::DeleteServer=>{if selected_server.is_some(){screen=Screen::ConfirmDelete;}else{status="Select a server first".into();}},
                Action::RefreshServers=>{servers=load_servers(saves);selected_server=None;status="Server list refreshed".into();},
                Action::ConnectSelected=>{
                    if let Some(server)=selected_server.and_then(|i|servers.get(i)) {
                        match connect_offline((server.host.trim(),server.port),server.host.trim(),server.port,username.trim()) {
                            Ok(connection)=>{let user=connection.username.clone();status=format!("PLAY CONNECTED | {user} | receiving server packets...");play_events=Some(start_play_session(connection));}
                            Err(e)=>status=format!("Handshake/login failed: {e}")
                        }
                    } else {status="Select a server from the list first".into();}
                },
                Action::SaveServer=>{
                    let parsed=selected_port(&server_port);
                    if server_name.trim().is_empty() || server_host.trim().is_empty() || parsed.is_err() { status=parsed.err().unwrap_or_else(||"Server name and address are required".into()); }
                    else { let entry=SavedServer{name:server_name.trim().to_string(),host:server_host.trim().to_string(),port:parsed.unwrap()};
                        if let Some(old)=servers.iter_mut().find(|s|s.host==entry.host&&s.port==entry.port){*old=entry;}else{servers.push(entry);}
                        match save_servers(saves,&servers){Ok(())=>status="Server saved".into(),Err(e)=>status=format!("Could not save server: {e}")}
                        screen=Screen::Multiplayer;
                    }
                },
                Action::ConnectServer=>{
                    match selected_port(&server_port) {
                        Ok(port) => { status=format!("Connecting to {}:{} ...",server_host,port); 
                            match connect_offline((server_host.trim(),port),server_host.trim(),port,username.trim()) {
                                Ok(connection)=>{ let username=connection.username.clone(); status=format!("PLAY CONNECTED | {username} | receiving server packets..."); play_events=Some(start_play_session(connection)); }
                                Err(e)=>status=format!("Handshake/login failed: {e}")
                            }
                        }, Err(message)=>status=message
                    }
                },
                Action::World(i)=>{let now=std::time::Instant::now();let double_click=last_world_click.is_some_and(|(previous,at)|previous==i&&now.duration_since(at).as_millis()<=500);last_world_click=Some((i,now));selected_world=Some(i);world_name=worlds.get(i).map(|w|w.metadata.level_name.as_deref().unwrap_or(&w.folder_name).to_string()).unwrap_or_default();status=worlds.get(i).map(|w|format!("Selected {}",w.metadata.level_name.as_deref().unwrap_or(&w.folder_name))).unwrap_or_default();if double_click{if let Some(world)=worlds.get(i){*launch_world_events.lock().unwrap()=Some(world.path.clone());event_loop.exit();return;}}}
            }current_buttons=buttons(screen,&worlds,&create_options);hover=None;overlay=make_overlay(&assets,screen,&worlds,hover,&servers,(if screen==Screen::RenameWorld||screen==Screen::ConfirmDeleteWorld{&world_name}else{&server_name},&server_host,&server_port,&username),&status,&create_world_name,&create_world_seed,&create_options);gpu_events.borrow_mut().as_mut().expect("menu GPU is alive").upload_overlay(&overlay);window_events.request_redraw();}}},
            WindowEvent::KeyboardInput{event,..} if event.state==ElementState::Pressed=>{
                if boot_visible { return; }
                if screen==Screen::CreateWorld {
                    if event.physical_key==PhysicalKey::Code(KeyCode::Tab) { create_focus=Some(if create_options.advanced {1}else{0}); }
                    else if event.physical_key==PhysicalKey::Code(KeyCode::Backspace) { if create_focus==Some(0){create_world_name.pop();}else if create_focus==Some(1){create_world_seed.pop();} }
                    else if let Some(text)=event.text.as_ref(){if let Some(field)=create_focus{let target=if field==0{&mut create_world_name}else{&mut create_world_seed};for ch in text.chars(){if !ch.is_control() && target.chars().count() < (if field==0 {32}else{128}) {target.push(ch);}}}}
                    overlay=make_overlay(&assets,screen,&worlds,hover,&servers,(&world_name,&server_host,&server_port,&username),&status,&create_world_name,&create_world_seed,&create_options);gpu_events.borrow_mut().as_mut().expect("menu GPU is alive").upload_overlay(&overlay);window_events.request_redraw();
                }
                if screen==Screen::RenameWorld {
                    if event.physical_key==PhysicalKey::Code(KeyCode::Backspace) { world_name.pop(); }
                    else if let Some(text)=event.text.as_ref() { for ch in text.chars(){if !ch.is_control() && world_name.chars().count()<32 { world_name.push(ch); }} }
                    overlay=make_overlay(&assets,screen,&worlds,hover,&servers,(&world_name,&server_host,&server_port,&username),&status,&create_world_name,&create_world_seed,&create_options);gpu_events.borrow_mut().as_mut().expect("menu GPU is alive").upload_overlay(&overlay);window_events.request_redraw();
                }
                if screen==Screen::ServerEntry || screen==Screen::DirectConnect {
                    if event.physical_key==PhysicalKey::Code(KeyCode::Backspace) { if let Some(field)=focused { let target=match field{0=>&mut server_name,1=>&mut server_host,2=>&mut server_port,_=>&mut username}; target.pop(); } }
                    else if event.physical_key==PhysicalKey::Code(KeyCode::Tab) { focused=Some(focused.map(|v|(v+1)%4).unwrap_or(0)); }
                    else if let Some(text)=event.text.as_ref() { if let Some(field)=focused { let target=match field{0=>&mut server_name,1=>&mut server_host,2=>&mut server_port,_=>&mut username}; for ch in text.chars(){if !ch.is_control() && target.len()<255 && (field!=2 || ch.is_ascii_digit()){target.push(ch);}} } }
                }
                if screen==Screen::ServerEntry || screen==Screen::DirectConnect { overlay=make_overlay(&assets,screen,&worlds,hover,&servers,(if screen==Screen::RenameWorld||screen==Screen::ConfirmDeleteWorld{&world_name}else{&server_name},&server_host,&server_port,&username),&status,&create_world_name,&create_world_seed,&create_options);gpu_events.borrow_mut().as_mut().expect("menu GPU is alive").upload_overlay(&overlay);window_events.request_redraw(); }
                if event.physical_key==PhysicalKey::Code(KeyCode::Escape){if screen==Screen::Main{event_loop.exit();}else{screen=match screen{Screen::ServerEntry|Screen::DirectConnect|Screen::ConfirmDelete=>Screen::Multiplayer,Screen::CreateWorld|Screen::RenameWorld|Screen::ConfirmDeleteWorld=>Screen::Worlds,_=>Screen::Main};current_buttons=buttons(screen,&worlds,&create_options);hover=None;overlay=make_overlay(&assets,screen,&worlds,hover,&servers,(if screen==Screen::RenameWorld||screen==Screen::ConfirmDeleteWorld{&world_name}else{&server_name},&server_host,&server_port,&username),&status,&create_world_name,&create_world_seed,&create_options);gpu_events.borrow_mut().as_mut().expect("menu GPU is alive").upload_overlay(&overlay);window_events.request_redraw();}}},
            WindowEvent::RedrawRequested=>{
                // Do not keep the RefCell mutable borrow alive across the match.
                // In particular, SurfaceError::Lost/Outdated must be able to
                // borrow the GPU again to read the size and reconfigure it.
                let render_result = {
                    let mut gpu_ref = gpu_events.borrow_mut();
                    gpu_ref.as_mut().expect("menu GPU is alive").render()
                };
                match render_result {
                    Ok(()) => {},
                    Err(wgpu::SurfaceError::Lost | wgpu::SurfaceError::Outdated) => {
                        let size = gpu_events.borrow().as_ref().expect("menu GPU is alive").window_size;
                        gpu_events.borrow_mut().as_mut().expect("menu GPU is alive").resize(size);
                        window_events.request_redraw();
                    },
                    Err(wgpu::SurfaceError::Timeout) => {},
                    Err(wgpu::SurfaceError::OutOfMemory) => event_loop.exit(),
                }
            },
            _=>{}},
        Event::AboutToWait=>{
            if !boot_visible && screen==Screen::Main {
                overlay=make_overlay(&assets,screen,&worlds,hover,&servers,(if screen==Screen::RenameWorld||screen==Screen::ConfirmDeleteWorld{&world_name}else{&server_name},&server_host,&server_port,&username),&status,&create_world_name,&create_world_seed,&create_options);
                gpu_events.borrow_mut().as_mut().expect("menu GPU is alive").upload_overlay(&overlay);
            }
            if boot_visible && std::time::Instant::now() >= boot_until {
                boot_visible = false;
                overlay=make_overlay(&assets,screen,&worlds,hover,&servers,(if screen==Screen::RenameWorld||screen==Screen::ConfirmDeleteWorld{&world_name}else{&server_name},&server_host,&server_port,&username),&status,&create_world_name,&create_world_seed,&create_options);
                gpu_events.borrow_mut().as_mut().expect("menu GPU is alive").upload_overlay(&overlay);
                window_events.request_redraw();
            }
            if let Some(receiver)=play_events.as_ref() {
                let mut changed=false;
                for event in receiver.try_iter() {
                    status=match event {
                        PlayEvent::Connected{username,..}=>format!("PLAY CONNECTED | {username}"),
                        PlayEvent::Packet{id,name,payload_len}=>format!("PLAY RX 0x{id:02X} {} ({payload_len} bytes)",name.unwrap_or("UNKNOWN")),
                        PlayEvent::KeepAliveAnswered=>"PLAY CONNECTED | Keep Alive answered".into(),
                        PlayEvent::ClientSettingsSent=>"PLAY CONNECTED | Client Settings sent".into(),
                        PlayEvent::PlayerPositionConfirmed{x,y,z,yaw,pitch}=>format!("PLAY CONNECTED | teleport confirmed ({x:.2}, {y:.2}, {z:.2}) yaw {yaw:.1} pitch {pitch:.1}"),
                        PlayEvent::Disconnected(reason)=>format!("SERVER DISCONNECTED: {reason}"),
                        PlayEvent::NetworkError(error)=>format!("PLAY NETWORK ERROR: {error}"),
                    };
                    changed=true;
                }
                if changed && (screen==Screen::Multiplayer || screen==Screen::ServerEntry || screen==Screen::DirectConnect) {
                    overlay=make_overlay(&assets,screen,&worlds,hover,&servers,(if screen==Screen::RenameWorld||screen==Screen::ConfirmDeleteWorld{&world_name}else{&server_name},&server_host,&server_port,&username),&status,&create_world_name,&create_world_seed,&create_options);
                    gpu_events.borrow_mut().as_mut().expect("menu GPU is alive").upload_overlay(&overlay);
                }
            }
            window_events.request_redraw();event_loop.set_control_flow(ControlFlow::WaitUntil(std::time::Instant::now()+std::time::Duration::from_millis(16)));
        },_=>{}}}).map_err(|e|Mc189Error::InvalidData(format!("title-screen event loop failed: {e}")))?;
    drop(gpu.borrow_mut().take());
    let selected_world = launch_world.lock()
        .map_err(|_| Mc189Error::InvalidData("world selection lock was poisoned".into()))?
        .clone();
    if let Some(world_path) = selected_world {
        // Release the menu's GPU surface but keep the exact same native Window
        // and EventLoop. Gameplay recreates only the renderer/surface on that window.
        window.set_title("Minecraft 1.8.9");
        let spawn = crate::player::load_world_spawn(&world_path)?;
        crate::textured_chunk::play_world_in_window(jar, atlas, &world_path, spawn, &mut event_loop, window)?;
    }
    Ok(())
}

const MENU_SHADER:&str=r#"
struct Params { time:f32, aspect:f32, pad0:f32, pad1:f32 };
@group(0) @binding(0) var panorama:texture_cube<f32>;
@group(0) @binding(1) var linear_sampler:sampler;
@group(0) @binding(2) var ui:texture_2d<f32>;
@group(0) @binding(3) var<uniform> params:Params;
@group(0) @binding(4) var ui_sampler:sampler;
struct Out{@builtin(position) position:vec4<f32>,@location(0) uv:vec2<f32>};
@vertex fn vs_main(@builtin(vertex_index)i:u32)->Out{var p=array<vec2<f32>,3>(vec2<f32>(-1.0,-1.0),vec2<f32>(3.0,-1.0),vec2<f32>(-1.0,3.0));var o:Out;o.position=vec4<f32>(p[i],0.0,1.0);o.uv=vec2<f32>((p[i].x+1.0)*0.5,1.0-(p[i].y+1.0)*0.5);return o;}
fn rotate_y(v:vec3<f32>,a:f32)->vec3<f32>{let c=cos(a);let s=sin(a);return vec3<f32>(c*v.x-s*v.z,v.y,s*v.x+c*v.z);}
fn rotate_x(v:vec3<f32>,a:f32)->vec3<f32>{let c=cos(a);let s=sin(a);return vec3<f32>(v.x,c*v.y-s*v.z,s*v.y+c*v.z);}
fn rotate_z(v:vec3<f32>,a:f32)->vec3<f32>{let c=cos(a);let s=sin(a);return vec3<f32>(c*v.x-s*v.y,s*v.x+c*v.y,v.z);}
fn panorama_rotation(v:vec3<f32>,yaw:f32,pitch:f32)->vec3<f32>{return rotate_x(rotate_z(rotate_x(rotate_y(v,yaw),pitch),1.570796327),3.141592654);}
fn panorama_blur_weight(k:i32)->f32{
    // Naga/wgpu 0.19 requires constant indexing for function-local arrays.
    // A switch preserves the exact binomial 15-tap kernel without dynamic indexing.
    switch k {
        case 0: { return 1.0; }
        case 1: { return 7.0; }
        case 2: { return 28.0; }
        case 3: { return 84.0; }
        case 4: { return 210.0; }
        case 5: { return 420.0; }
        case 6: { return 588.0; }
        case 7: { return 686.0; }
        case 8: { return 588.0; }
        case 9: { return 420.0; }
        case 10: { return 210.0; }
        case 11: { return 84.0; }
        case 12: { return 28.0; }
        case 13: { return 7.0; }
        case 14: { return 1.0; }
        default: { return 0.0; }
    }
}
fn sample_blurred(direction:vec3<f32>,right:vec3<f32>,up:vec3<f32>)->vec3<f32>{
    // Combined 15-tap kernel of seven vanilla three-tap horizontal blur passes.
    var sum=vec3<f32>(0.0);
    for(var k:i32=0;k<15;k=k+1){
        let offset=(f32(k)-7.0)/256.0;
        sum += textureSample(panorama,linear_sampler,normalize(direction+right*offset)).rgb*panorama_blur_weight(k);
    }
    return sum/2187.0;
}
@fragment fn fs_main(in:Out)->@location(0) vec4<f32>{
    let uv=in.uv;
    let fov_scale=1.7320508;
    let screen=vec2<f32>((uv.x-0.5)*params.aspect,0.5-uv.y)*fov_scale;
    let ticks=params.time*20.0;
    let pitch=0.34906585+sin(ticks/400.0)*0.4363323;
    let yaw=-ticks*0.00174532925;
    let direction=panorama_rotation(normalize(vec3<f32>(screen,1.0)),yaw,pitch);
    let right=panorama_rotation(vec3<f32>(1.0,0.0,0.0),yaw,pitch);
    let up=panorama_rotation(vec3<f32>(0.0,1.0,0.0),yaw,pitch);
    let bg=sample_blurred(direction,right,up);
    let overlay=textureSample(ui,ui_sampler,uv);
    return vec4<f32>(mix(bg,overlay.rgb,overlay.a),1.0);
}
"#;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn non_title_background_uses_tiled_darkened_vanilla_dirt() {
        let texture = RgbaImage::from_pixel(16, 16, Rgba([200, 160, 120, 255]));
        let mut canvas = RgbaImage::from_pixel(64, 64, Rgba([0, 0, 0, 0]));
        draw_vanilla_dirt_background(&mut canvas, &texture);
        assert_eq!(*canvas.get_pixel(0, 0), Rgba([50, 40, 30, 255]));
        assert_eq!(*canvas.get_pixel(31, 31), Rgba([50, 40, 30, 255]));
        assert_eq!(*canvas.get_pixel(32, 32), Rgba([50, 40, 30, 255]));
        assert_eq!(*canvas.get_pixel(63, 63), Rgba([50, 40, 30, 255]));
    }

    #[test]
    fn mojang_boot_overlay_is_white_and_centres_the_original_texture() {
        let mut mojang = RgbaImage::from_pixel(256, 256, Rgba([12, 34, 56, 255]));
        mojang.put_pixel(0, 0, Rgba([255, 0, 0, 255]));
        let assets = MenuAssets { panorama: Vec::new(), logo: RgbaImage::new(1, 1), mojang, options_background: RgbaImage::from_pixel(16, 16, Rgba([120, 100, 80, 255])), widgets: None, font: None, splash: String::new() };
        let overlay = make_mojang_overlay(&assets);
        assert_eq!(overlay.dimensions(), (UI_W, UI_H));
        assert_eq!(*overlay.get_pixel(0, 0), Rgba([255, 255, 255, 255]));
        assert_eq!(*overlay.get_pixel((UI_W - 256) / 2, (UI_H - 256) / 2), Rgba([255, 0, 0, 255]));
        assert_eq!(*overlay.get_pixel((UI_W + 256) / 2 - 1, (UI_H + 256) / 2 - 1), Rgba([12, 34, 56, 255]));
    }

    #[test]
    fn panorama_keeps_front_and_bottom_and_exchanges_only_lateral_faces() {
        // wgpu layers: +X, -X, +Y, -Y, +Z, -Z.
        assert_eq!(CUBE_FACE_TO_MINECRAFT_FILE, [1, 3, 4, 5, 0, 2]);
        assert_eq!(CUBE_FACE_TO_MINECRAFT_FILE[4], 0); // front
        assert_eq!(CUBE_FACE_TO_MINECRAFT_FILE[3], 5); // bottom
    }
    #[test]
    fn title_menu_matches_vanilla_main_button_layout() {
        let b=buttons(Screen::Main,&[],&CreateWorldOptions::default());
        assert_eq!(b.len(),6);
        assert_eq!(b[0].action,Action::Singleplayer);
        assert_eq!(b[0].rect,(327,168,200,20));
        assert_eq!(b[1].action,Action::Multiplayer);
        assert_eq!(b[1].rect,(327,192,200,20));
        assert_eq!(b[2].action,Action::Realms);
        assert_eq!(b[2].rect,(327,216,200,20));
        assert_eq!(b[3].rect,(327,252,98,20));
        assert_eq!(b[4].rect,(429,252,98,20));
        assert_eq!(b[5].rect,(303,252,20,20));
    }
    #[test]
    fn multiplayer_screen_exposes_save_connect_and_back_actions() {
        let b=buttons(Screen::Multiplayer,&[],&CreateWorldOptions::default());
        assert_eq!(b.len(),7);
        assert_eq!(b[0].action,Action::ConnectSelected);
        assert_eq!(b[1].action,Action::DirectConnect);
        assert_eq!(b[2].action,Action::AddServer);
        let entry=buttons(Screen::ServerEntry,&[],&CreateWorldOptions::default());
        assert_eq!(entry.len(),3);
        assert_eq!(entry[0].action,Action::SaveServer);
        assert_eq!(entry[2].action,Action::ConnectServer);
    }


    #[test]
    fn create_world_screen_has_vanilla_basic_and_advanced_controls() {
        let basic = CreateWorldOptions::default();
        let buttons = buttons(Screen::CreateWorld, &[], &basic);
        assert!(buttons.iter().any(|b| b.action == Action::CycleCreateMode));
        assert!(buttons.iter().any(|b| b.action == Action::ToggleCreateAdvanced));
        assert!(buttons.iter().any(|b| b.action == Action::Disabled));
        let mut advanced = basic;
        advanced.advanced = true;
        let buttons = buttons(Screen::CreateWorld, &[], &advanced);
        assert!(buttons.iter().any(|b| b.action == Action::ToggleCreateStructures));
        assert!(buttons.iter().any(|b| b.action == Action::CycleCreateWorldType));
        assert!(buttons.iter().any(|b| b.action == Action::ToggleCreateCheats));
        assert!(buttons.iter().any(|b| b.action == Action::ToggleCreateBonus));
        assert!(buttons.iter().any(|b| b.label == "DONE"));
    }

    #[test]
    fn hardcore_ui_state_suppresses_cheats_and_bonus_chest() {
        let mut options = CreateWorldOptions::default();
        options.mode = 1;
        options.cheats = true;
        options.bonus_chest = true;
        let buttons = buttons(Screen::CreateWorld, &[], &CreateWorldOptions { advanced:true, ..options });
        assert!(buttons.iter().any(|b| b.label == "ALLOW CHEATS: OFF"));
        assert!(buttons.iter().any(|b| b.label == "BONUS CHEST: OFF"));
    }

    #[test]
    fn logo_uses_a_small_rightward_optical_offset_without_moving_buttons() {
        let logo_left = ((UI_W - LOGO_W) / 2) as i32 + LOGO_OPTICAL_OFFSET_X;
        let first = button(0, "Singleplayer", Action::Singleplayer);
        let logo_center = logo_left + (LOGO_W / 2) as i32;
        let buttons_center = (first.rect.0 + first.rect.2 / 2) as i32;
        assert_eq!(logo_center - buttons_center, LOGO_OPTICAL_OFFSET_X);
        assert_eq!(BUTTON_X, (UI_W - BUTTON_W) / 2);
    }

    #[test]
    fn world_screen_exposes_world_cards_and_vanilla_action_rows() {
        let buttons = buttons(Screen::Worlds, &[], &CreateWorldOptions::default());
        assert_eq!(buttons.len(), 6);
        assert_eq!(buttons[0].label, "SELECT");
        assert_eq!(buttons[0].action, Action::LaunchSelectedWorld);
        assert_eq!(buttons[5].action, Action::Back);
    }

    #[test]
    fn button_hit_testing_uses_half_open_bounds() {
        let b=button(0,"Singleplayer",Action::Singleplayer);
        assert!(hit(&b,(BUTTON_X,BUTTON_Y)));
        assert!(hit(&b,(BUTTON_X+BUTTON_W-1,BUTTON_Y+BUTTON_H-1)));
        assert!(!hit(&b,(BUTTON_X+BUTTON_W,BUTTON_Y)));
        assert!(!hit(&b,(BUTTON_X,BUTTON_Y+BUTTON_H)));
    }
}

#[cfg(test)]
mod optional_port_tests {
    use super::{selected_port, DEFAULT_MINECRAFT_PORT};
    #[test] fn blank_port_uses_vanilla_default() { assert_eq!(selected_port(""), Ok(DEFAULT_MINECRAFT_PORT)); }
    #[test] fn whitespace_port_uses_vanilla_default() { assert_eq!(selected_port("  "), Ok(DEFAULT_MINECRAFT_PORT)); }
    #[test] fn custom_port_is_preserved() { assert_eq!(selected_port("25570"), Ok(25570)); }
    #[test] fn invalid_and_zero_ports_are_rejected() { assert!(selected_port("0").is_err()); assert!(selected_port("abc").is_err()); }
}
