//! Compatibility re-export: legacy drop resolution is owned by mc189-server.
pub use mc189_server::drop_registry::*;
