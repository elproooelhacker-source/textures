# EntityItem persistence — v2.2.3.129

## Save/load behavior

The integrated server is the owner of world item entities. This patch serializes its snapshots into each Anvil chunk's vanilla `Level.Entities` list. On startup, the server restores item entities from the chunks in its initial collision window; when a new chunk is streamed into the integrated server, its saved `Item` entities are loaded before that chunk becomes the active collision source.

The saved stack includes numeric item ID, count, metadata/damage, and optional stack `tag` NBT. Entity state includes absolute world position, velocity, age, and pickup delay. Previous render position is initialized to the loaded position, and the visual hover phase is reconstructed because it is not part of vanilla EntityItem's persisted NBT.

The renderer uses origin-relative coordinates. Save/load converts X/Z using the world's origin chunk, and chunk assignment uses Euclidean division so negative coordinates map to the correct Anvil chunk.

## Save lifecycle

Entity snapshots are marked dirty whenever the authoritative snapshot changes. They are written through the existing deferred persistence worker during the normal autosave interval and graceful close. The save updates the entity lists in the chunks that have hosted items, including empty lists to remove stale entities after pickup, despawn, or movement into another chunk. Existing unrelated chunk tags are preserved by `MutableChunk`.

## Test plan on Windows

1. Launch using `INICIAR-PRUEBA-MINECRAFT-RUST.bat`.
2. Enter a disposable test world and drop an item with Q, or break a block that drops an item.
3. Wait until the item is visible on the ground, then close the world normally and wait for the final save confirmation.
4. Reopen the same world. The item should appear at its saved location with its remaining pickup delay and age; it should not duplicate.
5. Pick it up, close normally, reopen, and confirm it does not reappear.
6. Repeat near a chunk boundary and at negative X/Z coordinates if possible.

Do not force-close the process during this first test: the feature is integrated with the graceful save barrier, and crash-consistent atomicity across all touched region files is not yet guaranteed.
