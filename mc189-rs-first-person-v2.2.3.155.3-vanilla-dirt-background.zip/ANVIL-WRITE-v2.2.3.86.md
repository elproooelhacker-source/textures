# Anvil/NBT mutable storage — v2.2.3.86

## Added

- Mutable legacy 1.8 chunk representation (`MutableChunk`) retains the complete original NBT tree, including tags this client does not interpret.
- `get_block` / `set_block` operate on 0..255 local chunk Y and legacy 12-bit block IDs + 4-bit metadata.
- Section arrays are edited in the exact 1.8 layout: `Blocks` low byte, optional high-ID `Add` nibbles, and `Data` metadata nibbles.
- Missing sections are created on demand when a non-air block is placed. Setting air in an absent section is a no-op.
- NBT writer supports all tag types 1..12 and validates homogeneous lists, string lengths and nesting depth.
- `save_mutable_chunk` preserves sibling records and timestamps, rebuilds the region sector table, writes a complete temporary file, flushes it, and swaps it into place. The previous region is retained as a uniquely named `.mca.bak-*` recovery copy.
- Invalid/truncated records and overlapping sectors abort the save instead of risking silent region corruption.
- Chunk coordinates are verified against requested world coordinates; negative chunk/region coordinates use Euclidean division.
- Replacing a block removes a matching block entity from `Level.TileEntities` when the block ID changes.
- CLI smoke-test/editor command: `set-world-block <world> <world-x> <world-y> <world-z> <block-id> <metadata>`.

## Important limits

- This is the persistent storage and in-memory block-mutation foundation, not yet the live mining loop. The renderer currently does not call this API after a mouse mining action.
- HeightMap and lighting arrays are preserved, not recalculated. A later world-lighting/mesh invalidation pass is required before using arbitrary edits as a fully simulated gameplay operation. Newly created sections initialize light arrays to zero; they must be relit by that pass.
- Close Minecraft/UltimMC before using the standalone `set-world-block` command. The command does not coordinate file locks with another process.
- Region rewrites retain a backup file beside the `.mca`. Keep it until the edited world has been checked in Minecraft.
- Existing chunks only: this command does not create an entirely new chunk or region entry.


## v2.2.3.87 in-memory extension

The decoded `ChunkData` type now has its own validated setter. This allows the live collision snapshot to be mutated without immediately serializing/reloading NBT. `LoadedWorldCollision::set_block_local` maps local session coordinates to loaded chunk coordinates and errors if the destination chunk is not resident. This is not yet connected to the mining input or renderer; that is the next integration stage.
