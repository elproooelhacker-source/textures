# v2.2.3.69 — Inventario: rendimiento y avatar

- Mantiene el overlay del HUD/inventario en la resolución lógica `ScaledResolution` de Minecraft 1.8.9. La GPU lo amplía con muestreo nearest; se evita redimensionar y subir un framebuffer completo a la GPU cuando solo cambia la selección de la barra rápida.
- Al cambiar de número, solo se recompone el overlay si el slot seleccionado realmente cambia.
- El avatar anterior basado en recortes 2D de la piel se reemplaza por un preview 3D rasterizado de cuboides texturizados, con dimensiones y regiones UV del `ModelBiped`/`ModelPlayer` de 1.8.9, incluidas las capas exteriores de la piel clásica 64×64.
- La rotación del avatar sigue la posición del cursor relativa al ancla vanilla `guiLeft + 51`, `guiTop + 75` (escala nominal 30).
- Al abrir el inventario, el cursor se inicializa en el centro de la ventana; E y Escape cierran la pantalla y restauran el flujo de entrada del juego.
- No se modifican las ecuaciones de iluminación del mundo ni la animación de golpe validada.

## Verificación

- Añadidas pruebas unitarias para la resolución lógica del overlay y los límites de rasterizado del avatar 3D.
- El ZIP se verifica con `zipfile.testzip()`. No se declara compilación ni ejecución de `cargo test` desde este entorno porque el toolchain Rust no está instalado aquí.
