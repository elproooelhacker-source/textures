# v2.2.2 — first-person controls and movement feel

## Fixes
- Corrected lateral movement so A moves toward the player's screen-left and D toward screen-right, using the same right-handed camera basis as the first-person view.
- Added a short jump buffer (140 ms) so a Space press just before landing is not discarded.
- Added a short coyote-time window (100 ms) to make jumping reliable at the edge of a block.
- Replaced instantaneous horizontal velocity changes with ground/air acceleration and ground friction for smoother starts and stops.
- Preserved mouse-look behavior from v2.2.1.

## Tests added/updated
- Buffered jump activates after landing.
- A/D lateral direction follows the first-person camera's screen-space basis.
- Diagonal movement remains normalized while acceleration ramps toward target speed.

## Scope
This is a control/physics correction only. The world still loads a fixed 3x3 chunk window. Dynamic chunk streaming is the next milestone and is intentionally kept separate so movement regressions can be isolated first. World files remain read-only.

## Validation note
The source and archive structure were statically inspected in the packaging environment. Rust/Cargo are not installed there, so `cargo fmt` and `cargo test` must be run on the Windows development machine.
