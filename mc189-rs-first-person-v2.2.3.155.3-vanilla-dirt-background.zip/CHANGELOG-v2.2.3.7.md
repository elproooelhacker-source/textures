# v2.2.3.7 — Dynamic chunk streaming

- Replaced the fixed 3x3 gameplay mesh with independently uploaded per-chunk GPU meshes.
- The player-centered streaming worker loads and builds chunks in the background, prioritizing the nearest chunks around the latest player chunk.
- Initial spawn chunks remain synchronously available so safe-spawn validation and first-frame collision are unchanged.
- Gameplay streams an 11x11 chunk square (radius 5), retains a 15x15 safety window (radius 7), and unloads collision data and GPU meshes outside that retention window.
- Chunk meshes are translated relative to the fixed spawn-chunk origin, preserving stable camera coordinates while the player travels through negative and positive world coordinates.
- Each chunk is meshed with its four horizontal Anvil neighbors so boundary occlusion, contextual block states, and fluid edges remain consistent when chunks are loaded independently.
- At most one completed chunk mesh is uploaded per event-loop iteration to spread GPU upload work across frames.
- The world remains read-only. Missing/corrupt chunks are not fabricated; missing chunks remain collision boundaries until the world actually contains them.
- Added tests for negative-coordinate chunk selection and streaming radius/retention configuration.

Validation note: this archive was prepared in an environment without the Rust toolchain, so `cargo fmt --all` and `cargo test --workspace` must be run on Windows before gameplay validation.
