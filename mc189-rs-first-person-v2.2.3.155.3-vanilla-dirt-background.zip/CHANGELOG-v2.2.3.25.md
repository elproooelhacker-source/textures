# v2.2.3.25 — smooth-lighting world-coordinate correction

## Bug fixed

The v2.2.3.24 vertex-light calculation sampled `CpuMeshQuad.positions` as if they were world coordinates. They are actually chunk-local model coordinates at build time; the streaming worker only translates completed meshes later, relative to the initial spawn chunk. For chunks away from world origin (especially negative coordinates), SkyLight/BlockLight and AO neighbor lookups therefore queried the wrong chunks and often fell back to full brightness. This explains why the previous build could compile and pass its tests while appearing unchanged in-game.

The calculation now adds the source chunk's world origin to each vertex before deriving the world-space light/AO sample positions. Render geometry and streaming translation are unchanged.

## Regression test

`vertex_lighting_samples_world_coordinates_for_negative_chunk_meshes` constructs a chunk at (-16, 15), assigns SkyLight 6/15 to a known vertex sample, and verifies the resulting vertex light is 0.4 rather than the missing-chunk fallback of 1.0.

## Scope

This is a targeted correction to the lighting foundation. Full 1.8.9 AO neighbor-face rules, separate sky/block channels, and the time/weather RGB lightmap remain future work.
