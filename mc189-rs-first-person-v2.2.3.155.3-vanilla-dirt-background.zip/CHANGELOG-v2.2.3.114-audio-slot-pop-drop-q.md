# v2.2.3.114 — audio, slot pop y soltar objetos

- El audio intenta leer primero cualquier `assets/minecraft/sounds.json` y `.ogg` presentes en `client.jar`, y luego usa el almacén original del launcher (`assets/indexes/*.json` + `assets/objects/<sha1>`). La búsqueda incluye la carpeta compartida de UltimMC y `%APPDATA%\.minecraft`; el lanzador acepta índices JSON con nombres distintos de `1.8.json`.
- Los mapas de assets combinan índices disponibles con prioridad para 1.8 y permiten completar objetos de audio ausentes en una copia parcial del índice. La selección de raíz ignora carpetas `assets/indexes` y `assets/objects` vacías, índices sin el objeto OGG presente y directorios virtuales de sonidos vacíos, para que un cache local incompleto no oculte el almacén compartido de UltimMC. Los eventos disponibles se listan explícitamente al cargar.
- La reproducción usa el sink normal de `rodio` para evitar el camino espacial de backend que puede quedar inaudible en ciertos dispositivos de Windows. La atenuación por distancia queda desactivada para estos eventos locales hasta que el audio comparta el marco de coordenadas absoluto de la cámara.
- El icono del pop se rasteriza primero en una superficie aislada de 16x16; no puede sobresalir del rectángulo del slot. El contador queda anclado y se mantiene separado del icono animado.
- Los movimientos y swaps manuales comparan snapshots reales antes/después y adoptan el nuevo estado sin armar pop. Los cambios de stack por pickup o consumo siguen disparando el efecto.
- `Q` suelta un objeto de la ranura hotbar seleccionada; `Ctrl+Q` suelta todo el stack. En la pantalla de inventario se aplica al slot bajo el cursor, igual que el contenedor vanilla.
- El registro numérico de objetos incluye slabs, puertas y vallas de madera adicionales para no perder stacks al soltarlos.
- El asset `client.jar` estándar de 1.8.9 no contiene normalmente los OGG; se leen del almacén oficial del launcher.

No se ejecutó Cargo en este entorno. La compilación y pruebas deben validarse con `EJECUTAR-PRUEBAS-RUST.bat`/`INICIAR-PRUEBA-MINECRAFT-RUST.bat` en Windows.
