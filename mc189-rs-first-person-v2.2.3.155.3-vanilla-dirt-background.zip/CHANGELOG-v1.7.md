# v1.7 — tree and vegetation rendering

- Added species/axis decoding and vanilla blockstate resolution for both legacy log families.
- Added all six leaf species, foliage-colormap tinting, and alpha-cutout handling.
- Added sapling species/stage selectors and model mappings for grass, fern, dead bush,
  flowers, reeds and both halves of all six double-plant species.
- Added log/leaf/vegetation render counters and focused metadata regression tests.
- Corrected the biome colormap pixel coordinate orientation to match Minecraft's
  row-major `temperature << 8 | humidity` lookup.
- No world data or client JAR files are modified.
