# v2.2.3.110 — Pickup animation and persistent player inventory

## MCP 1.8.9 pickup visual

- Added a transient `PickupAnimation` that follows the structure of `EntityPickupFX`.
- The collected item is rendered from its original world position toward the interpolated player position plus 0.5 blocks on Y.
- The interpolation uses `((age + partialTicks) / 3)^2`; the effect expires when its age reaches three ticks, matching the MCP update/render lifetime.
- Inventory insertion remains authoritative and immediate. The animation renders only a visual copy of the amount inserted. If the inventory accepts only part of a stack, the remainder stays as a world item; a full inventory does not consume the entity.

## Player inventory persistence

- Loads `Data.Player.Inventory` and `Data.Player.SelectedItemSlot` from the single-player world's `level.dat`.
- Saves the vanilla 1.8.9 InventoryPlayer slot layout: main/hotbar slots 0–35 and armor slots 100–103.
- Preserves each stack's opaque `ItemStack.tag` NBT payload, including data the current GUI does not interpret, and prevents differently tagged stacks from merging.
- Merges only the owned inventory fields into the existing `Data.Player` compound, retaining other player fields and all unrelated level metadata.
- Writes through `level.dat_new` and the `level.dat_old` backup pattern. Inventory changes are checkpointed by the background world-save worker every five minutes and flushed before a normal world close completes.
- The carried GUI cursor stack remains transient as in vanilla; player position, health, experience, and other player fields are not newly simulated or saved by this patch.

## Tests added

- Three-tick quadratic pickup path and expiry boundary.
- Main inventory, armor, selected slot, and opaque item NBT round-trip.
- Tagged stacks remain distinct when inserting/merging.
- `level.dat` Player patch round-trip with preservation of unrelated player and world metadata.
