# Research notes — v2.2.3.84

## Sources consulted
- MCP 1.8.9 source browser index: https://mc-packet-reference.netlify.app/1.8.9/source/ — lists 155 block classes including `BlockCocoa` and `BlockNetherWart`, and identifies the browser as deobfuscated MCP 1.8.9.
- MCP `Block.java`: https://mc-packet-reference.netlify.app/1.8.9/source/net/minecraft/block/block/ — base drop dispatch uses `quantityDroppedWithBonus(fortune, world.rand)` and the shared `World.rand` stream.
- MCP source repository references: https://github.com/Marcelektro/MavenMCP-1.8.9 and https://github.com/Nilsen84/mcp-1.8.9.

## Local client.jar inspection
- Path used: `/mnt/data/mc189fix/client.jar`
- SHA-256: `14f0d96d1a56fb4f5c3b2233d00699525893fe5ce3dcf181e7de59120595d298`
- Manifest declares `Main-Class: net.minecraft.client.Main`.
- Archive contains obfuscated class names (e.g. short names such as `bgx.class`), not MCP package paths. Signature verification had previously reported the JAR signature bytes verified but the signer certificate/chain is expired or untrusted. A matching mapping set was not present in the working project, so no claim is made that the obfuscated bytecode for the two block classes was individually identified.

## Implementation confidence / next verification
- ID 115 and ID 127 are the legacy registry IDs for Nether Wart and Cocoa.
- Nether Wart age is represented by the low metadata bits; mature harvest is treated separately from immature harvest, with Fortune applied only to the mature quantity path.
- Cocoa age is encoded in metadata bits 2–3; item output is cocoa beans (item 351, damage 3), with mature pods producing three.
- The source index and base `Block` source establish the exact version and shared RNG model, but the browser did not return the individual class source pages in this retrieval. Therefore the specialized per-class quantity formulas still require a direct MCP source/mapping cross-check before claiming byte-for-byte parity. This note deliberately records that limitation rather than overstating the evidence.
