# v2.2.3.62 — integración del pipeline de terreno

- Añadido `GeneratedTerrainChunk`, que agrupa coordenadas, `TerrainPrimer` y contadores de bloques tallados.
- Añadida `generate_overworld_terrain_chunk`, que conecta las etapas existentes en orden: campo de densidad, interpolación, reemplazo de superficie por bioma, cuevas y barrancos.
- La función valida los tamaños de entrada (vecindario de alturas 10×10 y biomas por bloque 16×16) antes de generar.
- Añadida prueba de repetibilidad de la tubería integrada y de rechazo de vecindarios inválidos.

## Límites conocidos

Esta versión integra las piezas ya presentes, pero no completa todavía la generación vanilla: faltan variantes especializadas de superficies (mesa, hielo/nieve), población de features/menas/árboles, estructuras, y paridad exacta de los caminadores y flujos RNG de los carvers. La etapa de población se mantiene separada de `provideChunk`, como en Minecraft 1.8.9.
