# v2.2.3.39

- Fixed the `mc189-app` test build by restoring the test-only `vanilla_face_shade` reference helper.
- The helper delegates to the existing `face_from_normal` and `ao_face_info` directional shading table, so regression tests exercise the same 1.8.x face factors used by mesh lighting.
- No production rendering behavior was changed by this test-only fix.
