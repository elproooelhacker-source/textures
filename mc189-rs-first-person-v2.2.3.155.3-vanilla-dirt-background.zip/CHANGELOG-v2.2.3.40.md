# v2.2.3.40 — Vanilla day/night progression and sky transition

- Added the Minecraft 1.8.9 `WorldProvider.calculateCelestialAngle` easing curve, including fractional world-time interpolation.
- Corrected `World.getSunBrightness` semantics: the vanilla 0.2 minimum ambient contribution is preserved at midnight and rain/thunder attenuate sunlight using the 1.8.x factors.
- The gameplay clock continues to advance at the classic 20 ticks per second, giving a 24,000-tick (20-minute) day, and now drives the sky background and the lightmap together.
- Added a smooth time-dependent overworld sky background with dawn/dusk warm transitions and weather dimming. The current renderer still uses a color background rather than the full vanilla sun, moon, stars, and horizon geometry; those remain separate rendering work.
- Added regression tests for celestial-angle easing, midnight ambient brightness, and day/night/twilight sky color changes.
