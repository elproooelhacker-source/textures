# v1.7.1 — biome colormap type correction

- Generalized biome tint lookup over a small `BiomeColorLookup` trait implemented by both `GrassColorMap` and `FoliageColorMap`.
- Fixes the v1.7 compile error where leaf tint passed a foliage map to a grass-only function.
- Adds a regression test that exercises biome tint lookup with both colormap types.
- No world format, asset format, or intended rendering behavior changes.
