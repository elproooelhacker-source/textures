# v2.2.3.45

- Added cutout rendering for vanilla cobweb and rail models.
- Added mob spawner block collision.
- Corrected title logo assembly from the two vanilla 155x44 source regions.
