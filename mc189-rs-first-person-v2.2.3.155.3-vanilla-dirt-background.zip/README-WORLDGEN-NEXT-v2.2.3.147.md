# Worldgen continuation — v2.2.3.147

Base: v2.2.3.146.

This revision adds the ordinary spruce tree generators from Minecraft Java 1.8.9 MCP (`WorldGenTaiga1` and `WorldGenTaiga2`) and enables their selector for the four normal/cold taiga biome IDs. All attempts share the population `JavaRandom` and the writable 3×3 terrain region.

Next work should port mega-taiga tree selection (`WorldGenMegaPineTree`), then specialized biome trees (swamp, savanna, jungle, roofed forest), and only afterward continue with the remaining flowers/grass/mushrooms/reeds/cactus/dead-bush features in `BiomeDecorator` order. Do not consume placeholder random calls for unimplemented generators: their variable internal random use matters.
