# v2.2.3.98 — mining hitch, hand swing, water refresh and AO corrections

## Addressed from the Windows play-test report

- First-person hand swing tick order now matches MCP: `EntityLivingBase.updateArmSwingProgress()` advances before `Minecraft.sendClickBlockToController()` requests the next swing. The wrapped `0.5 -> 0.0` progress is interpolated through `1.0`, preserving the full animation arc during continuous left-click mining.
- The edited chunk is sorted to the front of the mesh rebuild result and its mesh update is pushed to the front of the gameplay mesh queue. Queued stale versions of the same chunk are removed, so a mined opening and adjacent fluid surfaces do not wait behind distant streamed chunks.
- The main window thread now snapshots only the edited chunk. The serial block-edit worker loads the 5×5 lighting/mesh halo from Anvil after earlier queued edits have committed. This removes a burst of up to 25 `ChunkData` clones from the break frame while preserving the 5×5 relight boundary.
- Dropped item block-model vertices are cached per item state; generated item GPU buffers are persistent/reused and updated through `Queue::write_buffer`. This removes repeated model resolution and repeated GPU buffer allocation at the 20 Hz item-update cadence.
- AO normal-cube evaluation now follows MCP `Block.isBlockNormalCube()`: `Material.blocksMovement() && Block.isFullCube()`. This is deliberately distinct from `isOpaqueCube`, `Material.isSolid`, and `lightOpacity`. `BlockGlass` (ID 20) and stained glass are not full cubes, `BlockLeaves` and `BlockIce` inherit `isFullCube=true`, double slabs remain full cubes, half slabs do not, and `BlockBarrier` keeps its special AO value of 1.0.
- Light-propagation queues no longer enqueue every cell in saturated direct-sky columns. A source is queued only when one of its six neighbors can actually receive a higher light value. This cuts the huge number of no-op BFS nodes created by the 5x5 sky map while preserving propagation toward dark cells, caves and partial-opacity blocks.
- Added regression tests for MCP AO classification, continuous hand-swing wrap interpolation, restoring a water side after removing the opaque neighbor, glass/slab full-cube cases, and skipping saturated direct-sky queue sources.
- The Windows launcher now defaults to the UltimMC `.minecraft` directory and `C:\Users\Admin\Documents\client.jar` path supplied for this play-test; both remain editable at the prompts.

## Verification status

- Static source review and ZIP integrity validation only.
- Cargo/rustc are not available in this authoring environment; Windows compilation, GPU behavior, frame pacing, liquid rendering and lighting must be retested with the included launcher.
- The original world must remain closed in UltimMC while the Rust client is running. The launcher makes a timestamped `saves-backup-mc189-*` copy before launching by default.
