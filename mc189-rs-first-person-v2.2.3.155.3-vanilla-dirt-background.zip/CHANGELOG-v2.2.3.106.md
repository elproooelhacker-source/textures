# v2.2.3.106 — incremental light decrease/reseed and section-local chunk meshes

## Gameplay lighting

- Replaced the routine 3×3 forced light-map reset for block edits with a two-phase local update based on MCP 1.8.9 `World.checkLightFor`: remove values whose old predecessor contribution disappeared, then recompute raw light and re-propagate from surviving sources.
- Uses the vanilla radius-17 Manhattan update boundary and requires the corresponding loaded chunk area. If that exact precondition cannot be satisfied by the worker's in-memory neighborhood, the conservative neighborhood relight remains as a correctness fallback rather than applying a truncated light update.
- Recomputes only the edited HeightMap column when light opacity changes. When the first-air height changes, the skylight update seeds the whole affected vertical interval, mirroring `Chunk.relightBlock` before propagating lateral/vertical effects.
- Preserves surviving nearby emitters during removal and handles light changes crossing chunk borders. The second pass revisits zero-level dependent cells too, matching `World.checkLightFor`; `World.getRawLight`’s opaque-emitter opacity exception is applied to both SKY and BLOCK exactly as in MCP. Out-of-height light reads follow `World.getLightFor` defaults (negative Y clamps to the bottom layer; above build height SKY is 15 and BLOCK is 0).
- Missing light arrays are reconstructed as a baseline only when needed. Normal edits with valid saved light arrays stay on the incremental path.

## Section-local geometry and GPU uploads

- Gameplay mesh targets are now `(chunk, sectionY)` pairs. The edited block and only positions whose saved light value actually changed mark sections for rebuild; the model/AO/fluid neighborhood margin is retained.
- The section builder borrows one prepared neighborhood and walks only the selected 16×16×16 section. It does not clone/rebuild a full neighbor chunk for every mesh target. The persistent worker cache replaces only chunks whose block, HeightMap, or light values changed, instead of recloning all 25 loaded neighbors after every edit.
- GPU chunk meshes keep independent opaque, cutout, glass, and fluid buffers per section. A gameplay update replaces only the corresponding section's layer buffers; other sections remain resident.
- The CPU mesh master can extract/replace a section. Section overrides are retained so a late streamed full-chunk result cannot overwrite a newer gameplay section patch after that patch has been uploaded.
- Immediate block removal, collision update, and drop creation at the end of the mining animation remain unchanged.

## Regression coverage added

- Removal of torch light through a chunk boundary.
- Re-propagation from a surviving adjacent torch after an obsolete light dependency is removed.
- Opening a block-light path through a removed opaque block.
- Reopening a full-height skylight column and updating its HeightMap.
- Reconstructing a missing HeightMap without corrupting neighboring columns.
- Replacing one CPU mesh section across all render layers while preserving other sections, including an empty-section replacement.

## Verification limits

The archive is integrity-checked. This authoring environment does not have `cargo`, `rustc`, or a Windows GPU runtime, so Rust compilation, unit tests, and in-game frame-time measurements could not be run here. Run `EJECUTAR-PRUEBAS-RUST.bat` and the Windows release launcher on the target machine before treating this build as runtime-verified. The radius-17 fallback is intentionally retained for incomplete chunk neighborhoods; it is not removed or represented as incremental.
