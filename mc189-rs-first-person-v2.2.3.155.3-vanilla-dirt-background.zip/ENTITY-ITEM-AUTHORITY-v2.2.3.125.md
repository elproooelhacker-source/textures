# Server-owned EntityItem — v2.2.3.125

## MCP 1.8.9 references

The port is checked against the supplied deobfuscated 1.8.9 source:

- `net.minecraft.block.Block#spawnAsEntity(World, BlockPos, ItemStack)` — server-side spawn gate, three `World.rand.nextFloat()` position offsets, and default pickup delay.
- `net.minecraft.entity.item.EntityItem#onUpdate()` — pickup-delay countdown, gravity, `pushOutOfBlocks`, movement, lava response, nearby-item search cadence, ground slipperiness, drag/bounce, age, water movement, and 6000-tick despawn.
- `net.minecraft.entity.item.EntityItem#searchForOtherItemsNearby()` and `#combineItems(EntityItem)` — nearby AABB search and whole-stack-only merge rules.
- `net.minecraft.entity.Entity#moveEntity(...)` and `#pushOutOfBlocks(...)` — Y/X/Z collision clipping and embedded-entity escape behavior.
- `net.minecraft.world.World#handleMaterialAcceleration(...)` and `net.minecraft.block.BlockLiquid#modifyAcceleration(...)` — water-flow acceleration.

## Ownership after this increment

- `mc189-server::entity_item::EntityItem` owns block-drop entity IDs, item payload, metadata/NBT, previous/current position, velocity, age, pickup delay, hover phase, provisional-commit state, movement, collision, merge and despawn.
- A successful server-side mining break resolves the drop table and immediately constructs each `EntityItem` on the integrated server thread. The same server `JavaRandom` stream is continued for the three `Block.spawnAsEntity` position offsets. Constructor-only `Math.random()` values are not allowed to consume the shared world RNG; a deterministic per-entity substitute is used for initial horizontal impulse/hover phase.
- Entity updates run only on the integrated server's fixed 20 TPS thread. Full entity snapshots are included in `IntegratedSnapshot`; the app retains entity IDs and render-only copies for interpolation.
- The client no longer creates, advances, merges, collects or despawns block-generated drops. It receives confirmed transfer events for pickup animation and sound. Its remaining local `DroppedItem` simulation is only for player Q/Ctrl+Q drops, which are scheduled for step 3.
- New drops remain provisional until the in-memory block-edit worker accepts the matching transaction; provisional entities cannot merge or be picked up. On success the client sends a commit acknowledgement. If the worker rejects the edit, the client sends the exact provisional entity IDs to remove and restores the block state. Normal entity state remains server-owned.

## Implemented simulation behavior

- 0.25 × 0.25 entity AABB.
- Default ten-tick pickup delay; sentinel delay `32767` is not decremented and prevents merging.
- Gravity `0.03999999910593033`, Y/X/Z swept collision clipping, `pushOutOfBlocks` escape impulse, ground bounce, air drag, and ground friction.
- Known 1.8.9 slipperiness values for ice/packed ice/frosted ice (`0.98`) and slime (`0.8`); other blocks default to `0.6`.
- Water material acceleration from the collision world's liquid flow vectors and lava bounce on block change / 25-tick checks.
- Nearby merge search when an entity changes block coordinates or reaches a 25-tick interval. Merge compatibility checks item ID, metadata, NBT, nearby entity AABB distance, pickup-delay sentinel and transaction-commit state. As in MCP, a merge occurs only when the complete source stack fits; partial merges are not performed. The larger stack survives, with pickup delay=max and age=min.
- Item-specific merge limits use the shared legacy numeric item registry and the server `ItemStack` max-stack rules. This also corrects `written_book` from 16 to 1.
- Server despawn at age 6000; snapshots carry IDs and all render interpolation state.

## Pickup implemented in step 2

- Every server tick checks each committed entity against the authoritative player AABB and its pickup delay. The client does not submit a proximity result and cannot award the stack.
- The server resolves the numeric item ID through the shared registry and calls its own `PlayerInventory::insert`, preserving item damage and opaque NBT.
- Partial insertion subtracts only the inserted amount from the entity. A full inventory leaves the entity untouched. Fully collected entities are removed on the same server tick.
- Confirmed pickup events carry entity ID, item ID, metadata, transferred count, position and age. They are retained until the bounded snapshot channel accepts a snapshot. The client uses them only for the pickup animation and `random.pop` audio.
- Provisional block drops and entities with nonzero pickup delay cannot be collected.

## Deliberately not included in step 2

- Owner/thrower restrictions for player-thrown items are not represented yet; current server-owned entities are block drops with no thrower owner.
- Q/Ctrl+Q player drops, `/give`, `/clear`, cursor-stack close behavior and their inventory mutations remain transitional client paths for their scheduled migration step.
- `thrower` / `owner` protection for manually dropped items is not yet represented on server entities.
- The entity constructor's `Math.random()` stream is not reproducible from `World.rand`; deterministic per-entity pseudo-random values preserve the shared world RNG sequence but are not bit-for-bit equal to Java's process-global RNG.
- Entity fire damage, entity health, sound/particle side effects and full entity persistence are not implemented here.
- The dedicated TCP server does not yet share this integrated-world item simulation; the current gameplay path is the in-process single-player server.

## Validation status

Twelve focused server `EntityItem` tests cover world-RNG consumption, gravity/delay, block landing/bounce, embedded push-out, water flow, lava bounce, whole-stack merge limits, incompatible/distant/expired stacks, pickup-delay sentinel and pickup range. A server inventory test covers numeric-ID stack caps including `written_book`.

The authoring environment does not contain `cargo`, `rustc` or `rustfmt`; tests have been added but have **not** been compiled or executed here. Windows validation remains mandatory with `cargo test --workspace` and `cargo build --release --package mc189-app`.
