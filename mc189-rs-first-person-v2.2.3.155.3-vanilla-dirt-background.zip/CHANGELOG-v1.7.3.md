# v1.7.3 — direct tall-grass model resolution

## Fix

- Fixed legacy block ID 31 (dead bush, tall grass, fern) to resolve to the direct crossed-plane models `block/deadbush`, `block/tallgrass`, and `block/fern`.
- Removed the attempt to load the absent `assets/minecraft/blockstates/tallgrass.json`.
- Added regression tests for all three supported metadata values and rejection of unsupported metadata.

No world data or client JAR contents are modified.
