# World generation roadmap — v2.2.3.143

Implemented so far:

1. Java `Random` and GenLayer random primitives.
2. Biome map, terrain density and 4x8x4 interpolation.
3. Basic biome surface replacement.
4. Cave and ravine carving.
5. Default ore/deposit list and `WorldGenMinable` ellipsoid walk.
6. Minecraft 1.8.9 `MathHelper` sine/cosine lookup-index semantics for ore veins.
7. Mutable shared-RNG entry point for ore population, allowing future structure/lake/dungeon prelude integration without reseeding.

Still required before enabling Create World:

- Full `ChunkProviderGenerate.populate` prelude: mineshafts, villages, strongholds, temples, monuments, water/lava lakes, dungeons, and exact random-stream continuity.
- Cross-chunk write staging for feature generators that cross chunk boundaries.
- Mesa, ice, and other specialized biome surface algorithms.
- Full `BiomeDecorator` feature order and per-biome counts: trees, flowers, grass, mushrooms, reeds, cactus, lakes, and related features.
- Structure generation and persistent structure data.
- Snow/ice placement, heightmaps, skylight/block-light propagation, and spawn selection.
- Chunk serialization plus initial `level.dat` / player / world metadata creation, followed by reopen-and-continue tests.

The world-creation control remains disabled until the full generation and persistence path is integrated and validated.
