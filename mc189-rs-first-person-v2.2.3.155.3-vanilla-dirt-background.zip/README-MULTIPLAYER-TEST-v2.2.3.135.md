# Multiplayer PLAY-session test — v2.2.3.135

## What changed

The previous multiplayer diagnostic read a single PLAY packet and then let the TCP connection go out of scope. That closed the socket immediately after the first read. This version replaces that one-shot probe with a persistent session worker.

- The worker owns the authenticated TCP socket and continuously reads Protocol-47 PLAY frames on a background thread.
- Serverbound `S00PacketKeepAlive` (`0x00`) is answered with clientbound `C00PacketKeepAlive` (`0x00`), echoing the VarInt payload.
- On `S01PacketJoinGame` (`0x01`), RustClient sends `C15PacketClientSettings` (`0x15`) with the vanilla 1.8.9 field layout.
- `S08PacketPlayerPosLook` (`0x08`) is decoded, including relative-coordinate/rotation flags, and acknowledged with `C06PacketPlayerPosLook` (`0x06`).
- `S40PacketDisconnect` (`0x40`) is recognized and its JSON reason is shown.
- Each received packet is reported by ID, MCP name (when registered), and payload length in the Multiplayer screen status.
- Unknown packet IDs are consumed and logged rather than causing an immediate application-level rejection. Their framing and compression still must be valid.
- Socket reads happen off the window thread, so a quiet server does not freeze the menu.

## Test

Use the same original Java 1.8.9 test server as before, configured with `online-mode=false`. Connect with the saved host/IP; leave the port blank for `25565` unless the server uses a custom port.

After clicking CONNECT, keep the Multiplayer screen open. The status should progress through `PLAY CONNECTED`, received PLAY packet IDs, `Client Settings sent`, `teleport confirmed`, and `Keep Alive answered` when those packets arrive. If the server closes the session, RustClient now displays the server disconnect reason or the network error instead of silently dropping the socket after one packet.

## Current boundary

This is persistent PLAY transport and basic session maintenance, not full multiplayer gameplay yet. It does not yet decode remote chunk data into the renderer, replicate entities, synchronize movement/inventory, or implement online-mode Mojang/Microsoft authentication. The next implementation phase is decoding the remaining Join Game metadata, health/difficulty/abilities, chunk data, and the corresponding client state updates.

## Offline build

On the Windows PC, run the existing launcher. If you want to test the protocol crate directly and dependencies are cached, use:

```cmd
cargo test -p mc189-protocol --offline --locked
```

If the cache is incomplete, populate dependencies on the Internet-connected machine first and transfer the vendor/cache files as in the project's offline-build instructions.
