# v2.2.3.100 — immediate block drops; asynchronous persistence confirmation

## Root cause

`gpu_block_preview.rs` resolved block drops on the break tick but stored them in `pending_drop_spawns`. The entities were created only when `GameplayBlockEditWorker` returned its final result. That worker performs disk reads for the relight halo, rebuilds lighting, rewrites one or more Anvil region files, and rebuilds chunk meshes. The player therefore waited for the entire background transaction before seeing a drop, which felt like high server/network latency in a local single-player session.

## Changes

- Spawn each resolved `DroppedItem` immediately after the block-edit request is accepted by the worker queue.
- Store `pending_edit_revision` on provisional drops so the result can be matched to the exact disk transaction.
- Render provisional drops immediately, but prevent them from merging with other stacks or entering the inventory until the transaction is committed.
- On a successful center-chunk save, clear the provisional revision so normal pickup/merge behavior can proceed.
- On a failed transaction, remove only drops associated with that revision and restore the block in the live collision snapshot.
- Log the duration of the background save/light/mesh transaction for profiling the next Windows run.
- Add unit tests for the provisional pickup and merge restrictions.

## Validation

- Source-level review confirms the old `pending_drop_spawns` wait path is removed.
- ZIP integrity is checked after packaging.
- Cargo compilation and in-game timing still require the user's Windows environment; this environment does not have `cargo`/`rustc`.
