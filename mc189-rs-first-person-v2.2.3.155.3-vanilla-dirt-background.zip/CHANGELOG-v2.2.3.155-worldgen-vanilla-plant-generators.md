# v2.2.3.155 — vanilla plant generator primitives

Continues from v2.2.3.154. Adds legacy block representations and source-shaped generator routines for flower patches, dead bushes, reeds, cactus, waterlilies, pumpkins and melons. Generator attempt loops and conditional random draws follow the MCP 1.8.9 feature classes.

This is a generator-library milestone, not yet the complete BiomeDecorator integration. The caller still supplies biome-specific attempt counts, flower species and origin height. Flower-noise selection, double plants, small-mushroom bush generation, exact support/light/material predicates and the full vanilla decoration order remain to be ported. No bit-identical populate claim is made.

Cargo compilation/tests were not run in this environment.
