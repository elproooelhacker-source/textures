# v2.2.3.95 — Windows play-test launch package

## Added
- Windows CMD launcher that locates `.minecraft\saves`, accepts an UltimMC instance root containing `.minecraft`, resolves common 1.8.9 client JAR locations, and prompts for the JAR when auto-detection fails.
- Pre-launch verification for Cargo, rustc, world saves, and client JAR existence.
- Optional-by-default-confirmation full `saves` backup via Robocopy before launching; aborts if Robocopy reports a failed copy.
- Release build and native title-screen launch through the existing `main-menu` command.
- Separate workspace test runner and Spanish Windows start guide with controls, supported test cases, persistence warnings, and known limitations.

## Explicit scope
- This milestone packages and exposes the current 2.2.3.94 gameplay path for local Windows testing. It does not claim a successful Rust compilation or an in-game GPU test from the authoring environment.
- The player's NBT inventory is not loaded/saved; the in-session test inventory starts empty. Dropped entities and session inventory are not persisted when the native client exits.
- The game saves mined block changes into the selected existing world. Always keep the recommended backup and never run vanilla Minecraft simultaneously on the same save.
