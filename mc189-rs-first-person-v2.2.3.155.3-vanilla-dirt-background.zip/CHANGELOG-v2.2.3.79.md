# v2.2.3.79 — Vanilla first-person block centering

## Evidence-based change

- Inspected Minecraft 1.8.9 `client.jar` model JSONs: `item/stone.json` and `item/dirt.json` inherit block models and do not declare a `firstperson` transform; their first-person transform therefore defaults to zero rotation/translation and unit scale.
- Cross-checked MCP 1.8.9 `ItemRenderer.java` and `RenderItem.java`. `ItemRenderer.transformFirstPersonItem` provides the common hand pose and 0.4 scale. For GUI-3D block items, `ItemRenderer.renderItem` applies scale 2.0. `RenderItem.renderItem` then applies scale 0.5 and translate(-0.5, -0.5, -0.5) before drawing the baked model.
- Fixed only `vanilla_first_person_block_matrix` to include the missing final model-centering translation in the correct matrix order. Block mesh vertices remain in normalized 0..1 coordinates, so the centering translation belongs in the matrix rather than being guessed as a separate downward offset.
- Kept generated ITEM transforms unchanged. The generated ITEM mesh already centers its own vertices, so its matrix is not modified.
- Updated the unit test to assert that a block model's center maps to the hand anchor and that the block path remains distinct from the generated-item path.

## Validation

- ZIP archive integrity is checked after packaging.
- Rust tests/build were not run in this environment because Cargo/Rust are unavailable here. Run `cargo test --workspace` and `cargo build --workspace` on Windows to verify compilation and runtime appearance.
