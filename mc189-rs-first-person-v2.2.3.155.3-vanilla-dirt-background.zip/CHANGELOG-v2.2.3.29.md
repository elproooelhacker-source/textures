# v2.2.3.29 — Lighting data and vanilla directional/AO correction

This revision replaces the v2.2.3.28 presentation clamps with data-driven lighting behavior.

## Changes
- Removed the artificial 0.14 minimum vertex-light floor and 0.42 AO floor. Fully dark samples remain dark; the renderer no longer invents light to conceal bad inputs.
- Restored the Minecraft 1.8.x directional face factors: UP 1.0, DOWN 0.5, NORTH/SOUTH 0.8, WEST/EAST 0.6.
- Changed block AO values to the legacy `getAmbientOcclusionLightValue` values used by vanilla: normal opaque cubes 0.2, non-occluding blocks 1.0.
- Added the vanilla-style diagonal-corner fallback when both side samples are opaque.
- Kept SkyLight and BlockLight independently decoded and sampled. A missing BlockLight array now means zero block emission rather than erasing valid SkyLight.
- When SkyLight is absent, the reader uses the Anvil HeightMap's first-air boundary. Equality is treated as the first air block (`y >= HeightMap`), avoiding the previous one-block dark seam.
- Added regression tests for HeightMap equality, absent optional light arrays, preservation of SkyLight, negative chunk coordinates, and vanilla directional factors.

## Important scope note
This is a targeted correction to the current precomputed-light reader and vertex AO stage. It does not yet implement the complete time-dependent 16x16 vanilla lightmap (sun brightness, dimension brightness table, torch flicker, gamma, lightning/night vision), nor does it regenerate stale/missing chunk light propagation. Those require world-time/dimension state and a broader render-pipeline change. This revision should therefore be evaluated as a lighting-correctness step, not claimed as bit-for-bit full vanilla lighting.
