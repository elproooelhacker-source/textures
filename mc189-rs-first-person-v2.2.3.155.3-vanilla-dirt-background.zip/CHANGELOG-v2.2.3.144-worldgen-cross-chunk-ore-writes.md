# v2.2.3.144 — Worldgen cross-chunk ore writes

## Included

- Added `TerrainPopulationRegion`, a writable 3×3 chunk-primer neighborhood centered on the chunk being populated.
- `WorldGenMinable`-style vein placement now resolves block reads and writes using world coordinates and Euclidean chunk/local-coordinate conversion. A vein that crosses an X/Z chunk edge is no longer clipped to the origin primer when the adjacent primer is supplied.
- Added `populate_overworld_ores_in_region` and `populate_overworld_ores_in_region_with_rng` for neighborhood-aware population.
- Kept the original single-primer APIs (`populate_overworld_ores` and `populate_overworld_ores_with_rng`) as compatibility wrappers.
- Extracted `vanilla_chunk_population_seed` to expose and test the exact `ChunkProviderGenerate.populate` seed derivation, including signed Java `long` arithmetic and negative chunk coordinates.
- Added tests for population-seed arithmetic and a deterministic vein that crosses the east chunk boundary.

## Fidelity boundary

This version improves the ore feature write target, but it does **not** yet implement the complete `ChunkProviderGenerate.populate` prelude. Structure generation, water/lava lakes, dungeons, biome decoration, mob spawning, precipitation freezing and snow placement remain separate work. In particular, callers must provide already-generated adjacent chunk primers for cross-boundary writes to affect real neighboring terrain.

The existing convenience API with one primer intentionally has no neighboring terrain loaded and therefore retains single-chunk behavior. Use the region API for boundary-faithful generation.

## Validation

- ZIP archive integrity is checked after packaging.
- Rust compilation and `cargo test` were not run in this environment because `cargo`/`rustc` are unavailable.
