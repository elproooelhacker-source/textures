# Research notes — v2.2.3.85

Primary source: user-provided deobfuscated Minecraft 1.8.9 source archive `minecraft.zip`, inspected locally. Cross-reference client binary: `/mnt/data/mc189fix/client.jar`, SHA-256 `14f0d96d1a56fb4f5c3b2233d00699525893fe5ce3dcf181e7de59120595d298`. Source paths below are relative to `minecraft/net/minecraft/block/`.

## Drop rules transcribed
- `BlockDoublePlant.java`: `getItemDropped` returns no item for upper half; lower fern none; lower grass performs `rand.nextInt(8) == 0` for wheat seeds; other lower variants drop the block item. `damageDropped` preserves variant metadata for lower non-grass variants. `onHarvest` for shears on lower grass/fern spawns two `Blocks.tallgrass` with grass/fern metadata. The world-level paired-half behavior still needs to be handled by the mining/world mutation layer; this registry function only resolves the addressed half.
- `BlockSnow.java`: `harvestBlock` directly spawns `LAYERS + 1` snowballs, while `quantityDropped(Random)` returns zero. Metadata conversion is `(meta & 7) + 1`, so the player-harvest count is `(meta & 7) + 2`. This is deliberately modeled as player harvest, not environmental `dropBlockAsItem`.
- `BlockSnowBlock.java`: `getItemDropped` is snowball and `quantityDropped` is four.
- `BlockMelon.java`: base quantity `3 + random.nextInt(5)`; Fortune quantity is `min(9, base + random.nextInt(1 + fortune))`. The RNG call order is preserved.
- `BlockClay.java`: clay balls, quantity four.
- `BlockVine.java`: no ordinary item and quantity zero; `harvestBlock` with shears spawns one vine.
- `BlockWeb.java`: drops string ordinarily and overrides `canSilkHarvest()` to true; removed web ID 30 from the Silk Touch exclusion set.
- `BlockNetherWart.java`: age >= 3 yields `2 + nextInt(3)` plus optional `nextInt(fortune + 1)`; its base `getItemDropped` and `quantityDropped` are null/zero because the custom override handles spawning.
- `BlockCocoa.java`: age >= 2 spawns three brown dye (dye item ID 351, metadata 3), otherwise one; its custom method ignores fortune.

## Resource extraction findings
The supplied client JAR contains 5,597 ZIP entries, of which 3,085 are under `assets/minecraft/`. Extracted categories: 340 blockstates, 1 font resource, 1,595 models, 87 shaders, 1,058 textures, 3 texts, and 1 language resource. No OGG, WAV or MP3 file exists in this JAR. The 1.8.9 version metadata identifies asset index `1.8` and the asset index URL `https://launchermeta.mojang.com/mc/assets/1.8/e264980ad255aad2174cbe4d674c102474ae5202/1.8.json`. Vanilla audio is stored as separate hash-addressed objects in the launcher asset cache, not in client.jar. A new command can copy those objects using the index and `.minecraft/assets/objects` cache, but those objects were not available in this runtime.

## Remaining gaps
- No world-side paired-half handling for double plants in this drop-only module.
- No compilation or execution of Rust tests in this environment.
- No audio payloads bundled; obtaining them requires the exact 1.8.9 launcher asset index and its referenced objects, not client.jar. `extract-launcher-audio` currently validates paths and sizes, not SHA-1 digests.
- Drops are not yet connected to held-click mining, world mutation, mesh rebuild, item entities, pickup, inventory or Anvil persistence.
