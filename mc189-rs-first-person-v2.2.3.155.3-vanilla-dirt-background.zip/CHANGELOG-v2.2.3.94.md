# v2.2.3.94 — generated dropped-item sprites, sampled light and block-breaking cracks

## Added
- Dropped generated-item entities resolve metadata-aware 16x16 vanilla icons from `client.jar` through the same item model/texture resolver used by the inventory UI. The icon is extruded into an item-layer mesh and rendered in world space with a cached texture bind group. Block-like items continue through the block-atlas model path.
- Dropped item vertices sample decoded `SkyLight` and `BlockLight` from the loaded Anvil chunk at the entity's current block position. Missing sections use a heightmap-aware sky-light fallback; absent block-light data defaults to zero.
- Added `ChunkSection` and `ChunkData` light sampling accessors and a session-local `LoadedWorldCollision::light_at_local` lookup.
- Loaded the original ten `destroy_stage_0.png` through `destroy_stage_9.png` textures from the 1.8.9 client JAR and packed them into a nearest-filtered 160x16 strip.
- Added a depth-tested, alpha-blended world-space mining-crack pass. It uses the live `MiningController` stage (0–9), applies sampled target-block lighting, and clears on release, cancellation, a lost target, or block break.
- Refined dropped-item ground animation against MCP `RenderEntityItem`: stack-copy thresholds (>1, >16, >32, >48), age/hoverStart bob and spin rate, seeded Java-Random-187 offsets for 3D stack copies, and flat-sprite Z layering. Entity hover phase is deterministic and does not consume `World.rand`; MCP initializes this field with `Math.random()`.
- Completed missing legacy item-name mappings required by the current drop registry, including rail, end stone, lily pad, quartz, slime ball, apple, double-plant variants, leaves2/log2, pumpkin and wooden door.
- Added regression tests for all ten destroy-stage UV intervals, crack mesh and light values, generated drop IDs, dropped-item light propagation, MCP stack-copy thresholds, hover-phase RNG isolation, and decoded chunk light lookup.
- Updated the gameplay startup message so it no longer describes the world as read-only; mined block persistence is active while entity/inventory persistence remains future work.

## Scope and limitations
- Crack textures are the exact 1.8.9 source assets, and the animation stage is connected to live mining progress. The geometry is currently a six-face cube overlay; it does not yet substitute the target's baked model as MCP `BlockRendererDispatcher.renderBlockDamage` does. Partial/irregular block shapes, exact per-face UV orientation, blend/depth bias and interpolation still need comparison and refinement.
- Generated dropped items use the inventory's metadata-aware 16x16 resolved sprite and an extruded item-layer mesh. Special renderers (compass/clock/map animation, layered potion tinting, bows, fishing rods, armor stands and custom tile/entity renderers) are not yet full `RenderItem` parity.
- Dropped-item lighting samples the loaded chunk's stored light nibble at the entity block coordinate. It does not yet interpolate neighboring light samples or recompute stale block/sky light after world edits.
- Item physics/collision, merge timing, pickup behavior, NBT player-inventory persistence and the persisted `World.rand` state remain approximate or incomplete as documented in earlier milestones.
- Cargo/rustc are unavailable in this authoring environment, so Rust compilation, unit tests and in-game GPU validation remain unverified. ZIP integrity and static source checks are performed separately.
