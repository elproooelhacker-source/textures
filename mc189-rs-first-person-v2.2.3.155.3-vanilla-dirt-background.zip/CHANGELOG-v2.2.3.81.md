# v2.2.3.81 — Legacy drop registry expansion

- Added `drop_registry.rs`, independent from mining hardness/progress/raycast.
- Added typed `DropTool`, `ItemDrop`, `DropStatus` and `resolve_drops` API.
- Added handling for common legacy block drops, silk-touch block returns, fortune-scaled ore quantities, metadata-preserving block items, crops/vegetation special cases and explicit unknown-ID rejection above the 1.8.9 legacy block range.
- Added focused unit tests for stone -> cobblestone, diamond ore -> diamond, silk-touch stone, air and unknown IDs.
- Kept the existing `mining.rs` behavior unchanged.

## Accuracy boundary

This is an expanded first registry pass, not yet a claim of bit-for-bit complete vanilla parity. Some uncommon blocks still use the generic ItemBlock fallback; per-block Java `Random` call ordering, exact `World.rand` compatibility, Fortune distributions for every block, tile-entity/NBT drops, XP orbs, and the Silk Touch eligibility matrix require another source-by-source pass against MCP 1.8.9 before the registry can be certified complete. The module is not yet connected to the gameplay break event or rendered dropped-item entities.

## Validation

- ZIP integrity checked after packaging.
- Rust compilation/tests not run in this environment (Cargo toolchain unavailable).
