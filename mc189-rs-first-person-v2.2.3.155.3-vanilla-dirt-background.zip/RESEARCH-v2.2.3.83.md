# Research notes — v2.2.3.83

## Inspected MCP 1.8.9 sources
- Block base drop loop and `quantityDroppedWithBonus`: https://mc-packet-reference.netlify.app/1.8.9/source/net/minecraft/block/block/
- BlockLeaves: https://github.com/Marcelektro/MavenMCP-1.8.9/blob/master/src/main/java/net/minecraft/block/BlockLeaves.java
- BlockOldLeaf: https://mc-packet-reference.netlify.app/1.8.9/source/net/minecraft/block/blockoldleaf/
- BlockCrops: https://mc-packet-reference.netlify.app/1.8.9/source/net/minecraft/block/blockcrops/
- BlockPotato: https://mc-packet-reference.netlify.app/1.8.9/source/net/minecraft/block/blockpotato/
- BlockTallGrass: https://mc-packet-reference.netlify.app/1.8.9/source/net/minecraft/block/blocktallgrass/
- BlockNewLeaf implementation reference: https://www.javatips.net/api/Youtube-Hacked-Client-1.8-master/minecraft/net/minecraft/block/BlockNewLeaf.java
- BlockMelon source was also checked as a reminder that fortune can alter quantity via an additional random call: https://mc-packet-reference.netlify.app/1.8.9/source/net/minecraft/block/blockmelon/

## Important call-order findings
- Base `Block.dropBlockAsItemWithChance` first calls `quantityDroppedWithBonus`, then performs `nextFloat` chance checks, then calls `getItemDropped` for each successful attempt.
- Leaves override the base drop method: sapling chance roll first, then the subclass apple roll. It does not use the generic base quantity loop.
- Wheat's `BlockCrops` first delegates to the base drop method with Fortune 0, then for age 7 performs `3 + fortune` independent `nextInt(15) <= age` seed rolls.
- `BlockPotato` delegates to the crop logic and then performs an additional `nextInt(50) == 0` poisonous-potato roll for mature crops.
- Tall grass computes the number of trials as `1 + nextInt(fortune * 2 + 1)` and each trial independently calls `nextInt(8)` to decide whether wheat seeds appear.

## client.jar inspected locally
- Path used: `/mnt/data/mc189fix/client.jar`
- SHA-256: `14f0d96d1a56fb4f5c3b2233d00699525893fe5ce3dcf181e7de59120595d298`
- ZIP/JAR manifest declares `Main-Class: net.minecraft.client.Main`.
- Entries are timestamped 2015-12-09 10:24; block implementation classes are obfuscated (e.g. `auz.class`), and no `net/minecraft/block/*.class` entries exist under MCP names.
- `javap` confirms the inspected obfuscated class is unrelated renderer/math infrastructure, not a directly named MCP block class. A matching MCP/SRG mapping set is needed to tie each obfuscated class in this exact JAR to the MCP names without guesswork.
