# v2.2.3.150 — Jungle tree population

- Added jungle log/leaves and four directional vine states with legacy block IDs and metadata.
- Added jungle and jungle-edge tree attempt counts (50 and 2 per chunk) and the biome's conditional tree selector.
- Added the ordinary `WorldGenTrees` jungle variant (height base 4–10), including leaf canopy, trunk vines, leaf-edge vines, and cocoa RNG draws.
- Added `WorldGenShrub` jungle trunk/oak-leaf shape.
- Explicitly deferred `WorldGenBigTree` and `WorldGenMegaJungle` geometry/RNG walks. Those selected attempts are counted as unsupported instead of inventing random draws. Cocoa block placement itself is deferred; its conditional random draws are retained.
- Melons, 50 `WorldGenVines` attempts, flowers/grass and remaining biome decoration are not included.
- This is still a partial `BiomeDecorator` port, not a bit-identical whole-world generator.
