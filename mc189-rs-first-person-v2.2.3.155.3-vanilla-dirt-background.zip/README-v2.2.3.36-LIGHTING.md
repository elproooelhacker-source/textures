# Minecraft 1.8.9 lighting — v2.2.3.36

This version builds on v2.2.3.35. It carries independent per-corner ambient occlusion, sky light and block light through the chunk mesh and samples a 16×16 lightmap texture in the fragment shader.

Run from the project directory on Windows:

```cmd
cargo fmt --all
cargo test --workspace
cargo run -p mc189-app -- select-world "C:\Users\Admin\Downloads\UltimMC-Launcher-All-Versions (1)\UltimMC-Launcher-Win32\UltimMC\instances\1.8.9\.minecraft\saves" "C:\Users\Admin\Downloads\client.jar" "C:\Users\Admin\Downloads\block-atlas-output"
```

The lightmap table currently represents clear daytime with no torch flicker. This is an intermediate port; do not remove v2.2.3.35 until the runtime appearance has been checked.
