# v2.2.3.28 — softened smooth-lighting shadows

The first visible smooth-lighting pass exposed overly harsh dark corners and occasional near-black faces. This milestone makes a deliberate presentation adjustment:

- Ambient-occlusion minimum rises from 0.20 to 0.42, reducing the contrast of fully occluded corners.
- Directional face multipliers are softened: bottom 0.68, X sides 0.74, Z sides 0.86; top remains 1.0.
- Final per-vertex light is clamped to a 0.14 minimum to prevent a zero or missing saved-light sample from rendering a face completely black.
- Adds tests for the new factors and clamp.

This is intentionally a visual tuning step over the current first-pass lighting model. It is not a claim of exact vanilla 1.8.9 lighting: the complete combined-light/day-night lightmap, dimension-specific behavior, and exact `BlockModelRenderer` AO sampling are still pending. The world and client JAR remain read-only.
