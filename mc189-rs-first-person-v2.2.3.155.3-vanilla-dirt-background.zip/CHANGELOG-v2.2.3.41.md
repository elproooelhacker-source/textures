# v2.2.3.41 — Reconstructed fallback lighting

- Added in-memory reconstruction of missing `BlockLight` arrays using a multi-source queue propagation pass.
- Added in-memory reconstruction of missing `SkyLight` arrays using saved sky samples and direct-sky columns derived from the Anvil heightmap.
- Light propagation crosses loaded neighboring chunks, respects full opaque blocks, and applies attenuation for water, leaves, and ice.
- Existing saved `BlockLight` and `SkyLight` arrays are preserved; source world files remain read-only.
- Added regression tests for torch falloff, cave-side sky propagation, cross-chunk light, opaque barriers, and saved-array preservation.

Validation note: this build environment does not have the Rust toolchain (`cargo`/`rustfmt`), so compilation and test execution were not possible here. Run the validation commands below on Windows before launching the world.

```bat
cargo fmt --all
cargo test --workspace
```
