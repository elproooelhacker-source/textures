# Immediate block break and dropped-item rendering — v2.2.3.103

The mining event and visible geometry now share a same-frame transition. The authoritative collision snapshot is updated immediately on `MiningEvent::Broken`; the renderer uses per-vertex CPU ownership to omit that block from the existing GPU chunk mesh before the next redraw, while the drop entity is queued in the same fixed tick. This removes the old dependency on waiting for the background chunk mesh compiler before the mined block stops appearing.

The asynchronous edit worker still rebuilds the edited chunk and its relevant neighbors. This second stage is necessary because the newly exposed faces of adjacent blocks, fluid boundaries, ambient occlusion and light samples must be recomputed using the complete post-break neighborhood. Until that replacement arrives, the immediate owner-cull ensures the broken block itself cannot remain visible. On edit rejection, the rollback snapshot restores the previous display mesh and collision state and the provisional item is removed.

The item simulation remains deterministic at 20 TPS. Each entity stores its previous fixed-tick position. Before each window redraw, `RenderEntityItem`-style interpolation computes the visual position, bobbing and rotation from those two states using the current partial tick. This keeps simulation deterministic without displaying the 20 Hz stepped movement.

Item movement now uses an AABB of 0.25 x 0.25 and the world collision registry. The swept search covers all block cells touched by the movement, plus the row below the lower bound to include fence/gate collision boxes whose maximum Y extends to 1.5. Collision offsets are resolved vertically, then on X and Z, and clipped velocity components are stopped as in the vanilla entity movement path.

## Expected play-test

1. Hold left mouse until the final destroy-stage texture completes.
2. On the first frame after completion, the block should no longer be visible and its small item entity should already be present.
3. The new item should stop against nearby solid side walls instead of passing through them, and settle on the floor.
4. At 60 FPS or higher, item bobbing/spin/translation should appear interpolated rather than stepping at 20 TPS.
5. Wait for the asynchronous neighbor rebuild and check adjacent water/glass faces; these are intentionally rebuilt after the immediate hide.

The full chunk-neighborhood replacement is still asynchronous; newly exposed neighbor faces can finish on a later frame. This release specifically makes the broken block itself disappear immediately and spawns the drop in the same tick.


## v2.2.3.104 sequencing addendum

The live collision state and current block geometry are removed at the completed break event. The provisional item entity is inserted and a redraw requested before the edit worker is signaled to rebuild chunk meshes and lighting. This makes the drop transition independent of the asynchronous chunk/light refresh.
