# v2.2.3.109 — correct beacon opacity regression expectation

## Test correction

- Corrected the legacy opaque-block regression test: block ID 138 is the beacon, not the sea lantern. MCP 1.8.9 `BlockBeacon` explicitly returns `false` from both `isOpaqueCube()` and `isFullCube()`, so it must not occlude neighboring model faces.
- Kept block ID 169 (sea lantern) in the opaque-cube assertions. The production block classifier was already correct; no runtime opacity, lighting, or face-culling behavior was changed.
- Added explicit assertions for the beacon's non-opaque/non-full-cube behavior and the sea lantern's opaque behavior.

## Verification

- Compared against the bundled deobfuscated Minecraft 1.8.9 sources: `BlockBeacon.java`, `BlockSeaLantern.java`, and the base `Block.java` defaults.
- Source-level diff and ZIP integrity are checked. This authoring environment does not have `cargo` or `rustc`, so the workspace test suite must be rerun on Windows with `EJECUTAR-PRUEBAS-RUST.bat`.
