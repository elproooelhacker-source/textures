# v2.2.3.77 — generated item duplicate-plane fix

- Kept the v2.2.3.76 first-person transforms unchanged. No X/Y/Z item position, rotation, or display transform was changed.
- Changed only `build_generated_item_layer_vertices`: generated item sprites now emit one full alpha-cutout surface, plus the existing pixel-boundary side walls that give the item thickness.
- Removed the second complete, offset sprite plane. With the hand pipeline's two-sided rasterization (`cull_mode=None`), the extra plane was not needed to make the item visible from either side and could appear as a separate flat silhouette crossing the properly extruded tool.
- Updated the generated-layer geometry test to assert one surface plus four side quads for a single opaque texel.

## Verification status

- ZIP integrity checked after packaging.
- Rust tests/build not executed in this environment because Cargo/Rust are unavailable here.
- Please verify in the Windows client with a pickaxe and sword. This patch intentionally targets mesh duplication only and does not claim runtime confirmation until tested.
