# v2.2.3.24 — smooth-lighting foundation

## Rendering changes

- Added per-corner light storage to `CpuMeshQuad` and a matching interpolated GPU vertex attribute.
- Chunk mesh construction samples the Anvil section `SkyLight` and `BlockLight` nibble arrays using the same world-space neighborhood already loaded for fluid corner continuity.
- Added per-vertex neighbor occlusion sampling and the classic face shade factors: up 1.0, down 0.5, X sides 0.6, Z sides 0.8.
- Removed the previous synthetic directional diffuse calculation based on the camera-independent vector `(0.35, 0.82, 0.44)`.
- Model face shade=false bypasses the new lighting value, preserving emissive/unshaded model behavior.

## Compatibility

- Biome tint, cutout vegetation, water/lava pass separation, model UVs, and read-only world loading remain unchanged.
- Fluid quads and the first-person arm use neutral vertex light in this foundation release.

## Fidelity scope / known remaining work

This is the first smooth-lighting foundation, not yet a bit-for-bit port of the full 1.8.9 `BlockModelRenderer` + `EntityRenderer` pipeline. The saved sky/block channels are currently collapsed to a scalar maximum for the existing single-pass shader; vanilla's time/weather-dependent RGB lightmap is not yet implemented. Partial model bounds and the complete vanilla neighbor-face AO bitset logic are also not yet reproduced. Validate visual behavior before the next refinement.

## Tests added

- Anvil saved sky/block light nibble sampling.
- Vanilla directional face shade constants.
