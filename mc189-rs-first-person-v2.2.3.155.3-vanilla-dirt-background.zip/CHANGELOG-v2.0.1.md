# v2.0.1

## Corrección
- Corregida la sintaxis del `if` que marca `player.on_ground` tras una colisión vertical descendente en `player.rs`.
- Sin cambios en la lógica prevista del controlador ni en el resto de la base v2.0.0.

## Validación
- Se verificó la corrección textual y la integridad del ZIP.
- `cargo fmt` y `cargo test` deben ejecutarse en el entorno Windows del usuario; no se afirma una compilación local.
