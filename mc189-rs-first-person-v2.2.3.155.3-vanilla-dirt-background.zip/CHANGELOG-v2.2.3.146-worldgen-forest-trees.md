# v2.2.3.146 — Worldgen: oak and birch forest trees

## Included
- Continues from v2.2.3.145 without dropping the ore and underwater substrate-patch stages.
- Adds legacy block representations for oak/birch logs and leaves, including the `CHECK_DECAY=false` leaf metadata used by the MCP generators.
- Adds `WorldGenTrees(false)` behavior for ordinary oak trees: height draw, clearance volume, dirt conversion, randomized canopy layers, and trunk placement.
- Adds `WorldGenForest(false, false)` behavior for birch trees: height draw, clearance volume, randomized canopy layers, and trunk placement.
- Adds the tree attempt loop for Forest (4), Forest Hills (18), Birch Forest (27), and Birch Forest Hills (28), with their vanilla attempts-per-chunk and oak/birch selection draws.
- Tree writes use the 3x3 population region, so trunks and canopies are not clipped at chunk boundaries.
- Adds deterministic regression tests and legacy ID/metadata assertions.

## Fidelity boundary
- The supported biome tree implementations are limited to the MCP families listed above.
- Roofed forest canopy trees, giant trees, taiga generators, jungle, swamp, savanna, mega taiga, and other biome-specific tree generators are not included in this revision.
- The overall population pipeline still lacks the earlier `ChunkProviderGenerate.populate()` structures/lakes/dungeons and the later plant/flower/mushroom/reed/cactus stages. Therefore this is not yet bit-identical 1.8.9 world population.
- The tree generator implementations port the ordinary oak and birch algorithms and their variable random consumption, but no claim is made about full-world RNG parity until all earlier population generators are implemented in vanilla order.

## Validation
- ZIP integrity is checked before delivery.
- Cargo tests/build were not run in this environment because `cargo`/`rustc` are unavailable.
