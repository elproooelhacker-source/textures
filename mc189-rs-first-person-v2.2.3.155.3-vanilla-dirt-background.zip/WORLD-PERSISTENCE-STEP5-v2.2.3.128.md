# Step 5 — world ownership and persistence — v2.2.3.128

## Persisted state in this increment

- Modified chunk block IDs/metadata and lighting: deferred dirty-chunk snapshots, region-batched Anvil writes.
- Player inventory and selected hotbar slot: merged into `level.dat` `Data.Player`.
- Player pose: `Pos` (TAG_List of TAG_Double), `Rotation` (TAG_List of TAG_Float), and `Motion` (TAG_List of TAG_Double).

## Restore rules

- A valid finite saved `Pos` becomes the next gameplay target; otherwise the caller's world spawn remains the fallback.
- The position is passed through the existing safe-spawn/collision resolver, so a saved location inside blocks or without a safe standing position is not blindly trusted.
- Valid saved yaw/pitch are restored; pitch is clamped to the simulation's supported range.
- Motion is restored only when it is finite and each component is bounded; otherwise the player starts with zero velocity.
- Player coordinates are world coordinates in NBT. The integrated server keeps origin-relative coordinates; save/load converts at the boundary.

## Ownership and commit model

- Integrated server snapshots remain authoritative for player movement and inventory actions.
- The client observes the newest server snapshot and marks player data dirty when pose or inventory changes.
- The persistence worker writes immutable snapshots off the 20 TPS thread.
- An older save result cannot clear a newer player-data revision.
- Graceful close waits for pending block edits and the final disk commit. A failed final save keeps the session open for retry.

## Still not covered

- `EntityItem` save/load in chunk `Level.Entities` (including stack NBT, age, pickup delay, position and motion).
- Full entity/mob persistence and entity-ID lifecycle across restart.
- World `Time`/`DayTime`, weather timers/strength, and other mutable `level.dat Data` fields.
- Tile-entity ticking state and scheduled block ticks beyond preservation of existing NBT.
- A crash-safe transaction spanning region files and `level.dat` as one atomic world-wide commit.

This milestone must not be described as complete vanilla-equivalent persistence until these areas are implemented and tested against 1.8.9.
