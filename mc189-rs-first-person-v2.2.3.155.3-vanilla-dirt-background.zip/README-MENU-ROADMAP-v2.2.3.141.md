# Menu fidelity roadmap — v2.2.3.141

## Current state
- Main menu, Singleplayer selector and basic Multiplayer GUI are present.
- Singleplayer supports selecting, double-click launching, renaming `Data.LevelName`, and recoverable delete quarantine.
- Create World now has editable world-name and seed fields, Survival/Hardcore/Creative mode cycling, advanced view, structures/cheats/bonus-chest toggles and world-type cycling.
- The Create World button remains disabled until generation is sufficiently complete and verified.

## World creation blockers (must be solved before enabling Create)
1. Finish parity of `ChunkProviderGenerate` terrain generation, including exact biome-specific surface builders and exact cave/ravine RNG behavior.
2. Port `populate`/`populateChunk`: ores, trees, flowers, lakes, dungeons, snow/ice, biome decorators and structure starts/references, respecting `generateStructures`.
3. Implement Flat and Large Biomes generation, Amplified settings and Customized generator settings; support the exact `WorldType` settings and seed behavior.
4. Prepare spawn using the vanilla world-provider/spawn search rules and generate the required spawn chunks.
5. Implement bonus chest contents and placement, gated by Hardcore exactly as vanilla does.
6. Finalize chunk heightmaps, skylight/block light, biome arrays, entity/tile-entity lists and Anvil chunk NBT to a form that the existing loader can reopen.
7. Write `level.dat` with correct `Data`/`WorldGenSettings`/`GameRules`/`Player` fields and use transactional save-directory creation/rollback.
8. Verify deterministic chunk/block/biome outputs against a vanilla 1.8.9 reference world for known seeds and coordinates before enabling the button.

## Other menu work remaining
- Multiplayer ping/status protocol, MOTD, latency and server icons.
- LAN discovery and scrollable server list.
- Exact panorama 64-view render-to-texture pipeline and vanilla final projection.
- Loading screens for world load and remote server connect; connection failure/disconnect screens.
- Options, language, Realms and remaining vanilla dialogs.
