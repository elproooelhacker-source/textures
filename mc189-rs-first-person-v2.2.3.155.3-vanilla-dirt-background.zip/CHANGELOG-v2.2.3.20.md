# v2.2.3.20 — vanilla 1.8.9 liquid movement correction

## Player movement in water and lava
- Corrected the unit conversion between vanilla's blocks-per-tick motion and this engine's blocks-per-second velocity. The previous implementation applied liquid input, buoyant jump, water current and gravity impulses at only 1/20 of their vanilla strength.
- Water and lava now use the 1.8.9 `EntityLivingBase#moveEntityWithHeading` constants in the seconds-based simulation: `moveFlying(0.02F)`, water drag `0.8`, lava drag `0.5`, and gravity `0.02` blocks/tick.
- Held jump now applies the vanilla `+0.04` blocks/tick impulse in both water and lava.
- Water current acceleration uses the vanilla `World#handleMaterialAcceleration` impulse of `0.014` blocks/tick, converted to the engine's velocity units.
- Separated water contact, `isInLava` material bounds, and the uncontracted lava movement query used by vanilla travel. Corrected the vertical bounds of the expanded water/lava contact boxes.

## Tests
- Added exact 20 Hz regression tests for water movement acceleration, water gravity, held swimming, lava drag/gravity, and held jumping in lava.
- Strengthened the water-current test to assert the expected vanilla impulse after drag.

## Scope
- Keeps the world read-only and preserves the existing rendering, atlas, hand, crosshair, chunk streaming and biome tint work.
- This corrects player movement in existing liquid blocks; it does not add dynamic liquid simulation, damage, fire, oxygen or survival HUD.
