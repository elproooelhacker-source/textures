# v2.2.3.116 — pickup sound coverage and drop arm animation

## Pickup sound

- Kept `random.pop` on the one authoritative successful inventory insertion path, so mined-block drops and player-dropped entities use the same feedback.
- Added an explicit accepted-pickup diagnostic with item ID, inserted amount and remaining pickup delay. This distinguishes an actual inventory transfer from an item that is still protected by its vanilla pickup delay or cannot fit in the inventory.
- Preserved the vanilla 1.8.9 pitch formula from `EntityItem.onCollideWithPlayer` / `NetHandlerPlayClient`: `((rand1 - rand2) * 0.7 + 1.0) * 2.0`.
- Added subtle ±8% gain variation on top of the randomized pitch; the OGG event's own weighted variants continue to be selected randomly.

## Drop arm animation

- A successful `Q` or `Ctrl+Q` drop starts the existing interpolated first-person arm swing.
- The animation is coupled to a successful inventory removal/entity spawn, so pressing Q with an empty slot does not swing.
- The hovered-stack Q/Ctrl+Q path uses the same animation trigger.

## Vanilla compatibility note

- `EntityPlayer.dropItem` applies `setPickupDelay(40)` to manually dropped items. The 40-tick delay is preserved. The pickup sound fires when the item actually transfers into the inventory after that delay; simply touching a protected item does not play it.
