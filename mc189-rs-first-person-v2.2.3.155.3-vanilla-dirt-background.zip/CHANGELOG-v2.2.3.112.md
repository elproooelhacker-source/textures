# v2.2.3.112 — hotbar stack feedback and MCP block mining audio

## Inventory and stack feedback

- Ground pickups are authoritative inventory mutations in the same fixed simulation tick. The HUD/hotbar texture is refreshed immediately, even while the inventory screen is closed. An empty slot shows its newly collected block/item, and compatible pickups merge into the visible stack count (for example 1 to 2). Partial pickups leave the uncollected remainder in the world.
- The five-tick slot pop uses the MCP `GuiIngame.renderHotbarItem` formula with display-frame `partialTicks` interpolation. It is armed when a stack appears, a compatible stack grows, or an existing stack changes/decreases (for example 2 to 1). Number overlays stay anchored while only the icon is transformed. The observer checks item ID, metadata/damage, NBT payload, and count across 36 inventory slots plus four armor slots.
- The selected hand item is refreshed when a pickup changes the selected hotbar slot. The three-tick world-space `EntityPickupFX` copy and vanilla `random.pop` sound remain independent of the actual inventory transfer.
- Full-cube block item icons keep the existing isometric cube treatment; tool and generated items remain flat item sprites. This is a GUI icon treatment, not yet a general renderer for each item's full baked 3D model.

## Mining and pickup audio

- Sounds are resolved from the active launcher's `assets/indexes/1.8.json` and hashed `assets/objects` entries using the vanilla `sounds.json` definitions. The resource pack is not copied into the project.
- Every four valid block-damage ticks, the matching MCP `Block.stepSound` event plays at the block center with `(volume + 1) / 8` and `frequency * 0.5`. Destruction plays the individual break event with `(volume + 1) / 2` and `frequency * 0.8`.
- Profiles distinguish the vanilla stone, wood, grass, gravel, sand, cloth, snow, glass, metal, ladder, anvil, and slime sound types, including glass's `dig.glass` break override, ladder's `dig.wood`, anvil's `dig.stone`, and slime's `mob.slime.small`/`mob.slime.big` overrides. Wooden stair IDs inherit wood; stone-based stairs inherit stone.
- Missing hashed assets, unavailable OGG variants, or a missing output device disable audio with diagnostics but do not prevent entering a world.

## Regression coverage

Tests cover immediate HUD-side pickup insertion while the inventory is closed, merge count 1 to 2, decrement 2 to 1, the five-tick vanilla pop and partial-frame interpolation, saved-inventory initialization without a false pop, isometric block-item classification, OGG variant metadata/path handling, and vanilla block sound profile selection.

Cargo compilation/tests and actual Windows audio playback still need to be run on the user's Windows machine. This authoring environment has no Cargo/rustc installation or physical audio output device, so the release ZIP is integrity-checked but not build- or playback-verified here.
