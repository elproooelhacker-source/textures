# v2.2.3.44 — title-screen rendering and world handoff correction

- Preserve the six original panorama PNGs at their native 256x256 dimensions; reject unexpected dimensions instead of silently resampling them during asset loading.
- Separate panorama filtering from UI sampling. The panorama retains linear filtering while the logo, widgets and font overlay use nearest-neighbor sampling to preserve their authored pixels.
- Reverse the button widget state rows to correct the observed inverted hover appearance in the current UI composition.
- Launch the selected world through a fresh `play-world` process. winit allows one event loop per process, so this avoids attempting to recreate the title-screen event loop when starting gameplay.
- Add the `play-world <client.jar> <atlas-dir> <world-dir>` internal command used by the title-screen handoff.

Validation limitation: this environment does not have the Rust toolchain installed, so `cargo fmt` and `cargo test` could not be run here. The source changes and ZIP integrity were checked; Windows compilation and visual confirmation remain necessary.
