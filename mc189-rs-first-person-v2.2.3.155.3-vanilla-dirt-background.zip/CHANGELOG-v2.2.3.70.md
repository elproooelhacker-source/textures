# v2.2.3.70 — inventory preview and cursor sprite correction

- Render Steve's inventory preview at framebuffer pixel resolution in its own transparent sprite instead of rasterizing him inside the low-resolution full-screen GUI texture. The skin remains nearest-filtered, preserving Minecraft's pixel-art texture style while removing the coarse GUI-scale silhouette.
- Defer avatar/cursor sprite generation from every raw `CursorMoved` event to the coalesced `RedrawRequested` callback. Cursor movement no longer recomposes or uploads the entire HUD/inventory texture.
- Move the carried stack to a dedicated GPU sprite positioned from the framebuffer cursor coordinates. This fixes the previous local-vs-absolute GUI origin mismatch and keeps the carried icon above Steve.
- Leave the main inventory background, slot textures, light equations, world rendering and first-person hand swing untouched.
- Add unit tests for framebuffer-scale player preview output and carried-stack sprite sizing/content.

Validation: source-level checks and ZIP integrity are performed for this package. `cargo test --workspace` must be run on a Windows development machine because this build environment has no Rust toolchain installed.
