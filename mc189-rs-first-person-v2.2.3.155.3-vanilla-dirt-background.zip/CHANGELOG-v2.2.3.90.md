# v2.2.3.90 — Repair selected-tool resolver

## Changes
- Added the missing `held_tool_from_item_id` implementation used by gameplay mining and its unit tests.
- Recognizes the 1.8.9 wooden/stone/iron/diamond/golden pickaxes, axes and shovels, plus shears.
- Accepts both bare registry names and namespaced identifiers such as `minecraft:diamond_pickaxe`.
- Unknown and empty slots safely resolve to the empty hand.
- Expanded unit coverage for namespaced IDs and axe resolution.

## Important verification note
- Static source inspection found that v2.2.3.89 called and tested `held_tool_from_item_id` but did not define it. This release supplies the missing function, correcting a compile-blocking omission.
- Rust compilation and in-game testing are still not available in this environment; do not treat the project as compile-verified.
