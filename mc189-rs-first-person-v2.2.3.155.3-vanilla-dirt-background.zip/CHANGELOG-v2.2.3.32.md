# v2.2.3.32

- Corrected the negative-world-coordinate vertex-lighting regression test to expect the v2.2.3.31 vanilla-style lightmap curve for SkyLight level 6, rather than the pre-lightmap scalar value 0.4.
- No runtime lighting behavior changed in this release.
