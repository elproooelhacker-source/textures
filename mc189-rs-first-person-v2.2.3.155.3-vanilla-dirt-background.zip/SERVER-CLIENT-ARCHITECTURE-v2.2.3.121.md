# v2.2.3.121 — integrated server lifecycle and persistence

## Single-player world lifecycle

1. The normal title-screen Open World flow loads the spawn chunks and starts `IntegratedServer` automatically.
2. The server runs authoritative player movement/collision at a fixed 20 TPS on its own thread. The renderer sends sequenced input and consumes server snapshots.
3. The same integrated-server object owns `WorldPersistence`, a separate serial I/O worker. The client sends revisioned immutable chunk/player snapshots through the server API.
4. Persistence rewrites affected Anvil regions in batches and updates `level.dat` player data under the shared world I/O lock. The disk worker never blocks the 20 TPS simulation thread.
5. Autosaves occur every five minutes when dirty data exists. On close, the client first waits for outstanding block-edit work, submits a final save, and does not exit until the final result confirms all submitted revisions. A failed final write leaves the world session open so the user can retry.
6. After the window loop exits, `IntegratedServer` is dropped: its simulation thread is stopped and joined, then its persistence service closes its request channel and joins the writer. The world is not released while a save worker is still writing.

The separate `INICIAR-SERVIDOR-MINECRAFT-RUST.bat` remains for headless dedicated-server experiments; it is not part of normal single-player startup.

## Current limits

The app still owns mining/edit orchestration and submits the resulting chunk snapshots; this migration makes the server the disk-persistence owner but does not yet move every world mutation into the server tick. World time/weather metadata, dropped-item entities, complete entity/inventory simulation, remote chunk replication, and join-server UI are not yet migrated. The existing single-player inventory patch is persisted; this does not imply that all entity data is persisted.
