# v2.2.3.104 — drop-before-chunk/light refresh ordering

## Mining break sequence

- Preserve immediate live-world block removal: `collision.set_block_local(..., 0, 0)` runs as soon as the completed `MiningEvent::Broken` is handled, and the block's owned geometry is culled from the current CPU/GPU chunk mesh before the next redraw.
- Preserve the mining crack lifecycle: the drop is emitted only when `MiningEvent::Broken` arrives, i.e. after the mining progress reaches completion.
- Change the transaction order so the provisional `DroppedItem` entity is constructed and inserted into the live item list before the block-edit request is sent to the worker.
- Request a redraw immediately after inserting the drop. Only then enqueue neighbor-aware chunk rebuilding and lighting propagation, so that work cannot hold up creation/visibility of the drop.
- Keep revision-based provisional pickup/merge restrictions and rollback. If the worker channel is unavailable, remove only drops tagged with that edit revision, restore collision, clear the immediate hidden-block marker, and restore the prior mesh while preserving other pending removals.
- Keep successful chunk/light snapshots and mesh updates asynchronous; they replace the immediate filtered mesh when ready and continue to be saved by the existing deferred persistence pipeline.

## Verification

- Reviewed the mining event order and failure rollback path in `gpu_block_preview.rs`.
- ZIP integrity checked after packaging.
- Cargo/rustc and Windows GPU runtime are unavailable in this authoring environment. The new ordering still requires a fresh Windows release build and gameplay test to verify frame presentation and exact timing.

