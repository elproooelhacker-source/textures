# v2.2.3.54 — Biome generation pipeline foundation

## Added
- Deterministic biome raster API: `mc189_core::worldgen::generate_biome_map(seed, origin_x, origin_z, width, height)`.
- `BiomeMap` with world-coordinate lookup and the Java 1.8.9 biome ID constants.
- Seeded island initialization, early land expansion/coast erosion passes, zoom raster stages, and vanilla climate biome pools (warm, temperate, cool, snowy).
- Negative world coordinates use Euclidean coordinate division for stable chunk-grid addressing.

## Important scope note
This is an intermediate biome-generation implementation, not yet a byte-for-byte compatible full 1.8.9 `GenLayer` graph. The exact `RemoveTooMuchOcean`, `AddSnow`, `Edge`, `AddMushroomIsland`, `DeepOcean`, `GenLayerHills`, `GenLayerShore`, river mixing and Voronoi stages remain to be ported. It does not yet synthesize terrain blocks, populate features, create `level.dat`, or write Anvil region files. The API is intended as the biome input for the subsequent terrain generator.
