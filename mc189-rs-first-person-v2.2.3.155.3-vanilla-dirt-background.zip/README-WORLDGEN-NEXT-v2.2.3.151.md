# Worldgen v2.2.3.151

Continues from v2.2.3.150. Adds the specialized Big Tree and Mega Jungle paths used by `BiomeGenJungle.genBigTreeChance`.

The Big Tree uses one population-stream `nextLong()` to seed a private JavaRandom, then generates foliage nodes, leaf discs, branch supports and an axis-aware trunk/branch network. Mega Jungle follows the MCP 1.8.9 huge-tree clearance, 2x2 soil/trunk, crown, branch and vine logic.

Important remaining fidelity issue: vanilla reuses a mutable `WorldGenBigTree` instance per biome, retaining its initialized `heightLimit` across calls. This version still computes that private height limit per invocation. A persistent per-biome generator state must be added before claiming exact cross-chunk parity. Cocoa, melons, the 50-attempt WorldGenVines pass, and other biome decoration also remain pending.

No Rust compilation/tests were run because this packaging environment has no `cargo` or `rustc` executable.
