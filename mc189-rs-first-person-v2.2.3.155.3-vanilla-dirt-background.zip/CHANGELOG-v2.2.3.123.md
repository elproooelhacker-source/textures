# v2.2.3.123 — server-owned inventory model and container commands

## Migrated in this increment

- Extracted `ItemStack` and `PlayerInventory` from the graphical app into `mc189-server::inventory`. The app re-exports the same types for rendering compatibility; the data model and slot mutation rules now compile as part of the server crate.
- The integrated server receives the saved inventory at world startup and keeps the authoritative copy on its 20 TPS thread.
- Hotbar selection, left/right container clicks, armor-slot clicks, and shift-click transfers are now commands handled by the integrated server. The client sends slot/action intent and no longer applies those GUI mutations itself.
- Server snapshots replicate inventory only when its revision changes. A failed/full snapshot queue does not acknowledge the revision, so the update is retried rather than silently lost.
- Mining no longer accepts a client-provided held-tool descriptor or mining context. The server resolves the selected tool from its own inventory and derives grounded/submerged state from its authoritative player state.
- Added server-crate tests for the 36 main slots + four armor slots, hotbar validation, merge-first insertion, right-click splitting, and shift-click transfer.

## MCP 1.8.9 mapping reviewed

- `net.minecraft.entity.player.InventoryPlayer`: inventory layout, selected hotbar slot, NBT read/write, `addItemStackToInventory`, and current-item lookup.
- `net.minecraft.inventory.Container`: `slotClick`, `transferStackInSlot`, and `mergeItemStack`.
- `net.minecraft.client.gui.inventory.GuiContainer`: mouse-to-slot action dispatch. The Rust GUI remains a presentation/input adapter; it now submits supported actions to the server.

## Remaining client-owned/transitional systems

- Item entity creation, movement, merge, despawn, and pickup are not yet fully server-owned.
- Q/Ctrl+Q world drops, `/give` and `/clear` still have transitional client-side paths and are the next inventory actions to migrate.
- Container drag-splitting, number-key swaps, double-click collection, creative pick-block, crafting/container types, and all vanilla slot validity rules are not implemented by this increment.
- Tool durability and full player capability/effect attributes are not yet server-authoritative.
- The client still derives chunk lighting/meshes and streams chunk snapshots to the integrated server; world chunk loading/streaming ownership is not fully migrated.
- No Minecraft protocol 47 work is included. The internal dedicated-server transport remains separate and limited.

## Validation

- ZIP archive and source-level structural checks only.
- `cargo`, `rustc`, and `rustfmt` are unavailable in the authoring environment; no compile or runtime test success is claimed. Run `cargo test --workspace` on Windows before using this build.
