# v2.2.3.64 — Block mesh and state-resolution recovery

This revision is based specifically on `mc189-rs-first-person-v2.2.3.63 (2).zip`.

## Fixes

- Added vanilla 1.8.9 state mappings for ordinary glass, ice, and snow layers (metadata 0–7 -> `layers=1..8`).
- Added contextual state selection for all 13 classic stair families, including top/bottom halves and neighbor-derived straight/inner/outer shapes.
- Added contextual lower/upper-half state selection for oak, iron, spruce, birch, jungle, acacia, and dark-oak doors.
- Stopped dropping every stair variant with `uvlock=true`; rotated faces now receive a world-facing UV projection.
- A missing/invalid model variant now skips only the affected block state and logs the state selector, instead of aborting construction of the entire chunk.
- A missing texture-atlas sprite now skips only faces that use that sprite and logs the missing key, instead of failing mesh compilation for the whole chunk.
- Added regression tests for the newly mapped block families and UV-lock projection.

## Preservation

- No changes were made to the vanilla lighting equations, the lighting integration, menu transitions, world generation, or world save data.
- The ZIP contains the Rust project and its source changes; it does not include Mojang source files.

## Validation status

- ZIP archive integrity and embedded 1.8.9 asset selector coverage are checked as part of packaging.
- Cargo tests were not run in this environment because the Rust toolchain (`cargo`/`rustc`) is unavailable here. Run `cargo fmt --all` and `cargo test --workspace` on Windows to validate compilation.
