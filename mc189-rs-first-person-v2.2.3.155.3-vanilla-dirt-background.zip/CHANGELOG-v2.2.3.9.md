# mc189-rs v2.2.3.9

- Fixed first-person Steve arm startup failure with the 64x64 skin embedded in the Minecraft 1.8.9 client JAR.
- Accepts both 64x32 legacy and 64x64 player skins.
- Scales the arm UV vertical coordinates using the actual skin height, preserving the same classic right-arm region in either format.
- Added regression coverage for the 64x32 and 64x64 UV layouts.
- World streaming, collision, player movement, and camera interpolation are unchanged.

Validation note: ZIP integrity is checked. Run `cargo fmt --all` and `cargo test --workspace` on Windows before launching.
