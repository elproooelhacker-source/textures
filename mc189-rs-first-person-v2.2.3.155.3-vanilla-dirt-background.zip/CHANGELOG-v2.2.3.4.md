# v2.2.3.4 — crossed vegetation depth stability

## Fixed
- Routes vanilla crossed-vegetation textures (`tallgrass`, `fern`, and double-plant grass/fern) through a dedicated alpha-cutout render pipeline.
- Enables back-face culling for those crossed planes. Vanilla 1.8.9 defines front and back faces at the same zero-thickness geometry, with opposite winding and opposite triangulation diagonals; drawing both faces in the blended pipeline could produce coplanar depth instability.
- Uses replacement blending for binary-alpha plant textures, while retaining the existing blended pipeline for all other model geometry and fluids.
- Uses strict `Less` depth comparison for the world model pipeline.

## Preserved
- First-person movement, jump handling, camera interpolation, collision, world loading, and read-only world access are unchanged.
- No world data or files inside the original Minecraft JAR are modified.

## Validation
- Added a unit test covering the exact vanilla vegetation texture paths assigned to the cutout pipeline and confirming ordinary grass-block and leaf textures are excluded.
- The original 1.8.9 JAR was inspected: the crossed-plant alpha channels contain only 0 and 255 values, matching cutout rendering rather than blended transparency.
