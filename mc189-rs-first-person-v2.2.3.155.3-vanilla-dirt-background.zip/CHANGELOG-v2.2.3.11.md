# v2.2.3.11 — Vanilla first-person arm transform

- Replaced the hand-tuned screen-space pose with the exact static transform sequence from Minecraft 1.8.9 `ItemRenderer.renderPlayerArm` (zero equip/swing progress).
- Rebuilt the right arm from `ModelBiped` dimensions and pivot: `addBox(-3,-2,-2,4,12,4)`, pivot `(-5,2,0)`, scale `1/16`.
- Reproduced `ModelBiped`'s default idle arm roll (`0.1` radians).
- Added the `ModelPlayer` outer right-sleeve layer for 64x64 skins, inflated by `0.25` model pixels and mapped to UV offset `(40,32)`.
- Added regression checks for the vanilla transformed view-space bounds and both skin sizes.
- No changes to player movement, camera interpolation, chunk streaming, collision, or world loading.
