# v2.2.3.132 — Native Multiplayer server-entry screen

- Activated the existing Multiplayer title-screen button.
- Added a native server-entry screen with editable server name, address, port, and offline username fields.
- Added persistent saved-server entries in `servers-mc189-rust.json` beside the `saves` directory; selecting a saved entry fills the form.
- Added Save Server and Connect actions. Connect runs the existing Protocol-47 TCP handshake and offline LOGIN sequence, reports Login Success / the first PLAY packet when available, and reports server rejection, timeout, DNS, or premium-authentication requirements.
- The first integration is a handshake/login diagnostic, not a fully playable remote-world client. Servers requiring `online-mode=true` cannot be joined until Mojang/Microsoft session authentication is implemented.
- The test launcher now builds in Cargo offline mode so it does not try to update crates.io during the launch step.
