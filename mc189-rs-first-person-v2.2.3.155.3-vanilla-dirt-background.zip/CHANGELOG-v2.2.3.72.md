# v2.2.3.72 — hover/held items test fix

- Fixed the `cargo test --workspace` compilation error in the inventory test helper by initializing `InventoryUi.hovered_slot` to `None`.
- No gameplay behavior changed; this is a test-fixture initialization fix.
