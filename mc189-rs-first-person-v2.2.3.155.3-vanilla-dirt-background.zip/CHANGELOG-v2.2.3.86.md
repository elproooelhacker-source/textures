# v2.2.3.86 — Mutable Anvil/NBT foundation

- Added a complete NBT writer for tag IDs 1 through 12, plus mutable compound/list access.
- Added `MutableChunk` with 1.8 legacy block ID and metadata reads/writes over `Blocks`, `Add`, and `Data` arrays.
- Missing sections are allocated when a non-air block is written; unknown NBT tags and chunk metadata remain intact.
- Block-ID replacement removes a matching tile entity from `Level.TileEntities`.
- Added transactional full-region rewriting: preserves sibling chunk records and timestamps, validates sector overlap/record bounds, writes and flushes a temporary region, atomically swaps it into place, and retains a uniquely named backup.
- Added negative-coordinate-aware `load_mutable_chunk` / `save_mutable_chunk` APIs.
- Added `set-world-block` CLI for storage smoke testing and manual editing while Minecraft is closed.
- Added tests for legacy 12-bit IDs, metadata nibble editing, NBT round-trip/unknown-tag preservation, and region save/reload.

## Not yet complete

This is the memory mutation + persistent storage foundation. The live first-person mining input does not yet invoke it. HeightMap and lighting are not recalculated, and live chunk mesh invalidation/relighting remains a required integration step. Cargo/rustc were not available in the authoring environment, so Rust tests are included but not claimed as executed.
