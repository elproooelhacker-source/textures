# Deferred world persistence — v2.2.3.101

## Runtime data flow

1. The game loop optimistically changes the live collision chunk to air and sends an immutable pre-edit snapshot plus the block delta to `mc189-block-edit-worker`.
2. The edit worker validates the expected block state, applies the delta to its session cache, updates the affected light neighborhood, and builds replacement CPU chunk meshes. It does not open a mutable NBT chunk or write Anvil data.
3. The main thread receives the accepted decoded snapshots, updates live collision data, inserts them into `dirty_chunks` with the edit revision, and queues mesh uploads. Drops are released from provisional state as soon as the in-memory transaction is accepted; disk persistence is not on the mining path.
4. `mc189-world-save-worker` receives immutable dirty snapshots. Under the shared `world_io_lock`, it reloads original mutable NBT records, overlays block IDs/metadata and derived HeightMap/light values, then sends all modified chunks to `save_mutable_chunks`. If relighting produced an air-only section, its decoded light channels are materialized in the NBT `Sections` list so that light does not vanish on reload.
5. `save_mutable_chunks` groups the batch by region coordinates. Each affected region is reconstructed once, untouched sibling chunk records and timestamps are preserved, and a temporary file is synced before the current region is backed up and replaced.
6. A completed save reports the `(chunk coordinate, revision)` pairs. The main thread clears a dirty entry only if its current revision still equals the saved revision; newer edits remain dirty.
7. A five-minute checkpoint reduces crash-loss exposure. A graceful close stops new input, waits for outstanding edit transactions, flushes the entire dirty set, and exits only after the final result confirms success. A final-save error keeps the session open for retry.

## Thread ownership

- Window/render thread: input, optimistic live collision update, dirty snapshot bookkeeping, GPU queueing, close coordination.
- Block-edit worker: decoded authoritative chunk cache, block delta validation, local lighting work, CPU mesh build.
- Chunk streamer: disk chunk reads and background mesh builds.
- World-save worker: mutable NBT overlays and Anvil region commits.
- Shared `world_io_lock`: serializes region reads/writes across workers; it is never acquired by the per-frame render operation.

## Safety properties

- No region rewrite is performed synchronously by the block-mining handler.
- Save snapshots are immutable. Edits accepted while a checkpoint is running get newer revisions and cannot be incorrectly marked clean by an older save result.
- Region batches preserve untouched sibling chunk records and unknown NBT tags.
- Failed final persistence does not close the game and does not clear dirty entries.
- The launcher continues to recommend a pre-test copy of the world. Periodic checkpoints are crash-recovery protection, not a guarantee against power loss, disk failure, or forced process termination during a region replacement.

## Current scope boundary

Saved by this worker: modified block IDs, metadata, HeightMap, BlockLight, and SkyLight for changed chunks and affected light neighbors, including air-only sections which carry propagated light.

Not yet saved by this worker: player position/rotation, inventory, dropped-item entity NBT, mobs/entities, tile-entity ticking state beyond NBT preservation, world time/weather, random generator state, and other world/session metadata. These require distinct serialization and lifecycle integration before this can be described as a complete vanilla-equivalent save system.
