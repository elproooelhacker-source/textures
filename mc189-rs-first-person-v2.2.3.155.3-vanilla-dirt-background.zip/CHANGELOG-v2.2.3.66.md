# v2.2.3.66 — Vanilla first-person hand swing

Based on `mc189-rs-first-person-v2.2.3.65-collisions-atlas.zip`.

## Changes

- Added left-click hand swing after the first click captures the mouse, matching vanilla's focus-capture behavior.
- Ported the arm translation and yaw/roll curves from MCP 1.8.9 `ItemRenderer.renderPlayerArm`: translation based on `sin(sqrt(s) * PI)`, a 70-degree yaw arc, and a -20-degree roll arc.
- Ported the six-tick integer counter, halfway retrigger window, tick interpolation, and wrap from progress 5/6 to 1.0 in `EntityLivingBase` rather than using an approximate wall-clock timer.
- Rebuilds only the small arm vertex buffer while swinging; world chunk meshes, collision, atlas layout, and lighting equations are unchanged.
- Added regression coverage for both legacy 64x32 and modern 64x64 skins, including visible mid-swing displacement and return to the idle pose at progress 1.

## Source study

- `client.jar` was inspected as the vanilla 1.8.9 resource/binary archive. Its gameplay classes are obfuscated, so the logic was cross-checked against public MCP 1.8.9 decompiled sources: `ItemRenderer.renderPlayerArm` and `Minecraft.clickMouse`.
- Reference: https://github.com/Marcelektro/MavenMCP-1.8.9/blob/master/src/main/java/net/minecraft/client/renderer/ItemRenderer.java
- Reference: https://github.com/YouM02/mcp-1.8.9/blob/master/src/minecraft/net/minecraft/client/Minecraft.java

## Validation

- Source call-sites and buffer usage were inspected after changes.
- Cargo tests could not be executed in this environment because `cargo` and `rustc` are unavailable. Run `cargo fmt --all` and `cargo test --workspace` in Windows CMD.
- Reference: https://raw.githubusercontent.com/Marcelektro/MavenMCP-1.8.9/master/src/main/java/net/minecraft/entity/EntityLivingBase.java (1.8.9 swing counter/interpolation and six-tick default duration)
