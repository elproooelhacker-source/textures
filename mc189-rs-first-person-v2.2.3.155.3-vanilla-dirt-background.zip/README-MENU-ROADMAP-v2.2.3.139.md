# Minecraft Java 1.8.9 native GUI — roadmap after v2.2.3.139

This iteration ports more of `GuiSelectWorld` behavior using the deobfuscated 1.8.9 source as the reference.

Completed in this slice:
- Vanilla-like three-line world rows and selection-dependent buttons.
- Double-click launch.
- Display-name rename through `level.dat` `Data.LevelName`, preserving unrelated NBT.
- Confirmation before world deletion; confirmed saves are quarantined in `.mc189-trash` for recovery rather than destroyed.

Next parity work, in order:
1. `GuiCreateWorld`: exact layout and control state, then connect it only after a valid 1.8.9-compatible initial world creation pipeline exists.
2. `GuiSelectWorld`: scrolling, last-played date, conversion warning, recreate-from-`WorldInfo` options.
3. `GuiMultiplayer` / `ServerSelectionList`: protocol-47 status handshake, JSON MOTD formatting, ping time, favicon, LAN scan, scroll and keyboard navigation.
4. `GuiScreenAddServer`: vanilla text field positions, hostname validation, resource-pack policy toggle, enter/tab behavior.
5. `GuiConnecting` and loading/disconnect screens tied to the persistent PLAY state and chunk stream.
6. Exact panorama framebuffer pipeline (64 views, six faces, seven blur passes) and remaining secondary screens.
