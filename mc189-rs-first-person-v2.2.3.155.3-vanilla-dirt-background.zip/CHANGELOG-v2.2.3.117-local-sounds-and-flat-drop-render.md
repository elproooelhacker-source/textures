# v2.2.3.117 — local sound pack extraction and flat dropped-item rendering

## Project-local vanilla audio

- The selected 1.8 asset index is now materialized into `runtime/audio/assets/minecraft/sounds` on first world launch. Every `.ogg` object referenced by that exact index is copied from UltimMC's SHA-1 `assets/objects` cache; `sounds.json` is copied beside it when present.
- The executable prefers the project-local sound tree on later launches and continues to use the launcher cache/JAR as a fallback if an asset is missing. Existing files are reused when their indexed size matches.
- The Windows launcher sets `MC189_PROJECT_ROOT` explicitly so the cache is placed next to the project, not in an incidental working directory.
- The supplied vanilla 1.8.9 `client.jar` was checked and contains zero `.ogg` entries and no `assets/minecraft/sounds.json`. Thus the local sound pack is extracted from the official launcher object store using the 1.8 index; it cannot be extracted from absent JAR entries.
- Added a regression test for materializing an indexed sound file to the exact project-local path.

## Flat item entities

- Generated/flat item entities now keep the vanilla net 0.5 GROUND model scale. `RenderEntityItem.doRender` calls `RenderItem.renderItem(stack, bakedModel)` directly, so its inner 0.5 scale applies but the separate `preTransform` 2x path does not. GUI-3D block drops keep the extra outer 0.5 and remain net 0.25.
- The drop-only sprite mesh now has the mirrored back alpha-cutout plane from MCP `ItemModelGenerator`; the first-person held mesh stays unchanged to avoid reintroducing its former duplicate silhouette.
- Flat stack copies now start at `-0.0234375 * (countOfCopies - 1)` and step by `0.046875 * GROUND.scale.z`, centered around the entity as in `RenderEntityItem.func_177077_a`.
- Added face brightness to the extruded sprite silhouette.
- GUI-3D block drop transforms and their existing random pile offsets are retained.
- Added tests for drop-only back-face geometry and centered flat-stack spacing.

## Validation

- The supplied `client.jar` archive was inspected: no `.ogg` entries and no `assets/minecraft/sounds.json`.
- ZIP integrity is checked after packaging. This authoring environment does not have Cargo/rustc, so no claim is made that the Rust workspace tests or Windows runtime were executed here.
