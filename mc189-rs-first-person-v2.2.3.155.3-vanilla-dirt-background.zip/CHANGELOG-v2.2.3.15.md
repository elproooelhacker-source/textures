# v2.2.3.15 — vanilla 1.8.9 water/lava rendering

This increment replaces the approximate liquid mesh with the rendering rules from the Minecraft 1.8.9 `BlockFluidRenderer` / `BlockLiquid` implementation.

## Rendering changes

- Computes each liquid top corner from the same 2x2 neighborhood and weighted metadata-height average used by vanilla. A same-family liquid block above any sampled cell forces that corner to full height.
- Loads all eight neighboring chunks while building each chunk mesh, so diagonal water/lava connections are known even at chunk corners.
- Uses vanilla flow-vector decay differences and the `atan2(z, x) - PI/2` flow direction to select and rotate the flowing sprite UVs.
- Reproduces still/flow sprite choice, side UV ranges, 0.001 surface/side inset, bottom-face visibility, side shading (0.8 / 0.6), and the conditional second top quad from `BlockLiquid.shouldRenderSides`.
- Applies the vanilla 3x3 biome water-color average, including the swamp water multiplier `0xE0FFAE`.
- Gives water a dedicated translucent pass after opaque terrain, lava, and cutout vegetation. Water no longer writes depth; chunks with water are drawn far-to-near. Lava remains in the opaque pass, matching `BlockLiquid.getBlockLayer()`.
- Adds a runtime frame scheduler for the four animated liquid sprites, reading the actual PNG strips and `.mcmeta` frame order/timing from `block-atlas-output/animated`. Frame updates also refresh the atlas gutters to avoid edge bleed.

## Waterfalls and spreading

Existing falling and flowing states from the saved Anvil world now use the vanilla falling-height rule, vertical side faces, neighbor-derived corner heights, and directional flow texture. Existing horizontal flow levels therefore join and spread visually according to the saved block metadata.

The world remains read-only. `BlockDynamicLiquid.updateTick` is the separate simulation that changes block levels, creates new flow blocks, regenerates sources, and handles water/lava interactions. This increment does not mutate or simulate new fluid blocks; adding a transient in-memory fluid simulation is a separate gameplay feature and must not write to the user's original world.

## Validation status

- Added regression tests for vanilla corner averaging, full-height falling columns, water/lava exposed faces, and swamp water tint.
- The assistant environment does not contain `cargo`/`rustc`, so this archive has not been compiled here. Run `cargo fmt --all` and `cargo test --workspace` on Windows before launching the world.
- Transparency ordering is sorted at chunk granularity, not by every individual fluid quad. Full per-face translucent sorting and vanilla world/block light sampling remain future fidelity work.
