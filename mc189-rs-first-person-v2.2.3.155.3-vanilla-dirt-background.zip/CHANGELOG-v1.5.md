# v1.5 — first integrated textured chunk renderer

- Added `preview-textured-chunk` to connect Anvil chunk decoding, the legacy ID/metadata state registry, blockstate variants, model geometry, atlas UV remapping and the wgpu viewer.
- Added `ModelCatalog`, which indexes the JAR's model resources once and caches inherited models and compiled quads by canonical model path.
- Added deterministic world-position-based weighted variant selection for block instances.
- Added neighbor-derived `snowy` selection for grass and four-way connection selection for oak fences.
- Added conservative `cullface` removal when an adjacent block is in the explicit opaque full-cube occlusion set.
- Added chunk-aware camera framing and dynamic far clipping.
- Added visible coverage counters for rendered blocks, fluids, dedicated legacy visuals, unknown states, `uvlock`, and unsupported/missing models.
- Added CPU-side regression tests for stable coordinate seeds, fence connection classification, rotated cullface directions, and snowy grass state.

This milestone is a first textured chunk path, not full visual parity. Fluids, animated textures, tinting, lighting, tile entities, special metadata geometry, full transparency handling, and multi-page atlas support remain future work. `uvlock=true` states are deliberately skipped.

The authoring environment did not contain `cargo`/`rustc`; Windows compilation and test validation are required before treating this version as verified.
