# v2.2.3.82 — Drop RNG and ore semantics correction

## Scope

A narrow correctness pass over `crates/mc189-app/src/drop_registry.rs`. The mining controller, raycast, renderer, inventory and world storage were intentionally left untouched.

## Changes

- Replaced the previous custom LCG with a Java `java.util.Random` 48-bit generator (`nextInt(bound)` including rejection sampling, and `nextFloat`).
- Added `JavaRandom::from_internal_state` and `resolve_drops_with_rng` so a future world integration can preserve one shared `World.rand` stream instead of reseeding each block break.
- Corrected vanilla `BlockOre` behavior for coal, lapis, diamond, emerald and nether quartz, including Fortune multiplier ordering and lapis's base 4–8 roll.
- Corrected iron/gold ore to drop their ore-block item (not ingots); Fortune does not multiply these self-drops.
- Corrected obsidian to return obsidian rather than an empty drop.
- Corrected several common base drops that were previously incorrectly classified: iron/gold ore, bed, wooden door, redstone wire and tripwire.
- Narrowed the explicit no-drop set; valid but unimplemented block IDs now remain `Unknown` instead of being mislabeled as no-drop.
- Corrected redstone ore Fortune quantity to use two ordered rolls: base `4 + nextInt(2)`, then `nextInt(fortune + 1)`.
- Removed the dangerous generic fallback that silently treated every unimplemented block ID as its own item. Unimplemented valid IDs now return `DropStatus::Unknown` rather than a guessed drop.
- Added focused tests for Java RNG sequence, ore self-drops, obsidian, lapis and redstone Fortune rolls, and unsupported IDs.

## Source and artifact cross-check

- `client.jar` inspected locally: SHA-256 `14f0d96d1a56fb4f5c3b2233d00699525893fe5ce3dcf181e7de59120595d298`; its class files are obfuscated (e.g. `auz.class`) rather than MCP-named, so class-level behavior was cross-referenced against the deobfuscated 1.8.9 MCP source browser and source mirrors listed in `RESEARCH-v2.2.3.82.md`.
- `client.jar` was not modified or redistributed in this ZIP.

## Known limits

- This is not complete drop parity. The Silk Touch eligibility table is still a conservative/manual block-ID matrix and needs class-by-class verification.
- Some non-ore block rules still remain provisional. The redstone ore / glowstone / leaves / crops / gravel / double-plant families need their own source-by-source passes.
- XP orb drops are not yet represented in `ItemDrop` and are not implemented here.
- The module is not connected to the actual break event, world mutation, entity spawn, inventory pickup, or Anvil persistence.
- `resolve_drops` is a deterministic convenience entry point. Actual vanilla parity at runtime requires using `resolve_drops_with_rng` with the world's shared RNG state in the exact call order.

## Validation

- Java RNG sequence was independently compared with `java.util.Random` on seed 0 (`nextInt(100)`, `nextFloat`, `nextInt(100)`).
- ZIP integrity is checked after packaging.
- Rust compilation/unit tests were not run: Cargo/Rust toolchain is unavailable in this environment.
