# v2.2.3.88 — first live left-click mining integration

## Integrated
- Added a held-left-mouse state to the first-person gameplay event loop. Releasing the button or losing focus resets the mining controller.
- Runs the existing mining controller at the fixed 20 Hz gameplay tick.
- Uses the player's eye position/look direction and a 4.5-block voxel raycast to select the first solid loaded block.
- Connects mining progress to the existing hardness calculation (currently using the default hand tool and survival context).
- On a completed break, writes air into the Anvil chunk through the existing safe mutable-chunk writer, updates the live collision snapshot, rebuilds that chunk's textured mesh, and uploads the replacement GPU mesh.
- Added a gameplay remesh helper that reuses the chunk model/texture pipeline and neighboring world data.

## Important limitations
- This is the first end-to-end break path, not full Minecraft mining parity.
- The selected tool is currently treated as an empty hand; hotbar item-to-tool mapping, enchantments, effects, creative mode, and correct harvest/drop rules still need integration.
- Crack-stage rendering is not yet drawn on the targeted block.
- Item drops/entities, pickup, XP, and inventory insertion are not yet connected.
- Neighboring chunk meshes are not yet rebuilt for every boundary-sensitive block change; this needs a dedicated boundary update pass.
- HeightMap and lighting recomputation remain outstanding in the Anvil writer.
- Build and runtime tests were not executed in this environment because Cargo/Rust are unavailable. Validate with Windows Cargo before using a valuable world; keep a backup.
