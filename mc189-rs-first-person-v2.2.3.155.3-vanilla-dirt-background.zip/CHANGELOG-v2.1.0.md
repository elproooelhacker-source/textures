# v2.1.0 — Saved-world discovery and selection foundation

- Added read-only discovery of direct child world folders under `.minecraft/saves`.
- Validates `level.dat` and `region/` before listing a save; reads display name and spawn metadata.
- Added `list-worlds` for a deterministic inventory of saves.
- Added an interactive terminal world selector (`select-world`) that selects a save and opens the existing textured 3x3 region preview centered on its saved spawn chunk.
- World data is read-only; no save files are written or migrated.
- This is the first world-selection/loading path, not yet a graphical main menu or playable first-person session. Player collision queries, live keyboard/mouse input, first-person camera, and chunk streaming remain future milestones.
