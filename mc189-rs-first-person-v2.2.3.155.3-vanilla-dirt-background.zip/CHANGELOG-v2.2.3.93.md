# v2.2.3.93 — dropped item world rendering foundation

## Added
- Added a dynamic GPU vertex batch for dropped item entities.
- Dropped entities are rendered in the world pass using the world camera, block atlas, lightmap and terrain depth buffer. They are not HUD sprites and are occluded by terrain.
- Item geometry is resolved from the bundled Minecraft 1.8.9 JAR model catalog (`item/<registry-name>`) and compiled through the same atlas-aware block-model path used by first-person block items.
- Added ground-scale placement, age-based bobbing/spin, and a small number of offset model copies to communicate stack size.
- The batch is refreshed after fixed-tick entity physics, merge, despawn and pickup processing.

## Limitations
- This first renderer pass only displays dropped items whose resolved item model uses textures in the block atlas. Generated item textures (`textures/items`) and unsupported models are skipped rather than rendered with an incorrect texture.
- Item lighting currently uses full sky light and zero block light; per-position sampled world light is not yet connected.
- The ground transform and stack-copy presentation are an approximation; exact `RenderEntityItem` interpolation, bobbing, rotation and count thresholds still need MCP-level parity work.
- No Cargo/rustc toolchain is installed in the authoring environment, so compilation and runtime rendering could not be verified here. ZIP integrity is checked separately.
