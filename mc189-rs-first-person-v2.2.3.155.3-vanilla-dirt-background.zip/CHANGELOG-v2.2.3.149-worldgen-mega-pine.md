# v2.2.3.149 — Mega Pine / Mega Taiga

- Ported the `WorldGenMegaPineTree` path backed by `WorldGenHugeTrees` from MCP 1.8.9.
- Added spruce mega-pine height draws, clearance checks, 2x2 dirt support, layered circular crown, 2x2 trunk, and post-success podzol pass.
- Added podzol as legacy dirt block ID 3 metadata 2.
- Enabled mega taiga biome IDs 32/33 and mutated mega-spruce taiga ID 160 with the vanilla `BiomeGenTaiga.genBigTreeChance` branch structure.
- Preserved the extra `nextInt(13)` draw only for the type-1 mega taiga branch; mutated type 2 bypasses it as in MCP.
- Added deterministic mega-taiga regression coverage.

## Scope / limitations

- This is the mega-pine generator path only. The mega-taiga biome's additional boulder, fern, dead-bush, double-plant and mushroom decoration is not yet complete.
- `WorldGenMegaPineTree`'s post-generation podzol conversion is included, but world notifications are intentionally omitted by this data-only terrain pipeline.
- No bit-identical whole-world claim: population prelude structures/lakes/dungeons and the remaining biome decoration still need porting in vanilla order.
- Rust compilation/tests were not run in this environment if `cargo`/`rustc` are unavailable; ZIP integrity is checked separately.
