# Client/server architecture — v2.2.3.126

## Step 1 — EntityItem lifecycle
The integrated server owns creation of block-generated EntityItem instances, their 20 TPS update, collision, lava/water behavior, stack merging, pickup delay, and despawn.

## Step 2 — Item pickup
The server validates pickup delay, provisional state, player/entity AABB overlap and inventory capacity. It transfers only the accepted amount, retains a partial remainder, and publishes confirmed pickup events plus inventory snapshots.

## Step 3 — Inventory actions
The gameplay client now sends intents for:
- Q / Ctrl+Q from the selected hotbar slot.
- Q / Ctrl+Q from the hovered inventory/armor slot when the cursor stack is empty.
- Dropping the carried cursor stack when the inventory screen closes.
- `/give` after client-side item-name normalization, with independent server validation of the 1.8.9 numeric item ID, count and metadata.
- `/clear` (the currently supported no-argument form).

The integrated server performs the inventory mutation, increments the inventory revision, and creates authoritative player-thrown EntityItem instances with a 40-tick pickup delay. `/give` overflow is emitted into the world instead of being silently discarded. The client no longer performs local Q drops, command inventory edits, cursor reinsertion, or local EntityItem physics/merge/pickup/despawn. It renders only server EntityItem snapshots and applies server inventory snapshots.

## Remaining authority caveat
The GUI still stores a replica for rendering. Inventory persistence currently observes that replicated snapshot on the client; its source-of-truth path and world/chunk ownership remain part of the later authority/persistence audit.

## Remaining steps
- Step 4: durability and remaining player state.
- Step 5: chunk/world ownership and persistence source-of-truth audit.
- Step 6: close remaining authority gaps and run the full regression suite.
- Step 7: authoritative block placement.
- Step 8: Minecraft 1.8.9 protocol 47 interoperability.

## Validation status
Static source review and ZIP integrity checks are available from the authoring environment. Cargo tests and release compilation must still be run on the Windows machine with the Rust toolchain.
