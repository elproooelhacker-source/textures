# v2.2.3.14 — Water shoreline visibility

- Restored vertical liquid faces only at exposed fluid boundaries (air/empty space or lower neighboring fluid).
- Adjacent equal-height water blocks do not emit internal side faces; the lake interior remains a clean horizontal surface.
- Exposed shore edges are closed so the camera cannot look through the open side of the water volume into terrain/caves.
- Lava retains its prior top and exposed-side behavior.
- Added regression tests for exposed water shore edges and suppression of internal walls between adjacent water blocks.
- First-person arm, pumpkin collision, mushroom cutout, and all unrelated rendering behavior remain unchanged from v2.2.3.13.
