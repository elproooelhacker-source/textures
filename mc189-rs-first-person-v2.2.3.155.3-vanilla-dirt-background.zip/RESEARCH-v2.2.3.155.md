# Research notes

Compared generator algorithms against MCP 1.8.9 source classes: WorldGenFlowers, WorldGenDeadBush, WorldGenReed, WorldGenCactus, WorldGenWaterlily, WorldGenPumpkin and WorldGenMelon. BiomeDecorator.java confirms that these generators are invoked as part of genDecorations after the ore/substrate/tree/big-mushroom stages, with biome-configured counts.

Known modeling limits: TerrainPopulationRegion currently has a reduced block/material model. These ports approximate canBlockStay/canPlaceBlockAt with the represented block types, do not yet model full block collision/replaceability, light, upper/lower double-plant metadata, or the WorldGenFlowers type selection from biome flower noise.
