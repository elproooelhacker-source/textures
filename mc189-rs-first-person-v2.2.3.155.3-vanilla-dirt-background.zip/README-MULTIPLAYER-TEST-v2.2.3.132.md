# Multiplayer handshake test — v2.2.3.132

## What is available

The title-screen **Multiplayer** button opens a native server-entry screen. It supports:

- Server name, host/address, optional port, and offline username fields. A blank port uses the vanilla default `25565`.
- Click a field and type; `Backspace` deletes and `Tab` cycles through the four fields.
- `SAVE SERVER` stores the entry in `servers-mc189-rust.json` next to the `.minecraft/saves` directory.
- Click a saved server row to load its values back into the fields.
- `CONNECT` opens TCP and executes the existing Minecraft Java 1.8.9 Protocol-47 Handshake + Login Start flow.

## Test requirements

For a successful LOGIN test, use a Java 1.8.9-compatible server with `online-mode=false` and a valid offline username (1–16 ASCII letters, digits, or underscore). Enter the server host/address. The port may be left blank (defaults to `25565`) or entered separately for custom server ports. For a server on the same computer, use `127.0.0.1` and its listening port; for another computer on the LAN, use its reachable LAN IP and port.

A successful result reports `LOGIN SUCCESS`; if the server sends a PLAY packet promptly, its packet ID and payload size are shown too. A server with `online-mode=true` will request encryption/session authentication and is reported as requiring premium authentication. That is expected at this stage.

## Current boundary

This version does not yet load remote chunks, synchronize remote player movement, render a remote world, or implement Mojang/Microsoft session authentication. The connection is deliberately a handshake/login diagnostic, so it is suitable for testing the Protocol-47 connection foundation without implying full multiplayer gameplay.

## Launch

Use `INICIAR-PRUEBA-MINECRAFT-RUST.bat` as usual. Its release build now uses Cargo offline mode. If Cargo reports a missing package, the local Cargo cache/vendor directory must be populated first; the launcher will not try to access crates.io.

## Optional port (v2.2.3.134)
The port field is optional. Leave it empty to use Minecraft Java's default port `25565`; enter a number from `1` to `65535` only when the server uses a custom port.
