# v2.2.3.151 — Big trees and Mega Jungle

- Added a `WorldGenBigTree`-style generator for jungle biomes. The population RNG contributes exactly one `nextLong()` to seed the generator's private JavaRandom stream; the height, foliage-node, branch and trunk work then use that private stream.
- Added branch-axis metadata for oak logs (`metadata 4` for X and `metadata 8` for Z), rather than flattening every big-tree branch to vertical logs.
- Added `WorldGenMegaJungle(false, 10, 20, jungleLog, jungleLeaves)` behavior based on MCP 1.8.9: 2x2 clearance/soil, 2x2 trunk, three upper crown layers, branch generation, branch crowns and conditional vine attachments.
- Jungle biome selection now dispatches the 1/10 big-tree branch and, outside jungle edge, the 1/3 Mega Jungle branch instead of silently skipping those branches.
- Added deterministic generator tests for Mega Jungle and Big Tree terrain output.

## Fidelity caveats

- `BiomeGenBase` keeps one mutable `WorldGenBigTree` instance per biome, whose `heightLimit` is initialized only on its first successful use and retained. This version currently initializes a local height limit for each call; the private RNG handoff and per-call generator algorithm are ported, but cross-chunk shared-generator state still needs to be represented in the population context.
- The terrain model does not yet represent every block/material/state supported by the Java generator. Differential tests against the original Java 1.8.9 runtime are still required before claiming bit-identical world generation.
- Jungle cocoa, melons, the separate 50-attempt `WorldGenVines` pass, and the rest of `BiomeDecorator` remain incomplete.
- Rust compilation and `cargo test` were not run in the packaging environment because `cargo`/`rustc` are unavailable.
