# v2.2.3.17 — liquid movement, crosshair and grass-side biome tint

## Player and liquids
- Read water/lava block IDs and metadata from the active Anvil chunk window.
- Kept liquids non-solid; implemented liquid surface-height sampling and vanilla-style water/lava contact bounds.
- Added water current direction from adjacent liquid levels, water movement drag/gravity and held-jump swimming strokes.
- Added lava movement drag/gravity and held-jump strokes. Lava does not receive water-current acceleration.

## First-person UI
- Added a centered white crosshair with a dark outline.
- Crosshair is shown only while mouse capture is active and is rebuilt on window resize.

## Grass biome tint
- Grass/foliage biome tint uses the 3×3 biome neighborhood average used by vanilla `BiomeColorHelper`.
- Explicitly biome-tint `grass_side_overlay.png` on legacy grass blocks, even if its model face does not carry `tintindex`.

## Tests added
- Vanilla liquid height metadata mapping.
- Water detection and swimming motion without solid collision.
- Water current pushes the player according to neighbor-level gradient.
- Lava detection and stronger drag than water.
- Lava contact uses the vanilla material-bounds check even for low liquid levels.
- Grass side overlay receives biome tint independently of a missing tintindex.
- Crosshair geometry remains centered and finite at the reference resolution.
- Biome tint averages neighboring biome columns.

World remains read-only. This milestone does not add liquid block simulation/flow updates, health/damage/fire, oxygen, or a full survival HUD.
