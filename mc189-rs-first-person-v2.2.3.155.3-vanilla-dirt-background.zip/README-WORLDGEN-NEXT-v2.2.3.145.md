# World generation next steps — v2.2.3.145

The current faithful prefix of `BiomeDecorator.genDecorations` is now:
1. `generateOres()` (dirt, gravel, diorite, granite, andesite, coal, iron, gold, redstone, diamond, lapis).
2. Three sand patch attempts.
3. One clay patch attempt.
4. One gravel-as-sand patch attempt.

The prefix uses the same population RNG object throughout. Next, port the remaining decoration stages in MCP order, beginning with tree-count adjustment and tree placement, then mushrooms and plants. In parallel, implement the `ChunkProviderGenerate.populate()` prelude (structures/lakes/dungeons) without skipping RNG-consuming generator internals.
