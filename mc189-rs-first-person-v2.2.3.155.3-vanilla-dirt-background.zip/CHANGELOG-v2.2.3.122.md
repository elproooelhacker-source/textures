# v2.2.3.122 — server-authoritative mining and block drops

- Moved mining rules and legacy block drop table into `mc189-server`; app modules are compatibility re-exports.
- Integrated server now owns the mining controller and advances it at 20 TPS. The server computes its own raycast from authoritative player pose and collision chunks; it does not accept a client-selected block coordinate.
- On break, server captures the old block state, resolves drops using a server-owned JavaRandom stream initialized from `level.dat` RandomSeed, commits air in authoritative collision state, then sends an event to the client.
- Client uses the server event and drops to drive visuals and the existing asynchronous lighting/mesh worker. Server event includes original state to avoid a race if the client raycast changes before the event arrives.
- Added server-side unit tests for stone tool hardness, non-harvest divisor, and attack release reset. Existing drop registry tests now run under the server crate.

## Explicit remaining work

Inventory authority, item entity movement/merge/pickup, manual inventory drops, tool durability, exact continuous vanilla World.rand sequencing, dedicated TCP mining protocol and remote join are not migrated yet. The tool descriptor is currently sent by the client and must later be validated against server-owned inventory.

## Validation

TOML and source-level checks only; no Cargo compiler is available in the authoring environment.
