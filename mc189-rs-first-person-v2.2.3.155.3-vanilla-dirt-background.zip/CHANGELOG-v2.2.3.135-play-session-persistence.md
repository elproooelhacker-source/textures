# v2.2.3.135 — PLAY session persistence

## Objective
Keep the offline-mode Minecraft Java 1.8.9 connection alive after Login Success instead of reading one packet and dropping the TCP socket.

## Changes
- Added a dedicated PLAY-session worker that owns the TCP connection and continuously reads framed server-to-client packets.
- Responds to protocol-47 `S00PacketKeepAlive` (`0x00`) with `C00PacketKeepAlive` (`0x00`), echoing the exact VarInt payload.
- On `S01PacketJoinGame` (`0x01`), sends `C15PacketClientSettings` (`0x15`) using the 1.8.9 field order: locale `en_US`, render distance 8, chat visibility 0, chat colors enabled, all skin parts enabled.
- Decodes `S08PacketPlayerPosLook` (`0x08`), applies relative flags, and replies with `C06PacketPlayerPosLook` (`0x06`) to acknowledge the server teleport.
- Recognizes `S40PacketDisconnect` (`0x40`) and surfaces its reason.
- Exposes packet IDs, MCP names and payload sizes to the menu status display; unknown PLAY packets are consumed and logged rather than immediately treated as fatal.
- Moves socket reading off the window/event-loop thread so network waits do not freeze the menu.

## Scope and limitations
- This is a connection/session milestone, not yet a playable remote-world implementation.
- Chunk payload decoding, remote world rendering, entity replication, player movement, inventory synchronization and the full set of serverbound PLAY responses remain future work.
- The offline login path still requires servers configured with `online-mode=false`.

## Verification
- Added unit tests for the serialized `C15PacketClientSettings` field order and relative `S08`/`C06` teleport acknowledgement.
- ZIP integrity is checked when packaging. Rust compilation and Cargo tests are not available in the packaging environment; run `cargo test -p mc189-protocol --offline --locked` on the Windows machine with the project's cached dependencies.
