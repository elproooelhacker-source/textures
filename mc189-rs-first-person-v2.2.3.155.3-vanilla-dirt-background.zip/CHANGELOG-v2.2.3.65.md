# v2.2.3.65 — Translucent blocks, collisions, and atlas recovery

This revision continues from `mc189-rs-first-person-v2.2.3.64.zip`, which was based on `mc189-rs-first-person-v2.2.3.63 (2).zip`.

## Fixes

- Added a static frame-zero atlas alias for the animated vanilla sea-lantern sprite. The block now has a resolvable atlas region even before the dedicated non-fluid animation scheduler is implemented.
- Added automatic atlas refresh when the existing atlas manifest lacks the sea-lantern frame-zero entry. The refresh extracts the provided `client.jar`, rebuilds the atlas and removes temporary source files, so the normal `main-menu` command does not require a manual atlas rebuild.
- Routed clear and stained-glass textures through a dedicated blended translucent pass with depth writes disabled, ordered far-to-near by chunk, instead of blending them in the opaque depth-writing pass.
- Removed shared cullable faces between touching clear-glass blocks and between same-color stained-glass blocks to avoid rendering coincident interior faces.
- Added partial collision shapes for classic stairs, fences, fence gates, and wooden/iron door families. Open fence gates no longer obstruct the player; fences and closed gates extend to their classic 1.5-block collision height; doors use a thin, orientation-aware collision plane.
- Added half-block step movement and a stair-only additional half-step when the player's width overlaps the boundary between the lower and upper treads, allowing traversal of the simple stair shapes without permitting ordinary full cubes to be climbed as stairs.
- Inset door geometry planes that lie exactly on the boundary of the block cell by 0.001 blocks, avoiding coplanar overlap with neighboring wall faces. This does not modify lighting samples or equations.
- Added regression tests for the sea-lantern atlas alias, glass-pass classification, transparent shared-face culling, partial collision shapes, stair traversal and door boundary insets.

## Preservation

- The vanilla-derived lighting equations and their integration have not been modified.
- World files remain read-only; no changes are written to player worlds.
- The ZIP contains the Rust project and source changes, not Mojang source files.

## Validation status

- ZIP integrity is checked during packaging.
- The included 1.8.9 `client.jar` resource table was inspected to confirm the animated sea-lantern sprite and model families exist.
- Cargo tests were not run in this environment because `cargo` and `rustc` are unavailable here. Run `cargo fmt --all` and `cargo test --workspace` on Windows before/while testing the new build.

## Known scope

- Stair collision uses the selected straight orientation/half shapes; exact inner/outer corner collision and full vanilla entity movement parity remain follow-up work.
- Sea lantern rendering uses its first animation frame. Full five-frame sea-lantern animation is not yet scheduled.
- Translucent geometry is sorted by chunk center rather than per face, a practical first pass rather than complete vanilla render-order parity.
