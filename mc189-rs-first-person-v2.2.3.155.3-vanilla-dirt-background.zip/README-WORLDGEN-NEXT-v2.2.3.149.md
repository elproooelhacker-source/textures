# Worldgen continuation — v2.2.3.149

Base: v2.2.3.148.

This increment adds the MCP 1.8.9 mega-pine generator used by mega taiga. The implementation includes `WorldGenHugeTrees` height and clearance behavior, 2x2 base support, mega-pine crown/trunk construction, and the `func_180711_a` podzol patch pass. Podzol is serialized as legacy block 3 metadata 2.

Biome selector coverage includes IDs 32 and 33 plus mutated mega-spruce taiga ID 160. The type-1 selector consumes the 1-in-13 draw; type 2 does not, matching `BiomeGenTaiga.genBigTreeChance`.

Still pending: mega-taiga boulder and plant decoration, jungle/savanna/swamp tree generators, giant jungle trees, and the remaining `BiomeDecorator` features and population prelude.
