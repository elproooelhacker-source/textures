# v2.2.3.22 — liquid contact regression-test correction

## Correction
- Corrected the remaining legacy lava-contact regression test. Its level-7 lava surface is only 1/9 block high, while the test player starts with feet at Y=0.6; expecting lava contact in that geometry contradicted the new surface-intersection rule.
- The test now asserts that lava below the player's feet does not activate `in_lava`. Runtime liquid detection and movement code are unchanged from v2.2.3.21.

## Validation
- This is a test expectation correction, not a runtime behavior change. Run `cargo fmt --all` and `cargo test --workspace` on Windows.
- Expected: 136 `mc189-app` tests and 13 `mc189-storage` tests.
