# v2.2.3.121 — integrated server owns world persistence

- Opening a world now starts the integrated server's 20 TPS simulation and its server-owned persistence service automatically. No dedicated-server BAT is needed for single-player.
- Moved the deferred Anvil chunk and `level.dat` player-data writer from the app crate into `mc189-server::persistence`. The graphical client submits immutable revisioned snapshots; it no longer writes Anvil files.
- The server persistence worker serializes writes under the same world I/O lock used by chunk streaming and block-edit reads, batches chunk updates by region, and reports exactly which revisions reached disk.
- Autosave remains asynchronous and outside the 20 TPS tick loop. On exit, the client drains pending block edits, submits a final flush, waits for confirmed chunk/player commits, then exits; dropping the integrated server joins its simulation thread and drains/stops persistence before the world session is released. A failed final save keeps the world open for retry.
- The dedicated headless server BAT remains an optional separate-process test tool.

## Scope boundary

This is a lifecycle/persistence ownership migration, not yet a complete multiplayer-authoritative world. Mining transactions and some world state are still produced by app-side workers and submitted as snapshots. Dropped-item entities, complete entity persistence, world time/weather metadata, remote chunk streaming, and full network join UI remain future migrations. No claim is made that every vanilla world subsystem is persisted yet.

## Validation

Static source and manifest checks only. The authoring environment does not provide `cargo`, `rustc`, or `rustfmt`, so compilation and runtime tests must be run on the Windows test machine.
