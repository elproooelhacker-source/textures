# v2.2.3.111 — live inventory updates, slot-pop animation, and vanilla block mining sounds

## Inventory and pickup feedback

- A successful ground pickup updates the player inventory and re-rasterizes the HUD/hotbar in the same fixed simulation tick. A newly collected cobblestone stack appears in an empty hotbar slot immediately; another compatible pickup merges into that slot and updates its visible count (for example, 1 to 2) without opening the inventory. Partial pickup leaves the remaining count on the ground.
- Inventory UI change tracking covers all 36 main/hotbar slots and four armor slots. New stacks, merges, item/metadata/NBT changes, and count decrements arm the five-tick slot-pop animation. This includes decreasing a stack (for example 2 to 1).
- The icon uses MCP 1.8.9's `GuiIngame.renderHotbarItem` scale curve with frame interpolation. The count overlay is drawn outside the animated transform, keeping its position fixed while the icon bounces. Block items retain the existing isometric cube icon path; generated/tool items retain their flat item sprites.
- The existing three-tick `EntityPickupFX` visual copy and `random.pop` pickup sound remain separate from the authoritative inventory transfer. The selected hand item is refreshed if a pickup fills the selected hotbar slot.

## Mining sounds

- The audio loader resolves `.ogg` variants from the launcher's `assets/indexes/1.8.json` and hashed `assets/objects` entries via `sounds.json`; no resource pack is duplicated into the project.
- While mining, the matching `Block.stepSound` event plays every four valid block-damage ticks, using MCP's `(volume + 1) / 8` and `frequency * 0.5` factors. On destruction, the block's break event uses `(volume + 1) / 2` and `frequency * 0.8`.
- Sound profiles cover the vanilla stone, wood, grass, gravel, sand, cloth, snow, glass, metal, ladder, anvil, and slime sound types. The `dig.glass` event is preloaded, and the wooden stair IDs inherit the wood profile.
- OGG decoding, output-device setup, or asset-index failures do not prevent the client from starting; they disable audio with a diagnostic message.

## Regression coverage

Added tests for ground-pickup insertion into the visible hotbar, merging 1 to 2 and rearming the animation, isometric block-item classification, glass-break event availability, and the sound profiles for wooden/stone stairs. Existing tests continue to cover stack decrements, five-tick timing, and smooth partial-tick interpolation.

Cargo tests and Windows playback still need to be run on the user's Windows environment; this authoring environment has no Cargo/rustc or physical audio device.
