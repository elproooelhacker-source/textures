# v2.2.3.148 — Roofed Forest / Dark Oak canopy trees

## Added
- Dark oak log and leaf states with legacy Anvil IDs and metadata: log2 (162:1), leaves2 (161:1).
- Port of the MCP 1.8.9 `WorldGenCanopyTree(false)` placement algorithm: clearance scan, 2x2 dirt base, randomized horizontal trunk bend, 2x2 trunk, crown layers, top cap, branch roots and leaf pads.
- Roofed Forest's special 4x4 decoration placement loop and its tree-generator selector from `BiomeGenForest(type=3)`.
- Determinism and legacy-state tests.

## Important parity boundary
- The roofed-forest 1-in-20 big-mushroom branch is detected, but `WorldGenBigMushroom` is not implemented in this stage. The branch is counted as failed and its generator-internal random consumption is therefore not reproduced.
- `WorldGenCanopyTree` clearance can only recognize block types represented by the current terrain enum; saplings and vines are not represented.
- This is not yet full `BiomeDecorator` parity and does not claim bit-identical world generation.
- Cargo tests/build were not run in this environment because Rust tooling is unavailable.
