# v2.2.3.130 — protocolo de red vanilla 1.8.9, base offline

## Fuente MCP utilizada

Se inspeccionó el código desofuscado suministrado en Biblioteca, en particular `EnumConnectionState`, `C00Handshake`, `C00PacketLoginStart`, `S02PacketLoginSuccess`, `S03PacketEnableCompression`, `PacketBuffer`, `NettyCompressionDecoder` y `NettyCompressionEncoder`.

Corrección de precisión: el registro real del `EnumConnectionState` suministrado contiene **111 registros de paquetes**, no 105. El desglose exacto es 1 Handshaking, 4 Status, 6 Login y 100 Play. En Play son 74 servidor→cliente y 26 cliente→servidor; las clases anidadas C04/C05/C06 y S15/S16/S17 son registros distintos, igual que en vanilla.

## Implementado

- Nuevo crate `mc189-protocol` separado del servidor integrado.
- Registro de los 111 paquetes con IDs derivados del orden de `registerPacket` en la fuente MCP.
- Estados de conexión y direcciones de paquete.
- VarInt, String UTF-8 y framing TCP de Minecraft.
- Compresión Zlib y prefijo de longitud descomprimida conforme a los codecs Netty de 1.8.9.
- Handshake protocol 47 con destino LOGIN.
- Login Start offline con nombre de jugador.
- Procesamiento de Enable Compression, Login Success, Disconnect y detección de Encryption Request.
- Nuevo comando `probe-offline-server <host> <port> <username>` que confirma LOGIN y lee el primer paquete entrante de PLAY.
- Documentación completa de los IDs registrados y su clase MCP.

## Prueba local prevista

1. Iniciar el servidor oficial Minecraft Java 1.8.9 con `online-mode=false` y puerto 25565.
2. Desde la carpeta del proyecto ejecutar `cargo run -p mc189-app -- probe-offline-server 127.0.0.1 25565 JugadorRust`.
3. Confirmar `LOGIN SUCCESS` y que se reconoce el primer paquete PLAY (normalmente `S01PacketJoinGame`).

No se debe exponer un servidor `online-mode=false` a Internet: cualquiera podría entrar usando el nombre de otro jugador.

## Pendiente

No se presenta como cliente remoto jugable todavía. Faltan decodificadores de payload PLAY, incorporación de `S21PacketChunkData` al modelo de chunks, sincronización de posición/entidades/inventario, respuestas keep-alive y el bucle de red conectado al gameplay. La autenticación premium/cifrado AES queda para después de completar y validar el camino offline.

## Validación

El registro se comparó automáticamente contra las líneas `registerPacket` de `EnumConnectionState.java` y coincide en cantidad, estado, dirección, orden, ID y nombre MCP. Este entorno no dispone de `cargo` ni `rustc`, por lo que no se pudo ejecutar `cargo test --workspace` ni compilar el ejecutable. El ZIP se entrega con esa limitación explícita.
