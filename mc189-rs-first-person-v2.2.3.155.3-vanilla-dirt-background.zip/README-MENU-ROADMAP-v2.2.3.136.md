# Menú Minecraft 1.8.9 — hoja de ruta v2.2.3.136

La meta es portar el comportamiento de las pantallas MCP 1.8.9 a Rust/wgpu, no sustituirlas por capturas estáticas.

## Ya disponible en la base

- Panorama de seis caras, logo, widgets, tipografía y splash text cargados desde `client.jar`.
- Pantalla principal con distribución de botones basada en `GuiMainMenu#initGui` y composición de logo basada en `GuiMainMenu#drawScreen`.
- Primera fase de arranque Mojang con `textures/gui/title/mojang.png`, centrada sobre negro como `Minecraft#drawSplashScreen`.
- Selector de mundos rudimentario basado en los saves Anvil detectados.
- Pantalla multijugador provisional que guarda direcciones y prueba el login offline/PLAY persistente.

## Trabajo pendiente para fidelidad real

1. Portar `GuiScreen`/`GuiButton` como base de navegación, foco, teclado, mouse, escalado y tooltips.
2. Completar `GuiSelectWorld`: tarjetas, selección, editar, borrar con confirmación, recrear y crear mundo; scroll y metadatos vanilla.
3. Completar `GuiMultiplayer`: lista persistente `servers.dat` compatible, ping/status, iconos, selección, añadir/editar/eliminar y conexión.
4. Completar `GuiOptions`, opciones de idioma, controles, sonido y paquetes de recursos.
5. Portar `GuiConnecting` con estados reales de resolución/conexión/login, botón Cancel y retorno a la pantalla anterior.
6. Portar `LoadingScreenRenderer` y el fondo de tierra (`options_background.png`) para el progreso real de creación/carga de mundo y conexión.
7. Reproducir el panorama con el render 8x8 y el desenfoque de siete pasadas de `GuiMainMenu`, no solo una aproximación de kernel 3x3.
8. Comparar capturas con Java 1.8.9 a resoluciones y GUI scales equivalentes.

## Reglas de implementación

- Los recursos visuales salen de `client.jar`/assets oficiales de 1.8.9.
- Los estados de carga deben reflejar trabajo real; no inventar porcentajes ni mostrar una pantalla de carga estática.
- No eliminar ni alterar el transporte PLAY persistente mientras se trabaja en la interfaz.
- Cada pantalla nueva debe tener pruebas de layout/entrada/estado y conservarse en el siguiente ZIP completo.
