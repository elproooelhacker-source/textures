# v2.2.3.120 — dedicated server / client separation foundation

- Added `mc189-server`, a headless crate with no renderer/window/audio dependencies.
- Moved the authoritative player physics and loaded-world collision module from `mc189-app` into `mc189-server`; the graphical app re-exports it during the staged migration.
- Added a fixed 50 ms authoritative tick accumulator (20 TPS) that preserves backlog instead of dropping ticks.
- Added protocol v1 packets for handshake, sequenced player input, snapshots, ping/pong, and disconnect.
- Added independent TCP reader/writer threads and a `NetworkClient` adapter.
- Added dedicated server binary, configurable bind address and chunk radius, and a Windows launcher.
- Added a protocol probe that submits input and confirms authoritative snapshots.
- Server loads the existing world and spawn-area chunks read-only; no disk mutation or save is performed by this milestone.
- Explicitly documents that graphical client integration and migration of mining, blocks, inventory, dropped items, chunk streaming, and persistence remain subsequent milestones.
- Wired the single-player renderer to `IntegratedServer`: player movement and block collision now advance on a dedicated 20 TPS server thread. The render loop submits sequenced input and consumes the newest authoritative snapshots instead of invoking the physics tick.
- Mirrored chunk stream insert/remove operations and immediate block edit/rollback updates into the integrated server's collision view.
