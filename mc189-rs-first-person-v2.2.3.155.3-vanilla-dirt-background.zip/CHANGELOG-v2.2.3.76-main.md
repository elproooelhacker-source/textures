# v2.2.3.76 — Match vanilla generated-item transform path

- Rechecked the original `client.jar` model `assets/minecraft/models/item/diamond_pickaxe.json`: it inherits from `builtin/generated`, uses `layer0: items/diamond_pickaxe`, and defines first-person display rotation `[0, -135, 25]`, translation `[0, 4, 2]`, scale `[1.7, 1.7, 1.7]`.
- Compared the transform path with MCP 1.8.9 `RenderItem.renderItemModelTransform`, `preTransform`, and `renderItem`. Vanilla applies a 2x scale before the display transform on both paths: `ItemRenderer.renderItem` does it for GUI-3D models, while `RenderItem.preTransform` does it for flat/generated models. `RenderItem.renderItem` then applies 0.5x to both.
- Fixed the Rust transform matrix so both generated sprites and GUI-3D/block models use the same effective model scale. Previously only GUI-3D models received the 2x factor, leaving generated items with half the vanilla scale and an incorrect relationship between the front/back cutout planes and their edge extrusion.
- Updated the transform regression test to assert equal effective scaling for generated and GUI-3D models.
- The held-item path still draws one selected mesh per frame (`held_item_vertex_count`); generated tools use the `builtin/generated` sprite mesh, while cuboid models use the block-model mesh. They are not intentionally rendered as two separate item meshes.

## Validation

- Verified the package source and original `client.jar` model JSON.
- Compared implementation against MCP 1.8.9 source: https://github.com/Marcelektro/MavenMCP-1.8.9/blob/master/src/main/java/net/minecraft/client/renderer/ItemRenderer.java and https://github.com/Marcelektro/MavenMCP-1.8.9/blob/master/src/main/java/net/minecraft/client/renderer/entity/RenderItem.java
- ZIP integrity will be checked after packaging. Cargo/rustc are not installed in this environment, so Rust compilation/tests cannot be run here.
- Important: this fixes a confirmed transform mismatch; because this environment cannot run the renderer, the visual X-cross artifact still needs verification in the user's Windows build. If it persists, the next diagnostic is to capture the generated mesh's front/back/edge groups and compare them to vanilla's baked `builtin/generated` quads, rather than adding arbitrary offsets.
- Corrected the display-rotation order to MCP 1.8.9's actual `Y → X → Z` sequence. The previous Rust code used `Z → Y → X`; that was a concrete source of the crossed orientation visible on generated items.
