# v2.2.3.120 — server/client separation foundation

## Architecture decision

The project now has a dedicated `mc189-server` crate. It has no wgpu, winit, rodio, window, renderer, or client-asset dependency. The existing `mc189-app` remains the graphical client package. Player movement/collision code (`player.rs`) was moved into the server crate and is re-exported by the app during this migration so existing gameplay and regression tests continue to compile while the render-loop call site is migrated in a later step.

## Server process and authoritative tick

`mc189-server` now builds both a reusable library and a headless `mc189-server.exe` process. The process:

- Opens an existing 1.8.9 Anvil world read-only and loads a configurable square of chunks around the saved spawn (default radius 5, 11x11 chunks).
- Resolves a safe feet position using the same player collision implementation used by the current client.
- Accepts TCP clients on `0.0.0.0:25566` by default.
- Runs authoritative player movement at a fixed 50 ms step (20 ticks per second).
- Receives sequenced input state and look angles; rejects duplicate/out-of-order input sequences and non-finite yaw/pitch. One-shot jump edges are latched until a server tick so packet timing cannot erase them.
- Sends a welcome packet and authoritative player snapshots with tick number and acknowledged input sequence.
- Keeps socket reading/writing on per-connection threads; network I/O does not execute world simulation.
- Preserves overdue ticks in the accumulator instead of silently dropping simulation time when the server falls behind.

## Wire protocol v1

The first protocol is newline-delimited JSON for inspectability during bring-up:

- Client: `hello`, `input`, `ping`.
- Server: `welcome` (including world-origin chunk coordinates), `player_snapshot`, `pong`, `disconnect`.
- Every input has a monotonic sequence number; every snapshot acknowledges the last applied sequence.
- The codec is isolated in `protocol.rs`, so a compact binary codec can replace JSON later without changing gameplay message semantics.

The `NetworkClient` adapter is available in the server library and deliberately has no rendering dependencies. `mc189-server --probe 127.0.0.1:25566` exercises handshake, input submission, and snapshot reception. The integrated single-player server receives block collision updates when chunks stream in/out and when a block edit is applied or rolled back, so the server's player collision view follows the current loaded world.

## Source alignment

The 20 TPS scheduler follows the structure of MCP 1.8.9 `MinecraftServer.run()` and `MinecraftServer.tick()` (50 ms cadence and tick counter). Player input is represented separately from authoritative player state, following the responsibility split in `NetHandlerPlayServer.processInput()` and `processPlayer()`.

## What this milestone does NOT claim yet

This is the first architectural separation milestone, not the completed multiplayer conversion. Single-player movement/collision now runs in the integrated server thread. The graphical client has the TCP `NetworkClient` adapter, but its window/render loop is not yet switched to connect to a separate dedicated process. The dedicated process authoritatively simulates connected players and sends snapshots, but block mining/edit transactions, inventory, dropped items, other entities, world time/weather, chunk streaming, and world saves have not yet been migrated to server ownership. The dedicated server currently opens Anvil data read-only and does not write world changes. Do not open the same world in Java/UltimMC and the dedicated process simultaneously.

Next migration steps:

1. Add a graphical join-server flow that connects `NetworkClient` to a separate dedicated process and interpolates authoritative snapshots; single-player already uses the in-process integrated server.
2. Move block interaction/mining and block-edit transactions to server commands/results.
3. Move inventory, dropped-item entities, pickup, and entity simulation to server tick ownership.
4. Add server-owned chunk streaming and revisioned chunk/block/light snapshots.
5. Move autosave/checkpoint/final flush into server lifecycle; client shutdown must not close the world while the server is active.
6. Add multi-client entity replication, disconnect cleanup, validation/rate limits, and persistence regression tests.

## Windows test

1. Close Minecraft Java/UltimMC so the world is not concurrently opened.
2. Run `INICIAR-SERVIDOR-MINECRAFT-RUST.bat` and select the `New World` folder.
3. In a second CMD window run `PROBAR-CONEXION-SERVIDOR.bat`.
4. Expected logs include `[server] listening ... target=20 TPS`, a connection, a `welcome` packet, and at least three authoritative snapshots.

The probe is a transport/simulation smoke test; it is not yet the graphical game client. The normal single-player launcher also starts the new integrated server thread automatically for player movement.
