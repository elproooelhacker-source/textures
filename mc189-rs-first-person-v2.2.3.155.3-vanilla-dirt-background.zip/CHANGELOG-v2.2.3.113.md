# v2.2.3.113 — fix OGG sample conversion for Windows release build

- Fixed the compile error in `audio.rs`: the Vorbis decoder in rodio 0.20.1 yields signed 16-bit PCM samples, while `SamplesBuffer` stores `f32` samples.
- Normalize decoded PCM explicitly with `sample / 32768.0` before constructing shared audio clips.
- Added a regression test for the signed PCM normalization range.
- No changes to inventory behavior, mining timing, sound selection, or world data formats.

Validation: archive integrity checked. Cargo compilation and Windows audio playback still need to be verified on the user's Windows environment.
