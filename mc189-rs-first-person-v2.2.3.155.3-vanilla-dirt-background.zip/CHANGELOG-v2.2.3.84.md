# v2.2.3.84 — Nether crops and cocoa drops

## Drop registry
- Added block ID 115 (Nether Wart): immature age returns one Nether Wart; mature age uses the mature quantity range and Fortune bonus path.
- Added block ID 127 (Cocoa): metadata age selects one bean for immature pods and three beans for mature pods; output is dye item 351 with damage 3.
- Added deterministic tests across metadata ages, Fortune levels, and JavaRandom seeds.

## Scope and verification
- This is a drop-registry-only milestone. It does not connect mining input, world mutation, chunk mesh rebuilds, visible dropped-item entities, inventory pickup, or Anvil persistence.
- MCP 1.8.9 source index confirms the exact classes `BlockNetherWart` and `BlockCocoa` are part of the 1.8.9 block package. The local `client.jar` was inspected and its SHA-256 recorded in the research note. Its class names are obfuscated; without matching MCP/SRG mappings, this milestone does not claim direct bytecode-to-MCP class mapping.
- Cargo/Rust compilation and unit tests were not run in this environment. ZIP integrity is checked separately.
