# v2.2.3.141 — Create World controls

## Implemented
- Replaced the static Create World mockup with stateful controls.
- World name field accepts keyboard input (up to 32 characters) in the basic view.
- Advanced view switches the text field to the world seed, matching the vanilla screen's field relocation; seed input accepts up to 128 characters.
- Tab retains focus in the active field; Backspace edits it; mouse clicks focus the visible field.
- Game mode cycles Survival → Hardcore → Creative → Survival.
- Hardcore suppresses cheats and bonus chest; the automatic cheats transitions follow the vanilla behavior unless the user explicitly changed the cheats setting.
- Advanced options toggle structures, cheats, bonus chest and cycle Default, Flat, Large Biomes, Amplified and Customized world types.
- Buttons and displayed labels are rebuilt from the current settings state.
- Added tests for basic/advanced action sets and Hardcore display restrictions.

## Explicit limitation
The Create World action remains disabled. This is intentional: the current `mc189-core::worldgen` code is not yet a complete Minecraft 1.8.9 world generator. It has deterministic Java/GenLayer random streams, biome-map generation, terrain noise/density interpolation, basic biome surface replacement and cave/ravine carving, but does not yet provide the complete vanilla feature population pipeline (ores, vegetation, lakes, structures, biome-specific mesa/ice layers, spawn preparation, bonus chest placement, lighting/heightmap finalization and full Anvil save initialization). Enabling world creation now would create worlds that look valid in the menu but are incomplete or behaviorally incorrect.

## Validation
- Source-level checks and ZIP integrity check performed.
- Rust compilation and Cargo tests were not run: this environment does not have `cargo` or `rustc` installed.
