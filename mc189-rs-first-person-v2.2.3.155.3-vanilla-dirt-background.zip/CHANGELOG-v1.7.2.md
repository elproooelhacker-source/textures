# v1.7.2 — species-specific log blockstates

## Fix

- Fixed legacy log metadata resolution to use the six species-specific blockstate resources: `oak_log`, `spruce_log`, `birch_log`, `jungle_log`, `acacia_log`, and `dark_oak_log`.
- Previously the chunk renderer attempted to open the obsolete generic names `log` and `log2`, which are absent from the client asset layout used by this project and caused chunk preview to stop when it encountered a log.
- Extended regression assertions to verify the exact blockstate resource selected for every supported log species.

No world data, region files, or client JAR contents are modified.
