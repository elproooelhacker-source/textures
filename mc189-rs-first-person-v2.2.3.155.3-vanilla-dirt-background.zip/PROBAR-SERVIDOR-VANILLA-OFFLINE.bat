@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Minecraft 1.8.9 Rust - Vanilla offline protocol 47
set "MC189_HOST=127.0.0.1"
set "MC189_PORT=25565"
set "MC189_USER=JugadorRust"
echo ============================================================
echo   PRUEBA DE CONEXION A SERVIDOR VANILLA 1.8.9 - OFFLINE
echo ============================================================
echo.
echo Requiere un servidor oficial Minecraft Java 1.8.9 local con:
echo     online-mode=false
echo No expongas ese servidor a Internet: permite suplantar nombres.
echo.
set /p "MC189_HOST=Host del servidor [%MC189_HOST%]: "
if not defined MC189_HOST set "MC189_HOST=127.0.0.1"
set /p "MC189_PORT=Puerto [%MC189_PORT%]: "
if not defined MC189_PORT set "MC189_PORT=25565"
set /p "MC189_USER=Nombre offline [%MC189_USER%]: "
if not defined MC189_USER set "MC189_USER=JugadorRust"
echo.
echo Ejecutando handshake protocol 47 y login offline...
cargo run --release -p mc189-app -- probe-offline-server "%MC189_HOST%" "%MC189_PORT%" "%MC189_USER%"
echo.
pause
