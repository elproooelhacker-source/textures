@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Minecraft 1.8.9 Rust - Pruebas unitarias
where cargo >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Instala Rust estable desde https://rustup.rs
    pause
    exit /b 1
)
echo Ejecutando las pruebas de todo el workspace...
cargo test --workspace
set "TEST_EXIT=%ERRORLEVEL%"
echo.
if "%TEST_EXIT%"=="0" (
    echo [OK] Todas las pruebas del workspace terminaron correctamente.
) else (
    echo [ERROR] Cargo test devolvio codigo %TEST_EXIT%.
)
pause
exit /b %TEST_EXIT%
