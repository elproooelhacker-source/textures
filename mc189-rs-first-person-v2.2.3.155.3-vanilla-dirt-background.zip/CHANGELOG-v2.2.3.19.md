# v2.2.3.19 — biome tint test-fixture correction

## Fix
- Correct the biome-neighborhood averaging test to use a climate-dependent gradient colormap instead of a flat-color image.
- The previous flat fixture returned the same color for every biome, so it could not verify that samples across a chunk border included adjacent biome columns.

## Scope
- Test-only correction. No runtime rendering, gameplay, liquid physics, crosshair, texture, or world-data behavior changed.
- All v2.2.3.18 code and features are retained unchanged.
