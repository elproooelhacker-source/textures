# Minecraft 1.8.9 Rust — v2.2.3.133

## Integración: menú multijugador + corrección de cámara

- Conserva el menú Multijugador, formulario de servidor guardado y flujo de handshake/login de la v2.2.3.132.
- Corrige la reconciliación de snapshots: el servidor sigue siendo autoridad para posición, velocidad y estado físico, mientras yaw/pitch permanecen bajo control local del ratón.
- Evita que un snapshot atrasado reinicie la orientación y produzca tirones/giros bruscos de cámara.
- Limita pitch al rango vertical válido de la cámara.
- Añade pruebas de regresión para preservar yaw/pitch y mantener la autoridad del servidor sobre el estado físico.

La conexión remota sigue limitada a la fase de handshake/login documentada en la versión anterior; no equivale todavía a un cliente multijugador completo.
