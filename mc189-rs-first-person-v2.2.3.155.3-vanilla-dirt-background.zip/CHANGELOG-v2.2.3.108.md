# v2.2.3.108 — regression fixes from Windows workspace tests

## Correctness fixes

- Fixed the legacy opacity classifier for block ID 103 (melon). MCP `BlockMelon` inherits `Block.isOpaqueCube() == true`; its ID had accidentally been excluded with stems, vines, bars, and gates. It now occludes model faces and uses full-block light opacity, matching the 1.8.9 class hierarchy.
- Corrected dead-bush drop status: `BlockDeadBush.getItemDropped()` returns `null`, while its custom `harvestBlock()` path creates a dead-bush item only with shears. The no-shears case is now explicitly `NoDrop`, and shears produce one block item.
- Registered vine ID 106 as a known conditional harvest behavior. MCP `BlockVine` has no ordinary drop but explicitly spawns one vine when harvested with shears.
- Expanded the double-grass RNG regression sample. The first `nextInt(8)` results for small adjacent Java seeds do not include the successful branch, so the earlier 0..100 test range was an invalid sampling assumption; the implementation's MCP `nextInt(8)` rule is unchanged.

## Section mesh test fixture

- Fixed the CPU section replacement test fixture so each layer has 12 vertices for its two six-vertex sections, matching the 12 owner tags. The runtime ownership invariant itself remains enforced.

## Lighting test fixture

- Replaced the one-block-wall light test with a sealed one-block-wide tunnel. A single opaque block does not guarantee zero light behind it in vanilla because light can propagate around it in the other five directions. The revised fixture isolates the intended path-removal behavior without weakening the production algorithm or its assertions after the wall is removed.

## Verification

- Changes were checked against the deobfuscated Minecraft 1.8.9 sources for `Block.java`, `BlockMelon.java`, `BlockDeadBush.java`, `BlockDoublePlant.java`, and `BlockVine.java`.
- ZIP integrity is checked after packaging.
- This authoring environment does not have `cargo` or `rustc`; the full Windows workspace test suite must be rerun with `EJECUTAR-PRUEBAS-RUST.bat`. The supplied v2.2.3.107 run is the evidence used to target these six failing tests; no claim is made that v2.2.3.108 has already passed Cargo tests.
