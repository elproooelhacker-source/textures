# v2.2.3.155.3 — Vanilla dirt backgrounds for sub-GUIs

## Change
- Loaded the original `assets/minecraft/textures/gui/options_background.png` from `client.jar` as a required menu asset.
- Added the vanilla tiled dirt backdrop to every non-title menu screen, including Singleplayer (world selection) and Multiplayer.
- The dirt tile is enlarged to the 32-GUI-pixel repeat used by the vanilla GUI background and darkened to 25% brightness; the overlay is opaque so the title panorama no longer shows through these screens.
- Kept the title screen's animated panorama and the Mojang boot screen unchanged.
- Added a unit test for tile repetition, brightness and opacity.

## Validation
- ZIP structure and archive integrity checked after packaging.
- Source-level change inspected. Rust/Cargo compilation was not run in this environment; please run the Windows release launcher to validate GPU/UI behavior.
