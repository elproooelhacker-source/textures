# Lighting fallback — v2.2.3.41

This version adds an in-memory fallback for chunks whose Anvil sections omit `BlockLight` or `SkyLight` nibble arrays.

- Block light is seeded from saved light samples and known vanilla emissive blocks, then propagated through loaded chunks.
- Sky light is seeded from saved samples and direct-sky columns inferred from the saved heightmap, then propagated laterally.
- Opaque cubes stop propagation. Water, leaves, and ice attenuate it.
- Existing saved light arrays are not overwritten. The world is still opened read-only; the fallback changes only the renderer's in-memory chunk copies.
- Unloaded chunks remain outside the propagation domain until they are streamed in and meshes are rebuilt.

The opacity table is a conservative vanilla-family mapping, not yet a complete registry-wide port of every block's `getLightOpacity()` behavior. This pass is intended to improve missing-array fallback without replacing correct saved lighting.

## Windows CMD validation

From the extracted project directory:

```bat
cargo fmt --all
cargo test --workspace
```

Then launch with the same command used for v2.2.3.40:

```bat
cargo run -p mc189-app -- select-world "C:\Users\Admin\Downloads\UltimMC-Launcher-All-Versions (1)\UltimMC-Launcher-Win32\UltimMC\instances\1.8.9\.minecraft\saves" "C:\Users\Admin\Downloads\client.jar" "C:\Users\Admin\Downloads\block-atlas-output"
```
