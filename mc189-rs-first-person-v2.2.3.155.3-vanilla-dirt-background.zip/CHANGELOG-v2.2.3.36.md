# v2.2.3.36 — Vanilla lighting port, stage 1

This increment continues from v2.2.3.35 and replaces the remaining scalar-light path for model quads with independent vertex AO, sky-light and block-light values.

## Included

- Ports the six `EnumNeighborInfo` face tables, vertex translations and orientation-bound tables used by Minecraft 1.8.9 `BlockModelRenderer.AmbientOcclusionFace`.
- Applies vanilla packed-brightness averaging (`getAoBrightness`) and separate sky/block byte interpolation (`getVertexBrightness`).
- Keeps AO, sky light, block light and directional face shade as separate per-vertex attributes through the GPU vertex format.
- Adds a 16×16 GPU lightmap lookup texture and samples it after interpolating the two light coordinates. Its CPU table is derived from the 1.8.9 `EntityRenderer.updateLightmap` equations for clear daytime with zero torch flicker.
- Implements the flat-lighting path for block models declaring `ambientocclusion: false` (one face-neighbor brightness sample, no AO interpolation).
- Applies saved/emitted light to fluid quads instead of leaving them at the default full-bright vertex values; fluid face darkening remains baked into the existing fluid tint to avoid applying it twice.
- Adds regression coverage for the flat-lighting path and the 16×16 lightmap texture layout/channels.

## Scope and known limitations

This is a staged port, not yet a claim of complete vanilla renderer equivalence. The lightmap currently uses clear-day sun brightness and zero torch flicker; world time, weather, lightning-flash transitions and dynamic torch flicker are not yet connected. The block/material property tables are still represented by the project's supported legacy block-ID registry, so unsupported states cannot be guaranteed identical to vanilla. Fluids use the current renderer's per-block light sample rather than the complete vanilla fluid-renderer corner-brightness implementation.

The archive was checked for ZIP integrity. This environment does not contain Rust/Cargo, so compilation and test execution must be confirmed on the user's Windows machine.
