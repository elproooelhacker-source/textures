# v2.2.3.71 — Hover del inventario y objetos en primera persona

## Cambios

- Añadido el resaltado blanco translúcido de 16×16 del slot bajo el cursor, equivalente al `GuiContainer.drawScreen` de Minecraft 1.8.9 (`drawGradientRect` con `0x80FFFFFF`). Se dibuja como un quad de GPU independiente; cruzar slots no recompone ni sube la textura completa de la interfaz.
- Separado el marco de selección de la barra rápida del HUD. Usa el recorte original de `assets/minecraft/textures/gui/widgets.png` en `(0,22)` de tamaño `24×22`, escalado con nearest. Cambiar con `1–9` o rueda mueve únicamente los vértices de ese quad; no vuelve a componer y subir el HUD entero.
- Añadido renderizado de objetos sostenidos a partir de modelos JSON y texturas del `client.jar` 1.8.9: herencia de modelos, UV del atlas de bloques y geometría generada para iconos de objetos 2D.
- Aplicados los transformadores de `ItemRenderer` de 1.8.9: oscilación al golpear, pose en primera persona, transformación `display.firstperson`, escala 2 del camino de modelo 3D/generado y progreso de equipamiento con transición a 0,4 por tick y cambio de objeto por debajo de 0,1.
- La geometría de iconos generados usa planos frontal/trasero con alfa y extrusión solo en los bordes opacos. Reduce la cantidad de vértices respecto a la versión anterior y conserva el contorno transparente.
- Preservadas las ecuaciones de iluminación del mundo y el comportamiento de colisión existentes.

## Alcance pendiente

- Los renderizadores especiales de mapas, uso de arcos, cañas en estado lanzado, comida/bebida y bloqueo con objetos requieren sus rutas específicas de `ItemRenderer` y no se consideran completos en esta versión.
- El proyecto sigue siendo una recreación nativa y no incorpora el código fuente de Mojang dentro del ZIP.

## Validación

- Añadidas pruebas de unidad para la posición/escala del marco seleccionado y para las transformaciones de objetos en primera persona.
- Verificación del ZIP e inspección estática de los recursos/modelos relevantes del `client.jar`.
- No se afirma compilación ni ejecución de `cargo test`: el entorno de generación no dispone del toolchain de Rust.
