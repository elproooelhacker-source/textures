# Worldgen continuation after v2.2.3.154

The next work is to finish `BiomeDecorator.genDecorations()` in exact MCP 1.8.9 order before starting `ChunkProviderGenerate.populate()`:

1. Complete the remaining biome tree and mushroom overrides (`BiomeGenForest.decorate`, swamp tree, savanna tree, mushroom island giant mushrooms).
2. Implement `WorldGenFlowers` with biome-specific `pickRandomFlower` and the `GRASS_COLOR_NOISE` selection used by plains/forest.
3. Implement tall grass, fern, dead bush, double plants, water lilies, small mushrooms, reeds, cactus, pumpkins, melons, vines and cocoa, including each generator's exact random draws and support tests.
4. Port the per-biome `BiomeDecorator` counts and all subclass `decorate()` overrides. Do not assume one global set of counts.
5. Integrate one persistent shared `JavaRandom` stream across ore, substrate, tree, mushroom and remaining decoration stages; preserve generator-instance state where vanilla reuses a generator.
6. Only after that, port `ChunkProviderGenerate.populate()` structures/lakes/dungeons/spawn/freeze/snow in the exact call order.

Source of truth: the bundled `Minecraft-1.8.9-Deobfuscated-Source.zip`, not visual approximations.
