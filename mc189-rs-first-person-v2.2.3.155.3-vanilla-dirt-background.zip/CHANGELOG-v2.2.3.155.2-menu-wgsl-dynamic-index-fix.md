# v2.2.3.155.2 — menu panorama WGSL validation fix

- Fixes the title-screen shader validation panic on wgpu 0.19.4 / Naga.
- Replaces dynamic indexing into a function-local WGSL array with a constant `switch` lookup for the same 15 binomial blur weights.
- Preserves all 15 weights, offsets, sample order, and normalization (2187); intended visual blur is unchanged.
- Includes all source and world-generation changes from v2.2.3.155.1.
- Rust release compilation succeeded in the user's environment for v2.2.3.155.1. This patch has not yet been run on that GPU/runtime, so the menu launch must be retested.
