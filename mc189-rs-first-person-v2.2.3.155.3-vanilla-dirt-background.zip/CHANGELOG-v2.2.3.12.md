# v2.2.3.12 — First-person sleeve UV correction

- Preserves the vanilla 1.8.9 first-person arm transform, geometry, pivot, idle rotation, and sleeve inflation validated in v2.2.3.11.
- Corrects the 64x64 right-arm outer-sleeve UV vertical offset: the wear layer starts 16 pixels below the base arm's texture origin, not 32 pixels below it.
- Restricts sleeve sampling to the correct 64x64 skin region (V=32..48), avoiding unrelated/transparent pixels below the sleeve that could appear as stray flaps.
- Adds regression assertions for the sleeve UV range.
- No changes to camera, movement, collision, chunk streaming, or world loading.
