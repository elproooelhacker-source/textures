# v2.2.3.154 — Worldgen giant mushrooms (MCP 1.8.9)

Continues from the verified v2.2.3.151 project archive. The missing .152/.153 archives were not present in the retrievable Library listing, so this release does not pretend to contain their unverified changes. It reconstructs one discrete part of that work from the bundled MCP 1.8.9 source.

## Implemented

- Added `TerrainBlock` representations for huge brown/red mushroom blocks, retaining legacy block IDs 99/100 and `BlockHugeMushroom.EnumType` metadata 0–10.
- Added `JavaRandom::next_boolean()` using exactly one `next(1)` bit, matching `java.util.Random.nextBoolean()`.
- Added a source-based `WorldGenBigMushroom` port: random height, clearance volume, valid substrate check, brown/red cap geometry, corner metadata, all-inside metadata and stem.
- Preserved the vanilla generator-instance behavior in the decoration helper: its random mushroom type is chosen lazily once and retained for subsequent attempts in that pass.
- Added `decorate_overworld_big_mushrooms` and `populate_overworld_prefix_with_big_mushrooms`, with the stage ordered after trees as in `BiomeDecorator.genDecorations()`.
- Added regression tests for legacy IDs/metadata, deterministic generation and retained generator type.

## Source references checked

- `net/minecraft/world/gen/feature/WorldGenBigMushroom.java`
- `net/minecraft/block/BlockHugeMushroom.java`
- `net/minecraft/world/biome/BiomeDecorator.java`
- `net/minecraft/world/biome/BiomeGenMushroomIsland.java`

The mushroom-island biome sets `bigMushroomsPerChunk = 1`; other biomes default to zero. The API accepts this biome-specific count rather than guessing it.

## Fidelity limitations (not hidden)

- This is a discrete generator stage, not the complete decoration pipeline. Flower/grass/dead-bush/reed/cactus/lily-pad/small-mushroom/pumpkin/melon/double-plant/vine passes and biome-specific decoration overrides still need to be integrated in exact source order before `populate()` can be considered complete.
- `TerrainPopulationRegion` currently models only a subset of block materials and full-cube behavior. Mushroom clearance and cap replacement therefore use the representable air/leaves subset; unusual non-full blocks are not all modeled yet.
- The caller must supply the biome's `bigMushroomsPerChunk` value and invoke this stage immediately after the tree stage. The generic terrain pipeline does not silently invent biome settings.
- No bit-identical full-world parity claim is made. The shared population RNG must still be advanced by every preceding vanilla decoration/structure stage in exact order.

## Validation

- ZIP archive integrity checked after packaging.
- Rust compilation/tests were not run: this packaging environment does not expose `cargo`, `rustc`, or `rustfmt`. The new regression tests are included but remain unexecuted.
