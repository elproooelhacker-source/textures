# v2.2.3.8 — Classic Steve first-person arm

## Added
- Added a native 3D first-person right arm using the classic Steve skin from the Minecraft 1.8.9 client JAR (`assets/minecraft/textures/entity/steve.png`).
- Uses the classic right-arm UV layout with nearest-neighbor sampling and accepts both legacy 64x32 and modern 64x64 player skins.
- Renders the arm in a dedicated camera-space overlay pass, independently of world chunk depth and chunk streaming.
- Keeps the arm fixed to the view without modifying player movement, collision, camera interpolation, or world data.
- Preview modes do not display the arm; it is enabled only for gameplay sessions.

## Validation
- ZIP structure and source formatting checked in the packaging environment.
- Rust compilation and workspace tests must be run on Windows with the project's installed Rust toolchain.
