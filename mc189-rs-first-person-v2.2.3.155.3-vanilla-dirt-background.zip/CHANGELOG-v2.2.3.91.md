# v2.2.3.91 — Vanilla-style dropped item entity foundation

- Added `DroppedItem::spawn_from_drop`, accepting the resolved `ItemDrop` payload and a shared `JavaRandom` stream.
- Replaced the previous xorshift-only spawn path with Java `java.util.Random` draws for the 0.25–0.75 block spawn offset and horizontal launch velocity.
- Added one-world-tick `tick_vanilla`: item gravity of 0.04 blocks/tick², movement, 0.98 drag, age and pickup-delay updates.
- Added the 6000-tick despawn predicate and regression tests for spawn payload, offsets, velocity, gravity, drag, pickup delay and despawn age.

## Scope / limitations

This is the entity simulation foundation only. The gameplay event loop does not yet create, render, collide, merge, or pick up these item entities. Collision against the ground and water/lava behavior are not yet implemented. Do not interpret this version as complete dropped-item gameplay.

ZIP integrity is checked. Rust compilation and unit tests were not run in this environment because Cargo/rustc are unavailable.
