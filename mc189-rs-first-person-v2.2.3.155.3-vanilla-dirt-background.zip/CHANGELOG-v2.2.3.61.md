# v2.2.3.61

- Added a seeded ravine carver pass based on the 1.8.9 `MapGenRavine` path profile: broad horizontal radius, expanded vertical radius, per-height distortion profile, pitch/yaw drift, water-border rejection, and lava below Y=10.
- Added deterministic ravine regression coverage.
- This carver is exposed as `carve_ravines`; chunk-generation orchestration is not yet wired to invoke carvers in the complete vanilla order. The implementation is a close port of the visible MCP algorithm but still requires differential testing against a running 1.8.9 client for bit-exact output.
