# v2.2.3.139 — Singleplayer world management

## Vanilla source basis
Compared the native selector and rename/delete flows against the deobfuscated 1.8.9 classes `GuiSelectWorld`, `GuiRenameWorld`, and `GuiYesNo`.

## Implemented
- World list rows now follow the 1.8.9 selector's three-line text layout (display name, save folder, game mode/flags); removed the non-vanilla thumbnail tile.
- Double-clicking a selected world launches it, matching `GuiSelectWorld.List.elementClicked`.
- Rename screen edits `Data.LevelName` in `level.dat` instead of renaming the save folder. Existing unknown NBT tags are retained; write uses `level.dat_new` and `level.dat_old` transaction files.
- Delete now has a separate confirmation screen. To protect user saves during this reverse-engineering phase, confirmed deletion moves the complete save into `saves/.mc189-trash` rather than permanently erasing it. The save can be restored manually.
- World list is rediscovered after rename/delete; button enablement follows selection state.
- Added focused tests for NBT-preserving rename and recoverable deletion quarantine.

## Not yet vanilla-complete
- World-list scrolling and exact date formatting remain incomplete.
- Recreate still needs to populate the actual `GuiCreateWorld` controls from the selected `WorldInfo`.
- New-world creation remains disabled until a compatible 1.8.9 world-generation and initial-save pipeline is implemented; do not create a fake empty save.
- Multiplayer server status pings, MOTD formatting, latency icons, LAN discovery, and exact list scrolling remain pending.
- Panorama still lacks the original 8x8/64-view framebuffer render pipeline and is not claimed pixel-identical.

## Validation
- ZIP integrity checked after packaging.
- Rust compilation/tests were not run: this environment has no `cargo` or `rustc` executable.
