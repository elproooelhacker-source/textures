# v1.9.1 — First liquid geometry and furnace orientation audit

## Added
- First-pass legacy water and lava meshes for IDs 8/9 and 10/11.
- Classic liquid metadata surface heights: levels 0–7 use descending surface heights; falling levels 8–15 reach the block top.
- Top faces use still-sprite frame zero; exposed side faces use flow-sprite frame zero.
- Fluid side faces are culled against opaque blocks and same-family neighbors whose liquid surface is at least as high.
- Separate counters for rendered water blocks, lava blocks, generated fluid quads, and fluid blocks with no visible faces.
- Atlas planner aliases frame zero of water/lava still/flow strips while retaining original animated sprites and metadata for a future animation scheduler.
- Tests for metadata heights/families, source-fluid face generation, and atlas alias naming.

## Furnace orientation finding
The supplied 1.8.9 JAR defines `furnace` and `lit_furnace` as children of `block/orientable`. Their front textures are `blocks/furnace_front_off` and `blocks/furnace_front_on`; the blockstate rotates the north-facing model according to metadata. The classic mapping is 2=north, 3=south, 4=west, 5=east. The screenshot shows a valid furnace model, but the front texture may be on a face turned away from the current camera. It must remain aligned with saved metadata rather than being forced toward the camera.

## Limitations
- This is not yet a full Minecraft fluid renderer. Flow corner-height averaging, proper slope interpolation, exact flow-direction UV rotation, animated frame timing, and camera-dependent translucent sorting are not implemented.
- Rebuild the atlas from the extracted client textures using the new planner/rasterizer so `water_still_frame0`, `water_flow_frame0`, `lava_still_frame0`, and `lava_flow_frame0` entries exist.
- Source world data remains read-only.
- Rust compilation/tests were not run in the authoring environment because Cargo is unavailable; Windows validation is required.
