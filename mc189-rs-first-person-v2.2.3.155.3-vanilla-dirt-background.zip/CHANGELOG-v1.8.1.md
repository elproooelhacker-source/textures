# v1.8.1 — expanded verified legacy block registry

## Scope of this increment

This increment expands the numeric 1.8.9 ID/metadata mapper using the exact vanilla client JAR resource names. It does not claim complete 1.8.9 rendering parity.

### Newly mapped solid and metadata families

- Dirt: coarse dirt and podzol (`3:1`, `3:2`).
- Sand: red sand (`12:1`).
- Sponge: dry/wet selector (`19:0..1`).
- Sandstone: chiseled and smooth (`24:1..2`).
- Wool, stained glass, stained hardened clay, carpet: all 16 legacy dye metadata values (`35`, `95`, `159`, `171`).
- Stone bricks: normal, mossy, cracked, chiseled (`98:0..3`).
- Quartz: normal, chiseled, and default-axis pillar (`155:0..2`). X/Z pillar axis metadata (`155:3..4`) is intentionally still classified as a dedicated visual until rotated direct-model support is added.
- Lapis block, note block, gold/iron blocks, bricks, TNT, bookshelf, diamond block, snow block, netherrack, soul sand, glowstone, melon, nether brick, end stone, redstone lamps, emerald ore/block, beacon, redstone block, quartz ore, slime, sea lantern, hardened clay, coal block, packed ice.
- Prismarine rough/bricks/dark metadata (`168:0..2`).
- Additional ordinary solid blocks: lapis/gold/iron/diamond/emerald/redstone blocks, note block, bricks, TNT, bookshelf, snow, netherrack, soul sand, glowstone, melon, nether brick, end stone, lamps, beacon, quartz ore, slime, sea lantern, hardened clay, coal block, packed ice.
- Mycelium snowy-context variant and hay-block axis variants.
- Hay block axis selectors (`170:0,4,8`).
- Mycelium snowy context selector, resolved from the block above.

### Resource-name corrections

- Dead bush uses `block/dead_bush`, not `block/deadbush`.
- Tall grass uses `block/tall_grass`, not the abstract parent `block/tallgrass`.

### Validation performed against the supplied vanilla 1.8.9 client JAR

- All 82 newly referenced model JSON files exist (18 non-color models plus 64 dye-specific models).
- All 107 concrete texture bindings inherited by those 82 models resolve to PNG entries in the JAR.
- All 33 newly added blockstate selector checks (including sponge, mycelium and hay axes) resolve to existing blockstate entries and existing model files.

### Explicit remaining limitations

- No Rust compiler or Cargo is available in the build environment used for this archive preparation. `cargo fmt` and `cargo test` must be run by the user on Windows before treating this increment as compiled/tested.
- UV-lock remains unsupported; states requiring it are still skipped.
- Fluids, fire, tile-entity renderers, mushroom-block face masks, monster-egg substrate metadata, quartz pillar X/Z orientation, and several other metadata/contextual families remain dedicated follow-up work.
- Stained glass geometry is mapped, but correct translucent blending, sorting and depth-write behavior are not yet implemented.
- Many oriented or neighbor-connected families are not covered by this increment.


### Corrección posterior a pruebas en Windows
- Se corrigió el selector contextual de `mycelium`: en Minecraft 1.8.9 utiliza `snowy=false/true`, igual que `grass`, y cambia al modelo cubierto de nieve cuando encima hay una capa de nieve (ID 78) o hielo (ID 79).
- La prueba automatizada `mycelium_snowy_state_uses_snow_layer_and_ice_above` detectó que el selector no estaba conectado al resolver contextual.
