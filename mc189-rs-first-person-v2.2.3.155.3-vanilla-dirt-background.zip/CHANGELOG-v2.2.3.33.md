# v2.2.3.33 — Smooth vertex lighting and safe atlas mipmapping

- Changed smooth vertex lighting from one behind-face light sample to a four-sample corner neighborhood (base, both sides, diagonal), weighted by the matching AO values. This makes light transitions interpolate across each face instead of repeating one abrupt sample.
- Updated the negative-world-coordinate lighting regression test for the four-sample average.
- Added one half-resolution GPU mip level for the block atlas and enabled linear minification/mipmap filtering while retaining nearest magnification for crisp nearby pixel art.
- Limited the atlas to one mip level beyond the original because its two-pixel extruded gutters become one pixel at half resolution; deeper levels could blend neighboring sprite colors.
- Kept projected shadows disabled; this change affects ambient vertex lighting only.
- Documented the remaining approximation versus vanilla's complete AO and RGB lightmap paths.

Validation note: this environment does not have the Rust toolchain installed. The archive is source-reviewed and ZIP-verified, but `cargo fmt` and `cargo test` must be run on Windows before treating it as compiled.
