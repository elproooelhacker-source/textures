# Client/server ownership after v2.2.3.123

## Server (`mc189-server`)

- Runs authoritative player movement/collision and mining on the fixed 20 TPS simulation thread.
- Owns the active `PlayerInventory` data model, selected hotbar slot, cursor stack, armor slots, and supported slot mutation operations.
- Resolves the selected mining tool from its own inventory. The client only reports attack-held intent; it cannot choose a block target, tool tier, or player-ground/water mining context.
- Publishes player snapshots every tick and inventory snapshots only when the inventory revision changes.
- Remains the sole Anvil persistence writer through the deferred persistence service.

## Client (`mc189-app`)

- Owns wgpu rendering, camera, HUD, GUI textures, pointer coordinates, item icons, and animation presentation.
- Sends movement, attack-held, hotbar-select, and supported container-slot commands.
- Receives inventory snapshots and updates its GUI replica; supported container clicks do not mutate the local inventory before server confirmation.
- Continues to perform client-side visual chunk lighting/mesh work; it submits the resulting chunk snapshots to the server collision mirror.

## Supported authoritative inventory commands

- Select hotbar slot `0..8`.
- Left/right click on main inventory slots `0..35`.
- Left/right click on armor slots `36..39`.
- Shift-click transfers between hotbar/main inventory and armor/main inventory using the currently implemented merge/equip rules.

The current container implementation is deliberately a subset of MCP `Container.slotClick`; it is not yet a full vanilla container implementation. In particular, drag splitting and several special click modes remain pending.

## Next migration increment before block placement

1. Move `EntityItem` lifecycle to the server: spawn, pickup delay, gravity/drag, block collision, stack merge, despawn, and player pickup range.
2. Make pickup call server-owned `InventoryPlayer.addItemStackToInventory` semantics, then publish inventory and entity snapshots.
3. Move Q/Ctrl+Q drops and `/give`/`/clear` into server commands; remove the remaining app-side inventory mutations.
4. Move tool durability and mining context/effects to server-owned player/item state.
5. Only after these ownership boundaries are stable, add server-authoritative block placement with vanilla 1.8.9 placement checks and client-side predicted visuals reconciled against server results.

## Network protocol boundary

The integrated single-player server uses in-process commands/snapshots. The dedicated TCP transport still uses the project's internal JSON-line protocol and is not Minecraft protocol 47. Implementing protocol 47 remains deferred until after client/server gameplay migration and block placement.
