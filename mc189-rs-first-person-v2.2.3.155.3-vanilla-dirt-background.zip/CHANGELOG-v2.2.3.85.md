# v2.2.3.85 — MCP drops + client resource extraction

## Drop registry additions
- BlockDoublePlant (ID 175): upper-half no-drop; flower variants preserve metadata; double grass uses the 1-in-8 seed roll; double fern has no ordinary drop; shears on lower grass/fern halves produce two tall-grass items with the corresponding metadata.
- Snow layers (ID 78): player harvest produces `layers + 1` snowballs using metadata `(meta & 7) + 1`.
- Snow block (ID 80): four snowballs.
- Melon block (ID 103): 3 + `nextInt(5)` slices, then Fortune `nextInt(fortune + 1)`, clamped to nine.
- Clay block (ID 82): four clay balls.
- Vine (ID 106): no ordinary drop; shears produce one vine.
- Cobweb Silk Touch eligibility corrected to match `BlockWeb.canSilkHarvest()`.

## Client assets
- Added `extract-client-assets <client.jar> <output-assets/minecraft>`.
- Bundled only the 3,085 files under `assets/minecraft/` from the supplied client JAR (4,553,815 uncompressed bytes): blockstates, models, shaders, textures, font, lang and texts.
- No class files, META-INF, manifests or libraries were extracted.
- The client JAR has zero OGG/WAV/MP3 files. Added `extract-launcher-audio` to copy the matching asset-index sound objects from the launcher `.minecraft/assets/objects` cache; this requires the exact 1.8 asset index and locally cached objects. Audio files were not bundled because they are not present in the supplied JAR or local runtime.

## Verification status
- Input JAR SHA-256: `14f0d96d1a56fb4f5c3b2233d00699525893fe5ce3dcf181e7de59120595d298`.
- Asset count and extraction paths were checked with Python ZIP processing; the source JAR remained unchanged.
- ZIP package integrity checked after creation.
- Rust tests were added but not run: this environment has no `cargo` or `rustc`.
- This is still a drop-registry/resource-ingestion milestone, not an end-to-end mining integration.
