# v2.2.3 — grounded jump handling and smooth camera interpolation

## Fixed
- Refreshes ground support from the complete player collision box with a short, non-mutating downward probe before consuming a buffered jump.
- Preserves the jump request until the next fixed simulation step, rather than deriving it from a sampled keyboard state at frame boundaries.
- Adds concise jump diagnostics for the Space key event, the block below the player's feet, and whether the jump actually starts or remains buffered.
- Interpolates the rendered camera position between the previous and current fixed-step player states on every frame. Physics and collision remain deterministic at 20 Hz; only the visual camera is interpolated.

## Added tests
- Ground-support probe detects a floor without moving the player.
- Buffered jump starts when the collision box is supported by the floor.

## Scope
- Keeps the existing 3x3 loaded-chunk gameplay boundary and read-only world access.
- Does not yet implement chunk streaming, block interaction, or new block collision shapes.
