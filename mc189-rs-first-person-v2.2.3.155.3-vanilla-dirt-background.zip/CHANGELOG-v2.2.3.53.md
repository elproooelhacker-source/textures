# v2.2.3.53 — World generation foundation

This iteration pauses main-menu work and starts the Minecraft Java 1.8.9 world-generation subsystem.

## Added
- Vanilla seed text parsing: signed 64-bit decimal seeds use Java `Long.parseLong` semantics; other strings use Java `String.hashCode` over UTF-16 code units.
- Exact 48-bit `java.util.Random` primitive with `nextInt`, `nextLong`, `nextFloat`, and `nextDouble`.
- Separate `GenLayer` LCG with vanilla base-seed, world-seed, chunk-seed initialization, and bounded `nextInt` semantics.
- Unit tests for known Java Random outputs, seed-string behavior, and deterministic coordinate-specific GenLayer streams.

## Scope and limitations
This is the deterministic RNG/seed foundation only. It does not yet generate chunks, biomes, terrain, ores, caves, structures, or write Anvil region files. Those are the next implementation stages; this release must not be described as a completed world generator.
