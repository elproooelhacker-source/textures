# v2.2.3.89 — Selected hotbar tool affects mining

## Changes
- Gameplay mining now resolves the currently selected hotbar `ItemStack` into the legacy 1.8.9 tool category and tier.
- Wooden/stone/iron/diamond/golden pickaxes, axes and shovels plus shears are recognized by their registry item IDs.
- The resolved tool is passed to the existing MCP-shaped block-hardness calculation instead of always mining with an empty hand.
- Added unit coverage for item-to-tool resolution, including unknown items falling back to hand.

## Scope and limitations
- The inventory model does not yet preserve item enchantment NBT, so Efficiency remains zero.
- This does not add item durability, harvest/drop gating, crack rendering, dropped-item entities, or lighting/heightmap recomputation.
- Rust compilation and in-game verification remain outstanding; this environment has no Rust toolchain. ZIP integrity is checked separately.
