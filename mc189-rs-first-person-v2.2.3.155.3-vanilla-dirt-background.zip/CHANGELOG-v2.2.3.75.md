# v2.2.3.75 — Correct first-person item scale and generated-item side UVs

- Corrected first-person item transform ordering to follow MCP 1.8.9 `ItemRenderer` and `ItemCameraTransforms` rotation order (Z, Y, X).
- Removed the non-vanilla `0.4` first-person scale and applied the inner `RenderItem` `0.5` scale consistently.
- Applied the outer `ItemRenderer` scale of `2.0` only to GUI-3D/block models, rather than generated sprite models, to prevent swords/tools from appearing oversized.
- Corrected generated item-layer side-face UVs so side walls sample their actual silhouette edge instead of stretching the entire pixel texture across the thickness; this addresses stray-looking spikes on thin tools/swords.
- Added isometric, three-face shaded block icons in inventory/hotbar/cursor stack rendering for recognized full-cube block items. Non-cube items retain their native sprite rendering.

Validation note: source-level checks and ZIP integrity are performed for this package. Cargo/Rust compilation cannot be run in the current build environment because `cargo`/`rustc` are not installed; please verify with `cargo test --workspace` on Windows.

## Follow-up correction (v2.2.3.75)
- Restored the missing `ItemRenderer.transformFirstPersonItem` scale(0.4), verified against the original MCP 1.8.9 source. This reduces generated item models to the vanilla scale; combined with the `RenderItem` inner scale(0.5) and the model's own display scale, the diamond sword's 1.7 display scale is no longer incorrectly applied at 2.5x the intended size.
- Side walls of generated item layers now sample the exact centre of their source texel. This prevents UV edge ambiguity/adjacent texel bleed that can create cross-shaped protrusions on swords and tools.
- Added an assertion for the expected 0.2 effective unit scale of a default generated item (0.4 × 0.5) and retained the block-vs-sprite 2:1 scale assertion.
- Inventory block icons remain 16x16 logical pixels like vanilla's GUI. The existing isometric approximation still maps the same sprite onto each visible face; a fully faithful per-face inventory render needs rasterizing the actual resolved block model and its individual face textures, and is not claimed as complete in this patch.

## Follow-up correction (v2.2.3.76)
- The previous notes correctly restored the `ItemRenderer` 0.4 scale but missed `RenderItem.preTransform`'s 2x scale for non-GUI-3D generated items. v2.2.3.76 applies the vanilla 2x factor to both paths before the shared 0.5 factor, making their net scales equal.
