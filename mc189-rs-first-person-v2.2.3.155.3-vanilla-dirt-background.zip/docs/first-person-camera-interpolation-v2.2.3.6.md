# First-person camera interpolation — v2.2.3.6

The player simulation runs at a fixed 20 Hz, while the renderer can submit frames between simulation ticks. The camera therefore uses a render-only player pose interpolated between the previous and current simulation states.

Previously, the mouse-motion event updated the camera using the authoritative `player` state directly. That state is positioned on a 20 Hz simulation tick and is not necessarily the same as the interpolated camera position currently being displayed. An asynchronous mouse event could consequently submit a camera matrix with a raw simulation position between two interpolated frames. Window resize and swapchain recovery used the same raw-state update path.

The renderer now retains a separate `camera_player` pose. Mouse input copies only yaw and pitch into that pose, preserving its interpolated position. The next normal frame update computes a fresh interpolated pose. Resize and surface recovery also reuse the retained render pose.

This is deliberately limited to camera presentation. The authoritative simulation, collision state, movement constants, and tick frequency are unchanged.
