# Architecture notes

## Dependency direction

- `mc189-core`: shared primitives and error types; no graphics or storage dependencies.
- `mc189-storage`: read-only Anvil parser, bounded chunk decompression, NBT parser, and legacy block-array decoding; depends on `mc189-core`.
- `mc189-app`: command-line entry point and world-wide summaries; composes the crates.

## Anvil region header

An Anvil region file begins with an 8192-byte header:
- bytes 0..4096: 1024 location entries, 4 bytes each.
- bytes 4096..8192: 1024 timestamps, 4 bytes each.

Each location entry encodes a 3-byte sector offset and a 1-byte sector count. Sector offsets are measured in 4096-byte sectors. Region-local chunk slot ordering is `local_x + local_z * 32`; world chunk coordinates must use Euclidean division for negative values.

## Chunk payload

A region record contains a 4-byte big-endian length, a 1-byte compression type, and the compressed NBT payload. The reader currently supports gzip (1), zlib (2), and uncompressed (3), with a 64 MiB limit on the decompressed NBT payload.

The `decode_chunk` path expects the legacy 1.8-style `Level` compound and reads `xPos`, `zPos`, `Sections`, `Biomes`, and `HeightMap`. It does not yet decode entities, tile entities, scheduled ticks, or full player state. A separate bounded gzip/NBT reader reads selected global properties from `level.dat`; it is read-only.

## Legacy section block arrays (1.8.9)

Each populated section has a byte `Y`, a 4096-byte `Blocks` array, and a 2048-byte `Data` nibble array. Optional `Add` supplies the high four bits of each 12-bit block ID. Metadata and light arrays use low nibble for even block-array indices and high nibble for odd indices. The block-array index is `(local_y << 8) | (local_z << 4) | local_x`.

Decoded sections keep one block ID and one metadata value per block, with optional decoded block- and sky-light values. Queries treat a missing section as air (block ID 0, metadata 0), as required for the legacy format. Section Y values outside 0..15 and duplicate section Ys are rejected for the current 1.8.9 target. Biomes and HeightMap are retained as raw values for later terrain and renderer work; they are not interpreted as lighting or surface geometry yet.

## World metadata (`level.dat`)

`read_world_metadata` reads gzip-compressed NBT, requires the standard `Data` compound and extracts selected typed fields. A missing property remains `None`; a present property with the wrong NBT type is rejected rather than silently coerced. Both compressed file size and decompressed output are capped at 64 MiB. The `version` integer is reported as a storage-format version, not inferred to be the precise game version.

## Not implemented yet

- GPU rendering or a native window.
- Texture atlas and block model/metadata mapping.
- Block-face culling, AO, transparent layers, fluids, and 1.8 lighting propagation.
- Entity/tile-entity simulation, redstone, world generation, networking, or writes.


## Read-only block coordinate query

`inspect-block <world> <x> <y> <z>` maps world block coordinates to a chunk using Euclidean division by 16, then maps the chunk coordinate to its region and region-local slot using Euclidean division by 32. This deliberately avoids Rust's truncating integer division for negative positions. Before returning data, the command verifies that the chunk is stored and that the payload's `xPos` / `zPos` agree with the region slot. An absent chunk is not silently interpreted as air. The command reports the legacy numeric block ID and 4-bit metadata, along with optional section light and column biome/height values. Block-name lookup is not attempted because it requires a versioned vanilla registry and may require a modpack-specific registry.
