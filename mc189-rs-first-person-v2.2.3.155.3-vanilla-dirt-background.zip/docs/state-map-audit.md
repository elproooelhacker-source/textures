# Legacy block-state audit: interpretation

The `audit-world-state-map` command is deliberately a diagnostic, not a renderer. It reads world region/chunk data and checks a partial vanilla legacy-ID mapping against the local 1.8.9 JAR.

Categories mean:

- **Directly validated selector:** the expected selector exists in an existing blockstate JSON. Property key order is ignored, but the full set of `key=value` assignments must match.
- **Verified contextual model family:** all listed model variants exist, but the final choice still depends on nearby world state.
- **Legacy metadata/special visual path:** a known old numeric state requires a metadata-aware texture/model path or dedicated geometry (for example stone variants, logs/leaves, or cross-plane plants); it is not falsely reported as a missing JSON selector.
- **Blockstate file absent:** no matching blockstate JSON exists at the expected path. This may indicate that the classic block needs a dedicated renderer/mapping; it does not prove an asset is missing.
- **Selector absent from existing JSON:** the exact property selector is not present and needs investigation.
- **Multipart-only:** the file uses `multipart`, which this initial map does not yet evaluate for state selection.
- **Unmapped ID/metadata:** the current registry intentionally does not guess a visual state.

The report's `World data integrity` status is independent from visual mapping coverage. No successful audit here means the game is ready to render; actual block-state resolution, special renderers, neighbor culling, tint/lighting and GPU rendering remain separate milestones.

## Expanded registry pass

The expanded registry adds direct selectors for common cobblestone, diamond ore, clay, rail shapes, cobweb, mushroom, mossy-cobblestone, obsidian and torch variants. The six plank species are verified as direct model files instead of assuming an absent `blockstates/planks.json`; the audit checks the actual files under `models/block`. Oak fence selectors are validated as a 16-case neighbor-dependent family. Dead bush, flowers, sugar cane, mushroom blocks, double plants and fire remain explicit special visual paths rather than guessed cubes. Unknown ID/metadata combinations are ranked by the number of stored positions they affect so the largest gaps appear first.


## Follow-up: facing and tile-entity state classification

The registry now handles the common states observed in the test world for cactus, crafting table, furnace/lit furnace and pumpkin/lit pumpkin. It maps the spawner cage through `blockstates/mob_spawner.json` while leaving the spinning entity preview for a dedicated tile-entity renderer. Chests remain a dedicated tile-entity-renderer path; they must not be drawn as generic full cubes. These mappings are validated against the client's JSON selectors at runtime. Furnace facing uses classic metadata indices 2=north, 3=south, 4=west, 5=east; pumpkin facing uses 0=south, 1=west, 2=north, 3=east. Unsupported metadata stays unmapped.
