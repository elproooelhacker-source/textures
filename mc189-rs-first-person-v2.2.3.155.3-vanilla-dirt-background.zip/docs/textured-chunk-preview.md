# First integrated textured chunk preview

The `preview-textured-chunk` command joins the legacy Anvil reader, the 1.8.9 ID/metadata registry, blockstate variant resolution, the cached client-model catalog, the static texture atlas and the existing wgpu model viewer.

## Command

```powershell
cargo run -p mc189-app -- preview-textured-chunk "<world-folder>" "<client.jar>" "<atlas-output-directory>" <chunk-x> <chunk-z>
```

For the current test world and previously audited chunk:

```powershell
cargo run -p mc189-app -- preview-textured-chunk "C:\Users\Admin\Downloads\UltimMC-Launcher-All-Versions (1)\UltimMC-Launcher-Win32\UltimMC\instances\1.8.9\.minecraft\saves\New World" "C:\Users\Admin\Downloads\client.jar" "C:\Users\Admin\Downloads\block-atlas-output" -16 15
```

## Implemented in this milestone

- Loads and coordinate-validates the requested chunk and its four horizontal neighbors.
- Loads model JSON resources into one `ModelCatalog` per chunk build. Parent resolution and compiled model quads are cached by canonical model path.
- Uses the explicit 1.8.9 legacy ID/metadata map; unsupported states are counted, never guessed as cubes.
- Resolves direct blockstate selectors, direct model files, weighted alternatives and blockstate X/Y rotations.
- Uses a stable world-position-derived seed for weighted model selection, then Java's 48-bit `Random` implementation for the weighted draw.
- Resolves grass `snowy` from the block above and oak-fence connections from adjacent blocks.
- Applies conservative cullface removal only when the adjacent block belongs to the explicit opaque full-cube set.
- Remaps each model face UV through the existing static atlas and submits one combined chunk mesh to wgpu.
- Computes a camera target and clipping distance from the generated geometry.

## Deliberate exclusions

This is the first integrated textured chunk renderer, not yet a complete Minecraft renderer. Water/lava, animated atlas sprites, biome tinting, light/sky-light sampling, leaves and other metadata-specific visuals, flowers/cross-plane geometry, chest and other tile entities, stairs/doors/rails beyond currently mapped states, transparency sorting, ambient occlusion, and neighboring-chunk streaming are not implemented here. `uvlock=true` states are counted and skipped instead of rendered with incorrect UVs. The atlas viewer still requires a single static atlas page.

Missing horizontal neighbor chunks are treated as air for contextual states and face culling. The source world and client JAR are read-only; the command does not write into either.

## Validation required on Windows

The assistant environment used to prepare this source archive does not have `cargo` or `rustc`; the code has therefore not been compiled here. Run `cargo fmt --all` and `cargo test --workspace` before trying the preview command. A successful build/test is not proof of complete block coverage: use the printed rendered/skipped counters to audit the actual chunk.
