# Lighting port v2.2.3.36

## Reference methods inspected

The implementation was cross-checked against the obfuscated classes in the user's Minecraft 1.8.9 `client.jar`:

- `bgf$b`: `BlockModelRenderer.AmbientOcclusionFace.updateVertexBrightness`, `getAoBrightness`, and `getVertexBrightness`.
- `bgf$a`: `EnumNeighborInfo` direction-specific side offsets, shade values, and orientation tables.
- `bgf$c`: `VertexTranslations` for the six face directions.
- `bgf$d`: `Orientation` bound indices used by non-cubic faces.
- `afh`: block translucency, full/opaque cube queries, mixed packed brightness, and AO light value.
- `bfk.g`: `EntityRenderer.updateLightmap` color transformation.

## Per-face AO flow

For each model quad, the mesh builder derives its local min/max bounds, orders the 12 bound values by `EnumFacing` (the six facing bounds followed by their complements), and calculates the two flags used by `fillQuadBounds`.

The AO sampler then follows the original face table:

1. Offset the base sample by the face normal only when flag 0 requires it.
2. Sample the four table-defined side neighbors for AO and mixed packed brightness.
3. Test `Block.isTranslucent()` at each side sample plus the face normal. The relevant diagonal is sampled only when either corresponding side passes that test; otherwise the original side sample is reused.
4. Select center brightness from the face neighbor when flag 0 is set or that neighbor is not an opaque cube. AO's center value comes from the base block's `getAmbientOcclusionLightValue` behavior.
5. Apply the original four-corner arithmetic, zero-brightness substitution, independent sky/block packed-byte averaging, and orientation weights for non-cubic side faces.
6. Map the geometric corners into the baked quad's vertex order with the face's `VertexTranslations` table.

AO, sky light, block light, and directional shade are kept separate in the vertex stream.

## Lightmap path

Vertex sky and block levels are interpolated separately. A 16x16 texture is generated with X = block light and Y = sky light. Its texels use the original world-brightness lookup curve and the RGB equations inspected in `EntityRenderer.updateLightmap`. The fragment shader maps the interpolated levels to texel-center coordinates and samples with a linear sampler, avoiding a nonlinear operation on one already-interpolated maximum-light scalar.

This increment fixes the lightmap's clear-day color calculation only. The app does not yet feed world day-time or torch flicker into the table, and it does not implement the separate no-sky, gamma, night-vision, or fluid-rendering branches.
