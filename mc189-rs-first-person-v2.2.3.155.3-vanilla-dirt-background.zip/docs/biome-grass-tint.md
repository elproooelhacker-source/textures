# Biome-based grass tint

The chunk preview now uses the classic 1.8.9 chunk `Biomes` byte array (256 values, indexed `z * 16 + x`) to tint the model faces whose JSON declares a non-negative `tintindex` on legacy grass blocks (ID 2).

The color comes from `assets/minecraft/textures/colormap/grass.png` in the supplied vanilla client JAR. The biome's temperature and rainfall select a pixel using the vanilla grass colorizer formula:

- `temperature = clamp(temperature, 0, 1)`
- `rainfall = clamp(rainfall * temperature, 0, 1)`
- `x = floor((1 - temperature) * 255)`
- `y = floor((1 - rainfall) * 255)`

The sampled sRGB color is converted to linear RGB before it is passed to the GPU. This matters because the atlas is uploaded as `Rgba8UnormSrgb`, so texture samples are linear when multiplied in the fragment shader.

If a chunk lacks biome data, or its biome ID is not in the explicit 1.8 biome climate table, the grass remains untinted (white multiplier) and the counter reports the missing data. The renderer never substitutes a guessed generic green.

Leaves and water tinting, per-vertex biome interpolation at block boundaries, and biome-specific special cases remain future work.
