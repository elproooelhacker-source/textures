# Blockstate variant preview — weighted selection

The `preview-blockstate-variant` command connects the read-only 1.8.9 `variants` resolver to the existing textured GPU model preview. It loads one exact selector from `assets/minecraft/blockstates/<id>.json`, selects one alternative according to its declared `weight` using the 48-bit `java.util.Random` algorithm, resolves that model, and applies the variant X/Y rotations around the block center before compiling the textured mesh.

Example:

```powershell
cargo run -p mc189-app -- preview-blockstate-variant "C:\path\to\client.jar" "C:\path\to\block-atlas-output" oak_log "axis=y"
# Optional explicit seed (default is 0):
cargo run -p mc189-app -- preview-blockstate-variant "C:\path\to\client.jar" "C:\path\to\block-atlas-output" oak_log "axis=y" 12345
```

Use the blockstate resource ID without the `blockstates/` prefix (for example `oak_log`, `crafting_table`, or `minecraft:oak_log`). The selector must match the JSON key exactly; use an empty selector for the default variant.

## Weighted selection and seeds

- Every alternative's positive `weight` contributes to the selector's total weight.
- Selection uses Java's 48-bit `java.util.Random` algorithm and `nextInt(totalWeight)`, then walks the alternatives in JSON array order.
- If no seed is supplied, the preview uses seed `0`. Supplying the same seed and selector reproduces the same selected model.
- The seed is an explicit preview input, not yet a Minecraft world-position seed. A future world renderer must derive the seed from the block position using the exact 1.8.9 rendering path.
- Total weight is validated and must fit in a positive signed 32-bit integer.

## Deliberate limits

- `uvlock=true` is rejected until face-orientation UV compensation is implemented.
- `multipart` blockstates, tint indices, neighbor-dependent selection, and world lighting are not part of this step. Vanilla 1.8.9's 340 audited blockstates use `variants`; none in the supplied client JAR use `multipart`.
- The existing `preview-textured-block` command remains unchanged and available.

The command reads the JAR without modifying it.
