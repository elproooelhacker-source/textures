# Legacy stone variants — v1.8.0

Minecraft 1.8.9 stores the seven variants of stone under legacy block ID 1. Metadata 0 is ordinary stone and remains selected through `blockstates/stone.json` (`normal`). Metadata 1–6 do not correspond to additional blockstate files or different geometry: they reuse the same full-cube `block/stone` model with a metadata-selected texture.

| Metadata | Variant | Texture resource |
|---:|---|---|
| 0 | Stone | `blocks/stone.png` (vanilla blockstate) |
| 1 | Granite | `blocks/stone_granite.png` |
| 2 | Polished granite | `blocks/stone_granite_smooth.png` |
| 3 | Diorite | `blocks/stone_diorite.png` |
| 4 | Polished diorite | `blocks/stone_diorite_smooth.png` |
| 5 | Andesite | `blocks/stone_andesite.png` |
| 6 | Polished andesite | `blocks/stone_andesite_smooth.png` |

The chunk renderer clones the cached `block/stone` quads and replaces only each quad's texture resource path. Model-space positions, face directions, UV rectangles, UV rotations, cullfaces and normals are not changed. The existing atlas runtime then resolves each variant texture by its normal resource key. Missing atlas entries remain hard errors; there is no fallback to ordinary stone.

Metadata 7–15 is rejected as unsupported/reserved. The client-JAR state audit checks that the six override texture PNGs exist before counting these states as mapped.
