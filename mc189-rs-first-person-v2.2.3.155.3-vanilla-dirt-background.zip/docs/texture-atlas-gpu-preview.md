# Static atlas GPU preview

`preview-block-texture-atlas <atlas-output-directory>` is a focused validation stage between atlas rasterization and textured model rendering.

It loads and validates the runtime manifest through `AtlasRuntime`, uploads page zero using `GpuAtlasPage::upload`, creates a texture/sampler bind group, and displays the full page in a native wgpu window. The sampler uses nearest filtering and clamp-to-edge addressing. Animated sprites remain separate.

The preview intentionally does not claim to render block models or world chunks. The next stage is to feed model-resolved face UVs and compiled geometry into a textured mesh pipeline, then integrate blockstate rotations and chunk meshes.

## Textured single-block model preview (first integration step)

`preview-textured-block <client.jar> <atlas-output-directory> <model-id>` resolves one vanilla model from the client JAR (including its parent chain and inherited texture aliases), compiles its element faces, maps each face's model-space UV rectangle into the existing rasterized atlas, uploads atlas page zero, and draws the resulting textured mesh with wgpu. Example model IDs include `block/stone` and `minecraft:block/stone`.

This first integration intentionally has a narrow scope: a single model with static textures on atlas page zero. It does not yet select blockstate variants, apply blockstate X/Y rotations or `uvlock`, implement biome tinting, animation frames, neighbor culling, ambient occlusion, or render world chunks. The preview supports orbit (left mouse drag), zoom (wheel), reset (`R`), and close (`Esc`).
