# Resource pipeline for the 1.8.9 client JAR

This milestone adds a read-only archive inspector. It opens the user's local `client.jar` as a ZIP archive and checks the directory layout and signatures of a small set of representative files. It does not launch Java, extract assets, or change the JAR.

Command:

```text
cargo run -p mc189-app -- inspect-client-jar "C:\\Users\\Admin\\Downloads\\client.jar"
```

The report counts classic block/item textures and JSON block models, item models, and blockstates. It checks selected PNG signatures, basic JSON-object shape, and the Java class-file magic bytes for a representative class.

Limitations: this is a structural check, not a cryptographic provenance check or a definitive version identification. The next milestone should parse and validate blockstate/model JSON and build a mapping from legacy block IDs + metadata to the appropriate model and texture, with explicit handling for missing or unsupported states. Texture decoding and GPU upload should be added only after that mapping has tests.
