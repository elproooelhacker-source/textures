# Vegetation and tree rendering — v1.7 implementation

This milestone extends the textured chunk preview from terrain cubes to legacy 1.8.9
wood and vegetation states. It continues to read the original world and client JAR
without modifying either.

## Implemented paths

- Logs (IDs 17 and 162): decode species and axis from legacy metadata, resolve the
  vanilla `log` / `log2` blockstate axis variant, and override side/end texture paths
  for oak, spruce, birch, jungle, acacia and dark oak. The all-bark axis state uses the
  bark texture on every face.
- Leaves (IDs 18 and 161): decode all six legacy species, ignore decay flags for
  appearance, use the vanilla leaves model and species texture, and apply the foliage
  colormap using the stored biome ID.
- Saplings (ID 6): decode six species and the stage bit, then resolve the matching
  `sapling` blockstate selector.
- Tall grass / fern (ID 31), dead bush (ID 32), dandelion (ID 37), all nine red-flower
  variants (ID 38), reeds (ID 83), and both halves/species of double plants (ID 175)
  now map to their vanilla blockstate or crossed-plane model resources.
- Grass-like plant models that carry a tint index use the grass biome colormap.
- The fragment shader discards nearly transparent texels so cutout foliage does not
  write depth through fully transparent parts of a leaf texture.
- Chunk preview output reports rendered logs, leaves and cross-plane vegetation
  separately, as well as biome-tint coverage and unresolved model/state counts.

## Deliberate limitations

This is not yet a complete Minecraft renderer. Water/lava, vines, fire, crops, stems,
chorus-like blocks (not present in 1.8.9), tile entities, lighting/ambient occlusion,
translucent sorting, fancy/fast graphics leaf-mode differences, and all remaining
legacy metadata families still need dedicated work. The renderer does not fabricate
fallback cubes when a model or texture cannot be resolved; those states are reported.

The `foliage.png` / `grass.png` color-map lookup uses the biome's base temperature and
rainfall values. Height-adjusted biome temperature and special biome color overrides
remain a fidelity refinement. The four horizontal neighboring chunks are read for
neighbor-dependent states; diagonal chunk streaming is not implemented.

## Validation status

Source-level changes and regression tests are included for metadata decoding. This
archive has not been compiled in the assistant environment because the Rust toolchain
is unavailable there. Run `cargo fmt --all` and `cargo test --workspace` on Windows,
then run the chunk preview against the same world/JAR/atlas and inspect the per-family
counters before treating the renderer as validated.
