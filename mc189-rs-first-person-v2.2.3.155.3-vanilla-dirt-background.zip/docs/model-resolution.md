# Effective model and texture resolution

`resolve-client-models <client.jar>` is a read-only analysis stage for the Minecraft 1.8.9 resource pipeline.

## What it does

- Reads `assets/minecraft/blockstates/*.json` and collects concrete model targets from `variants` and `multipart` structures.
- Parses model JSON from `assets/minecraft/models/`.
- Resolves model parents recursively, with caching and cycle detection.
- Merges texture dictionaries parent-first and lets child bindings override parent bindings.
- Resolves chains such as `particle -> #all -> blocks/stone` using the final inherited texture table.
- Inherits element lists unless a child explicitly supplies its own `elements` field.
- Checks basic element vectors, optional element rotations, face directions, face texture IDs, UV arrays, and face UV rotations.
- Confirms the final vanilla texture paths used by concrete blockstate models exist in the JAR.

## Deliberate limits

This command does not select a blockstate from a legacy block ID and metadata value. It does not yet apply model X/Y rotations, `uvlock`, cull faces, ambient occlusion, tint indices, generated-item layers, or texture atlas stitching. The separate `compile-client-geometry` command now triangulation-prepares effective faces as CPU-side quads (four vertices per face) and preserves UV rectangles and face metadata. It does not create GPU buffers. A `PASS` means the checks implemented in this stage succeeded; it is not proof of pixel-identical Minecraft rendering.

The client JAR is opened as a ZIP/JAR archive and is neither extracted nor modified. Blockstate-level rotations and `uvlock` remain separate from local element rotations and are not yet applied by the geometry compiler. Texture and model files remain local to the user's installation.
