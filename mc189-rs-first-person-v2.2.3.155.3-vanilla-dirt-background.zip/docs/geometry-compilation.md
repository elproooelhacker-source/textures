# CPU model geometry compilation

`compile-client-geometry <client.jar>` is a read-only preparation and validation pass for the model geometry stage. It enumerates model roots referenced by vanilla blockstates, resolves model inheritance and inherited texture aliases, and compiles each effective cuboid face into four CPU vertices.

Each quad retains its resolved texture resource path, model-space UV rectangle, face UV quarter-turn, source face direction, optional `cullface`, `tintindex`, `shade`, and a geometric normal. Position coordinates are normalized from model units (0..16 convention) to one-block units. Per-element rotations are applied around their configured origins; `rescale` expands perpendicular axes by the classic inverse-cosine factor before the local rotation.

The compiler does not yet select a model for a numeric 1.8.9 block ID + metadata, apply blockstate X/Y variant rotations, implement `uvlock`, stitch texture sprites, perform neighbor-face culling or ambient occlusion, or upload a GPU mesh. Raw UV rectangles are retained instead of claiming the final per-vertex atlas UVs are ready.

Validation coverage includes canonical cube face winding/normals, default UV rectangles for representative directions, UV quarter-turn preservation (stored using a type that can represent 270 degrees), rejection of non-integer/unsupported UV rotations, local-rotation origin invariance, and missing texture detection. Runtime testing against the official client JAR is required to establish resource-wide coverage.
