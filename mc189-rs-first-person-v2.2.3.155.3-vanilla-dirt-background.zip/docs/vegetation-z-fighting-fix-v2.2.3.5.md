# Vanilla 1.8.9 foliage and flower cutout rendering

The dedicated vegetation path introduced for crossed grass and ferns now also handles flower textures, double-height flowers, saplings, and all six vanilla leaf textures.

## Why these textures use cutout rendering

These vanilla resources contain transparent texels rather than requiring general translucent blending. Sending them through the blended model pipeline can blend transparent pixels and write unstable depth for foliage surfaces. The cutout path discards texels with alpha below `0.1`, writes depth for visible texels, and uses replacement blending.

Crossed flowers, saplings, grass, and fern models expose opposite-winding faces on the same zero-thickness planes. Back-face culling selects the side facing the camera. The double sunflower's front and back textures are both retained in the model; culling chooses the correctly oriented face as the view moves around it.

Leaves remain their original full-cube models with their original UVs and biome tint. Only their texture render path changes; the model geometry and world data are not rewritten.

## Included vanilla textures

- Crossed grass and fern, including double-height grass and fern.
- All single-block flower textures and the double-height rose, peony, lilac, and sunflower textures.
- Oak, spruce, birch, jungle, acacia, and dark-oak leaves.
- Oak, spruce, birch, jungle, acacia, and dark-oak saplings.

Ordinary blocks and fluids remain on the previous render path. No player physics, chunk loading, world save, or client JAR behavior is changed.
