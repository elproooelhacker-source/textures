# Blockstate multipart resolver — phase 1

This phase adds a read-only evaluator for the Minecraft 1.8.9 `multipart` blockstate format.

## Supported

- Unconditional parts (`apply` without `when`).
- Property predicates, including comma-separated accepted values.
- Conjunctions of object properties.
- Nested `AND` and `OR` predicate arrays, with short-circuit evaluation.
- `apply` as one model object or an array of model alternatives.
- Per-application model resource ID, X/Y rotation, `uvlock`, and weight validation.
- Missing properties are errors rather than guessed values.

## Not yet supported

- Choosing a weighted alternative deterministically or randomly.
- Applying multipart model geometry to the GPU preview.
- UV-lock compensation, tinting, neighbor-derived properties, and world lighting.
- Automatic derivation of blockstate properties from legacy block ID/metadata.

The resolver deliberately reports metadata only. It does not claim that a multipart block is rendered yet.

## Diagnostic command

```powershell
cargo run -p mc189-app -- inspect-blockstate-multipart "C:\path\to\client.jar" fence "north=true,east=false,south=true,west=false"
```

Use `-` when the blockstate has only unconditional parts:

```powershell
cargo run -p mc189-app -- inspect-blockstate-multipart "C:\path\to\client.jar" iron_bars "-"
```

Properties must be supplied explicitly. If a condition references a missing property, evaluation stops with a clear error. This prevents a partial property set from silently producing an incomplete model.
