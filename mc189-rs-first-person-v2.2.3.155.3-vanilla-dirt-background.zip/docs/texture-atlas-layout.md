# Minecraft 1.8.9 block texture atlas

`plan-block-texture-atlas <texture-root> <layout.json>` inventories extracted `blocks/*.png` resources. PNG dimensions are read without assuming square or 16x16 images. Textures with a sibling `.png.mcmeta` declaring an `animation` object are excluded from the static atlas and listed separately. Static textures are deterministically packed onto 2048x2048 pages. Manifest coordinates (`x`, `y`, `width`, `height`, UVs) describe the original content rectangle; `padding` is the reserved gutter on every side.

`build-block-texture-atlas <texture-root> <layout.json> <output-directory>` validates the manifest before writing pixels. It checks format and counts, safe resource paths, positive dimensions, page bounds including gutters, exact UV-to-pixel correspondence, duplicate paths, and pairwise gutter overlap. Every referenced PNG is fully decoded and its actual dimensions must match the manifest. The output pages are RGBA8 PNGs named `block-atlas-0.png`, etc. Each source texel is copied unchanged after PNG decoding to RGBA8; the two-pixel gutter is filled by clamping source coordinates to the nearest edge texel, including corners. This preserves alpha and prevents neighboring base-level samples from bleeding into one another.

Animated textures are not flattened into static pages. Their PNG and `.mcmeta` files are copied under `animated/blocks/...`, preserving their relative resource path. The layout manifest is copied to `block-atlas-manifest.json`.

## Deliberate limitations

The offline atlas builder does not write mipmaps. At runtime, `GpuAtlasPage::upload` generates and uploads one half-resolution mip level. The two-pixel edge-extruded gutter becomes one texel at this level; deeper levels remain disabled because the gutter would collapse and neighboring sprites could bleed. This stage also does not resolve block-model texture aliases, apply model face UV rotations, or animate the copied assets at runtime. PNG decoding to RGBA8 may normalize source PNG color types/bit depth; it preserves decoded pixel values and alpha, not the original compressed PNG byte stream.

## Runtime atlas stage (v1.2)

`client_atlas_runtime` loads `block-atlas-manifest.json`, validates page dimensions and each entry's pixel/UV correspondence, and builds a path-to-region lookup. `remap_face_uv` converts model-pixel face UV rectangles (Minecraft's conventional 0..16 domain) into atlas UV coordinates while preserving the face's 0/90/180/270-degree UV rotation for the later mesh stage.

`GpuAtlasPage::upload` uploads one RGBA8 page into a wgpu `Rgba8UnormSrgb` texture, generates one half-resolution mip level with triangle filtering, and creates a sampler that keeps nearest magnification while using linear minification/mip filtering. It deliberately does not create a full mip chain: the two-pixel gutter only safely supports the first reduction. The integrated world renderer uses this GPU resource for block-model geometry.

Run `mc189-app inspect-block-texture-atlas <atlas-output-directory>` to validate the runtime manifest and decode every referenced atlas page before GPU integration.
