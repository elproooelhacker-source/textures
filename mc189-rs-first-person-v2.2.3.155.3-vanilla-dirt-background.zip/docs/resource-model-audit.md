# Client model/resource link audit

This milestone adds `audit-client-models`, a read-only pass over the vanilla client JAR.

```text
cargo run -p mc189-app -- audit-client-models "C:\\Users\\Admin\\Downloads\\client.jar"
```

It parses every `assets/minecraft/blockstates/*.json` and `assets/minecraft/models/**/*.json` entry. It checks that blockstate model references resolve to a model JSON entry, each explicit parent (except game-provided `builtin/*`) resolves to an entry, and direct non-alias texture references resolve to `.png` assets. Each JSON resource is bounded to 4 MiB; resources are read in-place from the archive and never extracted.

Texture references beginning with `#` are aliases and are deliberately deferred, because faithful resolution needs model inheritance and alias-cycle detection. Other intentionally deferred model semantics include variant selection for legacy numeric IDs/metadata, multipart evaluation, element coordinate bounds, face UVs, rotations, `uvlock`, tint indices, and ambient occlusion. This audit only verifies the first links in the resource graph and is not a Minecraft renderer.

The command prints at most 20 diagnostic examples for each class of problem, but the separate numeric counts are not truncated.
