# Crossed vegetation depth fix (Minecraft Java 1.8.9)

The vanilla `block/tallgrass` model defines two zero-thickness crossed elements. The first element exposes `north` and `south` faces on the same plane; the second exposes `west` and `east` faces on the same plane. The opposing faces use opposite winding. Because the face-corner order also differs, the two sides split the same quad along opposite diagonals.

The previous world pipeline disabled face culling and alpha-blended every model. It therefore submitted both coincident sides. A strict depth comparison alone was insufficient to make the rasterization of both triangulations deterministic.

The corrected path recognizes only the six vanilla crossed-plant texture resources and moves those quads into a dedicated pipeline:

- binary alpha test (`discard` for transparent texels; the vanilla textures were verified to contain alpha values 0 and 255 only),
- replacement blending (no alpha accumulation),
- back-face culling with the model's opposite-winding front/back faces,
- depth writes enabled with strict `Less` comparison.

This keeps the correctly authored UV mapping on each side: the camera-facing face is selected by winding, rather than deleting one side or offsetting vertices. All other geometry continues through the existing pipeline.
