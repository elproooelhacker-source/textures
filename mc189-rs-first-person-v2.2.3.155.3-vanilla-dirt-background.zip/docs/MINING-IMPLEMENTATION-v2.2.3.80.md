# Mining subsystem implementation notes (v2.2.3.80)

The new `mining.rs` module establishes the simulation contract for a faithful 1.8.9 mining path while remaining independent of rendering and the existing held-item transforms.

## Tick model
Call `MiningController::tick` once per 1/20-second world tick with the current ray hit, mouse-held state, selected tool, and player mining context. A changed target restarts damage; releasing the attack input or losing the target clears it. `MiningEvent::Broken` is the handoff point for world mutation and loot creation.

## Ray targeting
`raycast` traverses voxel cells in view direction up to the caller's reach and returns the entered face. The caller supplies the collision/selection predicate; this avoids treating every non-air block as a full cube where selection boxes differ.

## Vanilla damage
The implementation follows MCP's `Block.getPlayerRelativeBlockHardness`: hardness below zero cannot be mined; otherwise dig efficiency is divided by hardness and by 30 when harvestable or 100 when not harvestable. Player penalties and tool enchantment factors are applied to dig efficiency.

## Loot and dropped entities
`block_info` currently covers common blocks only. It intentionally returns `None` for unsupported IDs rather than inventing data. `DroppedItem` is the simulation state; world rendering and inventory insertion remain follow-up integration work.
