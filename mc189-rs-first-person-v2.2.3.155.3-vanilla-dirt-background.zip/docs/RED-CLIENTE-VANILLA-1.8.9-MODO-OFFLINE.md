# Cliente de red vanilla 1.8.9 — primera etapa no premium

## Objetivo

Conectar el ejecutable Rust directamente a un servidor dedicado oficial Minecraft Java 1.8.9 con `online-mode=false`. No se utiliza el servidor integrado Rust como intermediario.

## Fuente de verdad

La implementación se contrasta con el código desofuscado 1.8.9 incluido en la Biblioteca:

- `net/minecraft/network/EnumConnectionState.java`: IDs y orden de registro de todos los paquetes.
- `net/minecraft/network/PacketBuffer.java`: serialización de tipos primitivos, VarInt, strings y NBT.
- `net/minecraft/network/handshake/client/C00Handshake.java`: handshake.
- `net/minecraft/network/login/client/C00PacketLoginStart.java`: inicio de sesión.
- `net/minecraft/network/login/server/S02PacketLoginSuccess.java`: respuesta de login.
- `net/minecraft/network/login/server/S03PacketEnableCompression.java`: umbral de compresión.
- `net/minecraft/network/NettyCompressionDecoder.java` y `NettyCompressionEncoder.java`: framing comprimido.

## Qué se implementó en esta etapa

- Crate Rust independiente `mc189-protocol`.
- Registro de los 111 registros de paquete de `EnumConnectionState`, con IDs derivados del orden real del código fuente. Los paquetes anidados cuentan como registros distintos.
- Tipos de estado Handshaking, Status, Login y Play; direcciones cliente→servidor y servidor→cliente.
- Codificación/decodificación VarInt de hasta cinco bytes.
- Strings UTF-8 prefijadas por VarInt.
- Framing TCP Minecraft: longitud VarInt, ID VarInt y payload.
- Compresión Zlib activada por `S03PacketEnableCompression`, incluyendo paquetes debajo del umbral.
- Handshake con protocolo 47 y destino LOGIN.
- `C00PacketLoginStart` con nombre offline.
- Lectura de `S02PacketLoginSuccess`, `S00PacketDisconnect`, `S01PacketEncryptionRequest` y `S03PacketEnableCompression`.
- Diagnóstico CLI `probe-offline-server` para verificar LOGIN y leer el primer paquete PLAY recibido.

## Comando de diagnóstico

```bat
mc189-app probe-offline-server 127.0.0.1 25565 JugadorRust
```

También se incluye `PROBAR-SERVIDOR-VANILLA-OFFLINE.bat`, que solicita host, puerto y nombre. El servidor debe ser Minecraft Java 1.8.9 oficial, arrancado con `online-mode=false`. Esta opción es apropiada para una prueba local; no debe exponerse a Internet porque permite suplantar nombres de jugador.

## Alcance todavía pendiente

Esta etapa NO es todavía una sesión jugable. No se han implementado todavía los decodificadores de payload de los 100 registros PLAY, ni la traducción de chunks de red a los chunks/meshes del motor, ni el bucle bidireccional de movimiento e interacción. El siguiente trabajo es decodificar los paquetes PLAY necesarios para entrar en el mundo: `S01PacketJoinGame`, `S08PacketPlayerPosLook`, `S21PacketChunkData`, `S23PacketBlockChange`, `S06PacketUpdateHealth`, `S00PacketKeepAlive` y paquetes relacionados; después enviar las respuestas cliente necesarias (`C00PacketKeepAlive`, `C03PacketPlayer`, `C15PacketClientSettings`, `C17PacketCustomPayload`).

La autenticación premium (`S01PacketEncryptionRequest`, cifrado AES y autenticación de sesión) queda intencionalmente fuera de esta primera fase.
