# Vanilla fluid rendering — v2.2.3.15

The first-person chunk renderer now follows the relevant geometry and texture rules from the Minecraft 1.8.9 `BlockFluidRenderer` and `BlockLiquid` source.

## Geometry

Each block no longer receives a flat, isolated top. Its four top vertices call the vanilla corner-height calculation, which samples four blocks around that corner, weights source/falling levels, treats non-solid materials as air contributions, and returns full height when same-material fluid exists above a sampled block. This makes neighboring liquid surfaces share the same corner heights, including across diagonal chunk boundaries.

Top faces use the still sprite when the flow vector is zero, otherwise the flowing sprite with the vanilla angle-derived UV transform. Side faces use the flowing sprite and the vanilla half-height UV mapping. Same-family neighboring blocks do not receive internal walls. Exposed sides and bottom faces are culled against the appropriate neighboring blocks. The renderer also applies vanilla's 0.001 inset and directional side shading.

## GPU passes

Opaque blocks and lava render before cutout vegetation and translucent water. Water uses alpha blending, depth testing, and disabled depth writes. Water-bearing chunks are sorted far-to-near. This avoids the previous behavior where water vertices were interleaved with opaque block vertices and could write depth before the transparent layer was complete.

The fluid animation scheduler reads the four original vertical sprite strips and their `.mcmeta` files from the atlas output directory. It respects explicit frame lists, per-frame times, and default frame timing, and updates each sprite's atlas rectangle and extruded gutter in place.

## Read-only world behavior

The renderer displays the liquid block states already stored in the Anvil world. Falling metadata plus same-fluid blocks above create full-height waterfall columns; neighboring level metadata drives the flow direction and connected surface. No original world files are changed.

The separate vanilla `BlockDynamicLiquid.updateTick` algorithm changes world state over time (downward flow, shortest-path horizontal spreading, source regeneration, lava timing, and water/lava mixing). It is not run in this read-only rendering milestone. A future implementation can simulate those changes in a transient overlay without saving into the original world.
