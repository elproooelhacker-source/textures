# Torch flicker port — v2.2.3.38

## Reference behavior

The 1.8.9 `EntityRenderer.updateTorchFlicker()` consumes four `Math.random()` doubles per renderer update:

1. Add `(random() - random()) * random() * random()` to `torchFlickerDX`, converting the result to `float`.
2. Multiply the float accumulator by `0.9D`, converting back to `float`.
3. Approach `torchFlickerX` by `(torchFlickerDX - torchFlickerX) * 1.0F`.
4. Mark the lightmap dirty.

`JavaRandom48` implements the 48-bit LCG and `nextDouble()` bit assembly used by `java.util.Random`. The lightmap update now advances this state once per render-update event, rather than using a synthetic sine wave advanced every fifth world tick. This preserves the source client's update cadence and arithmetic. The process seed is intentionally session-local; an independent vanilla process has its own global `Math.random()` seed, so the two flicker streams are not expected to synchronize.

## Regression coverage

- Java `Random(1).nextDouble()` known sequence.
- Repeatability for equal seeds.
- Stateful non-zero torch flicker after updates.

## Scope

This change addresses the dynamic torch contribution to `EntityRenderer`'s 16x16 lightmap. It does not claim to complete the entire world-light simulation: block light propagation, sky-light propagation, weather transitions, lightning event timing, gamma/night vision, dimension-specific no-sky handling, and fluid rendering remain separate work.
