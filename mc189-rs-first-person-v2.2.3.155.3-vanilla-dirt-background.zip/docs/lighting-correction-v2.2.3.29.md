# Lighting correction v2.2.3.29

## Why the previous implementation produced false darkness

The previous implementation treated absent optional light arrays as a numeric zero, then applied non-vanilla brightness/AO floors. This conflated unknown or missing sky data with darkness and concealed some artifacts by changing the result after sampling.

## Current sampling contract

- Anvil SkyLight and BlockLight are separate 4-bit channels.
- BlockLight missing from a section is interpreted as 0.
- SkyLight missing from a section falls back to the chunk HeightMap first-air boundary when available.
- The Anvil HeightMap value is the first air Y above the highest relevant block, so `y == heightMap` is open sky.
- A missing section is treated as air; its sky fallback is determined by HeightMap.
- Vertex shade uses the classic 1.8.x directional factors and 0.2/1.0 block AO values.
- Each mesh corner now samples the face-adjacent block, both side neighbors, and the diagonal neighbor. Their light values are averaged with the corresponding AO factors before interpolation across the quad, reducing hard discontinuities between adjacent vertices.
- The scalar vertex-light path now converts the sampled level through the vanilla `WorldProvider.generateLightBrightnessTable` curve and applies the `EntityRenderer.updateLightmap` neutral floor (`value * 0.96 + 0.03`). This prevents a zero saved-light sample from becoming mathematically absolute black.

## Known limitations

The renderer still collapses the two saved channels to `max(SkyLight, BlockLight)` before shading and uses a neutral scalar approximation of the lightmap. Vanilla instead supplies packed combined light to a 16x16 RGB lightmap whose color depends on dimension, sun brightness, torch flicker, lightning and gamma. A later stage must carry both channels to the GPU and reproduce the complete `EntityRenderer.updateLightmap`; it must also honor block-specific light emission and vanilla's complete face-neighbor tables/partial-model bounds. Missing or stale light propagation is not rebuilt by this read-only renderer.


## Smooth vertex-light interpolation (v2.2.3.33)

The previous vertex path sampled only one light value behind each face corner. This release averages four corner-adjacent light samples (base, side U, side V, and diagonal), each weighted by its local AO value. The GPU then interpolates those vertex values across the face. This is intended to make adjacent light regions connect more smoothly without adding shadow maps or changing the user's disabled-shadow preference. It remains an approximation of vanilla 1.8.9 `BlockModelRenderer` and does not yet implement its full per-model AO lookup tables.
