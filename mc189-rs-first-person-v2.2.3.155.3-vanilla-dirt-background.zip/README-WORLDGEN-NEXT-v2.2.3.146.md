# Worldgen continuation — v2.2.3.146

Base: v2.2.3.145.

This revision extends the currently ported `BiomeDecorator.genDecorations` prefix:

1. `generateOres()`
2. sand patches (3)
3. clay patch (1)
4. gravel-as-sand patch (1)
5. supported forest tree attempts

New public entry point:

`populate_overworld_ores_substrate_trees_with_rng(rng, chunk_x, chunk_z, biome_id, region)`

The caller must pass the same population `JavaRandom` stream used by the earlier steps and a writable 3x3 neighborhood. The biome ID should be the biome selected by the population caller for the target chunk, not an arbitrary block-level biome sample.

Supported tree biomes:
- Forest / Forest Hills (4 / 18): 10 attempts plus the vanilla 1-in-10 extra attempt; oak generator selected on 4/5 of attempts, birch on 1/5.
- Birch Forest / Birch Forest Hills (27 / 28): 10 attempts plus the vanilla 1-in-10 extra attempt; birch generator.

The source-derived tree methods are intentionally separate. Unsupported biome IDs return zero tree attempts without consuming the tree-stage RNG, rather than pretending to implement their distinct generators.

Next source targets:
- `WorldGenBigTree` and `WorldGenCanopyTree` for forest variants.
- `WorldGenTaiga1`, `WorldGenTaiga2`, `WorldGenMegaPineTree`.
- `WorldGenSwamp`, `WorldGenSavannaTree`, jungle tree generators.
- Remaining BiomeDecorator features in exact order, then ChunkProviderGenerate structures/lakes/dungeons and biome-specific decoration.
