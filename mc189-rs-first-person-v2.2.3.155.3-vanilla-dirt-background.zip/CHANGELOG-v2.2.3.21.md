# v2.2.3.21 — liquid shore contact and original crosshair

## Liquid contact
- Removed the artificial 0.4-block downward expansion from the player's water and lava contact volumes. Swimming/liquid movement no longer activates while the feet are still above a liquid surface at the shoreline.
- Water and lava contact now checks the metadata-derived liquid surface against the actual player body AABB.
- Lava movement no longer treats any lava block within the body's integer Y range as contact without checking the liquid surface.
- Preserves the v2.2.3.20 1.8.9 movement impulses, water-current acceleration, liquid drag, gravity and held-jump behavior.

## Original Minecraft 1.8.9 crosshair
- Replaced the provisional crosshair geometry with the exact 17 opaque pixels from `assets/minecraft/textures/gui/icons.png`, source rectangle `(0, 0, 16, 16)`.
- Positions it using the vanilla `GuiIngame` coordinates: `(scaledWidth / 2 - 7, scaledHeight / 2 - 7)` and reproduces the original destination-inverting blend so it remains visible on light and dark backgrounds.
- Keeps the reticle visible only while mouse capture is active.

## Regression tests
- Added tests for water contact above and at the liquid surface, and for lava movement requiring actual surface intersection.
- Replaced the previous crosshair geometry test with a check for the vanilla 1.8.9 16×16 sprite mask.

## Scope
- The Anvil world remains read-only. No fluid simulation, damage, fire, oxygen or survival HUD was added.
- Smooth Lighting is intentionally the next milestone and has not been changed in this build.
