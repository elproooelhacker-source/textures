# v2.2.3.78 — separación de transformaciones de BLOCK e ITEM

- Se mantiene intacta la función de transformación de los ITEM generados (picos, espadas, herramientas y sprites).
- Se añade una ruta independiente para los modelos de tipo BLOCK que se resuelven como geometría de cubo/modelo 3D.
- La clasificación se realiza según si el modelo pudo resolverse y compilarse como quads del atlas; los modelos generados siguen la ruta ITEM.
- Referencia MCP 1.8.9: `ItemRenderer.renderItem` aplica `scale(2)` a modelos `shouldRenderItemIn3D`; `RenderItem.preTransform` aplica `scale(2)` a modelos no 3D; ambas rutas llegan al `scale(0.5)` de `RenderItem.renderItem`. Para bloques cuyo JSON no define `display.firstperson`, `ItemCameraTransforms` usa la transformación por defecto (rotación/traslación cero, escala uno).
- Importante: `ItemRenderer.doBlockTransformations()` es la pose de la acción de uso `EnumAction.BLOCK` (bloquear/defender), no una transformación general para sostener cualquier bloque; no se aplica indiscriminadamente a piedra/tierra/etc.
- Se añadió una prueba que verifica la separación y que las transformaciones por defecto mantienen la escala/pose vanilla. No se cambiaron los valores X/Y/Z de los ITEM.
- Compilación y pruebas completas no ejecutadas en este entorno porque Rust/Cargo no están instalados. Probar en Windows con `cargo test --workspace` y comparar bloques (piedra, tierra, adoquín) contra herramientas (pico/espada).
