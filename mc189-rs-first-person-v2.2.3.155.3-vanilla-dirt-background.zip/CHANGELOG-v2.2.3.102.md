# v2.2.3.102 — Fix title-screen redraw RefCell panic

## Confirmed failure from Windows play-test

The v2.2.3.101 user log showed a successful optimized build, successful texture extraction/atlas generation, and native title-screen initialization. The process then panicked at `crates/mc189-app/src/main_menu.rs` in the `WindowEvent::RedrawRequested` handler with `RefCell already mutably borrowed`.

## Root cause

The handler used `gpu_events.borrow_mut()...render()` directly as the `match` scrutinee. The temporary mutable `RefCell` borrow could remain alive through the match arms. On `SurfaceError::Lost` or `SurfaceError::Outdated`, the recovery arm then attempted an immutable borrow to read `window_size`, followed by another mutable borrow to call `resize`, causing a runtime borrow panic.

## Fix

- Execute `MenuGpu::render()` inside a dedicated lexical scope holding the mutable borrow.
- Store the returned `Result` in `render_result`; the `RefMut` is dropped at the end of the scope.
- Match the result only after the borrow has ended.
- Recover from `Lost`/`Outdated` by reading the current size, reacquiring a separate mutable borrow for `resize`, and requesting another redraw.
- Keep `Timeout` non-fatal and exit on `OutOfMemory`.

## Verification

- Static inspection confirms the mutable borrow ends before matching the surface result.
- The ZIP archive is integrity-tested after packaging.
- Cargo/rustc and a Windows GPU runtime are unavailable in this authoring environment. The v2.2.3.102 build and title-screen runtime therefore require confirmation from the Windows play-test.
