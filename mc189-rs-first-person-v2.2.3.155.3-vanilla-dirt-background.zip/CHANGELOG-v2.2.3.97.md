# v2.2.3.97 — Windows play-test compile fix

- Fixed Rust error E0282 in `drop_registry.rs` by explicitly typing the collected drop list as `Vec<ItemDrop>`.
- Fixed an unreachable duplicate match arm for block ID 98 in `mining.rs`; stone-brick metadata now reaches the dedicated arm and is preserved in the block drop descriptor.
- Added a regression test for stone-brick metadata.
- Kept the v2.2.3.96 Windows launcher path-capture fix and backup workflow unchanged.

The authoring container does not include `cargo`/`rustc`, so this package has not been compiled here. The user's Windows run must verify whether any subsequent compiler diagnostics remain.
