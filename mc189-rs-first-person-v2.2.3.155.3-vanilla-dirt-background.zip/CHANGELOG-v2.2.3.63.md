# v2.2.3.63 — fusión de v2.2.3.42 (iluminación) y v2.2.3.62 (menú + worldgen)

Base: v2.2.3.62 (main_menu, worldgen, ventana reutilizable, cutouts de telaraña/rieles, spawner sólido).

Portado desde v2.2.3.42:
- `textured_chunk.rs`: iluminación completa de la .42
  - luz de cielo derivada de los bloques cuando el chunk no trae HeightMap (`derived_first_air`) — importante para chunks generados por worldgen
  - lightmap con doble `*0.96+0.03` (gamma=0 de vanilla)
  - AO por vértice con correspondencia de esquinas por geometría
  - `calculate_flat_vertex_lighting` según `renderModelFlatQuads` (bit 0 de fillQuadBounds) y `shade` del elemento
  - luz de líquidos = max(propio, bloque superior) por canal
  - tablas de opacidad/emisión corregidas (telaraña, ids 65/90/119/120/140)
- `gpu_block_preview.rs`: gamma en el clear color y en `illumination` (pow 2.2) + test del lightmap ajustado

Conservado de v2.2.3.62 dentro de `textured_chunk.rs`: `play_world_in_window` / `play_world_impl`.
