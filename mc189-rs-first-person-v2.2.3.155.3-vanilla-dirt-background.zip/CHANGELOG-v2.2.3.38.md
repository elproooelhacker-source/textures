# v2.2.3.38 — Java-compatible torch flicker

Continues the 1.8.9 lightmap port.

## Included

- Replaces the synthetic sine-wave torch flicker with the Java 48-bit `java.util.Random` algorithm used by `Math.random()`.
- Ports the `EntityRenderer.updateTorchFlicker()` state accumulator and its double/float conversion points.
- Advances flicker at render-update cadence, independently of the 20 Hz world simulation tick.
- Adds tests for the known `Random(1)` sequence and deterministic seeded flicker.
- Removes duplicated sun-brightness implementation and duplicate regression test present in the input archive.

## Verification

Rust/Cargo are not installed in the build environment. Run `cargo fmt --all` and `cargo test --workspace` on Windows before using this increment as verified.
