# v1.9.2 — Vanilla blockstate rotation correction and 5×5 diagnostics

## Furnace/front-face investigation

- Verified the supplied Minecraft 1.8.9 JAR directly: both `furnace.json` and `lit_furnace.json` use the `block/orientable` model family. The inherited model assigns `#front` to the north face; `furnace` binds it to `furnace_front_off`, while `lit_furnace` binds it to `furnace_front_on`.
- Verified the vanilla blockstate rotations: north=0°, south=180°, west=270°, east=90°.
- Found a coordinate-convention mismatch: the renderer passed positive JSON Y angles directly to a right-handed `glam` quaternion. In the renderer's Minecraft world axes (east=+X, south=+Z), that reversed the intended east/west quarter-turn. The model front could therefore be placed on the opposite side from the metadata-facing direction.
- Corrected the sign of blockstate Y rotation in both vertex transformation and cull-face neighbor-offset transformation. This affects all rotated blockstate models, not only furnaces.
- Added regression tests proving that vanilla Y=90 sends a north-facing model face toward east, Y=270 sends it west, and furnace-front geometry follows the same transform.
- Added region-preview diagnostics that count successfully rendered furnaces by lit/unlit ID and saved metadata facing.

## 5×5 region test

- The existing region preview already supports radius 2, which requests up to 25 chunks (5×5). No separate renderer path is needed; the existing command can exercise it directly.
- Missing chunks remain skipped and reported in the `Loaded chunks: n / 25` line. Region meshes are still combined into one GPU mesh.

## Validation boundary

- Verified the furnace blockstate/model resources and rotation values against the supplied `client.jar`.
- Verified source assertions, balanced delimiters, and ZIP integrity in the build environment.
- Rust/Cargo are not installed in the build environment, so `cargo fmt` and `cargo test` must be run on Windows before treating this release as compiled and tested. The new regression tests are included for that run.
