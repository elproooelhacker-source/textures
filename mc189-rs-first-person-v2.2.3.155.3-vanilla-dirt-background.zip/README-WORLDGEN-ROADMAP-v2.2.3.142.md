# World generation roadmap — v2.2.3.142

Current implemented pipeline:

1. Java `Random` and GenLayer random primitives.
2. Biome map / terrain density and 4×8×4 interpolation.
3. Basic biome surface replacement.
4. Cave and ravine carving.
5. A separate ore population pass with the MCP `WorldGenMinable` ellipsoid algorithm and default `BiomeDecorator` deposits.
6. Legacy ID/metadata mapping for generated deposits.

Still required before enabling Create World:

- Structure-generation prelude and exact shared population RNG continuity.
- Mesa, ice, and other specialized biome surface algorithms.
- Full `BiomeDecorator` feature order and per-biome counts.
- Tree, flower, grass, mushroom, reed, cactus, lake, dungeon, and related feature generators.
- Village, mineshaft, stronghold, temple, and monument generation plus structure data.
- Snow/ice placement, heightmaps, skylight/block light propagation, and spawn selection.
- Chunk serialization and initial `level.dat`/player/world metadata creation, followed by reopen-and-continue tests.

The menu's Create World controls remain configurable, but world creation must stay disabled until these stages are integrated and validated end to end.
