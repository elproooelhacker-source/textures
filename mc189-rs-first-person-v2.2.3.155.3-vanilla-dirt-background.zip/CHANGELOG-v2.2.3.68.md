# v2.2.3.68 — Fix de compilación en resolución de modelos del inventario

Basado en v2.2.3.67-inventory-give.

## Cambios

- Corrige el error `E0499` al resolver el mapa de texturas heredadas de modelos dentro de `client.jar`.
- El contenido de cada archivo JSON se lee dentro de un ámbito local, de modo que el `ZipFile` se destruye y libera el préstamo mutable de `ZipArchive` antes de cargar recursivamente el modelo padre.
- Aplicado tanto a `resolve_model_texture` como a `resolve_model_texture_map` para evitar el mismo conflicto en ambos recorridos.
- No se modifican las ecuaciones de iluminación, la animación de la mano ni las reglas del inventario; este cambio es exclusivamente para resolver el préstamo de recursos.

## Validación

- ZIP verificado con `unzip -t`.
- El error reportado apunta al préstamo mutable de `ZipArchive` y se corrige cerrando explícitamente el ámbito de `ZipFile` antes de la llamada recursiva.
- No es posible ejecutar Cargo en el entorno de empaquetado; ejecutar `cargo fmt --all` y `cargo test --workspace` en Windows.
