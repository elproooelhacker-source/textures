# v2.2.1 — Spawn placement and mouse-look correction

## Fixed
- The saved `SpawnY` is no longer blindly treated as a safe feet height. Before opening the session, the player now searches the saved X/Z column for a standable position with a solid floor and two clear blocks of headroom. It searches upward first (for buried spawn coordinates), then downward (if the saved height is above the terrain). If no safe position exists in that column, startup stops with a clear error instead of placing the player inside terrain.
- Reversed the horizontal mouse delta sign in first-person look to correct the left/right inversion reported during the v2.2.0 test.

## Preserved
- Existing world files remain read-only.
- Current playable area remains the initial 3x3 loaded chunks; no dynamic streaming yet.
