# v2.2.3.55 — Vanilla terrain noise primitives

Continues directly from v2.2.3.54. The world-generation work now includes the reusable noise primitives used by the 1.8.9 overworld terrain pipeline:

- Ports the 3D and 2D paths of `NoiseGeneratorImproved`, including the vanilla permutation shuffle, coordinate offsets, fade curve, gradient selection, interpolation order, and accumulation scaling.
- Ports `NoiseGeneratorOctaves`, including octave frequency halving, coordinate flooring, 24-bit coordinate wrapping, and the x/z convenience sampling path.
- Adds `TerrainNoiseSet` with the vanilla constructor RNG-consumption order for the lower-limit, upper-limit, main, surface-Perlin, noiseGen5, depth, and mob-spawner fields.
- Keeps the four surface Simplex octaves private; their RNG footprint is reserved correctly, but Simplex output itself is not yet implemented. They are not falsely exposed as Perlin output.

## Not yet complete

This version does not yet create terrain blocks or chunks. The next stage is the 1.8.9 Simplex surface-noise port and the `ChunkProviderGenerate` 5×33×5 density field, biome-height blending, and 4×8×4 density interpolation. Biome layer parity, caves, ravines, structures, decoration, Anvil writing, and world creation integration remain later work.

No Cargo build or test run was performed in this environment.
