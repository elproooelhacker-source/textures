# v2.2.3.138 — menú vanilla ampliado (singleplayer y multiplayer)

## Cambios incluidos

- Pantalla Mojang de arranque con fondo blanco y textura original centrada.
- Menú principal: botones vanilla con filas de textura correctas (normal, hover y disabled), recorte izquierdo/derecho del atlas `widgets.png`, colores de texto, splash amarillo pulsante y movimiento del panorama ajustado a ticks 20/s.
- Panorama: orientación de cámara con las rotaciones de la pantalla original y kernel horizontal combinado de 15 muestras equivalente a siete pasadas de blur de tres taps.
- Selector de mundos con lista, iconos `icon.png`, selección y botones inferiores en las posiciones de `GuiSelectWorld`.
- Pantalla Crear mundo con controles visuales principales de `GuiCreateWorld`.
- Pantalla Multijugador con lista de servidores, selección, conectar, conexión directa, añadir, editar, eliminar con confirmación, actualizar lista y cancelar.
- Se conserva la sesión PLAY persistente y el handshake offline existente.

## Limitaciones conocidas (no afirmar paridad total)

- La generación de mundos no está habilitada en esta versión: el botón final de Crear mundo queda deshabilitado. Renombrar, borrar y recrear mundos en el selector también siguen deshabilitados; la selección y entrada a mundos existentes sí se mantienen.
- El listado de servidores es persistente en el archivo JSON propio. No se ha portado el `OldServerPinger`, el descubrimiento LAN ni el indicador de latencia/MOTD de `GuiMultiplayer`.
- Las pantallas de añadir servidor y conexión directa usan controles nativos simplificados; todavía no replican todos los detalles de `GuiTextField`/`GuiScreenAddServer` pixel por pixel.
- El render del panorama usa cubemap y muestreo shader. Aunque se ajustaron las rotaciones, velocidad y kernel de blur, todavía no se ha portado el framebuffer vanilla de 256x256 con sus 64 vistas 8x8 y el pipeline completo de seis caras. Por ello no se garantiza identidad píxel a píxel.
- No se implementa aún una pantalla de carga de servidor con transición al mundo remoto: el cliente todavía no procesa el conjunto completo de paquetes PLAY, chunks y entidades necesarios para entrar en un servidor real.
- Opciones, idioma y Realms continúan siendo pantallas/acciones provisionales.

## Verificación

- ZIP validado estructuralmente con `unzip -t`.
- No se ejecutaron `cargo test` ni `cargo check`: este entorno no tiene `cargo`, `rustc` ni `rustfmt`. La compilación debe verificarse en el equipo con Rust.
