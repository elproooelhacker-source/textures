# v2.0.0 — Player controller foundation

This milestone begins gameplay architecture while preserving the read-only world pipeline.

- Added a deterministic player state with classic 1.8 dimensions (0.6 × 1.8 blocks), eye height, yaw/pitch and velocity.
- Added fixed-step movement, normalized diagonal input, sprint multiplier, gravity, terminal velocity, jump gating and axis-separated swept block collision.
- Added a read-only spawn loader from `level.dat` with validation of the complete spawn tuple and classic build height.
- Added `inspect-player-spawn <world-folder>` to validate the actual world spawn before connecting the controller to the live renderer.
- Added unit tests for player dimensions, eye height, gravity/grounding, jumping, wall collision, diagonal normalization and yaw-relative movement.

This is deliberately the controller foundation, not yet the playable FPS window: keyboard/mouse capture, live world collision sampling, first-person camera integration, and streaming are subsequent integration steps. The existing preview commands and world data remain unchanged/read-only.
