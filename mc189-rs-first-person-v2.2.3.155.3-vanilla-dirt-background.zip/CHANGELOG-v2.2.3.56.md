# v2.2.3.56 — Simplex/Perlin de superficie

- Reemplaza el placeholder de cuatro octavas de superficie por `SimplexNoise` 2D y `PerlinNoise` multi-octava.
- Implementa sesgo simplex 2D, selección de triángulo, gradientes, atenuación y tabla de permutación.
- Implementa el acumulador Perlin vanilla: frecuencia `persistence * 0.5` y amplitud `0.55 / octaveScale`.
- Conserva las tres llamadas `nextDouble` y 256 llamadas `nextInt` por octava, manteniendo el flujo Java Random de los generadores posteriores.

## Alcance

Completa el generador Simplex/Perlin de variación superficial. Todavía no calcula el campo de densidad 5×33×5 ni construye chunks; ese será el siguiente bloque.

## Validación

ZIP verificado estructuralmente. No se ejecutó Cargo en este entorno.
