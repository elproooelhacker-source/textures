# v2.0.2 — Player physics collision corrections

- Fixed grounded-state detection to use the vertical collision result rather than exact floating-point position equality. This correctly recognizes floor contact after the swept collision refinement.
- Kept jump input semantics: a held jump input can initiate another jump after landing. The jump-return test now models a single key press followed by release, rather than holding jump for the entire landing interval.
- Corrected the horizontal wall test start position so the tested 0.05-second movement actually reaches the wall; the prior test began too far away to collide in one tick.
- No world format or existing renderer behavior changed.
