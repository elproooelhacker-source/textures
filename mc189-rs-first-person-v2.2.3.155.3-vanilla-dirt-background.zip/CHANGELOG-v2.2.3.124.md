# v2.2.3.124 — server-owned block EntityItem lifecycle

## Changes

- Added `mc189-server::entity_item` with authoritative entity IDs, item payload/metadata/NBT, spawn, fixed-tick simulation and snapshots.
- Block-generated drops now spawn on the integrated server immediately after the server commits the mined block to air. Drop resolution and the three spawn-position `World.rand` values use the server's shared Java RNG stream.
- The integrated server advances block-drop entities at 20 TPS: gravity, pickup-delay countdown, swept Y/X/Z block collision, embedded push-out, ground bounce/friction, water flow acceleration, lava bounce, nearby stack merge and age-6000 despawn.
- Nearby merging now follows the MCP whole-stack rule: no partial merges; compatible stacks must fit fully in the destination. Item stack caps are resolved through the shared 1.8.9 numeric item registry.
- `IntegratedSnapshot` now carries full entity snapshots. The app keeps `(entity_id, render_copy)` pairs and renders/interpolates them; it no longer creates or simulates block-generated drops.
- Added provisional entity state and entity-ID commit/rollback commands for the asynchronous in-memory block-edit transaction. Provisional drops cannot merge before the block edit is accepted, so a rollback cannot leave a merged duplicate behind.
- Moved the legacy numeric item registry helpers from the app into `mc189-server::inventory`, so server entity stack caps and client item-name conversion share one mapping.
- Corrected the vanilla `written_book` max stack size to 1 (MCP `ItemEditableBook` / `ItemWritableBook` constructors).

## Tests added

- Twelve server EntityItem tests for spawn RNG consumption, gravity/delay, collision/bounce, push-out, water/lava behavior, merge rules, despawn and pickup-range predicate.
- Numeric item stack-cap test covering tools, written books, signs, snowballs, redstone and ordinary blocks.
- Existing app tests for the shared numeric registry continue to exercise item-name/ID round-tripping.

## Scope boundary

This is step 1 only. Server-side inventory pickup transfer is step 2; Q/Ctrl+Q, `/give` and `/clear` remain in their planned later migration. Consequently, this increment does not yet complete collection of server-owned block drops into the authoritative inventory. Chunk lighting/mesh ownership and the dedicated TCP gameplay transport also remain transitional. No block placement or protocol 47 implementation is included.

## Validation

Source-level checks and archive integrity checks only. This environment has no Cargo or Rust compiler, so no Rust tests or release build are claimed. Run on Windows:

```cmd
cargo test --workspace
cargo build --release --package mc189-app
```

Then test mined drops settling on full blocks/slabs/stairs/fences, ice/slime friction, water current, lava contact, merging at 25-tick/search boundaries, and despawn after five minutes. Verify that client frame rate does not alter entity motion.
