# v2.2.3.127 — durability foundation (Step 4)

## Implemented
- Added the 1.8.9 max-durability registry for common tools, weapons, shears, bows, fishing rods, flint-and-steel, and armor pieces.
- The integrated server now applies one durability point to the selected pickaxe, axe, shovel, or shears after a successfully committed, non-zero-hardness block break, following `ItemStack.onBlockDestroyed` / `ItemStack.damageItem`.
- Stack removal follows MCP 1.8.9's `itemDamage > maxDamage` break condition. At `damage == maxDamage`, the bar is empty; the next durability point breaks the item.
- The client inventory renderer draws the vanilla 13x2 durability bar for hotbar, inventory, armor slots, and carried cursor stack. Width and green-to-red color use the 1.8.9 RenderItem formula.
- Added the `random.break` event and client playback when the authoritative server reports that the selected tool broke.
- Added unit tests for known durability values, non-damageable items, and max+1 break behavior.

## Scope and limitations
- Durability loss from mining is wired end-to-end. Sword durability from hitting entities and armor durability from receiving damage are not yet connected because entity combat/damage processing is not implemented in this milestone. Existing saved durability values for armor/weapons are rendered and preserved.
- Unbreaking enchantment probability and creative-mode durability immunity are not yet implemented. The next durability pass must wire those through the authoritative RNG/player state before claiming full 1.8.9 equivalence.
- Build and runtime tests were not executed in the authoring environment because `cargo`/`rustc` are unavailable.
