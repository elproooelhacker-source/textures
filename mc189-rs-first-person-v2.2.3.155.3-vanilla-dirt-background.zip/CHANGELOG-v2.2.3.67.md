# v2.2.3.67 — Inventory + `/give` prototype

This version builds on the tested v2.2.3.66 hand-swing base and adds the first usable, session-local player inventory.

## Implemented

- 36 main inventory slots: hotbar 0–8 plus main inventory 9–35, with vanilla 1.8.9 inventory and widgets textures loaded from the user's `client.jar`.
- `E` opens/closes the inventory; mouse movement updates the cursor highlight.
- `1`–`9` and mouse wheel select the hotbar slot. The HUD draws the hotbar and its selected slot.
- Left-click picks up, places, merges or swaps stacks. Right-click takes half, places one, or adds one to a compatible stack. Shift-click transfers between hotbar and main inventory.
- Four armor slots are interactive; compatible armor pieces can be placed and shift-clicked to equip/unequip.
- `T` opens chat and `/` opens chat with the slash prefilled.
- `/give <player> <item> [count] [damage]`, including `@p`, registry names, common aliases, selected legacy numeric IDs and 1.8 metadata such as colored wool. Local-only single-player player targeting is used because multiplayer does not exist yet. Also accepts `/give <item> [count] [damage]` as a convenience.
- `/clear` clears inventory, armor slots and cursor stack. `/help` lists commands.
- Sprite texture lookup resolves the item model's inherited texture from the 1.8.9 JAR. Common icon assets were statically checked against `client.jar`.
- Corrected stack-size rules for 1.8.9 buckets, maps, written books, doors, spawn eggs and common stackable items.

## Validation

- The new package was checked for ZIP integrity and common item/model texture paths were checked in the original 1.8.9 `client.jar`.
- Rust compilation/tests were not run in the authoring environment because the Rust toolchain is not installed. Run `cargo fmt --all` and `cargo test --workspace` on Windows before use.

## Current limitations

- Inventory changes are in-memory for this session; they are not written to the world's player NBT yet.
- The 2×2 crafting panel is visual only: no recipe matching or crafting result.
- If `/give` exceeds free inventory capacity, the uninserted remainder is reported instead of spawning dropped-item entities.
- No dropped-item pickup, death inventory, durability, enchantment/NBT stack data, multiplayer target resolution or complete held-item 3D renderer yet.
- Player preview is a textured 2D composition rather than vanilla's full 3D entity preview.
- Vanilla details not implemented here must not be interpreted as completed gameplay systems.
