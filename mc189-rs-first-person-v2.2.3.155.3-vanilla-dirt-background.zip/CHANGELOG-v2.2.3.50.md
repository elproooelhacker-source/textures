# v2.2.3.50

- Reduced the Minecraft logo rightward optical offset from 38 to 19 menu-canvas pixels (approximately 0.5 cm at 96 DPI for the 854 px title-screen canvas). Button positions remain unchanged.
- Preserves the v2.2.3.49 gameplay/window handoff and all other project changes.

Validation: ZIP integrity checked; Windows Rust formatting, tests, and runtime validation have not been run in this environment.
