# v1.4 — weighted blockstate variant selection

- Reused the v1.3 blockstate parser; no texture-atlas or model-inheritance code was replaced.
- Added weighted alternative selection using the 48-bit `java.util.Random` algorithm (`nextInt(totalWeight)`).
- Added an optional signed 64-bit seed to `preview-blockstate-variant`; omitted seed defaults to `0`.
- Preview output now reports the selected alternative, its weight, total alternatives, and seed.
- Added tests for Java RNG selection, weight ranges, empty inputs, and total-weight overflow.
- Kept `uvlock=true` as a hard error to avoid rendering incorrect UV orientation.
- Multipart parsing remains isolated; vanilla 1.8.9 JAR audit found 340 variant blockstates and zero multipart blockstates.

Validation limitation: this environment has no Rust toolchain (`cargo`/`rustfmt` unavailable). The archive is structurally checked, but `cargo fmt --all` and `cargo test --workspace` must be run on Windows before this milestone is considered validated.
