# v2.2.3.125 — server-authoritative EntityItem pickup

## Changes

- The integrated server now performs `EntityItem.onCollideWithPlayer` eligibility checks against its authoritative player AABB and server-owned entity state.
- Successful pickup transfers are inserted into the server-owned `PlayerInventory`; client proximity no longer awards server-owned block drops.
- Partial inventory capacity transfers only the accepted amount and leaves the remainder on the world entity. A full inventory leaves both inventory and entity unchanged.
- Provisional block drops remain ineligible until the corresponding block-edit transaction is committed. Pickup delay and unsupported numeric item IDs are respected.
- `IntegratedSnapshot` carries confirmed pickup events alongside revisioned inventory and entity snapshots. The server retains events until a snapshot is accepted by the bounded snapshot queue.
- Client pickup animation and `random.pop` audio are now triggered only by confirmed server transfer events. Pickup-confirmed inventory updates use the receive-item animation; ordinary container rearrangements still suppress it.

## Tests added

- Server pickup transfers a stack into the authoritative inventory and removes the fully collected entity.
- Partial insertion leaves the exact remaining entity count.
- Full inventory awards nothing and leaves the entity intact.
- Pickup delay and provisional state prevent collection.

## Remaining scope

- Q/Ctrl+Q world drops and `/give`/`/clear` remain transitional client-side paths for step 3.
- Cursor-stack close handling, durability, complete vanilla Container click semantics, world/chunk ownership and persistence source authority remain to be migrated/audited.
- No block placement or Minecraft protocol 47 work is included.

## Validation

- Source-level checks and ZIP integrity checks only. This environment has no Cargo/Rust compiler; no compiled test or release-build success is claimed.
- On Windows CMD, run `cargo test --workspace` and `cargo build --release --package mc189-app`.
