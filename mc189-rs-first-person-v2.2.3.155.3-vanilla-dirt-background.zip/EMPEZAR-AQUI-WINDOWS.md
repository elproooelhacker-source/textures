# Empezar aquí — prueba de Minecraft 1.8.9 Rust (v2.2.3.122)

Esta entrega está preparada para que puedas compilar y abrir el cliente nativo desde Windows CMD sin editar el código fuente.

## Antes de abrirlo

1. **Cierra Minecraft Java y UltimMC.** El cliente Rust escribe los bloques minados directamente en los archivos Anvil del mundo. No abras el mismo mundo simultáneamente en ambos clientes.
2. Descomprime el ZIP completo en una carpeta normal, por ejemplo `C:\MinecraftRustTest`. No ejecutes el BAT desde dentro del ZIP.
3. Instala Rust estable desde [https://rustup.rs](https://rustup.rs). Mantén la toolchain MSVC predeterminada. En Windows, si Cargo informa que falta `link.exe`, instala Visual Studio Build Tools con la carga de trabajo **Desarrollo para el escritorio con C++** y Windows SDK.
4. Necesitas conexión a Internet durante la primera compilación para descargar dependencias de Cargo.

## Iniciar el juego

1. Haz doble clic en `INICIAR-PRUEBA-MINECRAFT-RUST.bat`.
2. Este paquete ya viene con la ruta de tu instancia UltimMC preseleccionada. Pulsa **ENTER** en `Carpeta de juego` para usar `C:\Users\Admin\Downloads\UltimMC-Launcher-All-Versions (1)\UltimMC-Launcher-Win32\UltimMC\instances\1.8.9\.minecraft`. También puedes introducir otra ruta si cambiaste de instancia.
3. El lanzador ya reconoce `C:\Users\Admin\Documents\client.jar` como JAR predeterminado. Si se muestra la pregunta del JAR, puedes pulsar ENTER para mantener esa ruta o pegar otra con o sin comillas.
4. Acepta la copia de seguridad recomendada. Se crea una carpeta `saves-backup-mc189-AAAAmmdd-HHMMSS` junto a `saves`; no se modifica ni reemplaza la copia original.
5. El BAT compila `mc189-app` en modo release y abre el menú nativo. Entra en **Singleplayer** y selecciona **New World** (o el mundo que quieras probar).

El atlas se genera/actualiza automáticamente en `runtime\block-atlas` usando el JAR que indiques.

## Controles de la prueba

- WASD: moverse.
- Espacio: saltar.
- Shift: correr.
- Primer clic izquierdo: capturar el mouse. Después, mantén pulsado el clic izquierdo para minar.
- Mueve la mira a otro bloque o suelta el botón para cancelar el progreso y las grietas.
- Rueda del mouse o teclas 1–9: seleccionar ranura de la barra rápida.
- E: abrir/cerrar inventario.
- Q: soltar un objeto de la ranura seleccionada.
- Ctrl+Q: soltar todo el stack de la ranura seleccionada.
- Dentro del inventario, Q/Ctrl+Q sueltan un objeto o el stack completo del slot bajo el cursor (el cursor debe estar vacío).
- Esc: liberar el mouse; Esc otra vez cierra la sesión.

Para comprobar la rotura y los drops sin depender de herramientas, prueba primero con tierra, césped o grava. La piedra requiere un pico para soltar adoquín como en Minecraft. El inventario del jugador se carga y guarda en `level.dat`, incluyendo la hotbar, las ranuras principales, armadura y selección.

## Qué está incluido para probar

- Minado con clic izquierdo y cálculo del progreso a 20 ticks/segundo.
- Texturas vanilla `destroy_stage_0..9` para la animación de grietas (el overlay sigue siendo cúbico, no usa aún la geometría de cada bloque parcial).
- Rotura y escritura del bloque en el chunk Anvil, con reconstrucción de la malla del chunk afectado.
- Generación de drops de las reglas implementadas, representación de objetos de bloque y sprites de ítems, movimiento, recogida y unión básica de stacks.
- La hotbar se actualiza al recoger objetos sin abrir el inventario. El icono hace el pop de cinco ticks al aparecer o cambiar su cantidad; los movimientos manuales entre ranuras no disparan esa animación.
- El efecto de recogida y el audio de minado usan recursos vanilla. Los OGG de 1.8.9 normalmente no están dentro de `client.jar`: el launcher los conserva en `assets/objects` y sus hashes se resuelven mediante `assets/indexes/*.json`. El BAT busca el almacén compartido de UltimMC y muestra la ruta detectada. Al iniciar el mundo, la consola informa cuántas variantes OGG se decodificaron y qué eventos quedaron disponibles.
- Q/Ctrl+Q crean entidades de objeto físicas en el mundo para un objeto o todo el stack, respectivamente.

## Limitaciones conocidas de esta prueba

- No es todavía una recreación completa de Minecraft 1.8.9.
- Las entidades de objetos dejadas en el mundo aún no tienen persistencia completa entre sesiones; el inventario del jugador sí se escribe en `level.dat`.
- La física de los objetos y la iluminación siguen siendo aproximaciones. Después de romper bloques se recalcula HeightMap y la luz en el halo cargado, pero todavía no equivale al sistema global `World.checkLightFor` de Minecraft 1.8.9.
- El overlay de grietas utiliza seis caras cúbicas, no el baked model real de cada bloque.
- No hay generador de mundos; se deben abrir mundos Java existentes.
- El cliente puede no arrancar en equipos cuyo GPU/controlador no exponga una superficie compatible con wgpu.

## Diagnósticos

- `EJECUTAR-PRUEBAS-RUST.bat`: compila y ejecuta las pruebas unitarias del workspace sin abrir el juego.
- Si falla Cargo, conserva la salida de la consola completa. Si el juego falla al iniciar, conserva también el mensaje que imprime antes de cerrarse.

**Verificación del paquete:** el ZIP se somete a prueba de integridad y revisión estática de sus archivos. En el entorno de preparación no hay Cargo/rustc ni una GPU Windows, por lo que no se afirma que esta versión haya sido compilada o probada dentro del juego. El lanzador realiza la compilación real en tu PC y detiene el arranque si hay errores.


## Corrección del lanzador v2.2.3.100

Se corrigió la captura de la ruta manual del JAR. La lectura `SET /P` ahora se realiza fuera de bloques parentizados, evitando que la expansión anticipada de variables de CMD sustituya la ruta introducida por una cadena vacía.


## Corrección de compilación v2.2.3.100

Se corrigió el error `E0282` reportado por Cargo en `drop_registry.rs`, declarando explícitamente el vector final como `Vec<ItemDrop>`. También se eliminó una rama duplicada e inalcanzable para el bloque de ladrillos de piedra (ID 98), que ahora conserva correctamente sus metadatos al minarse.


## Ajustes de prueba v2.2.3.100

Esta versión responde a los problemas de la sesión Windows anterior:

- La animación de brazo se avanza antes de procesar el clic sostenido, siguiendo el orden de ticks MCP para `updateArmSwingProgress()` y `sendClickBlockToController()`.
- La copia del halo 5x5 y la lectura de chunks vecinos se ejecutan en el trabajador de edición, no en el hilo de la ventana. La compilación CPU de la malla también se hace fuera del hilo de render.
- La malla del chunk que se acaba de minar se prioriza, y las mallas vecinas necesarias para bordes/diagonales se reconstruyen después. Los vecindarios de malla se reducen a 3x3 en vez de clonar el halo 5x5 completo por cada chunk objetivo.
- Se corrige la clasificación AO de `BlockGlass` (ID 20), vidrio tintado y otros tipos según `Material.blocksMovement() && Block.isFullCube()`. Esto separa correctamente `isFullCube`, `isOpaqueCube` y `lightOpacity`.
- La cola de propagación de luz solo recibe fuentes que pueden aumentar la iluminación de algún vecino; ya no procesa todos los bloques de cielo abierto que ya tienen nivel 15.
- Los buffers dinámicos de los drops se reutilizan para evitar asignaciones GPU repetidas.
- Hay pruebas de regresión para grietas/animación sostenida, clasificación AO, caras de agua al retirar un bloque vecino y slabs dobles/medios.

La iluminación vuelve a calcularse para el halo afectado, pero su propagación aún es una implementación acotada y aproximada; hay que comprobar si desaparecen los focos negros del mundo real. La carga y guardado Anvil siguen ocurriendo en un trabajador serial para evitar bloquear el hilo de la ventana.


## Corrección de compilación por ámbito del JAR v2.2.3.100

El reporte de Cargo de Windows mostró tres errores E0425 en `textured_chunk.rs`: el parámetro `jar` se usaba para resolver variantes de modelos dentro de `build_chunk_from_neighborhood`, pero no formaba parte de la firma de esa función.

La ruta del JAR ahora se propaga explícitamente desde `start_gameplay_block_edit_worker` a `process_gameplay_block_edit`, luego a `build_chunk_from_neighborhood`; el flujo normal `build_chunk_from_selected` también la transmite. Esto corrige las tres referencias fuera de ámbito y elimina el aviso `jar` sin usar que aparecía en el mismo código.

La corrección es de compilación y de cableado de dependencias; no modifica el algoritmo de malla ni promete resolver todavía los síntomas gráficos que deben validarse dentro del juego.


## v2.2.3.100 — respuesta inmediata de drops

Los drops se crean inmediatamente en el tick que rompe el bloque; ya no esperan a que termine el guardado Anvil, el recálculo de luz ni la reconstrucción de mallas. Cada drop provisional conserva la revisión de edición que lo originó. Mientras la escritura está pendiente, se puede ver en el mundo, pero no se puede recoger ni fusionar con otros stacks. Si el guardado falla, se elimina ese drop provisional y se restaura el bloque. En consola aparece la duración del trabajo de guardado/luz/malla en segundo plano.


## v2.2.3.103 — rotura instantánea y drops suavizados

Al terminar la última fase de grietas, el cliente elimina la geometría del bloque objetivo del búfer de chunk antes de la siguiente redibujada y crea el drop en el mismo tick. La reconstrucción asíncrona posterior actualiza las caras vecinas, el agua y la iluminación. Los drops ahora colisionan con paredes y formas de bloque, y su posición se interpola en cada frame de renderizado.

Para probar: mantén clic izquierdo sobre un bloque hasta completar las grietas; comprueba que el bloque desaparece y el objeto aparece en el mismo frame; prueba a lanzar un objeto contra una pared y observa que no la atraviese; mira el movimiento del objeto entre ticks. Cierra de forma segura para que los chunks dirty se guarden como en la fase anterior.

## v2.2.3.101 — guardado diferido del mundo

Al romper bloques, el estado se modifica en memoria y el trabajador de minado ya no reescribe archivos `.mca`. Los chunks afectados quedan marcados como pendientes de guardado. El programa realiza puntos de control cada cinco minutos y, al cerrar la ventana o salir con el segundo Escape, espera a que termine el guardado final antes de cerrar. Si falla el guardado final, la sesión permanece abierta para que puedas reintentar.

Esta fase persiste los bloques, metadatos, HeightMap y arrays de luz de los chunks modificados. Todavía no guarda el NBT del jugador/inventario ni las entidades de drops; no cierres esperando que esos datos sobrevivan a la sesión hasta que implementemos su persistencia específica. Mantén siempre una copia de seguridad de `New World` durante las pruebas.

## Audio y soltar objetos (v2.2.3.114)

- El JAR de cliente estándar no suele incluir los archivos `.ogg`. El BAT busca el almacén compartido `assets` de UltimMC y exporta su ruta al proceso Rust. El juego combina los índices JSON que encuentre y prioriza el índice de 1.8.
- Al entrar al mundo, revisa las líneas `[audio] default output device opened successfully`, `[audio] loaded ... OGG variants`, y `[audio] playable events`. Al minar/recoger verás `[audio] play request event=...`. Si faltan sonidos, copia esas líneas `[AUDIO]`/`[audio]`; indican si falla la ruta, el índice, la decodificación o la salida de audio.
- El pop de cada stack se limita a una superficie aislada de 16x16 píxeles. Mover stacks con el mouse/shift-click no activa el pop. Recoger, aumentar o gastar un stack sí lo activa.
- En el HUD, `Q` deja un objeto de la ranura seleccionada y `Ctrl+Q` deja el stack completo. En el inventario, se aplica al slot bajo el cursor si no llevas un objeto en el cursor.


## Corrección v2.2.3.115

La ruta Q/Ctrl+Q consulta el stack bajo el cursor mediante `InventoryUi::hovered_stack()`, manteniendo privado el índice interno del slot.


## Corrección v2.2.3.116

Al recoger cualquier entidad de objeto, el registro `[pickup] accepted ... -> random.pop` confirma que el stack entró realmente al inventario y que se solicitó el sonido. Los objetos soltados manualmente mantienen el retardo vanilla de 40 ticks (2 segundos a 20 TPS), por lo que el pop se escucha cuando ya se pueden recoger. Al soltar con Q o Ctrl+Q, el brazo inicia la animación de swing únicamente si el objeto se soltó correctamente.


## Corrección v2.2.3.117 — audio local y objetos planos

- Al abrir el primer mundo, el cliente extrae todos los OGG que aparecen en el índice de assets 1.8 de UltimMC a `runtime\audio\assets\minecraft\sounds`. También copia `sounds.json` cuando el índice lo contiene. En siguientes aperturas reutiliza esos archivos locales.
- El archivo `client.jar` de Minecraft 1.8.9 no contiene OGG ni `sounds.json`; por eso la extracción obtiene los OGG del almacén oficial `assets\objects` de UltimMC, siguiendo los hashes del índice. No se descargan sonidos de terceros.
- La consola indica cuántos OGG se copiaron, reutilizaron o no se encontraron.
- Los objetos generados (diamantes, lingotes, herramientas, comida, etc.) usan la escala efectiva de `RenderItem` en GROUND, cara trasera con UV invertidas y copias de stack centradas como `RenderEntityItem`. La malla de primera persona y los drops de bloques permanecen separados.


## Corrección v2.2.3.118 — sonido de recogida vanilla y cara trasera alineada

- El sonido `random.pop` sigue ahora el camino del cliente MCP `NetHandlerPlayClient.handleCollectItem`: se solicita después de insertar el objeto en el inventario, en la posición de la entidad recogida, con volumen 0.2 y el pitch original basado en dos `nextFloat()`.
- Los canales de Rodio permanecen propiedad del gestor de audio hasta que terminan de reproducirse; el log informa `queued=true/false` por cada recogida.
- Los drops manuales mantienen los 40 ticks de protección vanilla. El sonido no se reproduce al pulsar Q, sino cuando el objeto vuelve a entrar realmente al inventario.
- La cara trasera de los sprites planos usa ahora los mismos límites XY centrados (-0.5 a 0.5) que la cara frontal, conservando la inversión horizontal de UV que define `ItemModelGenerator`.

## v2.2.3.120 — arquitectura servidor/cliente (primera fase)

El movimiento del jugador ya se ejecuta en un servidor integrado independiente del hilo gráfico, con un paso fijo de 50 ms (20 TPS). El cliente envía las entradas y consume snapshots autoritativos. La física/collision del jugador se encuentra ahora en `mc189-server`, no en el módulo del renderizador.

Para inspeccionar el proceso dedicado y su protocolo TCP (todavía no conectado al menú/renderizador gráfico):

1. Cierra Java/UltimMC y ejecuta `INICIAR-SERVIDOR-MINECRAFT-RUST.bat`.
2. En otra ventana CMD ejecuta `PROBAR-CONEXION-SERVIDOR.bat`.
3. El probe debe recibir `welcome` y varios `player_snapshot` del servidor.

No abras simultáneamente el mismo mundo desde el cliente Java y el proceso dedicado. Esta primera fase no guarda cambios desde el servidor dedicado y aún no migra minería, inventario ni entidades al servidor. El single-player normal sigue usando el flujo gráfico existente para esas características, mientras movimiento/colisiones ya son simulados por el servidor integrado.


## v2.2.3.121 — servidor integrado y guardado automático

Para un mundo de un jugador, abre el juego normalmente y selecciona el mundo. El servidor local de 20 TPS y su servicio de guardado se inician automáticamente; no abras `INICIAR-SERVIDOR-MINECRAFT-RUST.bat`. Al salir, el juego espera a que terminen las ediciones pendientes y a que el servidor confirme el guardado final antes de cerrar. Si el guardado falla, el mundo permanece abierto para reintentar.

El BAT del servidor dedicado sigue disponible solo para pruebas separadas de red. Esta fase persiste chunks modificados y datos del inventario del jugador; todavía no incluye persistencia completa de entidades/drop items ni metadatos dinámicos de tiempo/clima.


## v2.2.3.122 — minería y cálculo de drops en el servidor integrado

- El cliente ya no acumula el progreso de minería. Envía únicamente la intención de mantener el ataque y el tipo de herramienta; el servidor integrado calcula su propio raycast de 4.5 bloques, lee el estado real del chunk y actualiza el progreso a 20 TPS.
- Al completar la rotura, el servidor captura el estado original, calcula el resultado de la tabla de drops y cambia el bloque a aire en su propio mundo en ese mismo tick.
- La respuesta del servidor contiene el bloque original, la posición objetivo y los drops calculados; el cliente utiliza esa respuesta para sonidos, animación, entidad visual y reconstrucción de iluminación/mesh.
- Las fórmulas de dureza, eficiencia, fatiga, agua, caída y requisito de herramienta, junto con la tabla de drops legacy, ahora viven en `mc189-server`. La app mantiene reexports temporales para no romper el código de presentación.

**Límite de esta etapa:** el tipo de herramienta todavía se deriva del inventario visible del cliente y se envía como intención; el inventario aún no es autoridad exclusiva del servidor. El movimiento, merge, pickup y persistencia de las entidades de objeto todavía siguen en el lado del cliente. El RNG del servidor se inicializa desde `RandomSeed`, pero aún no reproduce el estado histórico completo de `World.rand` de una partida vanilla. El servidor dedicado TCP todavía no recibe paquetes de minería; este paso está conectado al servidor integrado de singleplayer.
