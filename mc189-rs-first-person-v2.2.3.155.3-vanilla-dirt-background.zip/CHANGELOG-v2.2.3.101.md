# v2.2.3.101 — In-memory world edits and deferred persistence

## Changes

- Removed Anvil writes from the per-block edit worker. A break now updates the session's decoded chunk state; the edit worker validates the old block state, applies the new state, updates a local 3x3 light neighborhood, and prepares CPU mesh replacements.
- Added a session cache for edited chunks and light-neighbor snapshots so consecutive edits do not need to reload the same chunk data from disk.
- Added `DirtyChunkSnapshot` tracking with monotonically increasing edit revisions. Each accepted edit marks every returned chunk snapshot (including changed light neighbors) dirty.
- Added a serial background `WorldSaveWorker`, separate from the render loop and block-edit worker.
- Added `MutableChunk::apply_chunk_snapshot` to apply decoded block IDs, metadata, HeightMap, BlockLight, and SkyLight to the original NBT tree while preserving unrelated tags; air-only sections carrying propagated light are materialized and saved too.
- Added `save_mutable_chunks`, which groups dirty chunks by region and rewrites each affected `.mca` region once per checkpoint instead of once per mined block.
- Added a shared world I/O mutex across chunk streaming, edit-worker region reads, and the save worker to avoid reading an Anvil region while its replacement is being committed.
- Added a five-minute safety autosave checkpoint.
- Window close and the second Escape press now request graceful shutdown: stop input/mining, drain pending in-memory edits, save all remaining dirty chunk snapshots, and close only after final persistence is confirmed.
- A failed final save leaves the world session open and dirty data available for retry.
- Added storage tests for decoded snapshot application, air-only light sections, and a two-chunk batch targeting the same Anvil region.
- Updated the Windows launcher banner and project documentation.

## Persistence scope

This milestone persists modified chunk block states, metadata, HeightMap, BlockLight, and SkyLight. It does **not** yet persist player position/inventory NBT, dropped-item entities, world time/weather, or other dynamic entities. A full-world save contract is not claimed until those components are connected.

## Verification

- Static inspection confirms the gameplay block-edit path no longer calls `save_mutable_chunk` or `save_mutable_chunks`.
- ZIP archive integrity is checked during packaging.
- Cargo/rustc are not installed in the authoring environment, so Rust compilation and unit-test execution remain unverified here. The Windows play-test must run `EJECUTAR-PRUEBAS-RUST.bat` and `INICIAR-PRUEBA-MINECRAFT-RUST.bat` to validate compilation and runtime behavior.
