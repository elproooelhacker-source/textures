# v2.2.3.16 — dark-oak atlas compatibility and sugar-cane cutout

## Fixes

- Added runtime atlas compatibility aliases for the legacy dark-oak log model texture names `blocks/log_dark_oak.png` and `blocks/log_dark_oak_top.png`. They now resolve to the original Minecraft 1.8.9 atlas sprites `blocks/log_big_oak.png` and `blocks/log_big_oak_top.png` when the legacy-named entries are absent. This fixes streamed chunk mesh uploads without duplicating or altering Mojang textures.
- Routed the vanilla sugar-cane/reeds texture `assets/minecraft/textures/blocks/reeds.png` through the existing binary-alpha cutout vegetation pipeline. This uses replacement blending, depth writes, and back-face culling like other crossed plants, preventing coincident opposite-winding faces from z-fighting while preserving transparent texels.

## Regression coverage

- Added tests for both dark-oak side/top atlas aliases.
- Added `reeds.png` to the cutout classification regression test.

## Unchanged

- Water/lava geometry, flow rendering, animation scheduling, and transparency passes from v2.2.3.15 are unchanged.
- First-person arm, player movement/collision, world streaming, and read-only world access are unchanged.
