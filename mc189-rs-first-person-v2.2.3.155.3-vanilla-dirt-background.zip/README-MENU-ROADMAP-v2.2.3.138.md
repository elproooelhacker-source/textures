# Menú Minecraft Java 1.8.9 — v2.2.3.138

Esta versión amplía las pantallas del menú y conserva el trabajo de red anterior.

## Ya presente en esta entrega
- Splash de Mojang con fondo blanco y textura del `client.jar`.
- Menú principal con botones vanilla, estados hover/disabled y splash pulsante.
- Selector de mundos con iconos, selección y controles inferiores.
- Pantalla visual de creación de mundo.
- Lista multijugador con selección, añadir/editar, conexión directa, confirmación de borrado y recarga de lista.
- Persistencia de servidores en `servers-mc189-rust.json`.
- Sesión PLAY persistente y respuesta Keep Alive del trabajo previo.

## Siguiente trabajo para paridad real
1. Portar `GuiSelectWorld` por completo: doble clic, selección y estado de botones, renombrar, borrar con confirmación y recrear mundo.
2. Portar `GuiCreateWorld` y conectar creación real al escritor de mundos/generador, con nombre, seed, modo, estructuras, cheats y bonus chest.
3. Portar `GuiMultiplayer`/`ServerSelectionList`: pings, MOTD, latencia, icono de servidor, detección LAN y scroll vanilla.
4. Portar `GuiScreenAddServer`, `GuiScreenServerList`, `GuiConnecting` y pantallas de progreso con los mismos eventos de red.
5. Completar el panorama vanilla con framebuffer 256x256, 64 vistas 8x8, seis caras y blur exacto; el shader actual es una aproximación calculada.
6. Portar opciones, idioma, Realms y demás pantallas secundarias.

La interfaz visual de esta versión no equivale todavía a una implementación completa de todas las acciones vanilla. La generación de mundos y las acciones destructivas/renombrado del selector permanecen deshabilitadas deliberadamente para proteger los saves.
